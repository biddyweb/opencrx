/*
 Copyright (c) 2006, Dennis M. Sosnoski
 All rights reserved.

 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this
 list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
 this list of conditions and the following disclaimer in the documentation
 and/or other materials provided with the distribution.
 * Neither the name of JiBX nor the names of its contributors may be used
 to endorse or promote products derived from this software without specific
 prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package org.jibx.typeinfo;

/**
 * Simple holder for field information.
 *
 * @author Dennis M. Sosnoski
 */
public class FieldDescription
{
    /** Field name. */
    private final String m_name;
    
    /** Access flags. */
    private int m_accessFlags;
    
    /** Type description. */
    private TypeDescription m_type;
    
    /** Field documentation text. */
    private String m_javaDoc;

    /** Type signature. */
    private String m_signature;
    
    /**
     * Constructor with all values.
     * 
     * @param name
     * @param access access flags
     * @param type actual type description (<code>null</code> if unspecified)
     * @param sig type signature (<code>null</code> if none)
     * @param doc documentation string (<code>null</code> if none)
     */
    public FieldDescription(String name, int access, TypeDescription type,
        String sig, String doc) {
        m_name = name;
        m_accessFlags = access;
        m_type = type;
        m_javaDoc = doc;
        m_signature = sig;
    }
    
    /**
     * Constructor with only basic information.
     * 
     * @param name
     * @param access access flags
     * @param type actual type description (<code>null</code> if none)
     */
    public FieldDescription(String name, int access, TypeDescription type) {
        this(name, access, type, null, null);
    }
    
    /**
     * Get field name.
     * 
     * @return name
     */
    public String getName() {
        return m_name;
    }
    
    /**
     * Get access flags.
     * 
     * @return flags
     */
    public int getAccessFlags() {
        return m_accessFlags;
    }
    
    /**
     * Set access flags.
     *
     * @param flags
     */
    public void setAccessFlags(int flags) {
        m_accessFlags = flags;
    }
    
    /**
     * Get type description.
     * 
     * @return type (<code>null</code> if unspecified)
     */
    public TypeDescription getType() {
        return m_type;
    }
    
    /**
     * Set type.
     *
     * @param type (<code>null</code> if unspecified)
     */
    public void setType(TypeDescription type) {
        m_type = type;
    }
    
    /**
     * Get documentation text.
     * 
     * @return doc (<code>null</code> if none)
     */
    public String getJavaDoc() {
        return m_javaDoc;
    }
    
    /**
     * Set documentation text.
     * 
     * @param doc (<code>null</code> if none)
     */
    public void setJavaDoc(String doc) {
        m_javaDoc = doc;
    }

    /**
     * Get field type signature.
     * 
     * @return signature
     */
    public String getSignature() {
        return m_signature;
    }
    
    /**
     * Set field type signature.
     *
     * @param sig
     */
    public void setSignature(String sig) {
        m_signature = sig;
    }
}