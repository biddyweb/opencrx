/*
Copyright (c) 2006, Dennis M. Sosnoski
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 * Neither the name of JiBX nor the names of its contributors may be used
   to endorse or promote products derived from this software without specific
   prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package org.jibx.typeinfo;


/**
 * Type description for a class.
 */
public class ClassDescription extends TypeDescription
{
    /** Simple class name (without package). */
    private final String m_name;
    
    /** Package information. */
    private final PackageDescription m_package;
    
    /** Superclass (<code>null</code> only for <code>java.lang.Object</code>). */
    private ClassDescription m_superClass;
    
    /** Interfaces implemented directly (not inherited). */
    private ClassDescription[] m_interfaces;
    
    /** Fields defined in class. */
    private FieldDescription[] m_fields;
    
    /** Methods defined in class. */
    private MethodDescription[] m_methods;
    
    /** Class documentation text. */
    private String m_javaDoc;
    
    /**
     * Constructor.
     * 
     * @param name simple name of class
     * @param pack containing package
     */
    public ClassDescription(String name, PackageDescription pack) {
        super("L" + pack.getInternalPrefix() + '/' + name + ';');
        m_name = name;
        m_package = pack;
    }
    
    /**
     * Get class name in external form from descriptor.
     * 
     * @param dtor class descriptor
     * @return class name in external form
     */
    public static String nameFromDescriptor(String dtor) {
        if (dtor.length() < 3 || dtor.charAt(0) != 'L' ||
            dtor.charAt(dtor.length()-1) != ';') {
            throw new IllegalArgumentException
                ("Not a valid class descriptor: " + dtor);
        }
        return dtor.substring(1, dtor.length()-1).replace('/', '.');
    }
    
    //
    // Access methods
    
    /**
     * Get fields.
     *
     * @return fields
     */
    public FieldDescription[] getFields() {
        return m_fields;
    }

    /**
     * Set fields.
     *
     * @param fields
     */
    public void setFields(FieldDescription[] fields) {
        m_fields = fields;
    }

    /**
     * Get interfaces.
     *
     * @return interfaces
     */
    public ClassDescription[] getInterfaces() {
        return m_interfaces;
    }

    /**
     * Set interfaces.
     *
     * @param interfaces
     */
    public void setInterfaces(ClassDescription[] interfaces) {
        m_interfaces = interfaces;
    }

    /**
     * Get methods.
     *
     * @return methods
     */
    public MethodDescription[] getMethods() {
        return m_methods;
    }

    /**
     * Set methods.
     *
     * @param methods
     */
    public void setMethods(MethodDescription[] methods) {
        m_methods = methods;
    }

    /**
     * Get package.
     *
     * @return package
     */
    public PackageDescription getPackage() {
        return m_package;
    }

    /**
     * Get superclass.
     *
     * @return superclass
     */
    public ClassDescription getSuperClass() {
        return m_superClass;
    }
    
    /**
     * Set documentation text.
     * 
     * @param doc
     */
    public void setJavaDoc(String doc) {
        m_javaDoc = doc;
    }
    
    /**
     * Get documentation text.
     * 
     * @return doc
     */
    public String getJavaDoc() {
        return m_javaDoc;
    }
    
    //
    // Base class overrides
    
    /* (non-Javadoc)
     * @see org.jibx.typeinfo.TypeDescription#toString()
     */
    public String toString() {
        return m_package.getExternalPrefix() + '.' + m_name;
    }
}