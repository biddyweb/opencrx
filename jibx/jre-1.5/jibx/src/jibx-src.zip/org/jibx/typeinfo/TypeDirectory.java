/*
Copyright (c) 2006, Dennis M. Sosnoski
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 * Neither the name of JiBX nor the names of its contributors may be used
   to endorse or promote products derived from this software without specific
   prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package org.jibx.typeinfo;

import java.util.HashMap;

/**
 * Directory of class descriptions. This just provides basic registration and
 * lookup functions, with the capacity to chain to other directories.
 */
public class TypeDirectory
{
    /** Map from descriptor or signature to type for all defined types. */
    private HashMap m_typeMap;
    
    /**
     * Constructor. Initializes the type directory with descriptions of
     * primitive types.
     * 
     * @param loader binary class loader
     */
    public TypeDirectory() {
        m_typeMap = new HashMap();
    }
    
    /**
     * Add type description to type directory.
     * 
     * @param desc type description to add
     */
    public void addType(TypeDescription desc) {
        m_typeMap.put(desc.getDescriptor(), desc);
    }
    
    /**
     * Get description for type.
     * 
     * @param dtor type descriptor
     * @return type description
     */
    public TypeDescription getType(String dtor) {
        return (TypeDescription)m_typeMap.get(dtor);
    }
}