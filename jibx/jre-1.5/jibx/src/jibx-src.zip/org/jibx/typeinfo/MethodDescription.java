/*
Copyright (c) 2006, Dennis M. Sosnoski
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 * Neither the name of JiBX nor the names of its contributors may be used
   to endorse or promote products derived from this software without specific
   prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package org.jibx.typeinfo;

/**
 * Simple holder for method information.
 */
public class MethodDescription
{
    /** Method name. */
    private final String m_name;
    
    /** Access flags. */
    private int m_accessFlags;
    
    /** Method type description. */
    private TypeDescription m_resultType;
    
    /** Parameter type descriptions. */
    private TypeDescription[] m_parameterTypes;
    
    /** Method documentation text. */
    private String m_javaDoc;
    
    /** Method signature. */
    private String m_signature;
    
    /**
     * Constructor with all values.
     * 
     * @param name
     * @param access access flags
     * @param type result type description (<code>null</code> if unspecified)
     * @param params parameter type descriptions (<code>null</code> if
     * unspecified)
     * @param sig type signature (<code>null</code> if none)
     * @param doc documentation string (<code>null</code> if none)
     */
    public MethodDescription(String name, int access, TypeDescription type,
        TypeDescription[] params, String sig, String doc) {
        m_name = name;
        m_accessFlags = access;
        m_resultType = type;
        m_parameterTypes = params;
        m_signature = sig;
        m_javaDoc = doc;
    }
    
    /**
     * Constructor with only basic information.
     * 
     * @param name
     * @param access access flags
     * @param type result type description (<code>null</code> if none)
     * @param params parameter type descriptions (<code>null</code> if
     * unspecified)
     */
    public MethodDescription(String name, int access, TypeDescription type,
        TypeDescription[] params) {
        this(name, access, type, params, null, null);
    }
    
    /**
     * Get access flags.
     *
     * @return flags
     */
    public int getAccessFlags() {
        return m_accessFlags;
    }
    
    /**
     * Set access flags.
     *
     * @param flags
     */
    public void setAccessFlags(int flags) {
        m_accessFlags = flags;
    }
    
    /**
     * Get parameter types.
     *
     * @return types
     */
    public TypeDescription[] getParameterTypes() {
        return m_parameterTypes;
    }
    
    /**
     * Set parameter types.
     *
     * @param types
     */
    public void setParameterTypes(TypeDescription[] types) {
        m_parameterTypes = types;
    }
    
    /**
     * Get signature.
     *
     * @return signature
     */
    public String getSignature() {
        return m_signature;
    }
    
    /**
     * Set signature.
     *
     * @param signature
     */
    public void setSignature(String signature) {
        m_signature = signature;
    }
    
    /**
     * Get result type.
     *
     * @return type
     */
    public TypeDescription getResultType() {
        return m_resultType;
    }
    
    /**
     * Set result type.
     *
     * @param type
     */
    public void setResultType(TypeDescription type) {
        m_resultType = type;
    }
    
    /**
     * Get name.
     *
     * @return name
     */
    public String getName() {
        return m_name;
    }
    
    /**
     * Get documentation text.
     * 
     * @return doc
     */
    public String getJavaDoc() {
        return m_javaDoc;
    }
    
    /**
     * Set documentation text.
     * 
     * @param doc
     */
    public void setJavaDoc(String doc) {
        m_javaDoc = doc;
    }
}