/*
Copyright (c) 2006, Dennis M. Sosnoski
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 * Neither the name of JiBX nor the names of its contributors may be used
   to endorse or promote products derived from this software without specific
   prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package org.jibx.typeinfo;

/**
 * Descriptor for primitive "class". There's really nothing to record for a
 * primitive type except the name and the actual type, so that's all this does.
 */
public class PrimitiveTypeDescription extends TypeDescription
{
    public static final PrimitiveTypeDescription BOOLEAN_TYPE =
        new PrimitiveTypeDescription("Z", "boolean");
    public static final PrimitiveTypeDescription BYTE_TYPE =
        new PrimitiveTypeDescription("B", "byte");
    public static final PrimitiveTypeDescription CHAR_TYPE =
        new PrimitiveTypeDescription("C", "char");
    public static final PrimitiveTypeDescription DOUBLE_TYPE =
        new PrimitiveTypeDescription("D", "double");
    public static final PrimitiveTypeDescription FLOAT_TYPE =
        new PrimitiveTypeDescription("F", "float");
    public static final PrimitiveTypeDescription INT_TYPE =
        new PrimitiveTypeDescription("I", "int");
    public static final PrimitiveTypeDescription LONG_TYPE =
        new PrimitiveTypeDescription("J", "long");
    public static final PrimitiveTypeDescription SHORT_TYPE =
        new PrimitiveTypeDescription("S", "short");
    public static final PrimitiveTypeDescription VOID_TYPE =
        new PrimitiveTypeDescription("V", "void");
    
    /** Singleton instance of primitive type directory. */
    private static final TypeDirectory s_instance;
    static {
        s_instance = new TypeDirectory();
        s_instance.addType(BOOLEAN_TYPE);
        s_instance.addType(BYTE_TYPE);
        s_instance.addType(CHAR_TYPE);
        s_instance.addType(DOUBLE_TYPE);
        s_instance.addType(FLOAT_TYPE);
        s_instance.addType(INT_TYPE);
        s_instance.addType(LONG_TYPE);
        s_instance.addType(SHORT_TYPE);
        s_instance.addType(VOID_TYPE);
    }
    
    /** External name for type. */
    private final String m_externalName;
    
    /**
     * Internal constructor.
     * 
     * @param dtor descriptor
     * @param xname external name
     */
    private PrimitiveTypeDescription(String dtor, String xname) {
        super(dtor);
        m_externalName = xname;
    }
    
    //
    // Base class overrides
    
    /* (non-Javadoc)
     * @see org.jibx.typeinfo.TypeDescription#isPrimitive()
     */
    public boolean isPrimitive() {
        return true;
    }
    
    /* (non-Javadoc)
     * @see org.jibx.typeinfo.TypeDescription#toString()
     */
    public String toString() {
        return m_externalName;
    }
}