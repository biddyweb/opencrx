/**
 * 
 */
package org.jibx.binding.generator.analysis;

import java.util.ArrayList;
import java.util.HashSet;

import org.jibx.typeinfo.FieldDescription;
import org.jibx.typeinfo.MethodDescription;
import org.jibx.typeinfo.TypeDescription;

/**
 * Walk through a class description.
 */
public abstract class Datalyze
{
    private static void printDescription(TypeDescription basetype) {
        ArrayList<TypeDescription> refs = new ArrayList<TypeDescription>();
        HashSet<TypeDescription> dones = new HashSet<TypeDescription>();
        refs.add(basetype);
        for (int i = 0; i < refs.size(); i++) {
            TypeDescription ref = refs.get(i);
            System.out.println(ref + " fields:");
            FieldDescription[] fields = ref.getFields();
            for (int j = 0; j < fields.length; j++) {
                FieldDescription field = fields[j];
                TypeDescription ftype = field.getType();
                System.out.println(" " + field.getName() + " of type " + ftype);
                processType(ftype, refs, dones);
            }
            System.out.println(ref + " methods:");
            MethodDescription[] methods = ref.getMethods();
            for (int j = 0; j < methods.length; j++) {
                MethodDescription method = methods[j];
                TypeDescription mtype = method.getResultType();
                System.out.print(" " + method.getName() + "() of type " +
                    mtype);
                TypeDescription[] ptypes = method.getParameterTypes();
                if (ptypes.length > 0) {
                    System.out.println(" has parameter types:");
                    for (int k = 0; k < ptypes.length; k++) {
                        TypeDescription ptype = ptypes[k];
                        System.out.println("  " + ptype);
                        processType(ptype, refs, dones);
                    }
                } else {
                    System.out.println();
                }
            }
        }
    }

    /**
     * Process a type definition. If the type is an array type it is first
     * converted to the base item type. If the resulting type has not previously
     * been seen it is then added to the list of types referenced and to the set
     * of types seen.
     * 
     * @param desc type description
     * @param refs types referenced
     * @param dones types seen
     */
    private static void processType(TypeDescription desc, ArrayList<TypeDescription> refs, HashSet<TypeDescription> dones) {
        while (desc.isArray()) {
            desc = desc.getArrayItemType();
        }
        String fdtor = desc.getDescriptor();
        if (!dones.contains(desc) && !desc.isPrimitive() &&
            desc.getFields().length > 0 &&
            !fdtor.startsWith("Ljava/lang") &&
            !fdtor.startsWith("Ljava/io") &&
            !fdtor.startsWith("Lsun/")) {
            refs.add(desc);
            dones.add(desc);
        }
    }
    
    public static void main(String[] args) {
        BinaryClassLoader loader = new BinaryClassLoader();
        loader.addPaths(System.getProperty("java.class.path"));
        loader.addPaths(System.getProperty("sun.boot.class.path"));
        TypeDirectory tdir = new TypeDirectory(loader);
        TypeDescription desc = tdir.getTypeInstance("Lcom/sosnoski/generics/PathDirectory;");
        printDescription(desc);
    }
}