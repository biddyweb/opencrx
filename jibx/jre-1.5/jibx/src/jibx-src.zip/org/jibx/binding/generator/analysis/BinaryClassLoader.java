
package org.jibx.binding.generator.analysis;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.StringTokenizer;

/**
 * Binary class loader. This takes an ordered set of paths to be searched, then
 * loads requested binary classes from those paths.
 */
public class BinaryClassLoader
{
    private final ArrayList<String> m_bases;
    
    public BinaryClassLoader() {
        m_bases = new ArrayList<String>();
    }

    public void addPaths(String list) {
        StringTokenizer tkzr = new StringTokenizer(list, File.pathSeparator);
        while (tkzr.hasMoreTokens()) {
            File file = new File(tkzr.nextToken());
            String spec = null;
            if (file.isFile() && file.getName().toLowerCase().endsWith(".jar")) {
                spec = "jar:file://" + file.getAbsolutePath() + "!/";
            } else if (file.exists()) {
                spec = "file://" + file.getAbsolutePath();
                if (!spec.endsWith("/")) {
                    spec += '/';
                }
            }
            if (spec != null) {
                m_bases.add(spec);
            }
        }
    }
    
    public byte[] getBytes(String dtor) {
        String pname = nameFromDescriptor(dtor).replace('.', '/') + ".class";
        for (int i = 0; i < m_bases.size(); i++) {
            String base = (String)m_bases.get(i);
            try {
                URL url = new URL(base + pname);
                InputStream is = url.openStream();
                
                // read the entire content into byte array
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buff = new byte[1024];
                int length;
                while ((length = is.read(buff)) >= 0) {
                    bos.write(buff, 0, length);
                }
                return bos.toByteArray();
                
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (FileNotFoundException e) {
                // normal event when not found relative to current base
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        throw new IllegalArgumentException("Class not found: " + pname);
    }

    /**
     * Get class name in external form from descriptor.
     * 
     * @param dtor class descriptor
     * @return class name in external form
     */
    public static String nameFromDescriptor(String dtor) {
        if (dtor.length() < 3 || dtor.charAt(0) != 'L' ||
            dtor.charAt(dtor.length()-1) != ';') {
            throw new IllegalArgumentException
                ("Not a valid class descriptor: " + dtor);
        }
        return dtor.substring(1, dtor.length()-1).replace('/', '.');
    }
}