/**
 * 
 */
package org.jibx.binding.generator.analysis;

import java.util.HashMap;

import org.jibx.typeinfo.TypeDescription;
import org.objectweb.asm.signature.SignatureVisitor;

public class ClassSignatureVisitor extends EmptySignatureVisitor
{
    /** Type directory. */
    private final TypeDirectory m_typeDirectory;
    
    /** Map from type parameters to types. */
    private HashMap<String,TypeDescription> m_typeMap;
    
    /** Last formal parameter name seen. */
    private String m_lastName;
    
    /** Formal parameter bound seen flag. */
    private boolean m_isBounded;
    
    /**
     * Constructor.
     * 
     * @param tdir type directory
     * @param tmap type substitution map
     */
    public ClassSignatureVisitor(TypeDirectory tdir, HashMap<String,TypeDescription> tmap) {
        m_typeDirectory = tdir;
        m_typeMap = tmap;
    }
    
    public void visitFormalTypeParameter(String name) {
        m_typeMap.put(name,
            m_typeDirectory.getTypeInstance("Ljava/lang/Object;"));
        m_lastName = name;
    }

    public SignatureVisitor visitClassBound() {
        return new EmptySignatureVisitor() {
            public void visitClassType(String name) {
                m_typeMap.put(m_lastName,
                    m_typeDirectory.getTypeInstance("L" + name + ';'));
                m_isBounded = true;
            }
        };
    }

    public SignatureVisitor visitInterfaceBound() {
        return new EmptySignatureVisitor() {
            public void visitClassType(String name) {
                if (!m_isBounded) {
                    m_typeMap.put(m_lastName,
                        m_typeDirectory.getTypeInstance("L" + name + ';'));
                }
            }
        };
    }
}