/*
Copyright (c) 2005, Dennis M. Sosnoski
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 * Neither the name of JiBX nor the names of its contributors may be used
   to endorse or promote products derived from this software without specific
   prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package org.jibx.binding.schemaold;

import org.jibx.binding.util.StringArray;
import org.jibx.schema.elements.AnnotatedBase;
import org.jibx.schema.elements.IValidationContext;
import org.jibx.schema.validation.ValidationContext;

/**
 * localSimpleType definition.
 *
 * Created Jul 29, 2005
 * @author Dennis M. Sosnoski
 */
public class LocalSimpleType extends AnnotatedBase
{
    /** List of allowed attribute names (including "id" from base). */
    public static final StringArray s_allowedAttributes =
        new StringArray(new String[] { "id" });
    
    //
    // Instance data
    
    /** Element name. */
    private final String m_name;
    
    /** Base for type (restriction, list, or union). */
    private AnnotatedBase m_base;

    /**
     * Constructor.
     * 
     * @param name element name used for instance
     */
    public LocalSimpleType(String name) {
        m_name = name;
    }

    /**
     * Get base type.
     * 
     * @return base type
     */
    public AnnotatedBase getBase() {
        return m_base;
    }

    /**
     * Set base type.
     * 
     * @param base base type
     */
    public void setBase(AnnotatedBase base) {
        m_base = base;
    }
    
    //
    // Implementation methods
    
    /* (non-Javadoc)
     * @see org.jibx.binding.schema.ElementBase#name()
     */
    public String name() {
        return m_name;
    }
    
    //
    // Validation methods

    /* (non-Javadoc)
     * @see org.jibx.binding.schema.ComponentBase#prevalidate(org.jibx.binding.schema.types.IValidationContext)
     */
    public void prevalidate(ValidationContext vctx) {
        
        // check for valid base type
        // TODO: check type
        m_base.prevalidate(vctx);
        
        // continue with parent class prevalidation
        super.prevalidate(vctx);
    }

    /**
     * @return
     */
    public ISimpleType getTypeDefinition() {
        // TODO Auto-generated method stub
        return null;
    }
}