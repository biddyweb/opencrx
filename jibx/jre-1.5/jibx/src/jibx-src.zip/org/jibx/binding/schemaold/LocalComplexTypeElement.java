/*
Copyright (c) 2005, Dennis M. Sosnoski
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 * Neither the name of JiBX nor the names of its contributors may be used
   to endorse or promote products derived from this software without specific
   prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package org.jibx.binding.schemaold;

import java.util.ArrayList;

import org.jibx.binding.util.StringArray;
import org.jibx.runtime.EnumSet;
import org.jibx.runtime.IUnmarshallingContext;
import org.jibx.runtime.JiBXException;
import org.jibx.schema.elements.AnnotatedBase;
import org.jibx.schema.elements.AnnotationItem;
import org.jibx.schema.elements.IValidationContext;
import org.jibx.schema.validation.ValidationContext;

/**
 * Model component for &lt;complexType> element not a direct child of a
 * &lt;schema> or &lt;redefine> element. This defines a local complex type which
 * can only be used in context.
 * TODO: add support for restriction
 *
 * @author Dennis M. Sosnoski
 */
public class LocalComplexTypeElement extends AnnotatedBase
{
    /** List of allowed attribute names. */
    public static final StringArray s_allowedAttributes =
        new StringArray(new String[] { "mixed" },
        AnnotatedBase.s_allowedAttributes);
    
    //
    // Value set information
    
    public static final int ALL_FINAL = 0;
    public static final int LIST_FINAL = 1;
    public static final int RESTRICTION_FINAL = 2;
    public static final int UNION_FINAL = 3;
    
    public static final EnumSet s_finalValues = new EnumSet(ALL_FINAL,
        new String[] { "#all", "list", "restriction", "union"});
    
    //
    // Instance data
    
    /** "final" attribute value for element. */
    private String m_final;
    
    /** "final" attribute code for element. */
    private int m_finalCode;
    
    /** Base for type (SimpleContent/ComplexContentElement, or
     All/Choice/SequenceElement) */
    private AnnotatedBase m_content;
    
    /** Attribute definitions included in type. */
    private ArrayList m_attributes;
    
    //
    // Base class overrides

    /* (non-Javadoc)
     * @see org.jibx.binding.schema.ElementBase#name()
     */
    public String name() {
        return "complexType";
    }

    /* (non-Javadoc)
     * @see org.jibx.binding.schema.ElementBase#preset(org.jibx.runtime.IUnmarshallingContext)
     */
    protected void preset(IUnmarshallingContext ictx) throws JiBXException {
        validateAttributes(ictx, s_allowedAttributes);
        super.preset(ictx);
    }
    
    //
    // Accessor methods

    /**
     * Get "final" attribute value.
     * 
     * @return final attribute value
     */
    public String getFinal() {
        return m_final;
    }

    /**
     * Set "final" attribute value.
     * 
     * @param finl final attribute value
     */
    public void setFinal(String finl) {
        m_final = finl;
    }

    /**
     * Get "final" attribute code. This method is only usable after
     * prevalidation.
     * 
     * @return final attribute code
     */
    public int getFinalCode() {
        return m_finalCode;
    }

    /**
     * Get base type.
     * 
     * @return base type
     */
    public AnnotatedBase getContent() {
        return m_content;
    }

    /**
     * Set base type.
     * 
     * @param base base type
     */
    public void setContent(AnnotatedBase base) {
        m_content = base;
    }
    
    /**
     * Get attribute definitions.
     * 
     * @return annotation items list
     */
    public final ArrayList getAttributes() {
        return m_attributes;
    }
    
    /**
     * Clear attribute definitions.
     */
    public final void clearItems() {
        m_attributes.clear();
    }
    
    /**
     * Add attribute definition.
     * 
     * @param item annotation item
     */
    public final void addItem(AnnotationItem item) {
        m_attributes.add(item);
    }
    
    //
    // Validation methods
    
    /* (non-Javadoc)
     * @see org.jibx.binding.schema.ComponentBase#prevalidate(org.jibx.binding.schema.types.IValidationContext)
     */
    public void prevalidate(ValidationContext vctx) {
        
        // check for valid attribute values
        if (m_final == null) {
            m_finalCode = -1;
        } else {
            m_finalCode = s_finalValues.getValue(m_final);
            if (m_finalCode < 0) {
                vctx.addError("'final' attribute value " + m_final +
                    " is not allowed");
            }
        }
        
        // continue with parent class prevalidation
        super.prevalidate(vctx);
    }
}