/*
Copyright (c) 2005, Dennis M. Sosnoski
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 * Neither the name of JiBX nor the names of its contributors may be used
   to endorse or promote products derived from this software without specific
   prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package org.jibx.binding.schemaold;

import org.jibx.binding.util.StringArray;
import org.jibx.runtime.IUnmarshallingContext;
import org.jibx.runtime.JiBXException;
import org.jibx.runtime.QName;
import org.jibx.schema.elements.AnnotatedBase;
import org.jibx.schema.elements.FacetElement;
import org.jibx.schema.elements.IValidationContext;
import org.jibx.schema.validation.ValidationContext;

/**
 * &lt;restriction> element definition used for simple content.
 *
 * @author Dennis M. Sosnoski
 */
public class SimpleRestrictionElement extends SimpleTypeBase
{
    /** List of allowed attribute names. */
    public static final StringArray s_allowedAttributes =
        new StringArray(new String[] { "base" },
        AnnotatedBase.s_allowedAttributes);
    
    //
    // Instance data
    
    /** Mask for allowed facets. */
    private final int m_allowedFacetMask;
    
    /** 'base' attribute value for element. */
    private QName m_base;
    
    /** Inline type definition (<code>null</code> if no inline type). */
    private LocalSimpleType m_inlineType;
    
    /** Base type definition (referenced by "base" attribute, or defined
      inline). */
    private ISimpleType m_baseTypeDefinition;
    
    /** Facets applied by restriction. */
    private FacetElement[] m_facets;
    
    /**
     * Constructor.
     * 
     * @param mask bit mask for allowed facets
     */
    public SimpleRestrictionElement(int mask) {
        m_allowedFacetMask = mask;
    }
    
    //
    // Base class overrides

    /* (non-Javadoc)
     * @see org.jibx.binding.schema.ElementBase#name()
     */
    public String name() {
        return "restriction";
    }
    
    /* (non-Javadoc)
     * @see org.jibx.binding.schema.ElementBase#preset(org.jibx.runtime.IUnmarshallingContext)
     */
    protected void preset(IUnmarshallingContext ictx) throws JiBXException {
        validateAttributes(ictx, s_allowedAttributes);
        super.preset(ictx);
    }
    
    /* (non-Javadoc)
     * @see org.jibx.binding.schema.SimpleTypeBase#getRestrictionBaseType()
     */
    public ISimpleType getRestrictionBaseType() {
        return m_baseTypeDefinition;
    }

    /* (non-Javadoc)
     * @see org.jibx.binding.schema.SimpleTypeBase#getRestrictionFacets()
     */
    public FacetElement[] getRestrictionFacets() {
        return m_facets;
    }

    /* (non-Javadoc)
     * @see org.jibx.binding.schema.SimpleTypeBase#getTypeForm()
     */
    public int getTypeForm() {
        return ISimpleType.RESTRICTION_TYPE;
    }
    
    //
    // Accessor methods
    
    /**
     * Get 'base' attribute value.
     * 
     * @return attribute value, or <code>null</code> if none
     */
    public QName getBase() {
        return m_base;
    }

    /**
     * Set 'base' attribute value.
     * 
     * @param base attribute value, or <code>null</code> if none
     */
    public void setItemType(QName base) {
        m_base = base;
    }

    /**
     * Get inline definition.
     * 
     * @return inline definition, or <code>null</code> if none
     */
    public LocalSimpleType getInlineDefinition() {
        return m_inlineType;
    }

    /**
     * Set inline definition.
     * 
     * @param def inline definition, or <code>null</code> if none
     */
    public void setInlineDefinition(LocalSimpleType def) {
        m_inlineType = def;
    }

    /**
     * Get base type. This method is only usable after validation.
     * 
     * @return base type
     */
    public ISimpleType getBaseType() {
        return m_baseTypeDefinition;
    }
    
    /**
     * Set facets.
     * 
     * @param facet definitions
     */
    public void setRestrictionFacets(FacetElement[] facets) {
        m_facets = facets;
    }
    
    //
    // Validation methods

    /* (non-Javadoc)
     * @see org.jibx.binding.schema.ComponentBase#prevalidate(org.jibx.binding.schema.types.IValidationContext)
     */
    public void prevalidate(ValidationContext vctx) {
        
        // check for valid attribute value
        if (m_base == null) {
            
            // no attribute, so must have inline type
            if (m_inlineType == null) {
                vctx.addError("<restriction> must have 'base' attribute or inline definition");
            } else {
                
                // validate inline type definition
                m_inlineType.prevalidate(vctx);
                
            }
        } else {
            m_base.prevalidate(vctx);
        }
        
        // validate the set of facets used
        int bitsseen = 0;
        for (int i = 0; i < m_facets.length; i++) {
            
            // make sure facet is allowed
            FacetElement facet = m_facets[i];
            int mask = facet.getBitMask();
            if ((m_allowedFacetMask & mask) == 0) {
                vctx.addError("Facet '" + facet.name() +
                    "' is not allowed here");
            }
            
            // check for conflict with other facets
            int excludes = facet.getExcludesMask();
            if ((excludes & bitsseen) != 0) {
                
                // find the prior facets which caused conflicts
                for (int j = 0; j < i; j++) {
                    FacetElement prior = m_facets[j];
                    if ((prior.getBitMask() & excludes) != 0) {
                        vctx.addError("Facet '" + facet.name() +
                            "' cannot be used with '" + prior.name() + '\'');
                        excludes ^= prior.getBitMask();
                    }
                }
                
            }
        }
        
        // continue with parent class prevalidation
        super.prevalidate(vctx);
    }
    
    /* (non-Javadoc)
     * @see org.jibx.binding.schema.ComponentBase#validate(org.jibx.binding.schema.IValidationContext)
     */
    public void validate(IValidationContext vctx) {
        
        // resolve base type reference
        if (m_base == null) {
            m_inlineType.validate(vctx);
            m_baseTypeDefinition = m_inlineType.getTypeDefinition();
        } else {
            m_baseTypeDefinition = (ISimpleType)vctx.findComponent(m_base);
            if (m_baseTypeDefinition == null) {
                vctx.addError("No definition found for referenced base type " +
                    m_base);
            }
        }
        
        // continue with parent class validation
        super.validate(vctx);
    }
}