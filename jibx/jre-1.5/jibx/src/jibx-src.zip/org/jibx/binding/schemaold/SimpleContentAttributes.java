
package org.jibx.binding.schemaold;

import org.jibx.binding.util.StringArray;
import org.jibx.runtime.EnumSet;
import org.jibx.runtime.IUnmarshallingContext;
import org.jibx.runtime.JiBXException;
import org.jibx.runtime.QName;
import org.jibx.schema.ComponentBase;

/**
 * Attributes shared between <b>element</b> and <b>attribute</b> elements.
 * 
 * @author Dennis M. Sosnoski
 */
public class SimpleContentAttributes extends ComponentBase
{
    /** "default" attribute value. */
    private String m_default;
    
    /** "fixed" attribute value. */
    private String m_fixed;
    
    /** "form" attribute value. */
    private String m_form;
    
    /** "type" attribute value. */
    private QName m_type;
    
    /** Attribute inline type definition (SimpleType). */
    private LocalSimpleType m_inlineType;
    
    /** Simple type definition (post-validation). */
    private ISimpleType m_simpleType;
    
    //
    // Base class overrides
    
    /* (non-Javadoc)
     * @see org.jibx.binding.schema.ElementBase#name()
     */
    public String name() {
        return "attribute";
    }

    /* (non-Javadoc)
     * @see org.jibx.binding.schema.ElementBase#preset(org.jibx.runtime.IUnmarshallingContext)
     */
    protected void preset(IUnmarshallingContext ictx) throws JiBXException {
        validateAttributes(ictx, s_allowedAttributes);
    }
    
    //
    // Accessor methods

    /**
     * Get "default" attribute value.
     * 
     * @return default attribute value
     */
    public String getDefault() {
        return m_default;
    }

    /**
     * Set "default" attribute value.
     * 
     * @param dflt default attribute value
     */
    public void setDefault(String dflt) {
        m_default = dflt;
    }

    /**
     * Get "fixed" attribute value.
     * 
     * @return fixed attribute value
     */
    public String getFixed() {
        return m_fixed;
    }

    /**
     * Set "fixed" attribute value.
     * 
     * @param fixed fixed attribute value
     */
    public void setFixed(String fixed) {
        m_fixed = fixed;
    }

    /**
     * Get "form" attribute value.
     * 
     * @return form attribute value
     */
    public String getForm() {
        return m_form;
    }

    /**
     * Set "form" attribute value.
     * 
     * @param form form attribute value
     */
    public void setForm(String form) {
        m_form = form;
    }

    /**
     * Get "type" attribute value.
     * 
     * @return type attribute value
     */
    public QName getType() {
        return m_type;
    }

    /**
     * Set "type" attribute value.
     * 
     * @param type type attribute value
     */
    public void setType(QName type) {
        m_type = type;
    }

    /**
     * Get "use" attribute value.
     * 
     * @return use attribute value
     */
    public String getUse() {
        return m_use;
    }

    /**
     * Set "use" attribute value.
     * 
     * @param use use attribute value
     */
    public void setUse(String use) {
        m_use = use;
    }

    /**
     * Get "use" attribute code. This method is only usable after prevalidation.
     * 
     * @return use attribute code
     */
    public int getUseCode() {
        return m_useCode;
    }

    /**
     * Get inline simple type definition.
     * 
     * @return type definition
     */
    public LocalSimpleType getInlineType() {
        return m_inlineType;
    }

    /**
     * Set inline simple type definition.
     * 
     * @param type type definition
     */
    public void setInlineType(LocalSimpleType type) {
        m_inlineType = type;
    }
}