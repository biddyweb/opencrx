/**
 * 
 */
package org.jibx.binding.generator.analysis;

import java.lang.reflect.Modifier;
import java.util.HashMap;

import org.jibx.typeinfo.ArrayClassDescriptor;
import org.jibx.typeinfo.FieldDescription;
import org.jibx.typeinfo.PrimitiveTypeDescription;
import org.jibx.typeinfo.TypeDescription;
import org.objectweb.asm.signature.SignatureReader;

/**
 * Directory of class descriptions.
 */
public class TypeDirectory
{
    /** Source for binary class representations. */
    private final BinaryClassLoader m_loader;
    
    /** Field list for all arrays. */
    final FieldDescription[] m_arrayFields;
    
    /** Map from descriptor or signature to type for all non-generic types,
     *  including generics with substitutions. */
    private HashMap<String,TypeDescription> m_typeMap =
        new HashMap<String,TypeDescription>();
    
    /** Map from generic classes descriptor to generic class information. */
    private HashMap<String,GenericTemplate> m_templateMap =
        new HashMap<String,GenericTemplate>();
    
    /**
     * Constructor. Initializes the type directory with descriptions of
     * primitive types.
     * 
     * @param loader binary class loader
     */
    public TypeDirectory(BinaryClassLoader loader) {
        m_loader = loader;
        addType(PrimitiveTypeDescription.BOOLEAN_TYPE);
        addType(PrimitiveTypeDescription.BYTE_TYPE);
        addType(PrimitiveTypeDescription.CHAR_TYPE);
        addType(PrimitiveTypeDescription.DOUBLE_TYPE);
        addType(PrimitiveTypeDescription.FLOAT_TYPE);
        addType(PrimitiveTypeDescription.INT_TYPE);
        addType(PrimitiveTypeDescription.LONG_TYPE);
        addType(PrimitiveTypeDescription.SHORT_TYPE);
        addType(PrimitiveTypeDescription.VOID_TYPE);
        m_arrayFields = new FieldDescription[] {
            new GenericFieldDescription("int", Modifier.PUBLIC, null, PrimitiveTypeDescription.INT_TYPE)
        };
    }
    
    /**
     * Add type description to type directory.
     * 
     * @param desc type description to add
     */
    public void addType(TypeDescription desc) {
        m_typeMap.put(desc.getDescriptor(), desc);
    }
    
    /**
     * Add generic class to template directory.
     * 
     * @param tmpl generic template to add
     */
    public void addTemplate(GenericTemplate tmpl) {
        m_templateMap.put(tmpl.getDescriptor(), tmpl);
    }
    
    /**
     * Get description for type. The type may be a primitive, an array, or a
     * class. If the type is a generic class, it will be treated as though all
     * type variables used their lower bounds.
     * 
     * @param dtor type descriptor
     * @return type description
     */
    public TypeDescription getTypeInstance(String dtor) {
        
        // check for an existing description
        TypeDescription desc = m_typeMap.get(dtor);
        if (desc == null) {
            
            // new description needed - must be array or class
            if (dtor.charAt(0) == '[') {
                desc = new ArrayClassDescriptor(dtor,
                    getTypeInstance(dtor.substring(1)));
            } else {
                
                // parse binary class to build description
                byte[] byts = m_loader.getBytes(dtor);
                desc = new SimpleClassDescription(dtor, byts, this);
            }
        }
        return desc;
    }

    /**
     * Get template for generic class. The returned template needs to be
     * instantiated with specific parameter types in order to create a
     * class description.
     * 
     * @param dtor generic class descriptor
     * @return generic template
     */
    public GenericTemplate getGenericInstance(String dtor) {
        GenericTemplate gdesc = m_templateMap.get(dtor);
        if (gdesc == null) {
            byte[] byts = m_loader.getBytes(dtor);
            gdesc = new GenericTemplate(dtor, byts, this);
        }
        return gdesc;
    }
    
    /**
     * Get description for generic class with specific type substitutions.
     * 
     * @param dtor field descriptor (no type parameter information)
     * @param sig field signature with type substitutions
     * @param types actual types used for instance (values may be
     * <code>null</code> if no substitution defined)
     * @return type description
     */
    public TypeDescription getSignatureInstance(String dtor, String sig,
        TypeDescription[] types) {
        
        // first check for direct match on substituted signature
        TypeDescription desc = (TypeDescription)m_typeMap.get(sig);
        if (desc == null) {
            
            // no direct match, first handle array
            if (sig.charAt(0) == '[') {
                desc = new ArrayClassDescriptor(sig,
                    getSignatureInstance(dtor.substring(1), sig.substring(1), types));
            } else {
                
                // handle type substitution to generic version of class
                GenericTemplate gdesc = getGenericInstance(dtor);
                desc = gdesc.getParameterized(sig, types);
            }
        }
        return desc;
    }
    
    /**
     * Get description for signature with type mapping.
     * 
     * @param sig field signature for type variables
     * @param tmap type mapping for variables
     * @return type description
     */
    public TypeDescription getMappedSignatureInstance(String sig,
        HashMap<String,TypeDescription> tmap) {
        SignatureDecompositionVisitor vtor =
            new SignatureDecompositionVisitor(this, tmap);
        new SignatureReader(sig).acceptType(vtor);
        return vtor.getDescription();
    }
}