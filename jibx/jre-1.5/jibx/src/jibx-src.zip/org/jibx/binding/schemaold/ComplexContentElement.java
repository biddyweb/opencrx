/*
Copyright (c) 2005, Dennis M. Sosnoski
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 * Neither the name of JiBX nor the names of its contributors may be used
   to endorse or promote products derived from this software without specific
   prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package org.jibx.binding.schemaold;

import java.util.ArrayList;

import org.jibx.binding.util.StringArray;
import org.jibx.runtime.EnumSet;
import org.jibx.runtime.IUnmarshallingContext;
import org.jibx.runtime.JiBXException;
import org.jibx.schema.elements.AnnotatedBase;

/**
 * Content representation for a <b>complexContent</b> element. This is a wrapper
 * for either an <b>extension</b> element or a <b>restriction</b> element.
 *
 * @author Dennis M. Sosnoski
 */
public class ComplexContentElement extends AnnotatedBase
{
    /** Extension element content (<code>null</code> if not extension). */
    private ExtensionElement m_extension;
    
    /** Restriction element content (<code>null</code> if not restriction). */
    private ComplexRestrictionElement m_restriction;
    
    //
    // Base class overrides

    /* (non-Javadoc)
     * @see org.jibx.binding.schema.ElementBase#name()
     */
    public String name() {
        return "complexContent";
    }

    /* (non-Javadoc)
     * @see org.jibx.binding.schema.ElementBase#preset(org.jibx.runtime.IUnmarshallingContext)
     */
    protected void preset(IUnmarshallingContext ictx) throws JiBXException {
        validateAttributes(ictx, s_allowedAttributes);
        super.preset(ictx);
    }
    
    //
    // Accessor methods

    /**
     * Check for extension.
     * 
     * @return extension flag
     */
    public boolean isExtension() {
        return m_extension != null;
    }

    /**
     * Get extension.
     * 
     * @return extension definition
     * @throws IllegalStateException if not extension
     */
    public ExtensionElement getExtension() {
        if (m_extension == null) {
            throw new IllegalStateException("Not extension");
        } else {
            return m_extension;
        }
    }

    /**
     * Check for restriction.
     * 
     * @return restriction flag
     */
    public boolean isRestriction() {
        return m_restriction != null;
    }

    /**
     * Get restriction.
     * 
     * @return restriction definition
     * @throws IllegalStateException if not restriction
     */
    public ComplexRestrictionElement getRestriction() {
        if (m_restriction == null) {
            throw new IllegalStateException("Not restriction");
        } else {
            return m_restriction;
        }
    }
}