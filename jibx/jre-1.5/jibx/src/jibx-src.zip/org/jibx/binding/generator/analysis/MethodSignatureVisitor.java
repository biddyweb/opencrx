/**
 * 
 */
package org.jibx.binding.generator.analysis;

import java.util.ArrayList;
import java.util.HashMap;

import org.jibx.typeinfo.TypeDescription;
import org.objectweb.asm.signature.SignatureVisitor;

public class MethodSignatureVisitor extends EmptySignatureVisitor
{
    /** Type directory. */
    private final TypeDirectory m_typeDirectory;
    
    /** Passed-in map from type parameters to types. */
    private HashMap<String,TypeDescription> m_typeMap;
    
    /** Parameter type descriptions. */
    ArrayList<TypeDescription> m_parameterTypes =
        new ArrayList<TypeDescription>();
    
    /** Nested visitor for nested signatures. */
    private SignatureDecompositionVisitor m_nestedVisitor;
    
    /** Type parameter seen flag. */
    private boolean m_hasTypeParameter;
    
    /** Extended map from type parameters to types for this method. */
    private HashMap<String,TypeDescription> m_methodTypeMap;
    
    /** Last formal parameter name seen. */
    private String m_lastName;
    
    /** Formal parameter bound seen flag. */
    private boolean m_isBounded;
    
    /**
     * Constructor.
     * 
     * @param tdir type directory
     * @param tmap type substitution map
     */
    public MethodSignatureVisitor(TypeDirectory tdir, HashMap<String,TypeDescription> tmap) {
        m_typeDirectory = tdir;
        m_typeMap = tmap;
    }
    
    private HashMap<String,TypeDescription> getTypeMap() {
        if (m_hasTypeParameter) {
            return m_methodTypeMap;
        } else {
            return m_typeMap;
        }
    }
    
    private void checkParameter() {
        if (m_nestedVisitor == null) {
            m_nestedVisitor = new SignatureDecompositionVisitor
                (m_typeDirectory, getTypeMap());
        } else {
            m_parameterTypes.add(m_nestedVisitor.getDescription());
            m_nestedVisitor.reset();
        }
    }
    
    public void visitFormalTypeParameter(String name) {
        if (!m_hasTypeParameter) {
            if (m_typeMap == null) {
                m_methodTypeMap = new HashMap<String,TypeDescription>();
            } else {
                m_methodTypeMap =
                    new HashMap<String,TypeDescription>(m_typeMap);
            }
            m_hasTypeParameter = true;
        }
        m_methodTypeMap.put(name,
            m_typeDirectory.getTypeInstance("Ljava/lang/Object;"));
        m_lastName = name;
    }

    public SignatureVisitor visitClassBound() {
        return new EmptySignatureVisitor() {
            public void visitClassType(String name) {
                m_methodTypeMap.put(m_lastName,
                    m_typeDirectory.getTypeInstance("L" + name + ';'));
                m_isBounded = true;
            }
        };
    }

    public SignatureVisitor visitInterfaceBound() {
        return new EmptySignatureVisitor() {
            public void visitClassType(String name) {
                if (!m_isBounded) {
                    m_methodTypeMap.put(m_lastName,
                        m_typeDirectory.getTypeInstance("L" + name + ';'));
                }
            }
        };
    }
    
    public SignatureVisitor visitParameterType() {
        checkParameter();
        return m_nestedVisitor;
    }
    
    public SignatureVisitor visitReturnType() {
        checkParameter();
        return m_nestedVisitor;
    }

    public TypeDescription[] getParameterTypes() {
        return m_parameterTypes.toArray
            (new TypeDescription[m_parameterTypes.size()]);
    }
    
    public TypeDescription getReturnType() {
        return m_nestedVisitor.getDescription();
    }
}