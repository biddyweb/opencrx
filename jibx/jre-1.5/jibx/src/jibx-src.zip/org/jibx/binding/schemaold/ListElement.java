/*
Copyright (c) 2005, Dennis M. Sosnoski
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 * Neither the name of JiBX nor the names of its contributors may be used
   to endorse or promote products derived from this software without specific
   prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package org.jibx.binding.schemaold;

import org.jibx.binding.util.StringArray;
import org.jibx.runtime.IUnmarshallingContext;
import org.jibx.runtime.JiBXException;
import org.jibx.runtime.QName;
import org.jibx.schema.elements.AnnotatedBase;
import org.jibx.schema.elements.IValidationContext;
import org.jibx.schema.validation.ValidationContext;

/**
 * &lt;list&gt; element definition.
 *
 * @author Dennis M. Sosnoski
 */
public class ListElement extends SimpleTypeBase
{
    /** List of allowed attribute names. */
    public static final StringArray s_allowedAttributes =
        new StringArray(new String[] { "itemType" },
        AnnotatedBase.s_allowedAttributes);
    
    //
    // Instance data
    
    /** 'itemType' attribute value for element (<code>null</code> if inline
      type). */
    private QName m_itemType;
    
    /** Inline type definition (<code>null</code> if no inline type). */
    private LocalSimpleType m_inlineType;
    
    /** Item type definition (referenced by "itemType" attribute, or defined
      inline). */
    private ISimpleType m_itemTypeDefinition;
    
    //
    // Base class overrides

    /* (non-Javadoc)
     * @see org.jibx.binding.schema.ElementBase#name()
     */
    public String name() {
        return "list";
    }
    
    /* (non-Javadoc)
     * @see org.jibx.binding.schema.ElementBase#preset(org.jibx.runtime.IUnmarshallingContext)
     */
    protected void preset(IUnmarshallingContext ictx) throws JiBXException {
        validateAttributes(ictx, s_allowedAttributes);
        super.preset(ictx);
    }

    /* (non-Javadoc)
     * @see org.jibx.binding.schema.SimpleTypeBase#getListItemType()
     */
    public ISimpleType getListItemType() {
        return m_itemTypeDefinition;
    }
    
    /* (non-Javadoc)
     * @see org.jibx.binding.schema.SimpleTypeBase#getTypeForm()
     */
    public int getTypeForm() {
        return ISimpleType.LIST_TYPE;
    }
    
    //
    // Accessor methods
    
    /**
     * Get 'itemType' attribute value.
     * 
     * @return attribute value, or <code>null</code> if none
     */
    public QName getItemType() {
        return m_itemType;
    }

    /**
     * Set 'itemType' attribute value.
     * 
     * @param type attribute value, or <code>null</code> if none
     */
    public void setItemType(QName type) {
        m_itemType = type;
    }

    /**
     * Get inline definition.
     * 
     * @return inline definition, or <code>null</code> if none
     */
    public LocalSimpleType getInlineDefinition() {
        return m_inlineType;
    }

    /**
     * Set inline definition.
     * 
     * @param def inline definition, or <code>null</code> if none
     */
    public void setInlineDefinition(LocalSimpleType def) {
        m_inlineType = def;
    }
    
    //
    // Validation methods
    
    /* (non-Javadoc)
     * @see org.jibx.binding.schema.ComponentBase#prevalidate(org.jibx.binding.schema.types.IValidationContext)
     */
    public void prevalidate(ValidationContext vctx) {
        
        // check for valid attribute value
        if (m_itemType == null) {
            
            // no attribute, so must have inline type
            if (m_inlineType == null) {
                vctx.addError("<list> must have 'itemType' attribute or inline definition");
            } else {
                
                // validate inline type definition
                m_inlineType.prevalidate(vctx);
                
            }
        } else {
            m_itemType.prevalidate(vctx);
        }
        
        // continue with parent class prevalidation
        super.prevalidate(vctx);
    }
    
    /* (non-Javadoc)
     * @see org.jibx.binding.schema.ComponentBase#validate(org.jibx.binding.schema.IValidationContext)
     */
    public void validate(IValidationContext vctx) {
        
        // resolve base type reference
        if (m_itemType == null) {
            m_inlineType.validate(vctx);
            m_itemTypeDefinition = m_inlineType.getTypeDefinition();
        } else {
            m_itemTypeDefinition = (ISimpleType)vctx.findComponent(m_itemType);
            if (m_itemTypeDefinition == null) {
                vctx.addError("No definition found for referenced base type " +
                    m_itemType);
            }
        }
        
        // continue with parent class validation
        super.validate(vctx);
    }
}