
package org.jibx.binding.generator.analysis;

import org.objectweb.asm.signature.SignatureVisitor;

/**
 * Default implementation of an ASM signature visitor. This can be used as a
 * base class by subclasses which override only the methods of interest.
 */
public class EmptySignatureVisitor implements SignatureVisitor
{
    public void visitFormalTypeParameter(String name) {}

    public SignatureVisitor visitClassBound() {
        return new EmptySignatureVisitor();
    }

    public SignatureVisitor visitInterfaceBound() {
        return new EmptySignatureVisitor();
    }

    public SignatureVisitor visitSuperclass() {
        return new EmptySignatureVisitor();
    }

    public SignatureVisitor visitInterface() {
        return new EmptySignatureVisitor();
    }

    public SignatureVisitor visitParameterType() {
        return new EmptySignatureVisitor();
    }

    public SignatureVisitor visitReturnType() {
        return new EmptySignatureVisitor();
    }

    public SignatureVisitor visitExceptionType() {
        return new EmptySignatureVisitor();
    }

    public void visitBaseType(char desc) {}

    public void visitTypeVariable(String name) {}

    public SignatureVisitor visitArrayType() {
        return new EmptySignatureVisitor();
    }

    public void visitClassType(String name) {}

    public void visitInnerClassType(String name) {}

    public void visitTypeArgument() {}

    public SignatureVisitor visitTypeArgument(char wildcard) {
        return new EmptySignatureVisitor();
    }

    public void visitEnd() {}
}