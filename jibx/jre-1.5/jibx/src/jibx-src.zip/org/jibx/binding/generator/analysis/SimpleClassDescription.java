/**
 * 
 */
package org.jibx.binding.generator.analysis;

import java.util.ArrayList;
import java.util.HashMap;

import org.jibx.typeinfo.FieldDescription;
import org.jibx.typeinfo.MethodDescription;
import org.jibx.typeinfo.TypeDescription;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.commons.EmptyVisitor;
import org.objectweb.asm.signature.SignatureReader;

/**
 * Description for normal class. This is used for a class with no type
 * parameters, or with no types specified for the type parameters, or for
 * interfaces with or without type parameters. In the case of a class with no
 * types specified the class bounds are used for the type parameters, ignoring
 * any type parameters included in the class bounds.
 */
public class SimpleClassDescription extends TypeDescription
{
    private final String m_name;
    private final FieldDescription[] m_fields;
    private final MethodDescription[] m_methods;
    private final boolean m_isGeneric;
    
    public SimpleClassDescription(String dtor, byte[] byts, TypeDirectory dir) {
        super(dtor);
        m_name = BinaryClassLoader.nameFromDescriptor(dtor);
        dir.addType(this);
        DescriptionBuilderVisitor vtor = new DescriptionBuilderVisitor(dir);
        ClassReader creader = new ClassReader(byts);
        creader.accept(vtor, true);
        m_fields = vtor.getFields();
        m_methods = vtor.getMethods();
        m_isGeneric = vtor.isGeneric();
    }
    
    public FieldDescription[] getFields() {
        return m_fields;
    }
    
    public MethodDescription[] getMethods() {
        return m_methods;
    }

    public String toString() {
        return m_name;
    }
    
    public boolean isGeneric() {
        return m_isGeneric;
    }
    
    /**
     * Visitor for generating the description information for a simple class (a
     * non-generic class, or a generic class used without type substitution).
     * If the class is generic, the bounds information from the signature is
     * substituted for the type parameters.
     */
    public class DescriptionBuilderVisitor extends EmptyVisitor
    {
        /** Type directory. */
        private final TypeDirectory m_typeDirectory;
        
        /** Map from type parameters to types (lazy create, only if generic). */
        private HashMap<String,TypeDescription> m_typeMap;
        
        /** Fields found in processing class definition. */
        private ArrayList<GenericFieldDescription> m_fields;
        
        /** Methods found in processing class definition. */
        private ArrayList<MethodDescription> m_methods;
        
        private DescriptionBuilderVisitor(TypeDirectory dir) {
            m_typeDirectory = dir;
            m_fields = new ArrayList<GenericFieldDescription>();
            m_methods = new ArrayList<MethodDescription>();
        }
        
        public void visit(int version, int access, String name, String sig,
            String sname, String[] inames) {
            if (sig != null) {
                m_typeMap = new HashMap<String,TypeDescription>();
                new SignatureReader(sig).accept
                    (new ClassSignatureVisitor(m_typeDirectory, m_typeMap));
            }
        }

        public FieldVisitor visitField(int access, String name, String desc,
            String sig, Object value) {
            TypeDescription type;
            if (sig == null) {
                type = m_typeDirectory.getTypeInstance(desc);
            } else {
                type = m_typeDirectory.
                    getMappedSignatureInstance(sig, m_typeMap);
            }
            m_fields.add(new GenericFieldDescription(name, access, sig, type));
            return super.visitField(access, name, desc, sig, value);
        }
        
        public MethodVisitor visitMethod(int access, String name, String desc,
            String sig, String[] exceptions) {
            TypeDescription type;
            TypeDescription params[];
            if (sig == null) {
                ArrayList<TypeDescription> plist =
                    new ArrayList<TypeDescription>();
                int start = 1;
                char chr;
                while ((chr = desc.charAt(start)) != ')') {
                    int scan = start;
                    while (chr == '[') {
                        chr = desc.charAt(++scan);
                    }
                    int end;
                    if (chr == 'L') {
                        end = desc.indexOf(';', scan) + 1;
                    } else {
                        end = scan + 1;
                    }
                    String pdesc = desc.substring(start, end);
                    plist.add(m_typeDirectory.getTypeInstance(pdesc));
                    start = end;
                }
                params = new TypeDescription[plist.size()];
                params = plist.toArray(params);
                type = m_typeDirectory.getTypeInstance(desc.substring(start+1));
            } else {
                MethodSignatureVisitor vtor =
                    new MethodSignatureVisitor(m_typeDirectory, m_typeMap);
                new SignatureReader(sig).accept(vtor);
                params = vtor.getParameterTypes();
                type = vtor.getReturnType();
            }
            m_methods.add(new MethodDescription(name, access, sig, type,
                params));
            return super.visitMethod(access, name, desc, sig, exceptions);
        }

        public FieldDescription[] getFields() {
            return m_fields.toArray(new GenericFieldDescription[m_fields.size()]);
        }

        public MethodDescription[] getMethods() {
            return m_methods.toArray(new MethodDescription[m_methods.size()]);
        }
        
        public boolean isGeneric() {
            return m_typeMap != null;
        }
    }
}