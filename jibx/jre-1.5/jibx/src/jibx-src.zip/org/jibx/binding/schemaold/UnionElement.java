/*
Copyright (c) 2005, Dennis M. Sosnoski
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 * Neither the name of JiBX nor the names of its contributors may be used
   to endorse or promote products derived from this software without specific
   prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package org.jibx.binding.schemaold;

import org.jibx.binding.util.StringArray;
import org.jibx.runtime.IUnmarshallingContext;
import org.jibx.runtime.JiBXException;
import org.jibx.runtime.QName;
import org.jibx.schema.elements.AnnotatedBase;
import org.jibx.schema.elements.IValidationContext;
import org.jibx.schema.validation.ValidationContext;

/**
 * &lt;union&gt; element definition.
 *
 * @author Dennis M. Sosnoski
 */
public class UnionElement extends SimpleTypeBase
{
    /** List of allowed attribute names. */
    public static final StringArray s_allowedAttributes =
        new StringArray(new String[] { "memberTypes" },
        AnnotatedBase.s_allowedAttributes);
    
    //
    // Instance data
    
    /** 'memberTypes' attribute value for element (<code>null</code> if inline
      types). */
    private QName[] m_memberTypes;
    
    /** Inline type definitions (<code>null</code> if no inline type). */
    private LocalSimpleType[] m_inlineTypes;
    
    /** Member type definitions (referenced by "memberTypes" attribute, or
      defined inline). */
    private ISimpleType[] m_memberTypeDefinitions;
    
    //
    // Base class overrides
    
    /* (non-Javadoc)
     * @see org.jibx.binding.schema.ElementBase#name()
     */
    public String name() {
        return "union";
    }
    
    /* (non-Javadoc)
     * @see org.jibx.binding.schema.ElementBase#preset(org.jibx.runtime.IUnmarshallingContext)
     */
    protected void preset(IUnmarshallingContext ictx) throws JiBXException {
        validateAttributes(ictx, s_allowedAttributes);
        super.preset(ictx);
    }

    /* (non-Javadoc)
     * @see org.jibx.binding.schema.SimpleTypeBase#getTypeForm()
     */
    public int getTypeForm() {
        return ISimpleType.UNION_TYPE;
    }
    
    /* (non-Javadoc)
     * @see org.jibx.binding.schema.SimpleTypeBase#getUnionMemberTypes()
     */
    public ISimpleType[] getUnionMemberTypes() {
        return m_memberTypeDefinitions;
    }
    
    //
    // Accessor methods
    
    /**
     * Get 'memberTypes' attribute value.
     * 
     * @return attribute value, or <code>null</code> if none
     */
    public QName[] getMemberTypes() {
        return m_memberTypes;
    }

    /**
     * Set 'memberTypes' attribute value.
     * 
     * @param types attribute value, or <code>null</code> if none
     */
    public void setItemType(QName[] types) {
        m_memberTypes = types;
    }

    /**
     * Get inline type definitions.
     * 
     * @return inline definitions, or <code>null</code> if none
     */
    public LocalSimpleType[] getInlineTypes() {
        return m_inlineTypes;
    }

    /**
     * Set inline type definitions.
     * 
     * @param def inline definitions, or <code>null</code> if none
     */
    public void setInlineTypes(LocalSimpleType[] defs) {
        m_inlineTypes = defs;
    }
    
    //
    // Validation methods
    
    /* (non-Javadoc)
     * @see org.jibx.binding.schema.ComponentBase#prevalidate(org.jibx.binding.schema.types.IValidationContext)
     */
    public void prevalidate(ValidationContext vctx) {
        
        // check for valid attribute value
        if (m_memberTypes == null) {
            
            // no attribute, so must have inline types
            if (m_inlineTypes == null) {
                vctx.addError("<union> must have 'memberTypes' attribute or inline definitions");
            } else {
                
                // validate inline type definitions
                for (int i = 0; i < m_inlineTypes.length; i++) {
                    m_inlineTypes[i].prevalidate(vctx);
                }
                
            }
        } else {
            for (int i = 0; i < m_memberTypes.length; i++) {
                m_memberTypes[i].prevalidate(vctx);
            }
        }
        
        // continue with parent class prevalidation
        super.prevalidate(vctx);
    }
    
    /* (non-Javadoc)
     * @see org.jibx.binding.schema.ComponentBase#validate(org.jibx.binding.schema.IValidationContext)
     */
    public void validate(IValidationContext vctx) {
        
        // resolve base type reference
        if (m_memberTypes == null) {
            
            // validate inline type definitions
            m_memberTypeDefinitions = new ISimpleType[m_inlineTypes.length];
            for (int i = 0; i < m_inlineTypes.length; i++) {
                LocalSimpleType type = m_inlineTypes[i];
                type.validate(vctx);
                m_memberTypeDefinitions[i] = type.getTypeDefinition();
            }
            
        } else {
            
            // find definitions referenced by name
            m_memberTypeDefinitions = new ISimpleType[m_memberTypes.length];
            for (int i = 0; i < m_memberTypes.length; i++) {
                QName qname = m_memberTypes[i];
                ISimpleType type = (ISimpleType)vctx.findComponent(qname);
                if (type == null) {
                    vctx.addError("No definition found for referenced base type " +
                        qname);
                } else {
                    m_memberTypeDefinitions[i] = type;
                }
            }
        }
        
        // continue with parent class validation
        super.validate(vctx);
    }
}