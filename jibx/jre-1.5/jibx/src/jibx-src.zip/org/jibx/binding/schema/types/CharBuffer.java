/*
Copyright (c) 2005, Dennis M. Sosnoski
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 * Neither the name of JiBX nor the names of its contributors may be used
   to endorse or promote products derived from this software without specific
   prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package org.jibx.binding.schema.types;

/**
 * Character sequence buffer. This is used for a modifiable version of a
 * character sequence.
 * 
 * Created Jul 24, 2005
 * @author Dennis M. Sosnoski
 */
public class CharBuffer extends CharArraySequence
{
    /**
     * Constructor with only length specified.
     * 
     * @param length buffer length
     */
    public CharBuffer(int length) {
        super(new char[length], 0, 0);
    }
    
    /**
     * Append characters of sequence. This appends the specified characters of
     * the sequence to the buffer.
     * 
     * @param seq original character sequence
     * @param diff size difference from original sequence
     */
    public void append(ICharSequence seq, int start, int length) {
        int curlen = length();
        if (seq instanceof CharArraySequence) {
            CharArraySequence arsq = (CharArraySequence)seq;
            System.arraycopy(arsq.getArray(), arsq.getStart()+start,
                getArray(), getStart()+curlen, length);
        } else {
            char[] array = getArray();
            int fill = getStart() + curlen;
            for (int i = 0; i < length; i++) {
                array[fill+i] = seq.charAt(start+i);
            }
        }
        setLength(curlen+length);
    }
}