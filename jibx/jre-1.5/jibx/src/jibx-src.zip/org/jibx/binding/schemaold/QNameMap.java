/*
Copyright (c) 2005, Dennis M. Sosnoski
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 * Neither the name of JiBX nor the names of its contributors may be used
   to endorse or promote products derived from this software without specific
   prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package org.jibx.binding.schemaold;

import java.util.HashMap;

import org.jibx.runtime.QName;

/**
 * Lookup map for objects identified by qualified names. At the top level this
 * uses a map based on local names. Depending on the number of occurrances of a
 * local name in the map, the value in the top level map can be the actual
 * object, an array of objects, or a secondary hashmap where the key value is
 * the namespace URI.
 *
 * @author Dennis M. Sosnoski
 */
public class QNameMap
{
    /** Maximum size for array of values (before going to secondary map). */
    private static final int MAX_ARRAY_SIZE = 4;
    
	/** Map of items corresponding to local names. */
	protected HashMap m_nameMap;

	/**
	 * Constructor.
	 */
	public QNameMap() {
		m_nameMap = new HashMap();
	}

	/**
	 * Get object by name.
	 *
	 * @param name local name
	 * @param uri namespace URI
	 * @return object with that name, or <code>null</code> if none
	 */
	public QName get(String name, String uri) {
        Object value = m_nameMap.get(name);
        if (value instanceof QName) {
            QName item = (QName)value;
            if (item.getUri().equals(uri)) {
                return item;
            }
        } else if (value instanceof QName[]) {
            QName[] values = (QName[])value;
            for (int i = 0; i < values.length; i++) {
                if (values[i].getUri().equals(uri)) {
                    return values[i];
                }
            }
        } else if (value instanceof HashMap) {
            HashMap urimap = (HashMap)value;
            return (QName)urimap.get(uri);
        }
        return null;
	}

    /**
     * Get object by qname.
     *
     * @param qname qualified name
     * @return object with that name, or <code>null</code> if none
     */
    public QName get(QName qname) {
        return get(qname.getName(), qname.getUri());
    }

	/**
	 * Add object to known set.
	 *
	 * @param qname qualified name
     * @param obj named object
	 */
	public void add(QName qname, Object obj) {
        String name = qname.getName();
        String uri = qname.getUri();
        Object value = m_nameMap.get(name);
        if (value instanceof QName) {
            QName prior = (QName)value;
            if (prior.getUri().equals(uri)) {
                throw new IllegalArgumentException("Duplicate name " + qname);
            } else {
                QName[] values = new QName[2];
                values[0] = prior;
                values[1] = qname;
                m_nameMap.put(name, values);
            }
        } else if (value instanceof QName[]) {
            QName[] values = (QName[])value;
            for (int i = 0; i < values.length; i++) {
                if (values[i].getUri().equals(uri)) {
                    throw new IllegalArgumentException("Duplicate name " +
                        qname);
                }
            }
            if (values.length < MAX_ARRAY_SIZE) {
                QName[] grows = new QName[values.length+1];
                System.arraycopy(values, 0, grows, 0, values.length);
                grows[values.length] = qname;
                m_nameMap.put(name, values);
            } else {
                HashMap urimap = new HashMap();
                for (int i = 0; i < values.length; i++) {
                    QName prior = values[i];
                    urimap.put(prior.getUri(), prior);
                }
                urimap.put(uri, name);
                m_nameMap.put(name, urimap);
            }
        } else if (value instanceof HashMap) {
            HashMap urimap = (HashMap)value;
            if (urimap.containsKey(uri)) {
                throw new IllegalArgumentException("Duplicate name " + qname);
            } else {
                urimap.put(uri, name);
            }
        }
	}

	/**
	 * Empty the known set of names.
	 */
	public void clear() {
		m_nameMap.clear();
	}
}