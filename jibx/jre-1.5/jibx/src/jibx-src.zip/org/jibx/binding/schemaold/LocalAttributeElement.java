
package org.jibx.binding.schemaold;

import org.jibx.binding.util.StringArray;
import org.jibx.runtime.EnumSet;
import org.jibx.runtime.IUnmarshallingContext;
import org.jibx.runtime.JiBXException;
import org.jibx.runtime.QName;
import org.jibx.schema.elements.AnnotatedBase;

/**
 * Model component for <b>attribute</b> element not a direct child of the
 * <b>schema</b> element. This defines a local attribute which can only be used
 * in context.
 * 
 * @author Dennis M. Sosnoski
 */
public class LocalAttributeElement extends AnnotatedBase
{
    /** List of allowed attribute names. */
    public static final StringArray s_allowedAttributes =
        new StringArray(new String[] { "default", "fixed", "form", "type",
        "use" }, AnnotatedBase.s_allowedAttributes);
    
    //
    // Value set information
    
    public static final int PROHIBITED_USE = 0;
    public static final int OPTIONAL_USE = 1;
    public static final int REQUIRED_USE = 2;
    
    public static final EnumSet s_finalValues = new EnumSet(PROHIBITED_USE,
        new String[] { "prohibited", "optional", "required"});
    
    //
    // Instance data
    
    /** "default" attribute value. */
    private String m_default;
    
    /** "fixed" attribute value. */
    private String m_fixed;
    
    /** "form" attribute value. */
    private String m_form;
    
    /** "type" attribute value. */
    private QName m_type;
    
    /** "use" attribute value. */
    private String m_use;
    
    /** "use" attribute code. */
    private int m_useCode;
    
    /** Attribute inline type definition (SimpleType). */
    private LocalSimpleType m_inlineType;
    
    //
    // Base class overrides
    
    /* (non-Javadoc)
     * @see org.jibx.binding.schema.ElementBase#name()
     */
    public String name() {
        return "attribute";
    }

    /* (non-Javadoc)
     * @see org.jibx.binding.schema.ElementBase#preset(org.jibx.runtime.IUnmarshallingContext)
     */
    protected void preset(IUnmarshallingContext ictx) throws JiBXException {
        validateAttributes(ictx, s_allowedAttributes);
        super.preset(ictx);
    }
    
    //
    // Accessor methods

    /**
     * Get "default" attribute value.
     * 
     * @return default attribute value
     */
    public String getDefault() {
        return m_default;
    }

    /**
     * Set "default" attribute value.
     * 
     * @param dflt default attribute value
     */
    public void setDefault(String dflt) {
        m_default = dflt;
    }

    /**
     * Get "fixed" attribute value.
     * 
     * @return fixed attribute value
     */
    public String getFixed() {
        return m_fixed;
    }

    /**
     * Set "fixed" attribute value.
     * 
     * @param fixed fixed attribute value
     */
    public void setFixed(String fixed) {
        m_fixed = fixed;
    }

    /**
     * Get "form" attribute value.
     * 
     * @return form attribute value
     */
    public String getForm() {
        return m_form;
    }

    /**
     * Set "form" attribute value.
     * 
     * @param form form attribute value
     */
    public void setForm(String form) {
        m_form = form;
    }

    /**
     * Get "type" attribute value.
     * 
     * @return type attribute value
     */
    public QName getType() {
        return m_type;
    }

    /**
     * Set "type" attribute value.
     * 
     * @param type type attribute value
     */
    public void setType(QName type) {
        m_type = type;
    }

    /**
     * Get "use" attribute value.
     * 
     * @return use attribute value
     */
    public String getUse() {
        return m_use;
    }

    /**
     * Set "use" attribute value.
     * 
     * @param use use attribute value
     */
    public void setUse(String use) {
        m_use = use;
    }

    /**
     * Get "use" attribute code. This method is only usable after prevalidation.
     * 
     * @return use attribute code
     */
    public int getUseCode() {
        return m_useCode;
    }

    /**
     * Get inline simple type definition.
     * 
     * @return type definition
     */
    public LocalSimpleType getInlineType() {
        return m_inlineType;
    }

    /**
     * Set inline simple type definition.
     * 
     * @param type type definition
     */
    public void setInlineType(LocalSimpleType type) {
        m_inlineType = type;
    }
}