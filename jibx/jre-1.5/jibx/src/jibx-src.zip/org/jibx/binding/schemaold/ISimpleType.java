/*
Copyright (c) 2005, Dennis M. Sosnoski
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 * Neither the name of JiBX nor the names of its contributors may be used
   to endorse or promote products derived from this software without specific
   prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package org.jibx.binding.schemaold;

import org.jibx.runtime.QName;
import org.jibx.schema.elements.FacetElement;

/**
 * Representation of a simpleType definition. A simpleType is either a
 * predefined schema type, or defined by a &lt;restriction> element, a &lt;list>
 * element, or a &lt;union> element.
 *
 * @author Dennis M. Sosnoski
 */
public interface ISimpleType
{
    //
    // Different simple types forms
    static final int BASE_TYPE = 0;
    static final int LIST_TYPE = 1;
    static final int UNION_TYPE = 2;
    static final int RESTRICTION_TYPE = 3;
    
    /**
     * Get the form of this simple type.
     * 
     * @return code for form
     */
    int getTypeForm();
    
    /**
     * Get the type name.
     * 
     * @return type name, or <code>null</code> if none
     */
    QName getTypeName();
    
    /**
     * Get list item type.
     * 
     * @return list item type, or <code>null</code> if not a list type
     */
    ISimpleType getListItemType();
    
    /**
     * Get member types of union.
     * 
     * @return item types in union, or <code>null</code> if not a union type
     */
    ISimpleType[] getUnionMemberTypes();
    
    /**
     * Get base type for restriction.
     * 
     * @return base type for restriction, or <code>null</code> if not a
     * restriction
     */
    ISimpleType getRestrictionBaseType();
    
    /**
     * Get facets applied to restriction.
     * 
     * @return facets in restriction, or <code>null</code> if not a restriction
     * type
     */
    FacetElement[] getRestrictionFacets();
}