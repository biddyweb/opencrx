/**
 * 
 */
package org.jibx.binding.generator.analysis;

import java.util.ArrayList;
import java.util.HashMap;

import org.jibx.typeinfo.FieldDescription;
import org.jibx.typeinfo.MethodDescription;
import org.jibx.typeinfo.TypeDescription;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.commons.EmptyVisitor;
import org.objectweb.asm.signature.SignatureReader;
import org.objectweb.asm.signature.SignatureVisitor;

/**
 * Template for class with type parameters. An instance of this class is built
 * to represent the generic class. When a specific set of type substitutions is
 * defined for the generic class an instance of the inner 
 * {@link com.sosnoski.asm.GenericTemplate$ParameterizedClassDescription}
 * class is created to represent that specific version of the generic class.
 * 
 * Inner classes require some special handling, since they can use the parameter
 * types defined by outer classes.
 */
public class GenericTemplate
{
    private final String m_descriptor;
    private final String m_baseName;
    private final TypeDirectory m_typeDirectory;
    private final FieldDescription[] m_genericFields;
    private final MethodDescription[] m_genericMethods;
    private final String[] m_typeParameters;
    private final TypeDescription[] m_upperBounds;
    private final GenericTemplate m_outerClass;
    
    public GenericTemplate(String dtor, byte[] byts, TypeDirectory dir) {
        
        // add this description to type directory even before filled in
        m_descriptor = dtor;
        m_baseName = BinaryClassLoader.nameFromDescriptor(dtor);
        m_typeDirectory = dir;
        dir.addTemplate(this);
        
        // check for outer class information needed
        int split = dtor.lastIndexOf('$');
        if (split > 0) {
            m_outerClass = dir.getGenericInstance(dtor.substring(0, split) + ';');
        } else {
            m_outerClass = null;
        }
        
        // build the generic description for this class
        DescriptionBuilderVisitor vtor = new DescriptionBuilderVisitor(dir);
        ClassReader creader = new ClassReader(byts);
        creader.accept(vtor, true);
        m_genericFields = vtor.getFields();
        m_genericMethods = vtor.getMethods();
        m_typeParameters = vtor.getTypeParameters();
        m_upperBounds = vtor.getUpperBounds();
    }
    
    public String getDescriptor() {
        return m_descriptor;
    }
    
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        } else if (obj instanceof GenericTemplate) {
            return m_descriptor.equals(((GenericTemplate)obj).m_descriptor);
        } else {
            return false;
        }
    }
    
    public int hashCode() {
        return m_descriptor.hashCode();
    }
    
    /**
     * Get description for parameterized type with type substitutions.
     * 
     * @param sig signature including all type substitutions
     * @param types actual types used for instance (values may be
     * <code>null</code> if no substitution defined)
     * @param tdir type directory
     * @return substituted type description
     */
    public TypeDescription getParameterized(String sig,
        TypeDescription[] types) {
        return new ParameterizedClassDescription(sig, types);
    }
    
    /**
     * Visitor for generating the description information for a generic class.
     */
    public class DescriptionBuilderVisitor extends EmptyVisitor
    {
        private final TypeDirectory m_typeDirectory;
        private ArrayList<GenericFieldDescription> m_fields;
        private ArrayList<MethodDescription> m_methods;
        private ArrayList<String> m_typeParameters;
        private ArrayList<TypeDescription> m_upperBounds;
        
        private DescriptionBuilderVisitor(TypeDirectory dir) {
            m_typeDirectory = dir;
            m_fields = new ArrayList<GenericFieldDescription>();
            m_methods = new ArrayList<MethodDescription>();
            m_typeParameters = new ArrayList<String>();
            m_upperBounds = new ArrayList<TypeDescription>();
        }
        
        public void visit(int version, int access, String name, String sig,
            String sname, String[] inames) {
            if (sig != null) {
                new SignatureReader(sig).accept(new ClassSignatureVisitor());
            }
            super.visit(version, access, name, sig, sname, inames);
        }

        public FieldVisitor visitField(int access, String name, String desc,
            String sig, Object value) {
            TypeDescription type = null;
            if (sig == null) {
                type = m_typeDirectory.getTypeInstance(desc);
            }
            m_fields.add(new GenericFieldDescription(name, access, sig, type));
            return super.visitField(access, name, desc, sig, value);
        }
        
        public MethodVisitor visitMethod(int access, String name, String desc,
            String sig, String[] exceptions) {
            TypeDescription type = null;
            TypeDescription params[] = null;
            if (sig == null) {
                ArrayList<TypeDescription> plist =
                    new ArrayList<TypeDescription>();
                int start = 1;
                char chr;
                while ((chr = desc.charAt(start)) != ')') {
                    int scan = start;
                    while (chr == '[') {
                        chr = desc.charAt(++scan);
                    }
                    int end;
                    if (chr == 'L') {
                        end = desc.indexOf(';', scan) + 1;
                    } else {
                        end = scan + 1;
                    }
                    String pdesc = desc.substring(start, end);
                    plist.add(m_typeDirectory.getTypeInstance(pdesc));
                    start = end;
                }
                params = new TypeDescription[plist.size()];
                params = plist.toArray(params);
                type = m_typeDirectory.getTypeInstance(desc.substring(start+1));
            }
            m_methods.add(new MethodDescription(name, access, type,
                params, sig, null));
            return super.visitMethod(access, name, desc, sig, exceptions);
        }
        
        private FieldDescription[] getFields() {
            return m_fields.toArray(new GenericFieldDescription[m_fields.size()]);
        }
        
        private MethodDescription[] getMethods() {
            return m_methods.toArray(new MethodDescription[m_methods.size()]);
        }

        private String[] getTypeParameters() {
            return m_typeParameters.toArray(new String[m_typeParameters.size()]);
        }
        
        private TypeDescription[] getUpperBounds() {
            return m_upperBounds.toArray(new TypeDescription[m_upperBounds.size()]);
        }
        
        private class ClassSignatureVisitor extends EmptySignatureVisitor
        {
            private boolean m_isBounded;
            
            public void visitFormalTypeParameter(String name) {
                m_typeParameters.add(name);
                m_upperBounds.add(m_typeDirectory.getTypeInstance("Ljava/lang/Object;"));
            }

            public SignatureVisitor visitClassBound() {
                return new EmptySignatureVisitor() {
                    public void visitClassType(String name) {
                        m_upperBounds.set(m_upperBounds.size()-1,
                            m_typeDirectory.getTypeInstance("L" + name + ';'));
                        m_isBounded = true;
                    }
                };
            }

            public SignatureVisitor visitInterfaceBound() {
                return new EmptySignatureVisitor() {
                    public void visitClassType(String name) {
                        if (!m_isBounded) {
                            m_upperBounds.set(m_upperBounds.size()-1,
                                m_typeDirectory.getTypeInstance("L" + name + ';'));
                        }
                    }
                };
            }
        }
    }
    
    /**
     * Parameterized type description, with actual types substituted for all
     * type parameters. The actual substitution of type parameters into the
     * fields is done at the time of first use, in order to avoid issues with
     * recursive class references.
     */
    private class ParameterizedClassDescription extends TypeDescription
    {
        private final TypeDescription[] m_types;
        private final String m_name;
        private FieldDescription[] m_fields;
        private MethodDescription[] m_methods;
        
        /**
         * Constructor. This creates the description for a parameterized type
         * with type substitutions from the generic instance. This has to add
         * itself to the type directory during construction in order to handle
         * recursive references.
         * 
         * @param sig signature including all type substitutions
         * @param types actual types used for instance (values may be
         * <code>null</code> if no substitution defined)
         * @return substituted type description
         */
        public ParameterizedClassDescription(String sig, TypeDescription[] types) {
            super(sig);
            if (sig.startsWith("Lcom/sosnoski")) {
                System.out.println("Processing " + sig);
            }
            StringBuffer buff = new StringBuffer();
            buff.append(m_baseName);
            buff.append('<');
            for (int i = 0; i < types.length; i++) {
                if (i > 0) {
                    buff.append(',');
                }
                if (types[i] == null) {
                    buff.append('*');
                } else {
                    buff.append(types[i]);
                }
            }
            buff.append('>');
            m_name = buff.toString();
            m_types = types;
            m_typeDirectory.addType(this);
        }
        
        public FieldDescription[] getFields() {
            if (m_fields == null) {
                
                // make sure the number of parameter types is correct
                if (m_typeParameters.length != m_types.length) {
                    throw new IllegalArgumentException("Wrong number of parameter types");
                }
                
                // handle the actual type substitutions
                HashMap<String, TypeDescription> tmap = buildSubstitutionMap();
                m_fields = new FieldDescription[m_genericFields.length];
                for (int i = 0; i < m_genericFields.length; i++) {
                    FieldDescription field = m_genericFields[i];
                    if (field.getType() == null) {
                        TypeDescription desc =
                            m_typeDirectory.getMappedSignatureInstance(field.getSignature(), tmap);
                        m_fields[i] = new GenericFieldDescription(field.getName(),
                            field.getAccessFlags(), field.getSignature(), desc);
                    } else {
                        m_fields[i] = field;
                    }
                }
            }
            return m_fields;
        }

        /**
         * Build substitution map for type parameters.
         * 
         * @return substitution map
         */
        private HashMap<String, TypeDescription> buildSubstitutionMap() {
            HashMap<String,TypeDescription> tmap =
                new HashMap<String,TypeDescription>();
            for (int i = 0; i < m_typeParameters.length; i++) {
                TypeDescription type = m_types[i];
                if (type == null) {
                    type = m_upperBounds[i];
                }
                tmap.put(m_typeParameters[i], type);
            }
            return tmap;
        }
        
        private MethodDescription instantiateMethod(HashMap<String, TypeDescription> tmap, MethodDescription method) {
            MethodSignatureVisitor vtor =
                new MethodSignatureVisitor(m_typeDirectory, tmap);
            new SignatureReader(method.getSignature()).accept(vtor);
            return new MethodDescription(method.getName(),
                method.getAccessFlags(), vtor.getReturnType(),
                vtor.getParameterTypes(), method.getSignature(), null);
        }
        
        public MethodDescription[] getMethods() {
            if (m_methods == null) {
                
                // make sure the number of parameter types is correct
                if (m_typeParameters.length != m_types.length) {
                    throw new IllegalArgumentException("Wrong number of parameter types");
                }
                
                // handle the actual type substitutions
                HashMap<String, TypeDescription> tmap = buildSubstitutionMap();
                m_methods = new MethodDescription[m_genericMethods.length];
                for (int i = 0; i < m_genericMethods.length; i++) {
                    MethodDescription method = m_genericMethods[i];
                    if (method.getResultType() == null) {
                        m_methods[i] = instantiateMethod(tmap, method);
                    } else {
                        m_methods[i] = method;
                    }
                }
            }
            return m_methods;
        }
        
        public String toString() {
            return m_name;
        }
    }
}