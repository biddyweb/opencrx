package org.jibx.binding.generator.analysis;

import java.util.ArrayList;
import java.util.HashMap;

import org.jibx.typeinfo.TypeDescription;
import org.objectweb.asm.signature.SignatureVisitor;

/**
 * Visitor for processing a field signature with type substitutions. This uses
 * itself recursively to process nested signatures, substituting actual types
 * for any type variable references found.
 * 
 * TODO: This is not handling subclasses!
 */
public class SignatureDecompositionVisitor extends EmptySignatureVisitor
{
    private final TypeDirectory m_directory;
    private final HashMap<String,TypeDescription> m_parameterMap;
    private int m_arrayCount;
    private String m_className;
    private char m_baseClass;
    private ArrayList<TypeDescription> m_parameterTypes;
    private boolean m_isInner;
    private boolean m_isNested;
    private boolean m_isOpen;
    private SignatureDecompositionVisitor m_nestedVisitor;
    private StringBuffer m_descriptorBuffer;
    private StringBuffer m_extendedBuffer;
    
    public SignatureDecompositionVisitor(TypeDirectory tdir,
        HashMap<String,TypeDescription> tmap) {
        m_directory = tdir;
        m_parameterMap = tmap;
        m_parameterTypes = new ArrayList<TypeDescription>();
        m_descriptorBuffer = new StringBuffer();
        m_extendedBuffer = new StringBuffer();
    }
    
    public void reset() {
        m_arrayCount = 0;
        m_className = null;
        m_parameterTypes.clear();
        m_isNested = false;
        m_isOpen = false;
        m_descriptorBuffer.setLength(0);
        m_extendedBuffer.setLength(0);
    }
    
    private void checkParameter() {
        if (m_isNested) {
            m_parameterTypes.add(m_nestedVisitor.getDescription());
            m_isNested = false;
        }
    }

    /**
     * Update both normal (untyped) and extended descriptor for class. This is
     * used for both top-level classes and inner classes, with the latter just
     * appending to the previously-generated outer class descriptor.
     */
    private void appendDescriptors() {
        
        // construct basic object class descriptor
        String name = m_className;
        if (name == null) {
            name = Character.toString(m_baseClass);
        }
        m_descriptorBuffer.append(m_className);
        m_extendedBuffer.append(m_className);
        if (m_parameterTypes.size() > 0) {
            
            // include parameter types in extended descriptor format
            m_extendedBuffer.append('<');
            for (int i = 0; i < m_parameterTypes.size(); i++) {
                TypeDescription pdesc = m_parameterTypes.get(i);
                if (pdesc == null) {
                    m_extendedBuffer.append('*');
                } else {
                    m_extendedBuffer.append(pdesc.getDescriptor());
                }
            }
            m_extendedBuffer.append('>');
            
        }
    }
    
    private void endParameters() {
        if (m_isOpen) {
            
            // take care of trailing parameter
            checkParameter();
            if (m_isInner) {
                
                // append inner class descriptor to outer class descriptor
                m_descriptorBuffer.append("$");
                m_extendedBuffer.append('$');
                appendDescriptors();
                System.out.println("Generated inner class descriptors:");
                System.out.println(" " + m_descriptorBuffer);
                System.out.println(" " + m_extendedBuffer);
                
            } else {
                
                // create array signature prefix
                for (int i = 0; i < m_arrayCount; i++) {
                    m_descriptorBuffer.append('[');
                    m_extendedBuffer.append('[');
                }
                
                // handle primitive or object class description
                if (m_className == null) {
                    m_descriptorBuffer.append(m_baseClass);
                    m_extendedBuffer.append(m_baseClass);
                } else {
                    m_descriptorBuffer.append('L');
                    m_extendedBuffer.append('L');
                    appendDescriptors();
                }
            }
            m_isOpen = false;
        }
    }

    public SignatureVisitor visitArrayType() {
        m_arrayCount++;
        m_isOpen = true;
        return this;
    }
    
    public void visitBaseType(char desc) {
        m_baseClass = desc;
        m_isOpen = true;
    }
    
    public void visitTypeVariable(String name) {
        TypeDescription desc = m_parameterMap.get(name);
        if (desc == null) {
            System.out.println("Missing");
        }
        String dtor = m_parameterMap.get(name).getDescriptor();
        if (dtor == null) {
            throw new IllegalStateException("Undefined type variable " + name);
        } else if (dtor.length() < 3 || dtor.charAt(0) != 'L' ||
            dtor.charAt(dtor.length()-1) != ';') {
            throw new IllegalArgumentException
                ("Not a valid class descriptor: " + dtor);
        } else {
            m_className = dtor.substring(1, dtor.length()-1);
            m_isOpen = true;
        }
    }
    
    public void visitClassType(String name) {
        m_className = name;
        m_isOpen = true;
    }
    
    public SignatureVisitor visitTypeArgument(char wildcard) {
        checkParameter();
        if (wildcard == '=' || wildcard == '+') {
            if (m_nestedVisitor == null) {
                m_nestedVisitor = new SignatureDecompositionVisitor(m_directory,
                    m_parameterMap);
            } else {
                m_nestedVisitor.reset();
            }
            m_isNested = true;
            return m_nestedVisitor;
        } else {
            m_parameterTypes.add(null);
            return new EmptySignatureVisitor();
        }
    }
    
    public void visitTypeArgument() {
        checkParameter();
        m_parameterTypes.add(null);
    }
    
    public void visitInnerClassType(String name) {
        endParameters();
        m_isInner = true;
    }
    
    public void visitEnd() {
        endParameters();
    }
    
    public TypeDescription getDescription() {
        
        // get the actual type description
        endParameters();
        if (m_parameterTypes.size() == 0) {
            if (m_className != null) {
                m_descriptorBuffer.append(';');
            }
            return m_directory.getTypeInstance(m_descriptorBuffer.toString());
        } else {
            TypeDescription[] ptypes =
                new TypeDescription[m_parameterTypes.size()];
            ptypes = m_parameterTypes.toArray(ptypes);
            if (m_className != null) {
                m_descriptorBuffer.append(';');
                m_extendedBuffer.append(';');
            }
            return m_directory.getSignatureInstance
                (m_descriptorBuffer.toString(), m_extendedBuffer.toString(),
                ptypes);
        }
    }
}