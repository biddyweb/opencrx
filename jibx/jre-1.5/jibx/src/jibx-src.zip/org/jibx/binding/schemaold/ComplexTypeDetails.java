/*
Copyright (c) 2005, Dennis M. Sosnoski
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 * Neither the name of JiBX nor the names of its contributors may be used
   to endorse or promote products derived from this software without specific
   prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package org.jibx.binding.schemaold;

import java.util.ArrayList;

import org.jibx.binding.util.StringArray;
import org.jibx.runtime.EnumSet;
import org.jibx.runtime.IUnmarshallingContext;
import org.jibx.runtime.JiBXException;
import org.jibx.schema.ComponentBase;
import org.jibx.schema.elements.CommonCompositorDefinition;

/**
 * Details of a complex type definition. This is used by both global and local
 * complex type definitions.
 *
 * @author Dennis M. Sosnoski
 */
public class ComplexTypeDetails extends ComponentBase
{
    /** Simple content definition (<code>null</code> if not simple content). */
    private SimpleContentElement m_simpleContent;
    
    /** Complex content definition (<code>null</code> if not complex
      content). */
    private ComplexContentElement m_complexContent;
    
    /** Model group definition (<code>null</code> if not model group). */
    private CommonCompositorDefinition m_contentModel;
    
    /** Attribute definitions included in type. */
    private ArrayList m_attributes;
    
    //
    // Accessor methods

    /**
     * Check for simple content.
     * 
     * @return simple content flag
     */
    public boolean isSimpleContent() {
        return m_simpleContent != null;
    }

    /**
     * Get simple content.
     * 
     * @return simple content definition
     * @throws IllegalStateException if not simple content
     */
    public SimpleContentElement getSimpleContent() {
        if (m_simpleContent == null) {
            throw new IllegalStateException("Not simple content");
        } else {
            return m_simpleContent;
        }
    }

    /**
     * Set simple content.
     * 
     * @param cont simple content definition
     */
    public void setSimpleContent(SimpleContentElement cont) {
        m_simpleContent = cont;
        m_complexContent = null;
        m_modelGroup = null;
    }

    /**
     * Check for complex content.
     * 
     * @return complex content flag
     */
    public boolean isComplexContent() {
        return m_complexContent != null;
    }

    /**
     * Get complex content.
     * 
     * @return complex content definition
     * @throws IllegalStateException if not complex content
     */
    public ComplexContentElement getComplexContent() {
        if (m_complexContent == null) {
            throw new IllegalStateException("Not complex content");
        } else {
            return m_complexContent;
        }
    }

    /**
     * Set complex content.
     * 
     * @param cont complex content definition
     */
    public void setComplexContent(ComplexContentElement cont) {
        m_complexContent = cont;
        m_simpleContent = null;
        m_modelGroup = null;
    }

    /**
     * Check for model group.
     * 
     * @return model group flag
     */
    public boolean isModelGroup() {
        return m_modelGroup != null;
    }

    /**
     * Get model group.
     * 
     * @return model group definition
     * @throws IllegalStateException if not model group
     */
    public CommonCompositorDefinition getContentModel() {
        if (m_modelGroup == null) {
            throw new IllegalStateException("Not model group");
        } else {
            return m_modelGroup;
        }
    }

    /**
     * Set model group.
     * 
     * @param mgrp model group definition
     */
    public void setContentModel(CommonCompositorDefinition cont) {
        m_modelGroup = cont;
        m_complexContent = null;
        m_simpleContent = null;
    }
    
    /**
     * Get attribute declarations.
     * 
     * @return attribute declarations list
     */
    public final ArrayList getAttributes() {
        return m_attributes;
    }
    
    /**
     * Clear attribute declarations.
     */
    public final void clearAttributes() {
        m_attributes.clear();
    }
    
    /**
     * Add attribute declaration.
     * 
     * @param attr attribute declaration
     */
    public final void addAttribute(AttributeElement attr) {
        m_attributes.add(attr);
    }
}