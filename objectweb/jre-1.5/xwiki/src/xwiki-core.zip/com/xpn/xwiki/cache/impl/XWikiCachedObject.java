package com.xpn.xwiki.cache.impl;

public interface XWikiCachedObject {
    public void finalize() throws Throwable;
}
