/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 */

package com.xpn.xwiki.objects.classes;

import java.util.List;
import java.util.Map;

import org.apache.ecs.xhtml.input;

import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.objects.BaseCollection;
import com.xpn.xwiki.objects.BaseProperty;
import com.xpn.xwiki.objects.StringProperty;
import com.xpn.xwiki.objects.meta.PropertyMetaClass;
import com.xpn.xwiki.plugin.query.XWikiCriteria;
import com.xpn.xwiki.plugin.query.XWikiQuery;

public class StringClass extends PropertyClass
{

    public StringClass(String name, String prettyname, PropertyMetaClass wclass)
    {
        super(name, prettyname, wclass);
        setSize(30);
    }

    public StringClass(PropertyMetaClass wclass)
    {
        this("string", "String", wclass);
    }

    public StringClass()
    {
        this(null);
    }

    public int getSize()
    {
        return getIntValue("size");
    }

    public void setSize(int size)
    {
        setIntValue("size", size);
    }

    public BaseProperty fromString(String value)
    {
        BaseProperty property = newProperty();
        property.setValue(value);
        return property;
    }

    public BaseProperty newProperty()
    {
        BaseProperty property = new StringProperty();
        property.setName(getName());
        return property;
    }

    public void displayEdit(StringBuffer buffer, String name, String prefix,
        BaseCollection object, XWikiContext context)
    {
        input input = new input();
        BaseProperty prop = (BaseProperty) object.safeget(name);
        if (prop != null) {
            input.setValue(prop.toFormString());
        }

        input.setType("text");
        input.setName(prefix + name);
        input.setID(prefix + name);
        input.setSize(getSize());
        buffer.append(input.toString());
    }

    public void displaySearch(StringBuffer buffer, String name, String prefix,
        XWikiCriteria criteria, XWikiContext context)
    {
        input input = new input();
        input.setType("text");
        input.setName(prefix + name);
        input.setID(prefix + name);
        input.setSize(getSize());
        String fieldFullName = getFieldFullName();
        Object value = criteria.getParameter(fieldFullName);
        if (value != null) {
            input.setValue(value.toString());
        }
        buffer.append(input.toString());
    }

    public void makeQuery(Map map, String prefix, XWikiCriteria query, List criteriaList)
    {
        String value = (String) map.get(prefix);
        if ((value != null) && (!value.equals(""))) {
            String startsWith = (String) map.get(prefix + "startswith");
            String endsWith = (String) map.get(prefix + "endswith");
            if ("1".equals(startsWith)) {
                criteriaList.add("jcr:like(@xp:" + getName() + ", '" + value + "%')");
            } else if ("1".equals(endsWith)) {
                criteriaList.add("jcr:like(@xp:" + getName() + ", '%" + value + "')");
            } else {
                criteriaList.add("jcr:like(@xp:" + getName() + ", '%" + value + "%')");
            }
            return;
        }

        value = (String) map.get(prefix + "exact");
        if ((value != null) && (!value.equals(""))) {
            criteriaList.add("@xp:" + getName() + "='" + value + "'");
            return;
        }

        value = (String) map.get(prefix + "not");
        if ((value != null) && (!value.equals(""))) {
            criteriaList.add("@xp:" + getName() + "!='" + value + "'");
            return;
        }
    }

    public void fromSearchMap(XWikiQuery query, Map map)
    {
        String[] data = (String[]) map.get("");
        if ((data != null) && (data.length == 1)) {
            query.setParam(getObject().getName() + "_" + getName(), data[0]);
        }
    }

}
