/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/

package org.bedework.calsvci;

import org.bedework.calfacade.BwAlarm;
import org.bedework.calfacade.BwCalendar;
import org.bedework.calfacade.BwCategory;
import org.bedework.calfacade.BwDateTime;
import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.BwEventProxy;
import org.bedework.calfacade.BwLocation;
import org.bedework.calfacade.BwContact;
import org.bedework.calfacade.BwStats;
import org.bedework.calfacade.BwString;
import org.bedework.calfacade.BwSystem;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.BwUserInfo;
import org.bedework.calfacade.RecurringRetrievalMode;
import org.bedework.calfacade.BwStats.StatsEntry;
import org.bedework.calfacade.base.BwDbentity;
import org.bedework.calfacade.base.BwShareableDbentity;
import org.bedework.calfacade.base.UpdateFromTimeZonesInfo;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.filter.BwFilter;
import org.bedework.calfacade.ifs.Directories;
import org.bedework.calfacade.mail.MailerIntf;
import org.bedework.calfacade.svc.BwAdminGroup;
import org.bedework.calfacade.svc.BwCalSuite;
import org.bedework.calfacade.svc.BwSubscription;
import org.bedework.calfacade.svc.BwView;
import org.bedework.calfacade.svc.EventInfo;
import org.bedework.calfacade.svc.UserAuth;
import org.bedework.calfacade.svc.prefs.BwPreferences;
import org.bedework.calfacade.svc.wrappers.BwCalSuiteWrapper;
import org.bedework.calfacade.syncml.BwSynchInfo;
import org.bedework.calfacade.syncml.BwSynchState;
import org.bedework.calfacade.timezones.CalTimezones;
import org.bedework.calfacade.util.CalFacadeUtil;
import org.bedework.calfacade.util.ChangeTable;
import org.bedework.icalendar.IcalCallback;

import edu.rpi.cct.misc.indexing.SearchLimits;
import edu.rpi.cct.uwcal.resources.Resources;
import edu.rpi.cmt.access.Ace;
import edu.rpi.cmt.access.AceWho;
import edu.rpi.cmt.access.Acl.CurrentAccess;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import net.fortuna.ical4j.model.component.VTimeZone;
import net.fortuna.ical4j.model.TimeZone;

/** This is the service interface to the calendar suite. This will be
 * used by web applications and web services as well as other applications
 * which wish to integrate calendar actions into their interface.
 *
 * <p>This is a high level interface which carries out commonly used
 * calendar operations which may involve a number of interactions with the
 * underlying database implementation.
 *
 * <p>Within the bedework system events and todos are treated identically. An
 * entity type field defines which is what and allows filtering based on type
 * of entity. Explicit calls to fetch an event always return the addressed
 * object which may be an event or a todo.
 *
 * <p>Calls for collections of event objects may include filters to specify
 * which type of entity is desired.
 *
 * @author Mike Douglass       douglm@rpi.edu
 */
public abstract class CalSvcI implements Serializable {
  /** (Re)initialise the object for a particular use.
   *
   * @param pars        Defines the global parameters for the object
   * @throws CalFacadeException
   */
  public abstract void init(CalSvcIPars pars) throws CalFacadeException;

  /** Called after init to flag this user as a super user.
   *
   * @param val       true for a super user
   * @throws CalFacadeException
   */
  public abstract void setSuperUser(boolean val) throws CalFacadeException;

  /** Called after init to flag this user as a super user.
   *
   * @return boolean true if super user
   */
  public abstract boolean getSuperUser();

  /** Get the current stats
   *
   * @return BwStats object
   * @throws CalFacadeException if not admin
   */
  public abstract BwStats getStats() throws CalFacadeException;

  /** Enable/disable db statistics
   *
   * @param enable       boolean true to turn on db statistics collection
   * @throws CalFacadeException if not admin
   */
  public abstract void setDbStatsEnabled(boolean enable) throws CalFacadeException;

  /**
   *
   * @return boolean true if statistics collection enabled
   * @throws CalFacadeException if not admin
   */
  public abstract boolean getDbStatsEnabled() throws CalFacadeException;

  /** Dump db statistics
   *
   * @throws CalFacadeException if not admin
   */
  public abstract void dumpDbStats() throws CalFacadeException;

  /** Get db statistics
   *
   * @return Collection of BwStats.StatsEntry objects
   * @throws CalFacadeException if not admin
   */
  public abstract Collection<StatsEntry> getDbStats() throws CalFacadeException;

  /** Get the system pars
   *
   * @return BwSystem object
   * @throws CalFacadeException if not admin
   */
  public abstract BwSystem getSyspars() throws CalFacadeException;

  /** Update the system pars
   *
   * @param val BwSystem object
   * @throws CalFacadeException if not admin
   */
  public abstract void updateSyspars(BwSystem val) throws CalFacadeException;

  /** Log the current stats
   *
   * @throws CalFacadeException if not admin
   */
  public abstract void logStats() throws CalFacadeException;

  /** Flush any backend data we may be hanging on to ready for a new
   * sequence of interactions. This is intended to help with web based
   * applications, especially those which follow the action/render url
   * pattern used in portlets.
   *
   * <p>A flushAll can discard a back end session allowing open to get a
   * fresh one. close() can then be either a no-op or something like a
   * hibernate disconnect.
   *
   * <p>This method should be called before calling open (or after calling
   * close).
   *
   * @throws CalFacadeException
   */
  public abstract void flushAll() throws CalFacadeException;

  /** Signal the start of a sequence of operations. These overlap transactions
   * in that there may be 0 to many transactions started and ended within an
   * open/close call and many open/close calls within a transaction.
   *
   * <p>The open close methods are mainly associated with web style requests
   * and open will usually be called early in the incoming request handling
   * and close will always be called on the way out allowing the interface an
   * opportunity to reacquire (on open) and release (on close) any resources
   * such as connections.
   *
   * @throws CalFacadeException
   */
  public abstract void open() throws CalFacadeException;

  /**
   * @return boolean true if open
   */
  public abstract boolean isOpen();

  /** Call on the way out after handling a request..
   *
   * @throws CalFacadeException
   */
  public abstract void close() throws CalFacadeException;

  /** Start a (possibly long-running) transaction. In the web environment
   * this might do nothing. The endTransaction method should in some way
   * check version numbers to detect concurrent updates and fail with an
   * exception.
   *
   * @throws CalFacadeException
   */
  public abstract void beginTransaction() throws CalFacadeException;

  /** End a (possibly long-running) transaction. In the web environment
   * this should in some way check version numbers to detect concurrent updates
   * and fail with an exception.
   *
   * @throws CalFacadeException
   */
  public abstract void endTransaction() throws CalFacadeException;

  /** Call if there has been an error during an update process.
   *
   * @throws CalFacadeException
   */
  public abstract void rollbackTransaction() throws CalFacadeException;

  /** Call to reassociate an entity with the current database session
   *
   * @param val
   * @throws CalFacadeException
   */
  public abstract void reAttach(BwDbentity val) throws CalFacadeException;

  /**
   * @return IcalCallback for ical
   */
  public abstract IcalCallback getIcalCallback();

  /** Return a string valued calendar environment property
   *
   * @param name
   * @return String property value
   * @throws CalFacadeException
   */
  public abstract String getEnvProperty(String name) throws CalFacadeException;

  /** Get the set of internationalized resources for this session
   *
   * @return Resources
   */
  public abstract Resources getResources();

  /** Get a name uniquely.identifying this system. This should take the form <br/>
   *   name@host
   * <br/>where<ul>
   * <li>name identifies the particular calendar system at the site</li>
   * <li>host part identifies the domain of the site.</li>..
   * </ul>
   *
   * @return String    globally unique system identifier.
   * @throws CalFacadeException
   */
  public abstract String getSysid() throws CalFacadeException;

  /** Return true if we believe a refresh is required. After a return of
   * true this method will return false until somebody updates the db.
   *
   * @return boolean    time to refresh
   * @throws CalFacadeException
   */
  public abstract boolean refreshNeeded() throws CalFacadeException;

  /* ====================================================================
   *                   Factory methods
   * ==================================================================== */

  /** Get currently configured mailer.
   *
   * @return MailerIntf object of class in config
   * @throws CalFacadeException
   */
  public abstract MailerIntf getMailer() throws CalFacadeException;

  /** Get an object which implements scheduling methods.
   *
   * @return SchedulingI object
   * @throws CalFacadeException
   */
  public abstract SchedulingI getScheduler() throws CalFacadeException;

  /** Return an object to handle directory information. This will be the default
   * object for the current usage, i.e. admin or user.
   *
   * @return Directories
   * @throws CalFacadeException
   */
  public abstract Directories getDirectories() throws CalFacadeException;

  /** Get a Groups object for non-admin users.
   *
   * @return Groups    implementation.
   * @throws CalFacadeException
   */
  public abstract Directories getUserDirectories() throws CalFacadeException;

  /** Get a Groups object for administrators. This allows the admin client to
   * display or manipulate administrator groups.
   *
   * @return Groups    implementation.
   * @throws CalFacadeException
   */
  public abstract Directories getAdminDirectories() throws CalFacadeException;

  /* ====================================================================
   *                   Users and accounts
   * ==================================================================== */

  /** Returns a value object representing the current user.
   *
   * @return BwUser       representing the current user
   * @throws CalFacadeException
   */
  public abstract BwUser getUser() throws CalFacadeException;

  /** Switch to the given non-null user. The access rights are determined by
   * the previous call to init.
   *
   * @param val         String user id
   * @throws CalFacadeException
   */
  public abstract void setUser(String val) throws CalFacadeException;

  /** Find the user with the given account name..
   *
   * @param val         String user id
   * @param create      If true create user entry if it doesn't exist
   * @return BwUser       representing the user
   * @throws CalFacadeException
   */
  public abstract BwUser findUser(String val, boolean create) throws CalFacadeException;

  /** Add an entry for the user.
   *
   * @param user
   * @throws CalFacadeException
   */
  public abstract void addUser(BwUser user) throws CalFacadeException;

  /** Returns a Collection of instance owners.
   *
   * @return Collection    of BwUser
   * @throws CalFacadeException
   */
  public abstract Collection<BwUser> getInstanceOwners() throws CalFacadeException;

  /** Get a UserAuth object which allows the application to determine what
   * special rights the user has.
   *
   * <p>Note that the returned object may require a one time initialisation
   * call to set it up correctly.
   * @see org.bedework.calfacade.svc.UserAuth#initialise(String, UserAuth.CallBack, int, boolean)
   * @see org.bedework.calfacade.svc.UserAuth#initialise(String, UserAuth.CallBack, Object, boolean)
   *
   * @param user         String account name
   * @param par          parameter object
   * @return UserAuth    implementation.
   * @throws CalFacadeException
   */
  public abstract UserAuth getUserAuth(String user, Object par)
      throws CalFacadeException;

  /** Get an initialised UserAuth object
   *
   * @return UserAuth    implementation.
   * @throws CalFacadeException
   */
  public abstract UserAuth getUserAuth() throws CalFacadeException;

  /** Return some sort of directory information for the given user
   *
   * @param account         String account name
   * @return BwUserInfo     directory information.
   * @throws CalFacadeException
   */
 public abstract BwUserInfo getDirInfo(String account)
     throws CalFacadeException;

  /* ====================================================================
   *                   Preferences
   * ==================================================================== */

  /** Returns the current user preferences.
   *
   * @return BwPreferences   prefs for the current user
   * @throws CalFacadeException
   */
  public abstract BwPreferences getUserPrefs() throws CalFacadeException;

  /** Returns the given user preferences.
   *
   * @param user
   * @return BwPreferences   prefs for the given user
   * @throws CalFacadeException
   */
  public abstract BwPreferences getUserPrefs(BwUser user) throws CalFacadeException;

  /** Update the current user preferences.
   *
   * @param  val     BwPreferences prefs for the current user
   * @throws CalFacadeException
   */
  public abstract void updateUserPrefs(BwPreferences val) throws CalFacadeException;

  /** Update preferred entity lists
   *
   * @param remove - true if removing object
   * @param cal
   * @param cat
   * @param loc
   * @param contact
   * @throws CalFacadeException
   */
  public abstract void updatePrefs(boolean remove,
                                   BwCalendar cal,
                                   BwCategory cat,
                                   BwLocation loc,
                                   BwContact contact) throws CalFacadeException;

  /* ====================================================================
   *                   Access
   * ==================================================================== */

  /** Change the access to the given calendar entity.
   *
   * @param ent      BwShareableDbentity
   * @param aces     Collection of ace
   * @param replaceAll true to replace the entire access list.
   * @throws CalFacadeException
   */
 public abstract void changeAccess(BwShareableDbentity ent,
                                   Collection<Ace> aces,
                                   boolean replaceAll) throws CalFacadeException;

 /** Remove any explicit access for the given who to the given calendar entity.
  *
  * @param ent      BwShareableDbentity
  * @param who      AceWho
  * @throws CalFacadeException
  */
 public abstract void defaultAccess(BwShareableDbentity ent,
                                    AceWho who) throws CalFacadeException;

 /** Check the access for the given entity. Returns the current access
  * or null or optionally throws a no access exception.
  *
  * @param ent
  * @param desiredAccess
  * @param returnResult
  * @return CurrentAccess
  * @throws CalFacadeException if returnResult false and no access
  */
 public abstract CurrentAccess checkAccess(BwShareableDbentity ent,
                                           int desiredAccess,
                                           boolean returnResult)
         throws CalFacadeException;

  /* ====================================================================
   *                   Timezones
   * ==================================================================== */

 /** Get the timezones cache object
  *
  * @return CalTimezones object
  * @throws CalFacadeException if not admin
  */
 public abstract CalTimezones getTimezones() throws CalFacadeException;

  /** Save a timezone definition in the database. The timezone is in the
   * form of a complete calendar definition containing a single VTimeZone
   * object.
   *
   * <p>The calendar must be on a path from a timezone root
   *
   * @param tzid
   * @param timezone
   * @throws CalFacadeException
   */
  public abstract void saveTimeZone(String tzid, VTimeZone timezone)
        throws CalFacadeException;

  /** Register a timezone object in the current session.
   *
   * @param id
   * @param timezone
   * @throws CalFacadeException
   */
  public abstract void registerTimeZone(String id, TimeZone timezone)
      throws CalFacadeException;

  /** Get a timezone object given the id. This will return transient objects
   * registered in the timezone directory
   *
   * @param id
   * @param tzowner
   * @return TimeZone with id or null
   * @throws CalFacadeException
   */
  public abstract TimeZone getTimeZone(final String id,
                                       BwUser tzowner) throws CalFacadeException;

  /** Find a timezone object in the database given the id. This bypasses
   * the directory.
   *
   * @param id
   * @param owner     event owner or null for current user
   * @return VTimeZone with id or null
   * @throws CalFacadeException
   */
  public abstract VTimeZone findTimeZone(final String id, BwUser owner) throws CalFacadeException;

  /** Clear all public timezone objects
   *
   * <p>Will remove all public timezones in preparation for a replacement
   * (presumably)
   *
   * @throws CalFacadeException
   */
  public abstract void clearPublicTimezones() throws CalFacadeException;

  /** Refresh the public timezone table - presumably after a call to clearPublicTimezones.
   * and many calls to saveTimeZone.
   *
   * @throws CalFacadeException
   */
  public abstract void refreshTimezones() throws CalFacadeException;

  /** Get all of timezone ids.
   *
   * @return List  of TimeZoneInfo
   * @throws CalFacadeException
   */
  public abstract List getTimeZoneIds() throws CalFacadeException;

  /** Update the system after changes to timezones. This is a lengthy process
   * so the method allows the caller to specify how many updates are to take place
   * before returning.
   *
   * <p>To restart the update, call the method again, giving it the result from
   * the last call as a parameter.
   *
   * <p>If called again after all events have been checked the process will be
   * redone using timestamps to limit the check to events added or updated since
   * the first check. Keep calling until the number of updated events is zero.
   *
   * @param limit   -1 for no limit
   * @param checkOnly  don't update if true.
   * @param info    null on first call, returned object from previous calls.
   * @return UpdateFromTimeZonesInfo staus of the update
   * @throws CalFacadeException
   */
  public abstract UpdateFromTimeZonesInfo updateFromTimeZones(int limit,
                                                     boolean checkOnly,
                                                     UpdateFromTimeZonesInfo info
                                                     ) throws CalFacadeException;

  /* ====================================================================
   *                   Calendar suites
   * ==================================================================== */

  /** Create a new calendar suite
   *
   * @param  val       BwCalSuite calendar suite object
   * @return BwCalSuiteWrapper for new object
   * @throws CalFacadeException
   */
  public abstract BwCalSuiteWrapper addCalSuite(BwCalSuite val) throws CalFacadeException;

  /** Get the current calendar suite
   *
   * @return BwCalSuiteWrapper null for unknown calendar suite
   * @throws CalFacadeException
   */
  public abstract BwCalSuiteWrapper getCalSuite() throws CalFacadeException;

  /** Get a calendar suite given the name
   *
   * @param  name     String name of calendar suite
   * @return BwCalSuiteWrapper null for unknown calendar suite
   * @throws CalFacadeException
   */
  public abstract BwCalSuiteWrapper getCalSuite(String name) throws CalFacadeException;

  /** Get a calendar suite given the 'owning' group
   *
   * @param  group     BwAdminGroup
   * @return BwCalSuiteWrapper null for unknown calendar suite
   * @throws CalFacadeException
   */
  public abstract BwCalSuiteWrapper getCalSuite(BwAdminGroup group)
          throws CalFacadeException;

  /** Get calendar suites to which this user has access
   *
   * @return Collection     of BwCalSuiteWrapper
   * @throws CalFacadeException
   */
  public abstract Collection<BwCalSuite> getCalSuites() throws CalFacadeException;

  /** Update a calendar suite object
   *
   * @param  val     BwCalSuiteWrapper object
   * @throws CalFacadeException
   */
  public abstract void updateCalSuite(BwCalSuiteWrapper val) throws CalFacadeException;

  /** Delete a calendar suite object
   *
   * @param  val     BwCalSuiteWrapper object
   * @throws CalFacadeException
   */
  public abstract void deleteCalSuite(BwCalSuiteWrapper val) throws CalFacadeException;

  /* ====================================================================
   *                   Calendars
   * ==================================================================== */

  /** Returns the tree of public calendars
   *
   * @return BwCalendar   root with all children attached
   * @throws CalFacadeException
   */
  public abstract BwCalendar getPublicCalendars() throws CalFacadeException;

  /** Return a list of public calendar collections.
   *
   * <p>Caldav currently does not allow collections inside collections so that
   * calendar collections are the leaf nodes only.
   *
   * @return Collection   of BwCalendar
   * @throws CalFacadeException
   */
  public abstract Collection<BwCalendar> getPublicCalendarCollections() throws CalFacadeException;

  /** Returns the root calendar for the current user.
   *
   * <p>For anonymous (public events) access, this method returns the same
   * as getPublicCalendars().
   *
   * <p>For authenticated, personal access this always returns the user
   * entry in the /user calendar tree, e.g. for user smithj it would return
   * /user/smithj
   *
   * @return BwCalendar   root
   * @throws CalFacadeException
   */
  public abstract BwCalendar getCalendars() throws CalFacadeException;

  /** Returns the root calendar for the given user.
   *
   * e.g. for user smithj it would return /user/smithj
   *
   * @param u    BwUser user
   * @return BwCalendar   root
   * @throws CalFacadeException
   */
  public abstract BwCalendar getCalendars(BwUser u) throws CalFacadeException;

  /** Returns children of the given calendar to which the current user has
   * some access.
   *
   * @param  cal          parent calendar
   * @return Collection   of BwCalendar
   * @throws CalFacadeException
   */
  public abstract Collection<BwCalendar> getCalendars(BwCalendar cal)
          throws CalFacadeException;

  /** Return a list of user calendar collections.
   *
   * <p>Caldav currently does not allow collections inside collections so that
   * calendar collections are the leaf nodes only.
   *
   * @return Collection   of BwCalendar
   * @throws CalFacadeException
   */
  public abstract Collection<BwCalendar> getCalendarCollections()
          throws CalFacadeException;

  /** Return a list of calendars in which calendar objects can be
   * placed by the current user.
   *
   * <p>Caldav currently does not allow collections inside collections so that
   * calendar collections are the leaf nodes only.
   *
   * @return Collection   of BwCalendar
   * @throws CalFacadeException
   */
  public abstract Collection<BwCalendar> getAddContentCalendarCollections()
          throws CalFacadeException;

  /** Return true if calendar is in use for events.
   *
   * @param val   BwCalendar
   * @return boolean true for in use
   * @throws CalFacadeException
   */
  public abstract boolean getCalendarInuse(BwCalendar val)
          throws CalFacadeException;

  /** Get a calendar we are interested in. This is represented by the id
   * of a calendar.
   *
   * @deprecated
   * @param  val     int id of calendar
   * @return CalendarVO null for unknown calendar
   * @throws CalFacadeException
   */
  public abstract BwCalendar getCalendar(int val) throws CalFacadeException;

  /** Get a calendar given the path
   *
   * @param  path     String path of calendar
   * @return BwCalendar null for unknown calendar
   * @throws CalFacadeException
   */
  public abstract BwCalendar getCalendar(String path) throws CalFacadeException;

  /** Get a special calendar (e.g. Trash) for the current user. If it does not
   * exist and is supported by the target system it will be created.
   *
   * @param  calType   int special calendar type.
   * @param  create    true if we should create it if non-existant.
   * @return BwCalendar null for unknown calendar
   * @throws CalFacadeException
   */
  public abstract BwCalendar getSpecialCalendar(int calType,
                                                boolean create) throws CalFacadeException;

  /** set the default calendar for the current user.
   *
   * @param  val    BwCalendar
   * @throws CalFacadeException
   */
  public abstract void setPreferredCalendar(BwCalendar  val) throws CalFacadeException;

  /** Get the default calendar for the current user.
   *
   * @return BwCalendar null for unknown calendar
   * @throws CalFacadeException
   */
  public abstract BwCalendar getPreferredCalendar() throws CalFacadeException;

  /** Add a calendar object
   *
   * <p>The new calendar object will be added to the db. If the indicated parent
   * is null it will be added as a root level calendar.
   *
   * <p>Certain restrictions apply, mostly because of interoperability issues.
   * A calendar cannot be added to another calendar which already contains
   * entities, e.g. events etc.
   *
   * <p>Names cannot contain certain characters - (complete this)
   *
   * <p>Name must be unique at this level, i.e. all paths must be unique
   *
   * @param  val     BwCalendar new object
   * @param  parentPath  String path to parent.
   * @return BwCalendar object as added. Parameter val MUST be discarded
   * @throws CalFacadeException
   */
  public abstract BwCalendar addCalendar(BwCalendar val, String parentPath)
      throws CalFacadeException;

  /** Change the name (path segment) of a calendar object.
   *
   * @param  val         BwCalendar object
   * @param  newName     String name
   * @throws CalFacadeException
   */
  public abstract void renameCalendar(BwCalendar val,
                                      String newName) throws CalFacadeException;

  /** Move a calendar object from one parent to another
   *
   * @param  val         BwCalendar object
   * @param  newParent   BwCalendar potential parent
   * @throws CalFacadeException
   */
  public abstract void moveCalendar(BwCalendar val,
                                    BwCalendar newParent) throws CalFacadeException;

  /** Update a calendar object
   *
   * @param  val     CalendarVO object
   * @throws CalFacadeException
   */
  public abstract void updateCalendar(BwCalendar val) throws CalFacadeException;

  /** Delete a calendar. Also remove it from the current user preferences (if any).
   *
   * @param val      BwCalendar calendar
   * @param emptyIt  true to delete contents
   * @return int     0 if it was deleted.
   *                 1 if it didn't exist
   *                 2 if in use
   * @throws CalFacadeException
   */
  public abstract int deleteCalendar(BwCalendar val,
                                     boolean emptyIt) throws CalFacadeException;

  /** Return true if cal != null and it represents a (local) user root
   *
   * @param cal
   * @return boolean
   * @throws CalFacadeException
   */
  public abstract boolean isUserRoot(BwCalendar cal) throws CalFacadeException;

  /* ====================================================================
   *                   Views
   * ==================================================================== */

  /** Add a view.
   *
   * @param  val           BwView to add
   * @param  makeDefault   boolean true for make this the default.
   * @return boolean false view not added, true - added.
   * @throws CalFacadeException
   */
  public abstract boolean addView(BwView val,
                                  boolean makeDefault) throws CalFacadeException;

  /** Remove the view.
   *
   * @param  val     BwView
   * @return boolean false - view not found.
   * @throws CalFacadeException
   */
  public abstract boolean removeView(BwView val) throws CalFacadeException;

  /** Find the named view.
   *
   * @param  val     String view name - null means default
   * @return BwView  null view not found.
   * @throws CalFacadeException
   */
  public abstract BwView findView(String val) throws CalFacadeException;

  /** Add a subscription to the named view.
   *
   * @param  name    String view name - null means default
   * @param  sub     BwSubscription to add
   * @return boolean false view not found, true - subscription added.
   * @throws CalFacadeException
   */
  public abstract boolean addViewSubscription(String name,
                                              BwSubscription sub) throws CalFacadeException;

  /** Remove a subscription from the named view.
   *
   * @param  name    String view name - null means default
   * @param  sub     BwSubscription to add
   * @return boolean false view not found, true - subscription added.
   * @throws CalFacadeException
   */
  public abstract boolean removeViewSubscription(String name,
                                                 BwSubscription sub) throws CalFacadeException;

  /** Return the collection of views - named collections of subscriptions
   *
   * @return collection of views
   * @throws CalFacadeException
   */
  public abstract Collection<BwView> getViews() throws CalFacadeException;

  /* ====================================================================
   *                   Current selection
   * This defines how we select events to display.
   * ==================================================================== */

  /** Set the view to the given named view. Null means reset to default.
   * Unset current subscriptions.
   *
   * @param  val     String view name - null for default
   * @return boolean false - view not found.
   * @throws CalFacadeException
   */
  public abstract boolean setCurrentView(String val) throws CalFacadeException;

  /** Get the current view we have set
   *
   * @return BwView    named Collection of BwSubscription or null for default
   * @throws CalFacadeException
   */
  public abstract BwView getCurrentView() throws CalFacadeException;

  /** Set the view to the given collection of subscriptions.
   * Unset current view.
   *
   * @param  val     Collection
   * @throws CalFacadeException
   */
  public abstract void setCurrentSubscriptions(Collection<BwSubscription> val)
          throws CalFacadeException;

  /** Get the current subscriptions we have set
   *
   * @return Collection of BwSubscription or null
   * @throws CalFacadeException
   */
  public abstract Collection<BwSubscription> getCurrentSubscriptions()
          throws CalFacadeException;

  /* ====================================================================
   *                   Search and filters
   * ==================================================================== */

  /** Set a search filter using the suppplied search string
   *
   * @param val    String search parameters
   * @throws CalFacadeException
   */
  public abstract void setSearch(String val) throws CalFacadeException;

  /** Return the current search string
   *
   * @return  String     search parameters
   * @throws CalFacadeException
   */
  public abstract String getSearch() throws CalFacadeException;

  /** Add a filter to the database. All references must be set.
   *
   * @param val
   * @throws CalFacadeException
   */
  public abstract void addFilter(BwFilter val) throws CalFacadeException;

  /** Update a filter
   *
   * @param  val           FilterVO object to upate
   * @throws CalFacadeException
   */
  public abstract void updateFilter(BwFilter val) throws CalFacadeException;

  /* ====================================================================
   *                   Subscriptions
   * ==================================================================== */

  /** Add a subscription for the current user.
   *
   * @param val      BwSubscription object
   * @throws CalFacadeException
   */
  public abstract void addSubscription(BwSubscription val)
          throws CalFacadeException;

  /** Find the named subscription for the current user.
   *
   * @param name     Name for subscription
   * @return BwSubscription object or null for not found
   * @throws CalFacadeException
   */
  public abstract BwSubscription findSubscription(String name) throws CalFacadeException;

  /** Remove a subscription for the current user.
   *
   * @param val      BwSubscription object
   * @throws CalFacadeException
   */
  public abstract void removeSubscription(BwSubscription val) throws CalFacadeException;

  /** Update subscriptions after a change.
   *
   * @param val      BwSubscription object
   * @throws CalFacadeException
   */
  public abstract void updateSubscription(BwSubscription val) throws CalFacadeException;

  /** Get this users subscription.
   *
   * @return Collection of subscriptions
   * @throws CalFacadeException
   */
  public abstract Collection<BwSubscription> getSubscriptions() throws CalFacadeException;

  /** Fetch the subscription from the db given an id
   *
   * @param id
   * @return the subscription
   * @throws CalFacadeException
   */
  public abstract BwSubscription getSubscription(int id) throws CalFacadeException;

  /** Ensure the subscription has a calendar object attached.
   *
   *  <p>No change will take place for a subscription witht the calendar marked
   *  as deleted or for an external subscription.
   *
   *  <p>If a calendar is already attached just returns with that.
   *
   *  <p>Otherwise attempts to fetch the calendar. On failure marks it as deleted
   *  and returns null, else embeds the object and returns with it.
   *
   * @param val      BwSubscription object
   * @return BwCalendar   or null
   * @throws CalFacadeException
   */
  public abstract BwCalendar getSubCalendar(BwSubscription val) throws CalFacadeException;

  /* ====================================================================
   *                   Categories
   * ==================================================================== */

  /** Returned to show if an entity was added. entity is set to retrieved entity
   *
   * @param <T> class of entity
   */
  public static class EnsureEntityExistsResult<T> {
    /** Was added */
    public boolean added;
    /** */
    public T entity;
  }

  /** Return a collection of BwCategory objects for the current user.
   * Returns an empty collection for no categories.
   *
   * @return Collection     of categories
   * @throws CalFacadeException
   */
  public abstract Collection<BwCategory> getCategories() throws CalFacadeException;

  /** Return all public categories. Returns an empty collection for no categories.
   *
   * @return Collection        of categories
   * @throws CalFacadeException
   */
  public abstract Collection<BwCategory> getPublicCategories() throws CalFacadeException;

  /** Return all editable categories. Returns an empty collection for no categories.
   *
   * @return Collection        of categories
   * @throws CalFacadeException
   */
  public abstract Collection<BwCategory> getEditableCategories()
          throws CalFacadeException;

  /** Add a Category to the database. The id will be set in the parameter
   * object.
   *
   * @param val   BwCategory object to be added
   * @return boolean true for added, false for already exists
   * @throws CalFacadeException
   */
  public abstract boolean addCategory(BwCategory val) throws CalFacadeException;

  /** Replace a category in the database.
   *
   * @param val   BwCategory object to be replaced
   * @throws CalFacadeException
   */
  public abstract void replaceCategory(BwCategory val) throws CalFacadeException;

  /** Delete a category with the given id. Also remove it from the current
   * user preferences (if any).
   *
   * @param val      BwCategory category
   * @return int     0 if it was deleted.
   *                 1 if it didn't exist
   *                 2 if in use
   * @throws CalFacadeException
   */
  public abstract int deleteCategory(BwCategory val) throws CalFacadeException;

  /** Ensure a category exists. If it does sets the id in the object and returns
   * false (not added).
   * If not creates the entity then sets the new id in the object and returns
   * true (added)..
   *
   * @param val   BwCategory value object. If this object has the id set,
   *                  we assume the check was made previously.
   * @return EnsureEntityExistsResult
   * @throws CalFacadeException
   */
  public abstract EnsureEntityExistsResult<BwCategory> ensureCategoryExists(
                        BwCategory val) throws CalFacadeException;

  /** Return given category for this user
   *
   * @param keyVal       BwString key field value
   * @return BwCategory  category value object
   * @throws CalFacadeException
   */
  public abstract BwCategory findCategory(BwString keyVal) throws CalFacadeException;

  /** Return events referencing the given Category
   *
   * @param val      BwCategory object to be checked
   * @return Collection of events
   * @throws CalFacadeException
   */
  public abstract Collection<EventInfo> getCategoryRefs(BwCategory val)
          throws CalFacadeException;

  /** Return count of events referencing the given Category
   *
   * @param val      BwCategory object to be checked
   * @return Collection of events
   * @throws CalFacadeException
   */
  public abstract int getCategoryRefsCount(BwCategory val)
          throws CalFacadeException;

  /* ====================================================================
   *                   Locations
   * ==================================================================== */

  /** Return all locations for this user. Returns an empty collection for
   * no locations. If this is a public admin instance, this will return all
   * public locations owned by the current user. Otherwise it returns all
   * personal locations owned by the user.
   *
   * @return Collection        of location value objects
   * @throws CalFacadeException
   */
  public abstract Collection<BwLocation> getLocations() throws CalFacadeException;

  /** Return public locations - excluding reserved entries. Returns an empty
   * collection for no locations.
   *
   * @return Collection        of location value objects
   * @throws CalFacadeException
   */
  public abstract Collection<BwLocation> getPublicLocations() throws CalFacadeException;

  /** Return all editable locations. Returns an empty collection for no locations.
   *
   * @return Collection        of location value objects
   * @throws CalFacadeException
   */
  public abstract Collection<BwLocation> getEditableLocations() throws CalFacadeException;

  /** Add a location to the database. The new owner and creator will be set to
   * the current suer if not already set..
   *
   * @param val   BwLocation object to be added
   * @return boolean true for added, false for already exists
   * @throws CalFacadeException
   */
  public abstract boolean addLocation(BwLocation val) throws CalFacadeException;

  /** Replace a location in the database.
   *
   * @param val   LocationVO object to be replaced
   * @throws CalFacadeException
   */
  public abstract void replaceLocation(BwLocation val) throws CalFacadeException;

  /** Return a location with the given id
   *
   * @param id     int id of the location
   * @return LocationVo object representing the location in question
   *                     null if it doesn't exist.
   * @throws CalFacadeException
   */
  public abstract BwLocation getLocation(int id) throws CalFacadeException;

  /** Return a location with the given uid
   *
   * @param uid     String uid of the location
   * @return BwLocation object representing the location in question
   *                     null if it doesn't exist.
   * @throws CalFacadeException
   */
  public abstract BwLocation getLocation(String uid) throws CalFacadeException;

  /* * Search the locations for a matching address and owner
   *
   * @param val         address to match for
   * @return BwLocation matching object or null if no match.
   * @throws CalFacadeException
   */
  //public abstract BwLocation findLocation(BwString val) throws CalFacadeException;

  /** Search the locations for a matching venue and owner
   *
   * @param uid         venue uid to match for
   * @return BwLocation matching object or null if no match.
   * @throws CalFacadeException
   */
  public abstract BwLocation findVenueLocation(String uid) throws CalFacadeException;

  /** Delete a given location. If this is public admin the location must be
   * public.
   *
   * @param val      LocationVO object to be deleted
   * @return int     0 if it was deleted.
   *                 1 if it didn't exist
   *                 2 if in use
   * @throws CalFacadeException
   */
  public abstract int deleteLocation(BwLocation val) throws CalFacadeException;

  /** Ensure a location exists. If it already does returns the object.
   * If not creates the entity and sets the new id in the object and returns
   * null (added).
   *
   * @param val     BwLocation object. If this object has the id set,
   *                we assume the check was made previously.
   * @param owner   null for current user
   * @return EnsureEntityExistsResult  with entity set toactualobject.
   * @throws CalFacadeException
   */
  public abstract EnsureEntityExistsResult<BwLocation> ensureLocationExists(BwLocation val,
                                                                            BwUser owner)
      throws CalFacadeException;

  /** Return events referencing the given location
   *
   * @param val      BwLocation object to be checked
   * @return Collection of EventInfo
   * @throws CalFacadeException
   */
  public abstract Collection<EventInfo> getLocationRefs(BwLocation val) throws CalFacadeException;

  /** Return count of events referencing the given location
   *
   * @param val      BwLocation object to be checked
   * @return int
   * @throws CalFacadeException
   */
  public abstract int getLocationRefsCount(BwLocation val) throws CalFacadeException;

  /* ====================================================================
   *                   Contacts
   * ==================================================================== */

  /** Return a collection of BwSponsor objects for the current user.
   * Returns an empty collection for no sponsors.
   *
   * @return Collection     of sponsors
   * @throws CalFacadeException
   */
  public abstract Collection<BwContact> getContacts() throws CalFacadeException;

  /** Return all public sponsors. Returns an empty  collection for no sponsors.
   *
   * @return Collection        of sponsor value objects
   * @throws CalFacadeException
   */
  public abstract Collection<BwContact> getPublicContacts() throws CalFacadeException;

  /** Return all editable sponsors. Returns an empty collection for no sponsors.
   *
   * @return Collection        of contact value objects
   * @throws CalFacadeException
   */
  public abstract Collection<BwContact> getEditableContacts() throws CalFacadeException;

  /** Add a contact to the database. The id will be set in the parameter
   * object.
   *
   * @param val   BwContact object to be added
   * @return boolean true for added, false for already exists
   * @throws CalFacadeException
   */
  public abstract boolean addContact(BwContact val) throws CalFacadeException;

  /** Replace a contact in the database.
   *
   * @param val   SponsorVO object to be replaced
   * @throws CalFacadeException
   */
  public abstract void replaceContact(BwContact val) throws CalFacadeException;

  /** Return contact with the given id
   *
   * @param id         int id of the sponsor
   * @return SponsorVo object representing the sponsor in question
   *                     null if it doesn't exist.
   * @throws CalFacadeException
   */
  public abstract BwContact getContact(int id) throws CalFacadeException;

  /** Return a contact with the given uid
   *
   * @param uid     String uid of the contact
   * @return BwLocation object representing the contact in question
   *                     null if it doesn't exist.
   * @throws CalFacadeException
   */
  public abstract BwContact getContact(String uid) throws CalFacadeException;

  /** Search the public sponsors for a matching name and owner
   *
   * @param s          BwContact object to match for
   * @return BwSponsor matching object or null if no match.
   * @throws CalFacadeException
   */
  public abstract BwContact findContact(BwString s) throws CalFacadeException;

  /** Delete a sponsor with the given id. Also remove it from the current
   * user preferences (if any).
   *
   * @param val      BwContact object to be deleted
   * @return int     0 if it was deleted.
   *                 1 if it didn't exist
   *                 2 if in use
   * @throws CalFacadeException
   */
  public abstract int deleteContact(BwContact val) throws CalFacadeException;

  /** Ensure a sponsor exists. If it already does returns the object.
   * If not creates the entity and sets the new id in the object and returns
   * null (added).
   *
   * @param val       BwContact object. If this object has the id set,
   *                  we assume the check was made previously.
   * @return EnsureEntityExistsResult
   * @throws CalFacadeException
   */
  public abstract EnsureEntityExistsResult<BwContact> ensureContactExists(BwContact val)
      throws CalFacadeException;

  /** Return events referencing the given sponsor
   *
   * @param val      BwContact object to be checked
   * @return Collection of Integer
   * @throws CalFacadeException
   */
  public abstract Collection<EventInfo> getContactRefs(BwContact val) throws CalFacadeException;

  /** Return count of events referencing the given sponsor
   *
   * @param val      BwContact object to be checked
   * @return int
   * @throws CalFacadeException
   */
  public abstract int getContactRefsCount(BwContact val) throws CalFacadeException;

  /* ====================================================================
   *                   Events
   * ==================================================================== */

  /** Return one or more events for the current user using the calendar,
   * (possibly specified as a subscription,) guid and the recurrence id as a key.
   *
   * <p>For non-recurring events, in normal calendar collections, one and only
   * one event should be returned.
   *
   * <p>For non-recurring events, in special calendar collections, more than
   * one event might be returned if the guid uniqueness requirement is relaxed,
   * for example, in the inbox.
   *
   * For recurring events, the 'master' event defining the rules together
   * with any exceptions should be returned.
   *
   * @param   sub       BwSubscription object
   * @param   cal       BwCalendar object
   * @param   guid      String guid for the event
   * @param   recurrenceId String recurrence id or null
   * @param recurRetrieval How recurring event is returned.
   * @return  Collection of EventInfo objects representing event(s).
   * @throws CalFacadeException
   */
  public abstract Collection<EventInfo> getEvent(BwSubscription sub, BwCalendar cal,
                                                 String guid,
                                                 String recurrenceId,
                                                 RecurringRetrievalMode recurRetrieval)
        throws CalFacadeException;

  /**
   */
  public static class DelEventResult {
    /** */
    public boolean eventDeleted;
    /** */
    public boolean locationDeleted;
    /** */
    public int alarmsDeleted;

    /**
     * @param eventDeleted
     * @param locationDeleted
     * @param alarmsDeleted
     */
    public DelEventResult(boolean eventDeleted,
                          boolean locationDeleted,
                          int alarmsDeleted) {
      this.eventDeleted = eventDeleted;
      this.locationDeleted = locationDeleted;
      this.alarmsDeleted = alarmsDeleted;
    }
  }

  /** Return filtered events for the current user.
   *
   * @param sub          BwSubscription object - null means use current view otherwise
   *                     only for given subscribed calendar
   * @param recurRetrieval How recurring event is returned.
   * @return Collection of EventInfo objects
   * @throws CalFacadeException
   */
  public abstract Collection<EventInfo> getEvents(BwSubscription sub,
                                                  RecurringRetrievalMode recurRetrieval)
          throws CalFacadeException;

  /** Return the events for the current user within the given date and time
   * range.
   *
   * @param sub          BwSubscription object - null means use current view otherwise
   *                     only for given subscribed calendar
   * @param filter       BwFilter object restricting search or null.
   * @param startDate    BwDateTime start - may be null
   * @param endDate      BwDateTime end - may be null.
   * @param recurRetrieval How recurring event is returned.
   * @return Collection  populated event value objects
   * @throws CalFacadeException
   */
  public abstract Collection<EventInfo> getEvents(BwSubscription sub,
                                                  BwFilter filter,
                                                  BwDateTime startDate,
                                                  BwDateTime endDate,
                                                  RecurringRetrievalMode recurRetrieval)
          throws CalFacadeException;

  /** Delete an event. Optionally delete the event location if it is no
   * longer in use.
   *
   * @param event              EventVO object to be deleted
   * @param delUnreffedLoc     delete the location if unreferenced
   * @return DelEventResult    result.
   * @throws CalFacadeException
   */
  public abstract DelEventResult deleteEvent(BwEvent event,
                                             boolean delUnreffedLoc)
      throws CalFacadeException;

  /** This class allows add and update event to signal changes back to the
   * caller.
   */
  public static class EventUpdateResult {
    /** */
    public int locationsAdded;
    /** */
    public int locationsRemoved;

    /** */
    public int contactsAdded;
    /** */
    public int sponsorsRemoved;

    /** */
    public int categoriesAdded;
    /** */
    public int categoriesRemoved;

    /** null or overrides that didn't get added */
    public Collection<BwEventProxy> failedOverrides;
  }

  /** Add an event and ensure its location and sponsor exist.
   *
   * <p>For public events some calendar implementors choose to allow the
   * dynamic creation of locations and sponsors. For each of those, if we have
   * an id, then the object represents a preexisting database item.
   *
   * <p>Otherwise the client has provided information which will be used to
   * locate an already existing location or sponsor. Failing that we use the
   * information to create a new entry.
   *
   * <p>For user clients, we generally assume no sponsor and the location is
   * optional. However, both conditions are enforced at the application level.
   *
   * <p>On return the event object will have been updated. In addition the
   * location and sponsor may have been updated.
   *
   * <p>The event to be added may be a reference to another event. In this case
   * a number of fields should have been copied from that event. Other fields
   * will come from the target.
   *
   * @param cal          BwCalendar defining recipient calendar
   * @param ei           EventInfo object to be added
   * @param rollbackOnError
   * @return EventUpdateResult Counts of changes.
   * @throws CalFacadeException
   */
  public abstract EventUpdateResult addEvent(BwCalendar cal,
                                             EventInfo ei,
                                             boolean rollbackOnError) throws CalFacadeException;

  /** Update an event.
   *
   * @param event         updated BwEvent object
   * @param overrides     Collection of BwEventProxy objects
   * @param changes
   * @throws CalFacadeException
   */
  public abstract void updateEvent(BwEvent event,
                                   Collection<BwEventProxy> overrides,
                                   ChangeTable changes) throws CalFacadeException;

  /** For an event to which we have write access we simply mark it deleted.
   *
   * <p>Otherwise we add an annotation maarking the event as deleted.
   *
   * @param event
   * @throws CalFacadeException
   */
  public abstract void markDeleted(BwEvent event) throws CalFacadeException;

  /** Get events given the calendar and String name. Return null for not
   * found. There should be only one event or none. For recurring, the
   * overrides and possibly the instances will be attached.
   *
   * @param cal        BwCalendar object
   * @param name       String possible name
   * @param recurRetrieval
   * @return EventInfo or null
   * @throws CalFacadeException
   */
  public abstract EventInfo getEvent(BwCalendar cal, String name,
                                     RecurringRetrievalMode recurRetrieval)
          throws CalFacadeException;

  /** Return calendars which contain guid and recurrence id
   *
   * @param guid
   * @param rid
   * @return containing calendars
   * @throws CalFacadeException
   */
  public abstract Collection<BwCalendar> findCalendars(String guid,
                                                       String rid)
          throws CalFacadeException;

  /** Result from copy or move operations. */
  public static enum CopyMoveStatus {
    /** */
    ok,

    /** Nothing happened */
    noop,

    /** Destination was created (i.e. didn't exist previously) */
    created,

    /** copy/move would create duplicate uid */
    duplicateUid,

    /** changing uids is illegal */
    changedUid,

    /** destination exists and overwrite not set. */
    destinationExists,
  }
  /** Copy or move the given named entity to the destination calendar and give it
   * the supplied name.
   *
   * @param from      Source named entity
   * @param overrides Associated event overrides.
   * @param to        Destination calendar
   * @param name      String name of new entity
   * @param copy      true for copying
   * @param overwrite if destination exists replace it.
   * @param newGuidOK   set a new guid if needed (e.g. copy in same collection)
   * @return CopyMoveStatus
   * @throws CalFacadeException
   */
  public abstract CopyMoveStatus copyMoveNamed(BwEvent from,
                                               Collection<BwEventProxy>overrides,
                                               BwCalendar to,
                                               String name,
                                               boolean copy,
                                               boolean overwrite,
                                               boolean newGuidOK) throws CalFacadeException;

  /* ====================================================================
   *                   Synchronization
   * ==================================================================== */

  /** Get the synch info for the current device and user.
   *
   * @return SynchInfoVO object or null.
   * @throws CalFacadeException
   */
   public abstract BwSynchInfo getSynchInfo() throws CalFacadeException;

  /** Add the synch info for the current device and user.
   *
   * @param val    SynchInfoVO object to add
   * @throws CalFacadeException
   */
  public abstract void addSynchInfo(BwSynchInfo val) throws CalFacadeException;

  /** Update the synch info for the current device and user. There must be
   * exactly one object to update.
   *
   * @param val    SynchInfoVO object to update
   * @throws CalFacadeException
   */
  public abstract void updateSynchInfo(BwSynchInfo val)
      throws CalFacadeException;

  /** Return synchronization state for the given event in the current
   * synchronization context as defined by the initialisation parameters,
   * that is the user and synchId. If the event has never been involved in a
   * synch process there will be no related synch state object.
   *
   * @param ev            EventVO object .
   * @return SynchStateVO object or null.
   * @throws CalFacadeException
   */
  public abstract BwSynchState getSynchState(BwEvent ev)
      throws CalFacadeException;

  /** Get the deleted synch states for the current user
   *
   * @return Collection of synch state objects (possibly empty)
   * @throws CalFacadeException
   */
  public abstract Collection<BwSynchState> getDeletedSynchStates() throws CalFacadeException;

  /** Add the synch state for the given event and user.
   *
   * @param val      SynchStateVO object.
   * @throws CalFacadeException
   */
  public abstract void addSynchState(BwSynchState val)
      throws CalFacadeException;

  /** Update the synch state for the given event and user. There must be
   * exactly one object to update.
   *
   * @param val    SynchStateVO object with associated event and user
   * @throws CalFacadeException
   */
  public abstract void updateSynchState(BwSynchState val)
      throws CalFacadeException;

  /** Get the synch data associated with the given object..
   *
   * @param val    SynchStateVO object
   * @throws CalFacadeException
   */
  public abstract void getSynchData(BwSynchState val) throws CalFacadeException;

  /** Set the synch state and data for the given user and event.
   * There may be zero to many objects to update.
   *
   * @param val    SynchStateVO object with associated event and user
   * @throws CalFacadeException
   */
  public abstract void setSynchData(BwSynchState val) throws CalFacadeException;

  /** Update the synch states for the current user and device.
   *
   * <p>This is called at the termination of synchronization to set any state
   * objects appropriately.
   *
   * <p><table cols="2">
   * <th><td>Old state</td><td>New state</td></th>
   * <tr><td>UNKNOWN</td><td>SYNCHRONIZED</td></tr>
   * <tr><td>SYNCHRONIZED</td><td>SYNCHRONIZED</td></tr>
   * <tr><td>NEW</td><td>SYNCHRONIZED</td></tr>
   * <tr><td>MODIFIED</td><td>SYNCHRONIZED</td></tr>
   * <tr><td>DELETED</td><td>entry deleted</td></tr>
   * <tr><td>CLIENT_DELETED</td><td>unchanged</td></tr>
   * <tr><td>CLIENT_DELETED_UNDELIVERED</td><td>CLIENT_DELETED</td></tr>
   * <tr><td>CLIENT_MODIFIED</td><td>unchanged</td></tr>
   * <tr><td>CLIENT_MODIFIED_UNDELIVERED</td><td>CLIENT_MODIFIED</td></tr>
   * </table>
   *
   * @throws CalFacadeException
   */
  public abstract void updateSynchStates() throws CalFacadeException;

  /* ====================================================================
   *                       Alarms
   * ==================================================================== */

  /** Get any alarms for the given event and user.
   *
   * @param event      BwEvent event
   * @param user       BwUser representing user
   * @return Collection of BwAlarm.
   * @throws CalFacadeException
   */
  public abstract Collection<BwAlarm> getAlarms(BwEvent event,
                                                BwUser user) throws CalFacadeException;

  /** Set an alarm on the event.
   *
   * <p>The supplied alarm object has been appropriately initialised.
   * We validate it then set the alarm on the event for the current user.
   *
   * @param  event          BwEvent object
   * @param  alarm          BwAlarm object
   * @throws CalFacadeException
   */
  public abstract void setAlarm(BwEvent event,
                                BwAlarm alarm) throws CalFacadeException;

  /** Update an alarm.
   *
   * @param val   BwAlarm  object .
   * @throws CalFacadeException
   */
  public abstract void updateAlarm(BwAlarm val) throws CalFacadeException;

  /** Return all unexpired alarms. If user is null all unexpired alarms will
   * be retrieved.
   *
   * @param user
   * @return Collection of unexpired alarms.
   * @throws CalFacadeException
   */
  public abstract Collection getUnexpiredAlarms(BwUser user) throws CalFacadeException;

  /** Return all unexpired alarms before a given time. If user is null all
   * unexpired alarms will be retrieved.
   *
   * @param user
   * @param triggerTime
   * @return Collection of unexpired alarms.
   * @throws CalFacadeException
   */
  public abstract Collection getUnexpiredAlarms(BwUser user, long triggerTime)
          throws CalFacadeException;

  /* ====================================================================
   *                   Searching and indexing methods
   * ==================================================================== */

  /** Convenience method to limit to now onwards.
   *
   * @return SearchLimits
   */
  public static SearchLimits fromToday() {
    SearchLimits lim = new SearchLimits();

    lim.fromDate = CalFacadeUtil.isoDate(new java.util.Date());

    return lim;
  }

  /** Convenience method to limit to before now.
   *
   * @return SearchLimits
   */
  public static SearchLimits beforeToday() {
    SearchLimits lim = new SearchLimits();

    lim.toDate = CalFacadeUtil.isoDate(CalFacadeUtil.yesterday());

    return lim;
  }

  /** Called to search an index. If publick is false and user is null then
   * search current user.
   *
   * XXX Security implications here. We should probably not return a count for
   * searching another users entries - or we should get an accurate count of
   * entries this user has access to.
   *
   * @param publick
   * @param user
   * @param   query    Query string
   * @param   limits   limits or null
   * @return  int      Number found. 0 means none found,
   *                                -1 means indeterminate
   * @throws CalFacadeException
   */
  public abstract int searchIndex(boolean publick,
                                  BwUser user,
                                  String query,
                                  SearchLimits limits) throws CalFacadeException;

  /** Called to retrieve results after a search of the index.
   *
   * @param start
   * @param num
   * @return  Collection of BwIndexSearchResultEntry
   * @throws CalFacadeException
   */
  public abstract Collection<BwIndexSearchResultEntry> getSearchResult(int start,
                                                                       int num)
        throws CalFacadeException;
}

