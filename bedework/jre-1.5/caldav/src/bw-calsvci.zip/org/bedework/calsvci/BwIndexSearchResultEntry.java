package org.bedework.calsvci;


import org.bedework.calfacade.BwCalendar;
import org.bedework.calfacade.svc.EventInfo;

/**
 * @author Mike Douglass
 *
 */
public class BwIndexSearchResultEntry {
  private EventInfo event;

  private BwCalendar cal;

  private float score;

  /** Constructor
   *
   * @param event
   * @param score
   */
  public BwIndexSearchResultEntry(EventInfo event, float score) {
    this.event = event;
    this.score = score;
  }

  /** Constructor
   *
   * @param cal
   * @param score
   */
  public BwIndexSearchResultEntry(BwCalendar cal, float score) {
    this.cal = cal;
    this.score = score;
  }

  /** Non-null if we got an event
   *
   * @return EventInfo object
   */
  public EventInfo getEvent() {
    return event;
  }

  /** Non-null if we got a calendar
   *
   * @return BwCalendar
   */
  public BwCalendar getCal() {
    return cal;
  }

  /** Score for this record
   *
   * @return float score
   */
  public float getScore() {
    return score;
  }
}
