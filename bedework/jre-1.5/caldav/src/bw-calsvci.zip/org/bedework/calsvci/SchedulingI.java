/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calsvci;

import org.bedework.calfacade.BwAttendee;
import org.bedework.calfacade.BwCalendar;
import org.bedework.calfacade.BwDateTime;
import org.bedework.calfacade.BwDuration;
import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.BwFreeBusy;
import org.bedework.calfacade.BwPrincipal;
import org.bedework.calfacade.ScheduleResult;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.svc.EventInfo;
import org.bedework.calfacade.util.Granulator.EventPeriod;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

/**
 * @author Mike Douglass
 *
 */
public interface SchedulingI extends Serializable {
  /** Schedule a meeting or publish an event. The event object must have the organizer
   * and attendees and possibly recipients set according to itip + caldav.
   *
   * <p>The event will be added to the users outbox which will trigger the send
   * of requests to other users inboxes. For users within this system the
   * request will be immediately addded to the recipients inbox. For external
   * users they are sent via mail.
   *
   * @param ei         EventInfo object containing with method=REQUEST, CANCEL,
   *                              ADD, DECLINECOUNTER or PUBLISH
   * @param recipient - non null to send to this recipient only (for REFRESH)
   * @return ScheduleResult
   * @throws CalFacadeException
   */
  public ScheduleResult schedule(EventInfo ei,
                                 String recipient) throws CalFacadeException;

  /**
   * @param ei
   * @param comment
   * @param recipient
   * @return ScheduleResult
   * @throws CalFacadeException
   */
  public ScheduleResult declineCounter(EventInfo ei,
                                       String comment,
                                       String recipient) throws CalFacadeException;

  /** Attendee wants a refresh
   *
   * @param ei event which is probably in a calendar.
   * @param comment - optional comment
   * @return   ScheduleResult
   * @throws CalFacadeException
   */
  public ScheduleResult requestRefresh(EventInfo ei,
                                       String comment) throws CalFacadeException;

  /** An attendee responds to a request.
   *
   * @param ei  The incoming event which should be in the inbox
   * @param delegate non-null if the attendee wants to delegate
   * @param meth   method for response ("REPLY", "COUNTER" etc)
   * @param partStat  participation status for REPLY
   * @param comment  String comment from attendee
   * @param rsvp   true if user wants to be notified
   * @param newCal  calendar to place event in or null
   * @param eventCals - if non-null where we have a copy or copies of the meeting
   * @return   ScheduleResult
   * @throws CalFacadeException
   */
  public ScheduleResult attendeeRespond(EventInfo ei,
                                        String delegate,
                                        String meth,
                                        String partStat,
                                        String comment,
                                        boolean rsvp,
                                        BwCalendar newCal,
                                        Collection<BwCalendar> eventCals) throws CalFacadeException;

  /** An attendee wishes to update a meeting, e.g. they wish to change their
   * participation status.
   *
   * @param ei  The event from the users calendar
   * @return   EventInfo suitable for updating and sending to the organizer.
   * @throws CalFacadeException
   */
  public EventInfo initAttendeeUpdate(EventInfo ei) throws CalFacadeException;

  /** Handle replies to scheduling requests - that is the schedule
   * method was REPLY. We, as an organizer (or their delegate) are going to
   * use the reply to update the original invitation and any copies.
   *
   * @param ei - the incoming event in the inbox
   * @param eventCals - if non-null where we have a copy or copies of the meeting
   * @return ScheduleResult showing how things went.
   * @throws CalFacadeException
   */
  public ScheduleResult processResponse(EventInfo ei,
                                        Collection<BwCalendar> eventCals) throws CalFacadeException;

  /** The organizer has cancelled the meeting - or taken us (the attendee) off
   * the list.
   *
   * <p>We will look for the event in the users calendar(s) and either remove it
   * or set the status to cancelled.
   *
   * @param ei            EventInfo object with method=CANCEL
   * @param action        Value from BwPreferences
   * @param eventCals - if non-null where we have a copy or copies of the meeting
   * @return ScheduleResult
   * @throws CalFacadeException
   */
  public ScheduleResult processCancel(EventInfo ei,
                                      int action,
                                      Collection<BwCalendar> eventCals) throws CalFacadeException;

  /** Respond to a scheduling request. The event object must have the organizer
   * and a single attendee and possibly recipient set according to itip + caldav.
   *
   * <p>The event will be added to the users outbox which will trigger the send
   * of a request to the organizers inbox. For an organizer within this system the
   * request will be immediately addded to the recipients inbox. For an external
   * organizer it is sent via mail.
   *
   * @param ei         EventInfo object with event with method=REPLY, COUNTER or
   *                    REFRESH
   * @return ScheduleResult
   * @throws CalFacadeException
   */
  public ScheduleResult scheduleResponse(EventInfo ei) throws CalFacadeException;

  /** Get the free busy for the given principal as a list of busy periods.
   *
   * @param cal    Calendar to provide free-busy for. Null for the user root
   *               for default collection (as specified by user).
   *               Used for local access to a given calendar via e.g. caldav
   * @param who    If cal is null get the info for this user, otherwise
   *               this is used as the free/busy result owner
   * @param start
   * @param end
   * @return BwFreeBusy
   * @throws CalFacadeException
   */
  public BwFreeBusy getFreeBusy(BwCalendar cal, BwPrincipal who,
                                BwDateTime start, BwDateTime end)
          throws CalFacadeException;

  /** Used for user interface. Result of dividing VFREEBUSY into equal sized
   * chunks.
   *
   * @author Mike Douglass
   *
   */
  public static class FbResponse implements Serializable {
    private BwDateTime start;
    private BwDateTime end;

    /** How did it go? Status from scheduling request */
    public int respCode;

    /** */
    public boolean noResponse;

    /** Who for */
    public BwAttendee attendee;

    private String recipient;

    /** Collection of Granulator.EventPeriod */
    public Collection<EventPeriod> eps = new ArrayList<EventPeriod>();

    /**
     * @param val
     */
    public void setStart(BwDateTime val) {
      start = val;
    }

    /**
     * @return BwDateTime start
     */
    public BwDateTime getStart() {
      return start;
    }

    /**
     * @param val
     */
    public void setEnd(BwDateTime val) {
      end = val;
    }

    /**
     * @return BwDateTime end
     */
    public BwDateTime getEnd() {
      return end;
    }

    /**
     * @param val
     */
    public void setRespCode(int val) {
      respCode = val;
    }

    /**
     * @return int
     */
    public int getRespCode() {
      return respCode;
    }

    /**
     * @param val
     */
    public void setNoResponse(boolean val) {
      noResponse = val;
    }

    /**
     * @return boolean
     */
    public boolean getNoResponse() {
      return noResponse;
    }

    /**
     * @param val
     */
    public void setRecipient(String val) {
      recipient = val;
    }
    /**
     * @return String
     */
    public String getRecipient() {
      return recipient;
    }

    /**
     * @param val
     */
    public void setAttendee(BwAttendee val) {
      attendee = val;
    }
    /**
     * @return BwAttendee
     */
    public BwAttendee getAttendee() {
      return attendee;
    }

    /**
     * @return boolean
     */
    public boolean okResponse() {
      return (respCode == ScheduleResult.ScheduleRecipientResult.scheduleOk) &&
             !noResponse;
    }
  }

  /**
   * @author douglm
   *
   */
  public static class FbResponses implements Serializable {
    private Collection<FbResponse> responses;

    private FbResponse aggregatedResponse;

    /**
     * @param val
     */
    public void setResponses(Collection<FbResponse> val) {
      responses = val;
    }

    /** All responses with status
     *
     * @return Collection of FbResponse
     */
    public Collection<FbResponse> getResponses() {
      return responses;
    }

    /** Aggregated response
     *
     * @param val
     */
    public void setAggregatedResponse(FbResponse val) {
      aggregatedResponse = val;
    }

    /** Aggregated response
     *
     * @return FbResponse
     */
    public FbResponse getAggregatedResponse() {
      return aggregatedResponse;
    }
  }

  /** Get calendar collections which affect freebusy.
   *
   * @return Collection of calendars.
   * @throws CalFacadeException
   */
  public Collection<BwCalendar> getFreebusySet() throws CalFacadeException;

  /** Get aggregated free busy for a ScheduleResult.
   *
   * @param sr ScheduleResult
   * @param start
   * @param end
   * @param granularity
   * @return FbResponses
   * @throws CalFacadeException
   */
  public FbResponses aggregateFreeBusy(ScheduleResult sr,
                                       BwDateTime start, BwDateTime end,
                                       BwDuration granularity) throws CalFacadeException;

  /** Granulate (divide into equal chunks and return the result. The response
   * from the original request may be for a different time range than requested.
   *
   * @param fb
   * @param start     start from original request
   * @param end       end from original request
   * @param granularity
   * @return FbResponse
   * @throws CalFacadeException
   */
  public FbResponse granulateFreeBusy(BwFreeBusy fb,
                                      BwDateTime start, BwDateTime end,
                                      BwDuration granularity) throws CalFacadeException;

  /** Return this users calendars containing copies of the meetings with the
   * same uid as that given.
   *
   * @param ev
   * @return possibly empty Collection of calendars excluding the inbox
   * @throws CalFacadeException
   */
  public Collection<BwCalendar> getMeetingCalendars(BwEvent ev) throws CalFacadeException;

  /** Find the attendee in this event which corresponds to the current user
   *
   * @param ev
   * @return attendee or null.
   * @throws CalFacadeException
   */
  public BwAttendee findUserAttendee(BwEvent ev) throws CalFacadeException;
}
