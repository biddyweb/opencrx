/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
 */
package org.bedework.calsvci;

import org.bedework.calfacade.BwTimeZone;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.base.UpdateFromTimeZonesInfo;
import org.bedework.calfacade.exc.CalFacadeException;

import net.fortuna.ical4j.model.component.VTimeZone;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

/** Actions to maintain a store of timezone definitions.
 *
 * @author Mike Douglass
 *
 */
public interface TimeZonesStoreI extends Serializable {
  /** Save a timezone definition in the database. The timezone is in the
   * form of a VTimeZone object.
   *
   * @param tzid
   * @param vtz
   * @throws CalFacadeException
   */
  public void saveTimeZone(String tzid,
                           VTimeZone vtz) throws CalFacadeException;

  /** Get a vtimezone object given the id and the owner of the event.
   *
   * <p>For a user will search local timezone defs first then public defs.
   *
   * <p>For public events searches only public.
   *
   * @param id
   * @param owner     expected owner of private timezone or null for current user
   * @param publick   true for a system timezone (owner not used)
   * @return VTimeZone
   * @throws CalFacadeException
   */
  public VTimeZone getTimeZone(final String id,
                               BwUser owner,
                               boolean publick) throws CalFacadeException;

  /** Get all known vtimezone objects.
   *
   * <p>For a user will replace public defs with local timezone defs with the
   * same id.
   *
   * <p>For public events return only public.
   *
   * @return Collection
   * @throws CalFacadeException
   */
  public Collection<BwTimeZone> getTimeZones() throws CalFacadeException;

  /** Get all user vtimezone objects.
   *
   * @param tzOwner
   * @return Collection
   * @throws CalFacadeException
   */
  public Collection<BwTimeZone> getUserTimeZones(BwUser tzOwner) throws CalFacadeException;

  /** Get all public vtimezone objects.
   *
   * @return Collection
   * @throws CalFacadeException
   */
  public Collection<BwTimeZone> getPublicTimeZones() throws CalFacadeException;

  /** Get all public timezone ids.
   *
   * @return Collection of String
   * @throws CalFacadeException
   */
  public Collection<String> getPublicTimeZoneIds() throws CalFacadeException;

  /** Clear all public timezone collection objects
   *
   * <p>Will remove all public timezones in preparation for a replacement
   * (presumably)
   *
   * @throws CalFacadeException
   */
  public void clearPublicTimezones() throws CalFacadeException;

  /** Get all of the timezone ids.
   *
   * @return List  of TimeZoneInfo
   * @throws CalFacadeException
   */
  public List getTimeZoneIds() throws CalFacadeException;

  /** Update the system after changes to timezones. This is a lengthy process
   * so the method allows the caller to specify how many updates are to take place
   * before returning.
   *
   * <p>To restart the update, call the method again, giving it the result from
   * the last call as a parameter.
   *
   * <p>If called again after all events have been checked the process will be
   * redone using timestamps to limit the check to events added or updated since
   * the first check. Keep calling until the number of updated events is zero.
   *
   * @param limit   -1 for no limit
   * @param checkOnly  don't update if true.
   * @param info    null on first call, returned object from previous calls.
   * @return UpdateFromTimeZonesInfo staus of the update
   * @throws CalFacadeException
   */
  public UpdateFromTimeZonesInfo updateFromTimeZones(int limit,
                                                     boolean checkOnly,
                                                     UpdateFromTimeZonesInfo info
                                                     ) throws CalFacadeException;
}
