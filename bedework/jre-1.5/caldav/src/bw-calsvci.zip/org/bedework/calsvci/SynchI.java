/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
 */
package org.bedework.calsvci;

import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.syncml.BwSynchInfo;
import org.bedework.calfacade.syncml.BwSynchState;

import java.io.Serializable;
import java.util.Collection;

/** Interface for handling bedework synchronization operations.
 *
 * <p>This is intended to be a generic synch interface on top of which we will
 * build different kinds of synchronization to support e.g. syncml, file synch
 * etc.
 *
 * <p>At the moment this interface preserves the code developed to date for syncml
 *
 * @author Mike Douglass
 *
 */
public interface SynchI extends Serializable {
  /** Get the synch info for the current device and user.
   *
   * @return BwSynchInfo object or null.
   * @throws CalFacadeException
   */
  public BwSynchInfo getInfo() throws CalFacadeException;

  /** Add the synch info for the current device and user.
   *
   * @param val    BwSynchInfo object to add
   * @throws CalFacadeException
   */
  public void addInfo(BwSynchInfo val) throws CalFacadeException;

  /** Update the synch info for the current device and user. There must be
   * exactly one object to update.
   *
   * @param val    BwSynchInfo object to update
   * @throws CalFacadeException
   */
  public void updateInfo(BwSynchInfo val) throws CalFacadeException;

  /** Return synchronization state for the given event in the current
   * synchronization context as defined by the initialisation parameters,
   * that is the user and synchId. If the event has never been involved in a
   * synch process there will be no related synch state object.
   *
   * @param ev            BwEvent object .
   * @return BwSynchState object or null.
   * @throws CalFacadeException
   */
  public BwSynchState getState(BwEvent ev) throws CalFacadeException;

  /** Get the deleted synch states for the current user
   *
   * @return Collection of synch state objects (possibly empty)
   * @throws CalFacadeException
   */
  public Collection<BwSynchState> getDeleted() throws CalFacadeException;

  /** Add the synch state for the given event and user.
   *
   * @param val      BwSynchState object.
   * @throws CalFacadeException
   */
  public void addState(BwSynchState val) throws CalFacadeException;

  /** Update the synch state for the given event and user. There must be
   * exactly one object to update.
   *
   * @param val    BwSynchState object with associated event and user
   * @throws CalFacadeException
   */
  public void updateState(BwSynchState val) throws CalFacadeException;

  /** Get the synch data associated with the given object..
   *
   * @param val    BwSynchState object
   * @throws CalFacadeException
   */
  public void getData(BwSynchState val) throws CalFacadeException;

  /** Set the synch state and data for the given user and event.
   * There may be zero to many objects to update.
   *
   * @param val    BwSynchState object with associated event and user
   * @throws CalFacadeException
   */
  public void setData(BwSynchState val) throws CalFacadeException;

  /** Update the synch states for the current user and device.
   *
   * <p>This is called at the termination of synchronization to set any state
   * objects appropriately.
   *
   * <p><table cols="2">
   * <th><td>Old state</td><td>New state</td></th>
   * <tr><td>UNKNOWN</td><td>SYNCHRONIZED</td></tr>
   * <tr><td>SYNCHRONIZED</td><td>SYNCHRONIZED</td></tr>
   * <tr><td>NEW</td><td>SYNCHRONIZED</td></tr>
   * <tr><td>MODIFIED</td><td>SYNCHRONIZED</td></tr>
   * <tr><td>DELETED</td><td>entry deleted</td></tr>
   * <tr><td>CLIENT_DELETED</td><td>unchanged</td></tr>
   * <tr><td>CLIENT_DELETED_UNDELIVERED</td><td>CLIENT_DELETED</td></tr>
   * <tr><td>CLIENT_MODIFIED</td><td>unchanged</td></tr>
   * <tr><td>CLIENT_MODIFIED_UNDELIVERED</td><td>CLIENT_MODIFIED</td></tr>
   * </table>
   *
   * @throws CalFacadeException
   */
  public void updateStates() throws CalFacadeException;
}
