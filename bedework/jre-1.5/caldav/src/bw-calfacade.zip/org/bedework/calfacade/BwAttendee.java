/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade;

import org.bedework.calfacade.base.BwDbentity;

/** Represent an attendee. An attendee entry is associated with a single event
 * and gives the participation status of the attendee for that event.
 *
 *  @author Mike Douglass   douglm - rpi.edu
 */
public class BwAttendee extends BwDbentity<BwAttendee> {
  /* Params fields */

  private String cn;
  private String cuType;
  private String delegatedFrom;
  private String delegatedTo;
  private String dir;
  private String language;
  private String member;
  private String sentBy;
  private boolean rsvp;
  private String role;

  /*     partstatparam      = "PARTSTAT" "="
                         ("NEEDS-ACTION"        ; Event needs action
                        / "ACCEPTED"            ; Event accepted
                        / "DECLINED"            ; Event declined
                        / "TENTATIVE"           ; Event tentatively
                                                ; accepted
                        / "DELEGATED"           ; Event delegated
                        / x-name                ; Experimental status
                        / iana-token)           ; Other IANA registered
                                                ; status
     ; These are the participation statuses for a "VEVENT". Default is
     ; NEEDS-ACTION
     partstatparam      /= "PARTSTAT" "="
                         ("NEEDS-ACTION"        ; To-do needs action
                        / "ACCEPTED"            ; To-do accepted
                        / "DECLINED"            ; To-do declined
                        / "TENTATIVE"           ; To-do tentatively
                                                ; accepted
                        / "DELEGATED"           ; To-do delegated
                        / "COMPLETED"           ; To-do completed.
                                                ; COMPLETED property has
                                                ;date/time completed.
                        / "IN-PROCESS"          ; To-do in process of
                                                ; being completed
                        / x-name                ; Experimental status
                        / iana-token)           ; Other IANA registered
                                                ; status
     ; These are the participation statuses for a "VTODO". Default is
     ; NEEDS-ACTION

     partstatparam      /= "PARTSTAT" "="
                         ("NEEDS-ACTION"        ; Journal needs action
                        / "ACCEPTED"            ; Journal accepted
                        / "DECLINED"            ; Journal declined
                        / x-name                ; Experimental status
                        / iana-token)           ; Other IANA registered
                                                ; status
     ; These are the participation statuses for a "VJOURNAL". Default is
     ; NEEDS-ACTION
   */
  private String partstat;

  // ENUM
  /* The uri */
  private String attendeeUri;

  /** RFC sequence value - needed to preserve last sequence # we saw from this
   * attendee
   */
  private int sequence;

  /** UTC datetime as specified in rfc - from replies */
  private String dtstamp;

  /** none set */
  public static final int partstatNone = -2;

  /** x-name or iana-token */
  public static final int partstatOther = -1;

  /** Event, to-do, journal */
  public static final int partstatNeedsAction = 0;
  /** Event, to-do, journal */
  public static final int partstatAccepted = 1;
  /** Event, to-do, journal */
  public static final int partstatDeclined = 2;
  /** Event, to-do */
  public static final int partstatTentative = 3;
  /** Event, to-do */
  public static final int partstatdelegated = 4;
  /** to-do */
  public static final int partstatcompleted = 5;
  /** to-do */
  public static final int partstatInProcess = 6;

  /** Defined partstat values */
  public final static String[] partstats = {
    "NEEDS-ACTION",
    "ACCEPTED",
    "DECLINED",
    "TENTATIVE",
    "DELEGATED",
    "COMPLETED",
    "IN-PROCESS"
  };

  /* Non - db field */
  private int participationStatus;

  /** Constructor
   *
   */
  public BwAttendee() {
  }

  /** Constructor
   *
   * @param cn
   * @param cuType
   * @param delegatedFrom
   * @param delegatedTo
   * @param dir
   * @param language
   * @param member
   * @param rsvp
   * @param role
   * @param partstat
   * @param sentBy
   * @param attendeeUri
   * @param sequence
   * @param dtstamp      String UTC last modification time from replies
   */
  public BwAttendee(String cn,
                    String cuType,
                    String delegatedFrom,
                    String delegatedTo,
                    String dir,
                    String language,
                    String member,
                    boolean rsvp,
                    String role,
                    String partstat,
                    String sentBy,
                    String attendeeUri,
                    int sequence,
                    String dtstamp) {
    super();
    setCn(cn);
    setCuType(cuType);
    setDelegatedFrom(delegatedFrom);
    setDelegatedTo(delegatedTo);
    setDir(dir);
    setLanguage(language);
    setMember(member);
    setRsvp(rsvp);
    setRole(role);
    setPartstat(partstat);
    setSentBy(sentBy);
    setAttendeeUri(attendeeUri);
    setSequence(sequence);
    setDtstamp(dtstamp);
  }

  /* ====================================================================
   *                      Bean methods
   * ==================================================================== */

  /** Set the cn
   *
   *  @param  val   String cn
   */
  public void setCn(String val) {
    cn = val;
  }

  /** Get the cn
   *
   *  @return String     cn
   */
  public String getCn() {
    return cn;
  }

  /** Set the cuType
   *
   *  @param  val   String cuType
   */
  public void setCuType(String val) {
    cuType = val;
  }

  /** Get the cuType
   *
   *  @return String     cuType
   */
  public String getCuType() {
    return cuType;
  }

  /** Set the delegatedFrom
   *
   *  @param  val   String delegatedFrom
   */
  public void setDelegatedFrom(String val) {
    delegatedFrom = val;
  }

  /** Get the delegatedFrom
   *
   *  @return String     delegatedFrom
   */
  public String getDelegatedFrom() {
    return delegatedFrom;
  }

  /** Set the delegatedTo
   *
   *  @param  val   String delegatedTo
   */
  public void setDelegatedTo(String val) {
    delegatedTo = val;
  }

  /** Get the delegatedTo
   *
   *  @return String     delegatedTo
   */
  public String getDelegatedTo() {
    return delegatedTo;
  }

  /** Set the dir
   *
   *  @param  val   String dir
   */
  public void setDir(String val) {
    dir = val;
  }

  /** Get the dir
   *
   *  @return String     dir
   */
  public String getDir() {
    return dir;
  }

  /** Set the language
   *
   *  @param  val   String language
   */
  public void setLanguage(String val) {
    language = val;
  }

  /** Get the language
   *
   *  @return String     language
   */
  public String getLanguage() {
    return language;
  }

  /** Set the member
   *
   *  @param  val   String member
   */
  public void setMember(String val) {
    member = val;
  }

  /** Get the member
   *
   *  @return String     member
   */
  public String getMember() {
    return member;
  }

  /** Set the rsvp
   *
   *  @param  val   boolean rsvp
   */
  public void setRsvp(boolean val) {
    rsvp = val;
  }

  /** Get the rsvp
   *
   *  @return boolean     rsvp
   */
  public boolean getRsvp() {
    return rsvp;
  }

  /** Set the role
   *
   *  @param  val   String role
   */
  public void setRole(String val) {
    role = val;
  }

  /** Get the role
   *
   *  @return String     role
   */
  public String getRole() {
    return role;
  }

  /** Set the partstat
   *
   *  @param  val   String partstat
   */
  public void setPartstat(String val) {
    partstat = val;

    participationStatus = checkPartstat(val);
  }

  /** Get the partstat
   *
   *  @return String     partstat
   */
  public String getPartstat() {
    return partstat;
  }

  /** Set the sentBy
   *
   *  @param  val   String sentBy
   */
  public void setSentBy(String val) {
    sentBy = val;
  }

  /** Get the sentBy
   *
   *  @return String     sentBy
   */
  public String getSentBy() {
    return sentBy;
  }

  /** Set the attendeeUri
   *
   *  @param  val   String attendeeUri
   */
  public void setAttendeeUri(String val) {
    attendeeUri = val;
  }

  /** Get the attendeeUri
   *
   *  @return String     attendeeUri
   */
  public String getAttendeeUri() {
    return attendeeUri;
  }

  /** Set the rfc sequence for this event
   *
   * @param val    rfc sequence number
   */
  public void setSequence(int val) {
    sequence = val;
  }

  /** Get the events rfc sequence
   *
   * @return int    the events rfc sequence
   */
  public int getSequence() {
    return sequence;
  }

  /**
   * @param val
   */
  public void setDtstamp(String val) {
    dtstamp = val;
  }

  /**
   * @return String datestamp
   */
  public String getDtstamp() {
    return dtstamp;
  }

  /* ====================================================================
   *                   Other non-db methods
   * ==================================================================== */

  /** Return an index for the partstat
   *
   *  @param  val   String partstat
   *  @return int index, <0 for undefined
   */
  public static int checkPartstat(String val) {
    if (val == null) {
      return partstatNone;
    }

    for (int i = 0; i < partstats.length; i++) {
      if (partstats[i].equals(val)) {
        return i;
      }
    }

    return partstatOther;
  }

  /** Set an index for the participation status. Must be None or a defined
   * status
   *
   * @param val
   */
  public void setParticipationStatus(int val) {
    if (val == partstatOther) {
      throw new RuntimeException("Illegal value for participationStatus - " +
                                 "cannot set other");
    }

    if (val >= partstats.length) {
      throw new RuntimeException("Illegal value for participationStatus");
    }

    if (val == partstatNone) {
      setPartstat(null);
    } else {
      setPartstat(partstats[val]);
    }
  }

  /** Get an index for the participation status
   *
   * @return int
   */
  public int getParticipationStatus() {
    return participationStatus;
  }

  /** Copy this objects values into the parameter
   *
   * @param val
   */
  public void copyTo(BwAttendee val) {
    val.setCn(getCn());
    val.setCuType(getCuType());
    val.setDelegatedFrom(getDelegatedFrom());
    val.setDelegatedTo(getDelegatedTo());
    val.setDir(getDir());
    val.setLanguage(getLanguage());
    val.setMember(getMember());
    val.setRsvp(getRsvp());
    val.setRole(getRole());
    val.setPartstat(getPartstat());
    val.setSentBy(getSentBy());
    val.setAttendeeUri(getAttendeeUri());
    val.setSequence(getSequence());
    val.setDtstamp(getDtstamp());
  }

  /* ====================================================================
   *                   Object methods
   * ==================================================================== */

  public int hashCode() {
    return getAttendeeUri().hashCode();
  }

  public int compareTo(BwAttendee that)  {
    if (this == that) {
      return 0;
    }

    return getAttendeeUri().compareTo(that.getAttendeeUri());
  }

  public String toString() {
    StringBuffer sb = new StringBuffer("BwAttendee{");

    toStringSegment(sb);
    sb.append(", cn=");
    sb.append(cn);
    sb.append(", cuType=");
    sb.append(getCuType());
    sb.append(", delegatedFrom=");
    sb.append(getDelegatedFrom());
    sb.append(", delegatedTo=");
    sb.append(getDelegatedTo());
    sb.append(", dir=");
    sb.append(getDir());
    sb.append(", language=");
    sb.append(getLanguage());
    sb.append(", member=");
    sb.append(getMember());
    sb.append(", rsvp=");
    sb.append(getRsvp());
    sb.append(", role=");
    sb.append(getRole());
    sb.append(", partstat=");
    sb.append(getPartstat());
    sb.append(", sentBy=");
    sb.append(getSentBy());
    sb.append(", attendeeUri=");
    sb.append(getAttendeeUri());
    sb.append(",\n sequence=");
    sb.append(getSequence());
    sb.append(", dtstamp=");
    sb.append(getDtstamp());
    sb.append("}");

    return sb.toString();
  }

  public Object clone() {
    BwAttendee nobj = new BwAttendee(getCn(),
                                     getCuType(),
                                     getDelegatedFrom(),
                                     getDelegatedTo(),
                                     getDir(),
                                     getLanguage(),
                                     getMember(),
                                     getRsvp(),
                                     getRole(),
                                     getPartstat(),
                                     getSentBy(),
                                     getAttendeeUri(),
                                     getSequence(),
                                     getDtstamp());
    //nobj.setId(getId());

    return nobj;
  }
}

