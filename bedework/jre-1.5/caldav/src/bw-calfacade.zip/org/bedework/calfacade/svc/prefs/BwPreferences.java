/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
package org.bedework.calfacade.svc.prefs;

import org.bedework.calfacade.base.BwOwnedDbentity;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.svc.BwSubscription;
import org.bedework.calfacade.svc.BwView;
import org.bedework.calfacade.util.CalFacadeUtil;
import org.bedework.calfacade.BwProperty;

import java.util.Collection;
import java.util.TreeSet;

/** Account preferences for Bedework. These affect the user view of calendars.
 *
 *  @author Mike Douglass douglm@rpi.edu
 *  @version 1.0
 */
public class BwPreferences extends BwOwnedDbentity {
  /** The subscriptions
   */
  private Collection<BwSubscription> subscriptions;

  /** Collection of BwView
   */
  protected Collection<BwView> views;

  private String email;

  /** The calendar they will use by default.
   */
  private String defaultCalendarPath;

  private String skinName;

  private String skinStyle;

  /** Name of the view the user prefers to start with. null for default
   */
  private String preferredView;

  /** "day", "week" etc
   */
  private String preferredViewPeriod;

  /* Size of page in search results
   */
  private int pageSize = 10;

  /** Flag days as workdays. Space for not, "W" for a workday.
   * 7 characters with Sunday the first. Localization code should handle
   * first day of week.
   */
  private String workDays;

  /** Time in minutes for workday start, e.g. 14:30 is 870
   */
  private int workdayStart;

  /* Time in minutes for workday end, e.g. 17:30 is 1050
   */
  private int workdayEnd;

  /* When adding events do we prefer end date ("date")
   *  or duration ("duration"). Note the values this field takes
   *  are internal values only - not meant for display.
   */
  private String preferredEndType;

  /** Value identifying an extra simple user mode - we just do stuff without
   * asking
   */
  public static final int basicMode = 0;

  /** Value identifying a simple user mode - we hide some stuff but make
   * fewer assumptions
   */
  public static final int simpleMode = 1;

  /** Value identifying an advanced user mode - reveal it in all its glory
   */
  public static final int advancedMode = 2;

  /** Max mode value
   */
  public static final int maxMode = 2;

  private int userMode;

  private boolean hour24;

  private boolean scheduleAutoRespond;

  /** Do not auto process cancels */
  public static int scheduleAutoCancelNoAction = 0;

  /** Set status to cancelled */
  public static int scheduleAutoCancelSetStatus = 1;

  /** Delete the event */
  public static int scheduleAutoCancelDelete = 2;

  /** */
  public static int scheduleMaxAutoCancel = 2;

  private int scheduleAutoCancelAction;

  private boolean scheduleDoubleBook;

  /** Do not auto process responses */
  public static int scheduleAutoProcessResponsesNoAction = 0;

  /** Only auto process accept responses */
  public static int scheduleAutoProcessResponsesAccepts = 1;

  /** Auto process all responses */
  public static int scheduleAutoProcessResponsesAll = 2;

  /** */
  public static int scheduleMaxAutoProcessResponses = 2;

  private int scheduleAutoProcessResponses;

  private Collection<BwProperty> properties;

  /** Constructor
   *
   */
  public BwPreferences() {
  }

  /* ====================================================================
   *                   Bean methods
   * ==================================================================== */

  /** Set of subscriptions
   *
   * @param val        Collection of BwSubscription
   */
  public void setSubscriptions(Collection<BwSubscription> val) {
    subscriptions = val;
  }

  /** Get the subscriptions
   *
   * @return Collection    of BwSubscription
   */
  public Collection<BwSubscription> getSubscriptions() {
    return subscriptions;
  }

  /** Set of views principal has defined
   *
   * @param val        Collection of BwView
   */
  public void setViews(Collection<BwView> val) {
    views = val;
  }

  /** Get the calendars principal is subscribed to
   *
   * @return Collection    of BwView
   */
  public Collection<BwView> getViews() {
    return views;
  }

  /**
   * @param val
   */
  public void setEmail(String val) {
    email = val;
  }

  /**
   * @return String email
   */
  public String getEmail() {
    return email;
  }

  /**
   * @param val
   */
  public void setDefaultCalendarPath(String val) {
    defaultCalendarPath = val;
  }

  /**
   * @return String default calendar path
   */
  public String getDefaultCalendarPath() {
    return defaultCalendarPath;
  }

  /**
   * @param val
   */
  public void setSkinName(String val) {
    skinName = val;
  }

  /**
   * @return String skin name
   */
  public String getSkinName() {
    return skinName;
  }

  /**
   * @param val
   */
  public void setSkinStyle(String val) {
    skinStyle = val;
  }

  /**
   * @return String skin style
   */
  public String getSkinStyle() {
    return skinStyle;
  }

  /**
   * @param val
   */
  public void setPreferredView(String val) {
    preferredView = val;
  }

  /**
   * @return String preferred view
   */
  public String getPreferredView() {
    return preferredView;
  }

  /** The value should be a non-internationalized String out of
   * "today", "day", "week", "month", "year". The user interface can present
   * language appropriate labels.
   *
   * @param val
   */
  public void setPreferredViewPeriod(String val) {
    preferredViewPeriod = val;
  }

  /**
   * @return String preferred view period
   */
  public String getPreferredViewPeriod() {
    return preferredViewPeriod;
  }

  /** Set number of results in search result page
   * @param val
   */
  public void setPageSize(int val) {
    pageSize = val;
  }

  /**
   * @return number of results in search result page
   */
  public int getPageSize() {
    return pageSize;
  }

  /**
   * @param val
   */
  public void setWorkDays(String val) {
    workDays = val;
  }

  /**
   * @return String work days
   */
  public String getWorkDays() {
    return workDays;
  }

  /**
   * @param val
   */
  public void setWorkdayStart(int val) {
    workdayStart = val;
  }

  /**
   * @return int work day start
   */
  public int getWorkdayStart() {
    return workdayStart;
  }

  /**
   * @param val
   */
  public void setWorkdayEnd(int val) {
    workdayEnd = val;
  }

  /**
   * @return int work day end
   */
  public int getWorkdayEnd() {
    return workdayEnd;
  }

  /**
   * @param val
   */
  public void setPreferredEndType(String val) {
    preferredEndType = val;
  }

  /**
   * @return String preferred end type (none, duration, date/time)
   */
  public String getPreferredEndType() {
    return preferredEndType;
  }

  /**
   * @param val
   */
  public void setUserMode(int val) {
    userMode = val;
  }

  /**
   * @return int user mode
   */
  public int getUserMode() {
    return userMode;
  }

  /**
   * @param val
   */
  public void setHour24(boolean val) {
    hour24 = val;
  }

  /**
   * @return bool
   */
  public boolean getHour24() {
    return hour24;
  }

  /**
   * @param val
   */
  public void setScheduleAutoRespond(boolean val) {
    scheduleAutoRespond = val;
  }

  /**
   * @return bool
   */
  public boolean getScheduleAutoRespond() {
    return scheduleAutoRespond;
  }

  /**
   * @param val
   */
  public void setScheduleAutoCancelAction(int val) {
    scheduleAutoCancelAction = val;
  }

  /**
   * @return int
   */
  public int getScheduleAutoCancelAction() {
    return scheduleAutoCancelAction;
  }

  /**
   * @param val
   */
  public void setScheduleDoubleBook(boolean val) {
    scheduleDoubleBook = val;
  }

  /**
   * @return bool
   */
  public boolean getScheduleDoubleBook() {
    return scheduleDoubleBook;
  }

  /**
   * @param val
   */
  public void setScheduleAutoProcessResponses(int val) {
    scheduleAutoProcessResponses = val;
  }

  /**
   * @return int
   */
  public int getScheduleAutoProcessResponses() {
    return scheduleAutoProcessResponses;
  }

  /**
   * @param val
   */
  public void setProperties(Collection<BwProperty> val) {
    properties = val;
  }

  /**
   * @return properties
   */
  public Collection<BwProperty> getProperties() {
    return properties;
  }

  /**
   * @return int
   */
  public int getNumProperties() {
    Collection c = getProperties();
    if (c == null) {
      return 0;
    }

    return c.size();
  }

  /**
   * @param val
   */
  public void addProperty(BwProperty val) {
    Collection<BwProperty> c = getProperties();
    if (c == null) {
      c = new TreeSet<BwProperty>();
      setProperties(c);
    }

    if (!c.contains(val)) {
      c.add(val);
    }
  }

  /**
   * @param val
   * @return boolean
   */
  public boolean removeProperty(BwProperty val) {
    Collection c = getProperties();
    if (c == null) {
      return false;
    }

    return c.remove(val);
  }

  /**
   * @return BwProperty
   */
  public Collection<BwProperty> copyProperties() {
    if (getNumProperties() == 0) {
      return null;
    }
    TreeSet<BwProperty> ts = new TreeSet<BwProperty>();

    for (BwProperty p: getProperties()) {
      ts.add(p);
    }

    return ts;
  }

  /**
   * @return BwProperty
   */
  public Collection<BwProperty> cloneProperties() {
    if (getNumProperties() == 0) {
      return null;
    }
    TreeSet<BwProperty> ts = new TreeSet<BwProperty>();

    for (BwProperty p: getProperties()) {
      ts.add((BwProperty)p.clone());
    }

    return ts;
  }

  /* ====================================================================
   *                   Convenience methods
   * ==================================================================== */

  /**
   * @param val
   * @throws CalFacadeException
   */
  public void addSubscription(BwSubscription val) throws CalFacadeException {
    Collection<BwSubscription> c = getSubscriptions();
    if (c == null) {
      c = new TreeSet<BwSubscription>();
      setSubscriptions(c);
    }
    if (c.contains(val)) {
      throw new CalFacadeException(CalFacadeException.duplicateSubscription,
                                   val.toString());
    }
    c.add(val);
  }

  /**
   * @param val
   * @return boolean true if removed
   */
  public boolean addView(BwView val) {
    Collection<BwView> c = getViews();
    if (c == null) {
      c = new TreeSet<BwView>();
      setViews(c);
    }
    if (c.contains(val)) {
      return false;
    }

    c.add(val);
    return true;
  }

  /** Set the workday start minutes from a String time value
   *
   * @param val  String time value
   * @throws CalFacadeException
   */
  public void setWorkdayStart(String val) throws CalFacadeException{
    setWorkdayStart(makeMinutesFromTime(val));
  }

  /** Get the workday start as a 4 digit String hours and minutes value
   *
   * @return String work day start time
   */
  public String getWorkdayStartTime() {
    return CalFacadeUtil.getTimeFromMinutes(getWorkdayStart());
  }

  /** Set the workday end minutes from a String time value
   *
   * @param val  String time value
   * @throws CalFacadeException
   */
  public void setWorkdayEnd(String val) throws CalFacadeException{
    setWorkdayEnd(makeMinutesFromTime(val));
  }

  /** Get the workday end as a 4 digit String hours and minutes value
   *
   * @return String work day end time
   */
  public String getWorkdayEndTime() {
    return CalFacadeUtil.getTimeFromMinutes(getWorkdayEnd());
  }

  /* ====================================================================
   *                   Object methods
   * ==================================================================== */

  /** Comapre this view and an object
   *
   * @param  o    object to compare.
   * @return int -1, 0, 1
   */
  public int compareTo(Object o) {
    if (o == this) {
      return 0;
    }

    if (o == null) {
      return -1;
    }

    if (!(o instanceof BwPreferences)) {
      return -1;
    }

    BwPreferences that = (BwPreferences)o;

    return getOwner().compareTo(that.getOwner());
  }

  public int hashCode() {
    return getOwner().hashCode();
  }

  public boolean equals(Object obj) {
    return compareTo(obj) == 0;
  }

  public String toString() {
    StringBuilder sb = new StringBuilder("BwPreferences(");

    toStringSegment(sb);
    sb.append(", email=");
    sb.append(getEmail());
    sb.append(", defaultCalendarPath=");
    if (getDefaultCalendarPath() == null) {
      sb.append("null");
    } else {
      sb.append(getDefaultCalendarPath());
    }
    sb.append(", skinName=");
    sb.append(getSkinName());
    sb.append(", skinStyle=");
    sb.append(getSkinStyle());
    sb.append(", preferredView=");
    sb.append(getPreferredView());
    sb.append(", preferredViewPeriod=");
    sb.append(getPreferredViewPeriod());
    sb.append(", workDays=");
    sb.append(getWorkDays());
    sb.append(", workdayStart=");
    sb.append(getWorkdayStart());
    sb.append(", workdayEnd=");
    sb.append(getWorkdayEnd());

    if (getSubscriptions() != null) {
      sb.append("\n subscriptions:\n");
      for (BwSubscription sub: getSubscriptions()) {
        sb.append("\n");
        sb.append(sub);
      }
    }

    if (getViews() != null) {
      sb.append("\n views:\n");
      for (BwView v: getViews()) {
        sb.append("\n");
        sb.append(v);
      }
    }

    sb.append(")");

    return sb.toString();
  }

  /* ====================================================================
   *                   private methods
   * ==================================================================== */

  /** Turn a String time value e.g. 1030 into a numeric minutes value and set
   * the numeric value in the prefeences.
   *
   * <p>Ignores anything after the first four characters which must all be digits.
   *
   * @param val  String time value
   * @return int minutes
   * @throws CalFacadeException
   */
  private int makeMinutesFromTime(String val) throws CalFacadeException{
    boolean badval = false;
    int minutes = 0;

    try {
      int hours = Integer.parseInt(val.substring(0, 2));
      minutes = Integer.parseInt(val.substring(2, 4));
      if ((hours < 0) || (hours > 24)) {
        badval = true;
      } else if ((minutes < 0) || (minutes > 59)) {
        badval = true;
      } else {
        minutes *= (hours * 60);
      }
    } catch (Throwable t) {
      badval = true;
    }

    if (badval) {
      throw new CalFacadeException("org.bedework.prefs.badvalue", val);
    }

    return minutes;
  }
}
