/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade.exc;

/** Exception somewhere in the calendar facade
 *
 * @author Mike Douglass douglm@rpi.edu
 */
public class CalFacadeException extends Exception {
  /* Property names used as message value. These should be used to
   * retrieve a localized message and can also be used to identify the
   * cause of the exception.
   *
   * Every CalFacadeException should have one of these as the getMessage()
   * value.
   */

  /* ****************** principals and ids ****************************** */

  /** principal does not exist */
  public static final String principalNotFound =
      "org.bedework.exception.principalnotfound";

  /** unknown principal type */
  public static final String unknownPrincipalType =
      "org.bedework.exception.unknownprincipaltype";

  /** bad calendar user address */
  public static final String badCalendarAddr =
    "org.bedework.caladdr.bad";

  /** null calendar user address */
  public static final String nullCalendarAddr =
      "org.bedework.caladdr.null";

  /* ****************** domains ****************************** */

  /** no default domain defined */
  public static final String noDefaultDomain =
      "org.bedework.domains.nodefault";

  /* ****************** (Admin) groups ****************************** */

  /** The admin group already exists */
  public static final String duplicateAdminGroup =
      "org.bedework.exception.duplicateadmingroup";

  /** The group is already on the path to the root (makes a loop) */
  public static final String alreadyOnGroupPath =
      "org.bedework.exception.alreadyonagrouppath";

  /** Group g does not exist */
  public static final String groupNotFound =
      "org.bedework.exception.groupnotfound";

  /* ****************** Calendars ****************************** */

  /** Couldn't find calendar */
  public static final String calendarNotFound =
      "org.bedework.exception.calendarnotfound";

  /** Somebody tried to create a duplicate calendar */
  public static final String duplicateCalendar =
      "org.bedework.exception.duplicatecalendar";

  /** Somebody tried to create a calendar with children */
  public static final String calendarNotEmpty =
      "org.bedework.exception.calendarnotempty";

  /** */
  public static final String illegalCalendarCreation =
      "org.bedework.exception.illegalcalendarcreation";

  /** */
  public static final String cannotDeleteCalendarRoot =
      "org.bedework.exception.cannotdeletecalendarroot";

  /* ****************** Subscriptions ****************************** */

  /** Somebody tried to create a duplicate subscription */
  public static final String duplicateSubscription =
      "org.bedework.exception.duplicatesubscription";

  /* ****************** Ical translation **************************** */

  /** Tried to specify attendees for publish */
  public static final String attendeesInPublish =
      "org.bedework.exception.ical.attendeesinpublish";

  /** Tried to specify end and duration for an event */
  public static final String endAndDuration =
      "org.bedework.exception.ical.endandduration";

  /** Must have a guid */
  public static final String noGuid =
      "org.bedework.exception.ical.noguid";

  /* ****************** Users ****************************** */

  /** No such account */
  public static final String noSuchAccount =
      "org.bedework.exception.nosuchaccount";

  /* ****************** Events ****************************** */

  /** No guid for this event */
  public static final String noEventGuid =
      "org.bedework.exception.noeventguid";

  /** No name for this event */
  public static final String noEventName =
      "org.bedework.exception.noeventname";

  /** The guid for this event already exists in this collection */
  public static final String duplicateGuid =
      "org.bedework.exception.duplicateguid";

  /** The name for this event already exists in this collection */
  public static final String duplicateName =
      "org.bedework.exception.duplicatename";

  /** Cannot locate instances for ... */
  public static final String cannotLocateInstance =
      "org.bedework.exception.cannotlocateinstance";

  /** There are no instances for this recurring event. */
  public static final String noRecurrenceInstances =
      "org.bedework.exception.norecurrenceinstances";

  /** Cannot supply overrides for nonrecurring event. */
  public static final String overridesForNonRecurring =
      "org.bedework.exception.overridesfornonrecurring";

  /* ****************** Scheduling ****************************** */

  /** Access is disallowed to any attendee. */
  public static final String schedulingAttendeeAccessDisallowed =
      "org.bedework.error.scheduling.attendeeaccessdisallowed";

  /** Attendee bad */
  public static final String schedulingBadAttendees =
      "org.bedework.error.scheduling.badttendees";

  /** Entity had a  bad method set */
  public static final String schedulingBadMethod =
      "org.bedework.error.scheduling.badmethod";

  /** A bad response method was attempted */
  public static final String schedulingBadResponseMethod =
      "org.bedework.error.scheduling.badresponsemethod";

  /** event is not in inbox */
  public static final String schedulingBadSourceCalendar =
      "org.bedework.error.scheduling.badsourcecalendar";

  /** invalid destination calendar for event */
  public static final String schedulingBadDestinationCalendar =
      "org.bedework.error.scheduling.baddestinationcalendar";

  /** Duplicate uid found in the target calendar  */
  public static final String schedulingDuplicateUid =
      "org.bedework.error.scheduling.duplicateuid";

  /** Expected exactly one attendee for reply. */
  public static final String schedulingExpectOneAttendee =
      "org.bedework.error.scheduling.expectoneattendee";

  /** Attendee partStat is bad. */
  public static final String schedulingInvalidPartStatus =
      "org.bedework.error.scheduling.invalidpartstatus";

  /** Multiple events were found in the target calendar  */
  public static final String schedulingMultipleEvents =
      "org.bedework.error.scheduling.multipleevents";

  /** You are not an attendee of the meeting. */
  public static final String schedulingNotAttendee =
      "org.bedework.error.scheduling.notattendee";

  /** Entity required attendees but had none. */
  public static final String schedulingNoAttendees =
      "org.bedework.error.scheduling.noattendees";

  /** Entity required originator but had none. */
  public static final String schedulingNoOriginator =
      "org.bedework.error.scheduling.noOriginator";

  /** Entity required recipients but had none. */
  public static final String schedulingNoRecipients =
      "org.bedework.error.scheduling.norecipients";

  /** Attendee for reply not in event. */
  public static final String schedulingUnknownAttendee =
      "org.bedework.error.scheduling.unknownattendee";

  /** Unknown event - organizer possibly deleted it?. */
  public static final String schedulingUnknownEvent =
      "org.bedework.error.scheduling.unknownevent";

  /** Invalid scheduling response. */
  public static final String schedulingBadResponse =
      "org.bedework.error.scheduling.badresponse";

  /** Invalid scheduling action. */
  public static final String schedulingBadAction =
      "org.bedework.error.scheduling.badaction";

  /** System error: Invalid freebusy granulator date limit - Must be DATETIME. */
  public static final String schedulingBadGranulatorDt =
      "org.bedework.error.scheduling.badgranulatordt";

  /* ****************** Timezones ****************************** */

  /** Error reading timezones */
  public static final String timezonesReadError =
      "org.bedework.error.timezones.readerror";

  /** Unknown timezones */
  public static final String unknownTimezone =
      "org.bedework.error.unknown.timezone";

  /** Bad date */
  public static final String badDate =
      "org.bedework.error.bad.date";

  /* ****************** Misc ****************************** */

  /** */
  public static final String illegalObjectClass =
      "org.bedework.exception.illegalobjectclass";

  /** */
  public static final String staleState =
      "org.bedework.exception.stalestate";

  private String extra;

  /** Constructor
   *
   */
  public CalFacadeException() {
    super();
  }

  /**
   * @param t
   */
  public CalFacadeException(Throwable t) {
    super(t);
  }

  /**
   * @param s
   */
  public CalFacadeException(String s) {
    super(s);
  }

  /**
   * @param s  - retrieve with getMessage(), property ame
   * @param extra String extra text
   */
  public CalFacadeException(String s, String extra) {
    super(s);
    this.extra = extra;
  }

  /**
   * @return String extra text
   */
  public String getExtra() {
    return extra;
  }

  /**
   * @return String message and 'extra'
   */
  public String getMessageExtra() {
    if (getExtra() != null) {
      return super.getMessage() + "\t" + getExtra();
    }

    return super.getMessage();
  }
}
