/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade.svc.prefs;

import org.bedework.calfacade.base.BwDbentity;
import org.bedework.calfacade.svc.BwAuthUser;

/** Base object which is closest to the db representation.
 * Possibly used for ejb or hibernate mapping generation.
 *
 * <p>Value object to represent authorised calendar user preferences.
 * These should really be in the same table.
 *
 *  @author Mike Douglass douglm@rpi.edu
 *  @version 1.0
 */
public class BwAuthUserPrefs extends BwDbentity
        implements BwCommonUserPrefs {
  protected BwAuthUser authUser;

  /** Users preferred categories.
   */
  private CategoryPref categoryPrefs;

  /** Users preferred locations.
   */
  protected LocationPref locationPrefs;

  /** Users preferred contacts.
   */
  private ContactPref contactPrefs;

  /** Users preferred calendars.
   */
  protected CalendarPref calendarPrefs;

  /* ====================================================================
   *                   Bean methods
   * ==================================================================== */

  /**
   * @param val
   */
  public void setAuthUser(BwAuthUser val) {
    authUser = val;
  }

  /**
   * @return BwAuthUser associated auth user
   */
  public BwAuthUser getAuthUser() {
    return authUser;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.svc.prefs.BwCommonUserPrefs#setCategoryPrefs(org.bedework.calfacade.svc.prefs.CategoryPref)
   */
  public void setCategoryPrefs(CategoryPref val) {
    categoryPrefs = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.svc.prefs.BwCommonUserPrefs#getCategoryPrefs()
   */
  public CategoryPref getCategoryPrefs() {
    return categoryPrefs;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.svc.BwCommonUserPrefs#setPreferredLocations(java.util.Collection)
   */
  public void setLocationPrefs(LocationPref val) {
    locationPrefs = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.svc.BwCommonUserPrefs#getPreferredLocations()
   */
  public LocationPref getLocationPrefs() {
    return locationPrefs;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.svc.prefs.BwCommonUserPrefs#setContactPrefs(org.bedework.calfacade.svc.prefs.ContactPref)
   */
  public void setContactPrefs(ContactPref val) {
    contactPrefs = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.svc.prefs.BwCommonUserPrefs#getContactPrefs()
   */
  public ContactPref getContactPrefs() {
    return contactPrefs;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.svc.prefs.BwCommonUserPrefs#setCalendarPrefs(org.bedework.calfacade.svc.prefs.CalendarPref)
   */
  public void setCalendarPrefs(CalendarPref val) {
    calendarPrefs = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.svc.prefs.BwCommonUserPrefs#getCalendarPrefs()
   */
  public CalendarPref getCalendarPrefs() {
    return calendarPrefs;
  }

  /* ====================================================================
   *                   Object methods
   * ==================================================================== */

  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }

    if (!(obj instanceof BwAuthUserPrefs)) {
      return false;
    }

    BwAuthUserPrefs that = (BwAuthUserPrefs)obj;

    return getAuthUser().equals(that.getAuthUser());
  }

  public int hashCode() {
    return getAuthUser().hashCode();
  }

  public String toString() {
    StringBuffer sb = new StringBuffer();

    sb.append("BwAuthUserPrefs{id=");
    sb.append(getId());
    sb.append("authUser=");

    BwAuthUser au = getAuthUser();
    String account = "NULL";
    if (au != null) {
      account = au.getUser().getAccount();
    }

    sb.append(account);
    sb.append("\ncategoryPrefs=");
    sb.append(getCategoryPrefs());
    sb.append("\nlocationPrefs=");
    sb.append(getLocationPrefs());
    sb.append("\nsponsorPrefs=");
    sb.append(getContactPrefs());
    sb.append("\ncalendarPrefs=");
    sb.append(getCalendarPrefs());
    sb.append("}");

    return sb.toString();
  }

  public Object clone() {
    BwAuthUserPrefs aup = new BwAuthUserPrefs();

    aup.setId(getId());

    // Don't clone the authuser - sets up a loop

    aup.setCategoryPrefs((CategoryPref)getCategoryPrefs().clone());
    aup.setLocationPrefs((LocationPref)getLocationPrefs().clone());
    aup.setContactPrefs((ContactPref)getContactPrefs().clone());
    aup.setCalendarPrefs((CalendarPref)getCalendarPrefs().clone());

    return aup;
  }
}
