package org.bedework.calfacade;

import java.util.ArrayList;
import java.util.Collection;

/** Result for a call to a scheduling method
 *
 * @author douglm
 */
public class ScheduleResult {
  /** Result for a single recipient.
   */
  public static class ScheduleRecipientResult {
    /** */
    public String recipient;

    /** Unprocessed */
    public final static int scheduleUnprocessed = -1;

    /** Added to users inbox */
    public final static int scheduleOk = 0;

    /** */
    public final static int scheduleNoAccess = 1;

    /** User is external - will be contacted */
    public final static int scheduleDeferred = 2;

    /** Earlier request so ignored */
    public final static int scheduleIgnored = 3;

    /** One of the above */
    public int status = scheduleUnprocessed;

    /** Set if this is the result of a freebusy request. */
    public BwFreeBusy freeBusy;

    public String toString() {
      StringBuilder sb = new StringBuilder("ScheduleRecipientResult{");

      ScheduleResult.tsseg(sb, "", "recipient", recipient);
      ScheduleResult.tsseg(sb, ", ", "status", status);

      sb.append("}");

      return sb.toString();
    }
  }

  /** If non-null error from CalFacadeException
   */
  public String errorCode;

  /** To go with the error code
   */
  public Object extraInfo;

  /** True if an event had a previously seen sequence and dtstamp.
   * recipient results will be set but no action taken.
   */
  public boolean ignored;

  /** Flagged by incremented sequence or dtstamp in event. */
  public boolean reschedule;

  /** Flagged by same sequence and dtstamp in event. */
  public boolean update;

  /** Collection of ScheduleRecipientResult */
  public Collection<ScheduleRecipientResult> recipientResults =
    new ArrayList<ScheduleRecipientResult>();

  public String toString() {
    StringBuilder sb = new StringBuilder("ScheduleResult{");

    tsseg(sb, "", "errorCode", errorCode);

    tsseg(sb, "\n, ", "ignored", ignored);
    tsseg(sb, ", ", "reschedule", reschedule);
    tsseg(sb, ", ", "ignored", ignored);

    if ((recipientResults != null) && !recipientResults.isEmpty()) {
      for (ScheduleRecipientResult srr: recipientResults) {

        sb.append("\n");
        sb.append(srr);
      }
    }
    sb.append("}");

    return sb.toString();
  }

  private static void tsseg(StringBuilder sb, String delim, String name, int val) {
    sb.append(delim);
    sb.append(name);
    sb.append("=");
    sb.append(val);
  }

  private static void tsseg(StringBuilder sb, String delim, String name, String val) {
    sb.append(delim);
    sb.append(name);
    sb.append("=");
    sb.append(val);
  }

  private static void tsseg(StringBuilder sb, String delim, String name, boolean val) {
    sb.append(delim);
    sb.append(name);
    sb.append("=");
    sb.append(val);
  }
}
