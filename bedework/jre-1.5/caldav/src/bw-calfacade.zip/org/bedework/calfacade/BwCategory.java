/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade;

import org.bedework.calfacade.base.CollatableEntity;
import org.bedework.calfacade.util.CalFacadeUtil;

import java.util.Comparator;

/** A category in Bedework. This value object does no consistency or validity
 * checking
 *.
 *  @version 1.0
 */
public class BwCategory extends BwEventProperty<BwCategory>
        implements CollatableEntity, Comparator<BwCategory> {
  private BwString word;
  private BwString description;

  /** Constructor
   */
  public BwCategory() {
    super();
  }

  /** Set the word
   *
   * @param val    BwString word
   */
  public void setWord(BwString val) {
    word = val;
  }

  /** Get the word
   *
   * @return BwString   word
   */
  public BwString getWord() {
    return word;
  }

  /** Delete the category's keyword - this must be called rather than setting
   * the value to null.
   *
   */
  public void deleteWord() {
    this.addDeletedEntity(getWord());
    setWord(null);
  }

  /** Set the category's description
   *
   * @param val    BwString category's description
   */
  public void setDescription(BwString val) {
    description = val;
  }

  /** Get the category's description
   *
   *  @return BwString   category's description
   */
  public BwString getDescription() {
    return description;
  }

  /** Delete the category's description - this must be called rather than setting
   * the value to null.
   *
   */
  public void deleteDescription() {
    this.addDeletedEntity(getDescription());
    setDescription(null);
  }

  /* ====================================================================
   *                   EventProperty methods
   * ==================================================================== */

  public BwString getFinderKeyValue() {
    return getWord();
  }

  /* ====================================================================
   *                   CollatableEntity methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CollatableEntity#getCollateValue()
   */
  public String getCollateValue() {
    return getWord().getValue();
  }

  /* ====================================================================
   *                   Action methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.BwDbentity#afterDeletion()
   */
  public void afterDeletion() {
    addDeletedEntity(getWord());
    addDeletedEntity(getDescription());
  }

  /* ====================================================================
   *                        Convenience methods
   * ==================================================================== */

  /**
   * @param val
   */
  public void setWordVal(String val) {
    BwString s = getWord();
    if (val == null) {
      if (s != null) {
        addDeletedEntity(s);
        setWord(null);
      }
      return;
    }

    if (s == null) {
      s = new BwString();
      setWord(s);
    }
    s.setValue(val);
  }

  /**
   * @return String
   */
  public String getWordVal() {
    BwString s = getWord();
    if (s == null) {
      return null;
    }

    return s.getValue();
  }

  /**
   * @param val
   */
  public void setDescriptionVal(String val) {
    BwString s = getDescription();
    if (val == null) {
      if (s != null) {
        addDeletedEntity(s);
        setDescription(null);
      }
      return;
    }

    if (s == null) {
      s = new BwString();
      setWord(s);
    }
    s.setValue(val);
  }

  /**
   * @return String
   */
  public String getDescriptionVal() {
    BwString s = getDescription();
    if (s == null) {
      return null;
    }

    return s.getValue();
  }

  /** Size to use for quotas.
   *
   * @return int
   */
  public int length() {
    return super.length() +
           getWord().length() +
           getDescription().length();
  }

  /* ====================================================================
   *                        Object methods
   * ==================================================================== */

  public int compare(BwCategory o1, BwCategory o2) {
    return o1.compareTo(o2);
  }

  public int compareTo(BwCategory that) {
    if (that == null) {
      return -1;
    }

    int res = CalFacadeUtil.cmpObjval(getWord(), that.getWord());

    if (res != 0) {
      return res;
    }

    return CalFacadeUtil.cmpObjval(getOwner(), that.getOwner());
  }

  public int hashCode() {
    int hc = 1;

    if (getWord() != null) {
      hc *= getWord().hashCode();
    }

    if (getOwner() != null) {
      hc *= getOwner().hashCode();
    }

    return hc;
  }

  public String toString() {
    StringBuffer sb = new StringBuffer("BwCategory{");

    toStringSegment(sb);
    sb.append(", word=");
    sb.append(word);
    sb.append("}");

    return sb.toString();
  }

  public Object clone() {
    BwCategory cat = new BwCategory();
    cat.setOwner((BwUser)getOwner().clone());
    cat.setPublick(getPublick());
    cat.setCreator((BwUser)getCreator().clone());
    cat.setAccess(getAccess());
    cat.setWord((BwString)getWord().clone());
    cat.setDescription((BwString)getDescription().clone());

    return cat;
  }
}
