/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade.util;

import org.bedework.calfacade.BwDateTime;
import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.exc.CalFacadeBadDateException;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.timezones.CalTimezones;

import net.fortuna.ical4j.model.Parameter;
import net.fortuna.ical4j.model.ParameterList;
import net.fortuna.ical4j.model.Property;
import net.fortuna.ical4j.model.property.DateProperty;

import java.io.Serializable;
import java.net.InetAddress;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.TimeZone;
import java.util.TreeSet;

/** A few helpers.
 *
 * UID generation copied from hibernate.
 *
 * @author Mike Douglass     douglm - rpi.edu
 *  @version 1.0
 */
public class CalFacadeUtil implements Serializable {
  private static final DateFormat isoDateFormat =
      new SimpleDateFormat("yyyyMMdd");

  private static final DateFormat isoDateTimeFormat =
      new SimpleDateFormat("yyyyMMdd'T'HHmmss");

  private static final DateFormat isoDateTimeTZFormat =
      new SimpleDateFormat("yyyyMMdd'T'HHmmss");

  private static final DateFormat isoDateTimeUTCTZFormat =
      new SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'");

  private static final DateFormat isoDateTimeUTCFormat =
      new SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'");

  private static final DateFormat rfc822GMTFormat =
    new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss Z");

  static {
    isoDateTimeUTCFormat.setTimeZone(net.fortuna.ical4j.model.TimeZone.getTimeZone(
                                 net.fortuna.ical4j.util.TimeZones.UTC_ID));
    isoDateTimeUTCFormat.setLenient(false);

    rfc822GMTFormat.setTimeZone(net.fortuna.ical4j.model.TimeZone.getTimeZone(
                                 net.fortuna.ical4j.util.TimeZones.UTC_ID));
  }

  /*  ---------------- UID gen fields -------------------- */

  private static final int IP;
  static {
    int ipadd;
    try {
      ipadd = toInt(InetAddress.getLocalHost().getAddress());
    } catch (Exception e) {
      ipadd = 0;
    }
    IP = ipadd;
  }

  private static short counter = (short) 0;
  private static final int JVM = (int) ( System.currentTimeMillis() >>> 8 );

  private static String sep = "-";

  /*  ---------------- UID gen fields -------------------- */

  /** Default locale for the system
   */
  public static final Locale defLocale = Locale.getDefault();

  /** This might now work well enough - we probably need a class to define
   * and recognize all new language codes - see Locale.getLanguage
   */
  public static final String defLang;
  static {
    String l = defLocale.getLanguage();
    if (l == null) {
      l = Locale.ENGLISH.getLanguage();
    }

    defLang = l;
  }

  private CalFacadeUtil() {
  }

  /** From hibernate.util
   *
   * @param bytes
   * @return int
   */
  public static int toInt(byte[] bytes ) {
    int result = 0;
    for (int i = 0; i < 4; i++) {
      result = (result << 8) - Byte.MIN_VALUE + (int)bytes[i];
    }

    return result;
  }

  /** Code copied and modified from hibernate UUIDHexGenerator
   *
   * @return String uid.
   */
  public static String getUid() {
    /* Unique down to millisecond */
    short hiTime = (short)(System.currentTimeMillis() >>> 32);

    int loTime = (int)System.currentTimeMillis();

    int ct;

    synchronized(CalFacadeUtil.class) {
      if (counter < 0) {
        counter = 0;
      }

      ct = counter++;
    }

    return new StringBuffer(36).
            append(format(IP)).append(sep).
            append(format(JVM)).append(sep).
            append(format(hiTime)).append(sep).
            append(format(loTime)).append(sep).
            append(format(ct)).
            toString();
  }

  private static String format(int intval) {
    String formatted = Integer.toHexString(intval);
    StringBuffer buf = new StringBuffer("00000000");
    buf.replace(8 - formatted.length(), 8, formatted);

    return buf.toString();
  }

  private static String format(short shortval) {
    String formatted = Integer.toHexString(shortval);
    StringBuffer buf = new StringBuffer("0000");
    buf.replace(4 - formatted.length(), 4, formatted);

    return buf.toString();
  }

  /** Check for a valid transparency - null is invalid
   *
   * @param val
   * @return boolean true = it's OK
   */
  public static boolean validTransparency(String val) {
    if (val == null) {
      /* We could argue that's valid as the default but I think that leads to
       * problems.
       */
      return false;
    }

    if (BwEvent.transparencyOpaque.equals(val)) {
      return true;
    }

    return BwEvent.transparencyTransparent.equals(val);
  }

  /** Update the to Collection with from elements. This is used to
   * add or remove members from a Collection managed by hibernate for example
   * where a replacement of the Collection is not allowed.
   *
   * @param <T>   class of Collections
   * @param from
   * @param to
   * @return boolean true if changed
   */
  public static <T> boolean updateCollection(Collection<T> from, Collection<T> to) {
    boolean changed = false;

    if (from != null) {
      for (T o: from) {
        if (!to.contains(o)) {
          to.add(o);
          changed = true;
        }
      }
    }

    /* Make set of objects to remove to avoid concurrent update exceptios. */
    TreeSet<T> deleted = new TreeSet<T>();

    for (T o: to) {
      if ((from == null) || !from.contains(o)) {
        deleted.add(o);
      }
    }

    int numDeleted = deleted.size();
    if (numDeleted != 0) {
      changed = true;

      if (numDeleted == to.size()) {
        to.clear();
      } else {
        for (T o: deleted) {
          to.remove(o);
        }
      }
    }

    return changed;
  }

  /**
   * @return Date value for yesterday.
   */
  public static Date yesterday() {
    Calendar cal = Calendar.getInstance();
    cal.add(Calendar.DATE, -1);

    return cal.getTime();
  }

  /** Turn Date into "yyyyMMdd"
   *
   * @param val date
   * @return String "yyyyMMdd"
   */
  public static String isoDate(Date val) {
    synchronized (isoDateFormat) {
      return isoDateFormat.format(val);
    }
  }

  /** Turn Now into "yyyyMMdd"
   *
   * @return String "yyyyMMdd"
   */
  public static String isoDate() {
    return isoDate(new Date());
  }

  /** Turn Date into "yyyyMMddTHHmmss"
   *
   * @param val date
   * @return String "yyyyMMddTHHmmss"
   */
  public static String isoDateTime(Date val) {
    synchronized (isoDateTimeFormat) {
      return isoDateTimeFormat.format(val);
    }
  }

  /** Get Now as "yyyyMMddTHHmmss"
   *
   * @return String "yyyyMMddTHHmmss"
   */
  public static String isoDateTime() {
    return  isoDateTime(new Date());
  }

  /** Turn Date into "yyyyMMddTHHmmss" for a given timezone
   *
   * @param val date
   * @param tz TimeZone
   * @return String "yyyyMMddTHHmmss"
   */
  public static String isoDateTime(Date val, TimeZone tz) {
    synchronized (isoDateTimeTZFormat) {
      isoDateTimeTZFormat.setTimeZone(tz);
      return isoDateTimeTZFormat.format(val);
    }
  }

  /** Turn Date into "yyyyMMddTHHmmssZ"
   *
   * @param val date
   * @return String "yyyyMMddTHHmmssZ"
   */
  public static String isoDateTimeUTC(Date val) {
    synchronized (isoDateTimeUTCFormat) {
      return isoDateTimeUTCFormat.format(val);
    }
  }

  /** Turn Date into "???"
   *
   * @param val date
   * @return String "???"
   */
  public static String rfc822Date(Date val) {
    synchronized (rfc822GMTFormat) {
      return rfc822GMTFormat.format(val);
    }
  }

  /** Get Date from "yyyyMMdd"
   *
   * @param val String "yyyyMMdd"
   * @return Date
   * @throws CalFacadeException
   */
  public static Date fromISODate(String val) throws CalFacadeException {
    try {
      synchronized (isoDateFormat) {
        return isoDateFormat.parse(val);
      }
    } catch (Throwable t) {
      throw new CalFacadeBadDateException();
    }
  }

  /** Get Date from "yyyyMMddThhmmss"
   *
   * @param val String "yyyyMMddThhmmss"
   * @return Date
   * @throws CalFacadeException
   */
  public static Date fromISODateTime(String val) throws CalFacadeException {
    try {
      synchronized (isoDateTimeFormat) {
        return isoDateTimeFormat.parse(val);
      }
    } catch (Throwable t) {
      throw new CalFacadeBadDateException();
    }
  }

  /** Get Date from "yyyyMMddThhmmss" with timezone
   *
   * @param val String "yyyyMMddThhmmss"
   * @param tz TimeZone
   * @return Date
   * @throws CalFacadeException
   */
  public static Date fromISODateTime(String val,
                                     TimeZone tz) throws CalFacadeException {
    try {
      synchronized (isoDateTimeTZFormat) {
        isoDateTimeTZFormat.setTimeZone(tz);
        return isoDateTimeTZFormat.parse(val);
      }
    } catch (Throwable t) {
      throw new CalFacadeBadDateException();
    }
  }

  /** Get Date from "yyyyMMddThhmmssZ" with timezone
   *
   * @param val String "yyyyMMddThhmmssZ"
   * @param tz TimeZone
   * @return Date
   * @throws CalFacadeException
   */
  public static Date fromISODateTimeUTC(String val,
                                        TimeZone tz) throws CalFacadeException {
    try {
      synchronized (isoDateTimeUTCTZFormat) {
        isoDateTimeUTCTZFormat.setTimeZone(tz);
        return isoDateTimeUTCTZFormat.parse(val);
      }
    } catch (Throwable t) {
      throw new CalFacadeBadDateException();
    }
  }

  /** Get Date from "yyyyMMddThhmmssZ"
   *
   * @param val String "yyyyMMddThhmmssZ"
   * @return Date
   * @throws CalFacadeException
   */
  public static Date fromISODateTimeUTC(String val) throws CalFacadeException {
    try {
      synchronized (isoDateTimeUTCFormat) {
        return isoDateTimeUTCFormat.parse(val);
      }
    } catch (Throwable t) {
      throw new CalFacadeBadDateException();
    }
  }

  /** Get RFC822 form from "yyyyMMddThhmmssZ"
   *
   * @param val String "yyyyMMddThhmmssZ"
   * @return Date
   * @throws CalFacadeException
   */
  public static String fromISODateTimeUTCtoRfc822(String val) throws CalFacadeException {
    try {
      synchronized (isoDateTimeUTCFormat) {
        return rfc822Date(isoDateTimeUTCFormat.parse(val));
      }
    } catch (Throwable t) {
      throw new CalFacadeBadDateException();
    }
  }

  /** Check Date is "yyyyMMdd"
   *
   * @param val String to check
   * @return boolean
   * @throws CalFacadeException
   */
  public static boolean isISODate(String val) throws CalFacadeException {
    try {
      if (val.length() != 8) {
        return false;
      }
      fromISODate(val);
      return true;
    } catch (Throwable t) {
      return false;
    }
  }

  /** Check Date is "yyyyMMddThhmmddZ"
   *
   * @param val String to check
   * @return boolean
   * @throws CalFacadeException
   */
  public static boolean isISODateTimeUTC(String val) throws CalFacadeException {
    try {
      if (val.length() != 16) {
        return false;
      }
      fromISODateTimeUTC(val);
      return true;
    } catch (Throwable t) {
      return false;
    }
  }

  /** Check Date is "yyyyMMddThhmmdd"
   *
   * @param val String to check
   * @return boolean
   * @throws CalFacadeException
   */
  public static boolean isISODateTime(String val) throws CalFacadeException {
    try {
      if (val.length() != 15) {
        return false;
      }
      fromISODateTime(val);
      return true;
    } catch (Throwable t) {
      return false;
    }
  }

  /** Get a java.util.Date object from the value
   * XXX - this will neeed to be supplied with a tz repository
   *
   * @param val
   * @param timezones
   * @return Date object representing the date
   * @throws CalFacadeException
   */
  public static Date getDate(BwDateTime val,
                             CalTimezones timezones) throws CalFacadeException {
    String dtval = val.getDtval();

    try {
      if (val.getDateType()) {
        return fromISODate(dtval);
      }

      if (dtval.endsWith("Z")) {
        return fromISODateTimeUTC(dtval);
      }

      String tzid = val.getTzid();
      if (tzid == null) {
        return fromISODateTime(dtval);
      }

      return fromISODateTime(dtval,
                             timezones.getTimeZone(tzid, val.getTzowner()));
    } catch (CalFacadeException cfe) {
      throw cfe;
    } catch (Throwable t) {
      throw new CalFacadeBadDateException();
    }
  }

  /** Get a date/time object representing the given date and time
   *
   * @param date       Java Date object
   * @param timezones
   * @return BwDateTime object representing the date
   * @throws CalFacadeException
   */
  public static BwDateTime getDateTime(Date date,
                                       CalTimezones timezones) throws CalFacadeException {
    String dtval = isoDateTime(date);
    return getDateTime(dtval, false, false, false, null, null, null,
                       timezones);
  }

  /** Get a date object representing the given date and flags
   *
   * @param date       String iso date or date/time
   * @param dateOnly
   * @param UTC
   * @param floating    boolean true if this is a floating time
   * @param tzid - String tzid or null for default, UTC or floating.
   * @param tzowner
   * @param timezones
   * @return Date object representing the date
   * @throws CalFacadeException
   */
  public static BwDateTime getDateTime(String date, boolean dateOnly,
                                       boolean UTC, boolean floating,
                                       String tzid, BwUser tzowner,
                                       CalTimezones timezones) throws CalFacadeException {
    return getDateTime(date, dateOnly, UTC, floating, tzid, null, tzowner,
                       timezones);
  }

  /** Get a date object representing the given date and flags
   *
   * @param date       String iso date or date/time
   * @param dateOnly
   * @param UTC
   * @param floating    boolean true if this is a floating time
   * @param tzid - String tzid or null for default, UTC or floating.
   * @param tz - timezone to use
   * @param tzowner
   * @param timezones
   * @return Date object representing the date
   * @throws CalFacadeException
   */
  public static BwDateTime getDateTime(String date, boolean dateOnly,
                                       boolean UTC, boolean floating,
                                       String tzid,
                                       net.fortuna.ical4j.model.TimeZone tz,
                                       BwUser tzowner,
                                       CalTimezones timezones) throws CalFacadeException {
    BwDateTime dtm = new BwDateTime();

    if (dateOnly || UTC || floating) {
      tzid = null;
    }

    if (tz != null) {
      tzid = tz.getID();
    } else if (tzid != null) {
      tz = timezones.getTimeZone(tzid, tzowner);
      if (tz == null) {
        throw new CalFacadeException(CalFacadeException.unknownTimezone, tzid);
      }
    } else if (!UTC && !floating) {
      // Asking for default
      tzid = timezones.getDefaultTimeZoneId();
      tz = timezones.getDefaultTimeZone();
    }

    if (isISODateTimeUTC(date) && !UTC) {
      // Convert to local time (relative to supplied timezone)

      Date dt = fromISODateTimeUTC(date);
      date = isoDateTime(dt, tz);
    }

    dtm.init(dateOnly, date, tzid, tz, tzowner, timezones);

    return dtm;
  }

  /** Get a date object representing the given String UTC date/time
   *
   * @param date
   * @return BwDateTime object representing the date
   * @throws CalFacadeException
   */
  public static BwDateTime getDateTimeUTC(String date) throws CalFacadeException {
    BwDateTime dtm = new BwDateTime();

    dtm.initUTC(false, date);

    return dtm;
  }

  /** Return true for null or empty
   *
   * @param val
   * @return boolean
   */
  public static boolean isEmpty(Collection val) {
    if (val == null) {
      return true;
    }

    return val.isEmpty();
  }
  /** Compare two strings. null is less than any non-null string.
   *
   * @param s1       first string.
   * @param s2       second string.
   * @return int     0 if the s1 is equal to s2;
   *                 <0 if s1 is lexicographically less than s2;
   *                 >0 if s1 is lexicographically greater than s2.
   */
  public static int compareStrings(String s1, String s2) {
    if (s1 == null) {
      if (s2 != null) {
        return -1;
      }

      return 0;
    }

    if (s2 == null) {
      return 1;
    }

    return s1.compareTo(s2);
  }

  /** Compare two possibly null objects for equality
   *
   * @param thisone
   * @param thatone
   * @return boolean true if both null or equal
   */
  public static boolean eqObjval(Object thisone, Object thatone) {
    if (thisone == null) {
      return thatone == null;
    }

    return thisone.equals(thatone);
  }

  /** Compare two possibly null objects
   *
   * @param thisone
   * @param thatone
   * @return int -1, 0, 1,
   */
  public static int cmpObjval(Comparable thisone, Comparable thatone) {
    if (thisone == null) {
      if (thatone == null) {
        return 0;
      }

      return -1;
    }

    if (thatone == null) {
      return 1;
    }

    return thisone.compareTo(thatone);
  }

  /** Compare two possibly null objects
   *
   * @param thisone
   * @param thatone
   * @return int -1, 0, 1,
   */
  public static int cmpObjval(Collection<? extends Comparable> thisone,
                              Collection<? extends Comparable> thatone) {
    if (thisone == null) {
      if (thatone == null) {
        return 0;
      }

      return -1;
    }

    if (thatone == null) {
      return 1;
    }

    int thisLen = thisone.size();
    int thatLen = thatone.size();

    int res = cmpIntval(thisLen, thatLen);
    if (res != 0) {
      return res;
    }

    Iterator<? extends Comparable> thatIt = thatone.iterator();
    for (Comparable c: thisone) {
      res = cmpObjval(c, thatIt.next());

      if (res != 0) {
        return res;
      }
    }

    return 0;
  }

  /** Compare two boolean objects
  *
  * @param thisone
  * @param thatone
  * @return int -1, 0, 1,
  */
  public static int cmpBoolval(boolean thisone, boolean thatone) {
    if (thisone == thatone) {
      return 0;
    }

    if (!thisone) {
      return -1;
    }

    return 1;
  }

  /** Compare two int objects
  *
  * @param thisone
  * @param thatone
  * @return int -1, 0, 1,
  */
  public static int cmpIntval(int thisone, int thatone) {
    if (thisone == thatone) {
      return 0;
    }

    if (thisone < thatone) {
      return -1;
    }

    return 1;
  }

  /** Return a String representing the given String array, achieved by
   * URLEncoding the individual String elements then concatenating with
   *intervening blanks.
   *
   * @param  val    String[] value to encode
   * @return String encoded value
   */
  public static String encodeArray(String[] val){
    if (val == null) {
      return null;
    }

    int len = val.length;

    if (len == 0) {
      return "";
    }

    StringBuffer sb = new StringBuffer();

    for (int i = 0; i < len; i++) {
      if (i > 0) {
        sb.append(" ");
      }

      String s = val[i];

      try {
        if (s == null) {
          sb.append("\t");
        } else {
          sb.append(URLEncoder.encode(s, "UTF-8"));
        }
      } catch (Throwable t) {
        throw new RuntimeException(t);
      }
    }

    return sb.toString();
  }

  /** Return a StringArray resulting from decoding the given String which
   * should have been encoded by encodeArray
   *
   * @param  val      String value encoded by encodeArray
   * @return String[] decoded value
   */
  public static String[] decodeArray(String val){
    if (val == null) {
      return null;
    }

    int len = val.length();

    if (len == 0) {
      return new String[0];
    }

    ArrayList<String> al = new ArrayList<String>();
    int i = 0;

    while (i < len) {
      int end = val.indexOf(" ", i);

      String s;
      if (end < 0) {
        s = val.substring(i);
        i = len;
      } else {
        s = val.substring(i, end);
        i = end + 1;
      }

      try {
        if (s.equals("\t")) {
          al.add(null);
        } else {
          al.add(URLDecoder.decode(s, "UTF-8"));
        }
      } catch (Throwable t) {
        throw new RuntimeException(t);
      }
    }

    return al.toArray(new String[al.size()]);
  }

  /** Given a class name return an object of that class.
   * The class parameter is used to check that the
   * named class is an instance of that class.
   *
   * @param className String class name
   * @param cl   Class expected
   * @return     Object checked to be an instance of that class
   * @throws CalFacadeException
   */
  public static Object getObject(String className, Class cl) throws CalFacadeException {
    try {
      Object o = Class.forName(className).newInstance();

      if (o == null) {
        throw new CalFacadeException("Class " + className + " not found");
      }

      if (!cl.isInstance(o)) {
        throw new CalFacadeException("Class " + className +
                                     " is not a subclass of " +
                                     cl.getName());
      }

      return o;
    } catch (CalFacadeException ce) {
      throw ce;
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /* ====================================================================
             ical utilities
     ==================================================================== */

  /** Add val to prop
   *
   * @param prop
   * @param val
   */
  public static void addIcalParameter(Property prop, Parameter val) {
    ParameterList parl =  prop.getParameters();

    parl.add(val);
  }

  /** Get named parameter from prop
   *
   * @param prop
   * @param name
   * @return Parameter
   */
  public static Parameter getIcalParameter(Property prop, String name) {
    ParameterList parl =  prop.getParameters();

    if (parl == null) {
      return null;
    }

    return parl.getParameter(name);
  }

  /** Return the timezone id if it is set for the property.
   *
   * @param val
   * @return String tzid or null.
   */
  public static String getTzid(DateProperty val) {
    Parameter tzidPar = getIcalParameter(val, "TZID");

    String tzid = null;
    if (tzidPar != null) {
      tzid = tzidPar.getValue();
    }

    return tzid;
  }

  /** Turn the int minutes into a 4 digit String hours and minutes value
   *
   * @param minutes  int
   * @return String 4 digit hours + minutes
   */
  public static String getTimeFromMinutes(int minutes) {
    return pad2(minutes / 60) + pad2(minutes % 60);
  }

  /** Return String value of par padded to 2 digits.
   * @param val
   * @return String
   */
  public static String pad2(int val) {
    if (val > 9) {
      return String.valueOf(val);
    }

    return "0" + String.valueOf(val);
  }
}
