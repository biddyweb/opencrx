/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade.svc.prefs;

import org.bedework.calfacade.util.CalFacadeUtil;

import java.io.Serializable;
import java.util.Collection;
import java.util.TreeSet;

/** Represent a set of user preferences from a Collection - e.g. preferred category.
 *
 *  @author Mike Douglass douglm - rpi.edu
 *  @version 1.0
 *
 * @param <T> Type of element in the collection
 */
public class CollectionPref<T> implements Serializable {
  /** If true automatically add preference to the preferred list
   */
  protected boolean autoAdd = true;

  /** Users preferred collection.
   */
  protected Collection<T> preferred;

  /** If true we automatically add preference to the preferred list
   *
   * @param val
   */
  public void setAutoAdd(boolean val) {
    autoAdd = val;
  }

  /**
   * @return boolean true if we automatically add preference to the preferred list
   */
  public boolean getAutoAdd() {
    return autoAdd;
  }

  /**
   * @param val
   */
  public void setPreferred(Collection<T> val) {
    preferred = val;
  }

  /**
   * @return Collection of preferred entries
   */
  public Collection<T> getPreferred() {
    return preferred;
  }

  /** Add the element to the preferred collection. Return true if it was
   * added, false if it was in the list
   *
   * @param val        Element to add
   * @return boolean   true if added
   */
  public boolean add(T val) {
    Collection<T> c = getPreferred();
    if (c == null) {
      c = new TreeSet<T>();
      setPreferred(c);
    }

    if (c.contains(val)) {
      return false;
    }

    c.add(val);
    return true;
  }

  /** Remove the element from the preferred collection. Return true if it was
   * removed, false if it was not in the list
   *
   * @param val        Element to remove
   * @return boolean   true if removed
   */
  public boolean remove(T val) {
    Collection<T> c = getPreferred();

    if ((c == null) || (!c.contains(val))) {
      return false;
    }

    return c.remove(val);
  }

  /* ====================================================================
   *                   Object methods
   * ==================================================================== */

  @SuppressWarnings("unchecked")
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }

    if (!obj.getClass().equals(getClass())) {
      return false;
    }

    CollectionPref<T> that = (CollectionPref<T>)obj;

    if (that.getAutoAdd() != getAutoAdd()) {
      return false;
    }

    return CalFacadeUtil.eqObjval(getPreferred(), that.getPreferred());
  }

  public int hashCode() {
    int h = 1;
    if (getAutoAdd()) {
      h = 2;
    }

    Collection<T> c = getPreferred();
    if (c != null) {
      h *= c.hashCode();
    }

    return h;
  }

  public String toString() {
    StringBuffer sb = new StringBuffer();

    sb.append("CollectionPref{");
    sb.append("autoAdd=");
    sb.append(getAutoAdd());

    Collection<T> c = getPreferred();

    if (c != null) {
      sb.append("preferred={");
      for (T el: c) {
        sb.append(" ");
        sb.append(el);
      }
    }
    sb.append("}");

    return sb.toString();
  }

  public Object clone() {
    CollectionPref<T> cp = new CollectionPref<T>();

    cp.setAutoAdd(getAutoAdd());

    Collection<T> c = getPreferred();

    if (c != null) {
      TreeSet<T> nc = new TreeSet<T>();
      for (T el: c) {
        nc.add(el);
      }

      cp.setPreferred(nc);
    }

    return cp;
  }
}
