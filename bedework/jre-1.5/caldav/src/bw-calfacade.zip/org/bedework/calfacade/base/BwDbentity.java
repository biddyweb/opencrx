/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade.base;

import org.bedework.calfacade.CalFacadeDefs;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

/** Base type for a database entity. We require an id and the subclasses must
 * implement hashcode and compareTo.
 *
 * @author Mike Douglass
 * @version 1.0
 *
 * @param <T>
 */
public class BwDbentity<T> implements Comparable<T>, Serializable {
  private int id = CalFacadeDefs.unsavedItemKey;

  /* Hibernate does not implicitly delete db entities during update or
   * save, except for those referenced as part of a Collection.
   *
   * These lists allows us to do explicit deletes when we delete or
   * update the entry.
   */

  private Collection<BwDbentity<?>> deletedEntities;

  /* db version number */
  private int seq;

  /* For quota'd dbentities. */
  private int byteSize;

  /** The last calculated byte size should be stored with the entity. On update
   * call calculateByteSize to get a new value and use the difference to adjust
   * the quota.
   *
   * @param val
   */
  public void setByteSize(int val) {
    byteSize = val;
  }

  /**
   * @return int last byte size
   */
  public int getByteSize() {
    return byteSize;
  }

  /** No-arg constructor
   *
   */
  public BwDbentity() {
  }

  /** Create an entity specifying the fields
   *
   * @param id            int unique ID for the sponsor
   */
  public BwDbentity(int id) {
    this.id = id;
  }

  /**
   * @param val
   */
  public void setId(int val) {
    id = val;
  }

  /**
   * @return int id
   */
  public int getId() {
    return id;
  }

  /** Set the seq for this entity
   *
   * @param val    int seq
   */
  public void setSeq(int val) {
    seq = val;
  }

  /** Get the entity seq
   *
   * @return int    the entity seq
   */
  public int getSeq() {
    return seq;
  }

  /* ====================================================================
   *                   Action methods
   * ==================================================================== */

  /** Add a deleted entity - these may appear as a result of updates.
   * A null parameter is a noop.
   *
   * @param val
   */
  public void addDeletedEntity(BwDbentity<?> val) {
    if ((val == null) || val.unsaved()) {
      return;
    }

    if (deletedEntities == null) {
      deletedEntities = new ArrayList<BwDbentity<?>>();
    }

    deletedEntities.add(val);
  }

  /**
   * @return deleted entities or null
   */
  public Collection<BwDbentity<?>> getDeletedEntities() {
    return deletedEntities;
  }

  /** Called when we are about to delete from the db
   *
   */
  public void beforeDeletion() {
  }

  /** Called after delete from the db
   *
   */
  public void afterDeletion() {
  }

  /** Called when we are about to update the object.
   *
   */
  public void beforeUpdate() {
  }

  /** Called when we are about to save the object. Default to calling before
   * update
   *
   */
  public void beforeSave() {
    beforeUpdate();
  }

  /**
   * @return true if this entity is not saved.
   */
  public boolean unsaved() {
    return getId() == CalFacadeDefs.unsavedItemKey;
  }

  /** Size to use for quotas.
   * @return int
   */
  public int length() {
    return 8;  // overhead
  }

  /* ====================================================================
   *                   Convenience methods
   * ==================================================================== */

  /** This actually returns character size - not byte size. Getting byte size
   * might slow things up.
   *
   * @param val
   * @return int
   */
  protected int stringSize(String val) {
    if (val == null) {
      return 0;
    }

    return val.length();
  }

  protected int collectionSize(Collection<? extends BwDbentity<?>> c) {
    if (c == null) {
      return 0;
    }

    int len = 0;
    for (BwDbentity<?> dbe: c) {
      len += dbe.length();
    }

    return len;
  }

  /** Add our stuff to the StringBuffer
   *
   * @param sb    StringBuffer for result
   */
  protected void toStringSegment(StringBuffer sb) {
    sb.append("id=");
    sb.append(getId());
  }

  /** Add our stuff to the StringBuilder
   *
   * @param sb    StringBuilder for result
   */
  protected void toStringSegment(StringBuilder sb) {
    sb.append("id=");
    sb.append(getId());
  }

  /* ====================================================================
   *                   Object methods
   * The following are required for a db object.
   * ==================================================================== */

  /** Make visible
   * @return Object of class T
   */
  public Object clone() {
    return null;
  }

  public int compareTo(T o) {
    throw new RuntimeException("compareTo must be implemented for a db object");
  }

  public int hashCode() {
    throw new RuntimeException("hashcode must be implemented for a db object");
  }

  /* We always use the compareTo method
   */
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }

    return compareTo((T)obj) == 0;
  }
}
