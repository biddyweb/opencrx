/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade.util;

import org.bedework.calfacade.BwDateTime;
import org.bedework.calfacade.BwFreeBusyComponent;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.timezones.CalTimezones;

import net.fortuna.ical4j.model.DateTime;
import net.fortuna.ical4j.model.Period;

import org.apache.log4j.Logger;

import java.util.TreeSet;

/** Class to help handling of event periods when building free busy information
 * @author douglm
 *
 */
public class EventPeriods {
  private boolean debug;

  private CalTimezones ctz;

  private BwDateTime start;
  private String startTzid;
  private DateTime dtstart;

  private BwDateTime end;
  private String endTzid;
  private DateTime dtend;

  private Object[] periods = new Object[4];

  /**
   * @param ctz
   * @param start
   * @param end
   * @param debug
   * @throws CalFacadeException
   */
  public EventPeriods(CalTimezones ctz,
                      BwDateTime start, BwDateTime end,
                      boolean debug) throws CalFacadeException {
    this.ctz = ctz;
    this.debug = debug;

    this.start = start;
    this.end = end;

    startTzid = start.getTzid();
    endTzid = end.getTzid();

    try {
      dtstart = new DateTime(ctz.getUtc(start.getDtval(), startTzid, null, null));
      dtend = new DateTime(ctz.getUtc(end.getDtval(), endTzid, null, null));
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }

    dtstart.setUtc(true);
    dtend.setUtc(true);
  }

  /**
   * @param pstart
   * @param pend
   * @param owner
   * @param type
   * @throws CalFacadeException
   */
  public void addPeriod(BwDateTime pstart, BwDateTime pend, BwUser owner,
                        int type) throws CalFacadeException {
    // Ignore if times were specified and this period is outside the times

    /* Don't report out of the requested period */

    String dstart;
    String stzid;
    String dend;
    String etzid;

    if ((pstart.after(end)) || (pend.before(start))) {
      //XXX Should get here - but apparently we do.
      return;
    }

    if (pstart.before(start)) {
      dstart = start.getDtval();
      stzid = startTzid;
    } else {
      dstart = pstart.getDtval();
      stzid = pstart.getTzid();
    }

    if (pend.after(end)) {
      dend = end.getDtval();
      etzid = endTzid;
    } else {
      dend = pend.getDtval();
      etzid = pend.getTzid();
    }

    dstart = ctz.getUtc(dstart, stzid, null, owner);
    dend = ctz.getUtc(dend, etzid, null, owner);

    try {
      DateTime psdt = new DateTime(dstart);
      DateTime pedt = new DateTime(dend);

      psdt.setUtc(true);
      pedt.setUtc(true);

      add(new EventPeriod(psdt, pedt, type));
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /**
   * @param pstart
   * @param pend
   * @param owner
   * @param type
   * @throws CalFacadeException
   */
  public void addPeriod(DateTime pstart, DateTime pend, BwUser owner,
                        int type) throws CalFacadeException {
    // Ignore if times were specified and this period is outside the times

    /* Don't report out of the requested period */

    if ((pstart.after(dtend)) || (pend.before(dtstart))) {
      //XXX Should get here - but apparently we do.
      return;
    }

    if (pstart.before(dtstart)) {
      pstart = dtstart;
    }

    if (pend.after(dtend)) {
      pend = dtend;
    }

    add(new EventPeriod(pstart, pend, type));
  }

  /**
   * @param type
   * @return BwFreeBusyComponent or null for no entries
   * @throws CalFacadeException
   */
  @SuppressWarnings("unchecked")
  public BwFreeBusyComponent makeFreeBusyComponent(int type) throws CalFacadeException {
    TreeSet<EventPeriod> eventPeriods = (TreeSet<EventPeriod>)periods[type];
    if (eventPeriods == null) {
      return null;
    }

    BwFreeBusyComponent fbc = new BwFreeBusyComponent();
    fbc.setType(type);

    Period p = null;

    for (EventPeriod ep: eventPeriods) {
      if (debug) {
        trace(ep.toString());
      }

      if (p == null) {
        p = new Period(ep.start, ep.end);
      } else if (ep.start.after(p.getEnd())) {
        // Non adjacent periods
        fbc.addPeriod(p.getStart(), p.getEnd());

        p = new Period(ep.start, ep.end);
      } else if (ep.end.after(p.getEnd())) {
        // Extend the current period
        p = new Period(p.getStart(), ep.end);
      } // else it falls within the existing period
    }

    if (p != null) {
      fbc.addPeriod(p.getStart(), p.getEnd());
    }

    return fbc;
  }

  @SuppressWarnings("unchecked")
  private void add(EventPeriod p) {
    TreeSet<EventPeriod> eps = (TreeSet<EventPeriod>)periods[p.type];
    if (eps == null) {
      eps = new TreeSet<EventPeriod>();
      periods[p.type] = eps;
    }
    eps.add(p);
  }

  private static void trace(String msg) {
    Logger.getLogger(Granulator.class).debug(msg);
  }
}
