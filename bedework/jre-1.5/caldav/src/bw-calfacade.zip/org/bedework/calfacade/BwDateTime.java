/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade;

import org.bedework.calfacade.exc.CalFacadeBadDateException;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.timezones.CalTimezones;
import org.bedework.calfacade.util.CalFacadeUtil;

import java.io.Serializable;
import java.util.Comparator;

import net.fortuna.ical4j.model.Date;
import net.fortuna.ical4j.model.DateTime;
import net.fortuna.ical4j.model.Dur;
import net.fortuna.ical4j.model.Parameter;
import net.fortuna.ical4j.model.ParameterList;
import net.fortuna.ical4j.model.TimeZone;
import net.fortuna.ical4j.model.parameter.Value;
import net.fortuna.ical4j.model.property.DateProperty;
import net.fortuna.ical4j.model.property.DtEnd;
import net.fortuna.ical4j.model.property.DtStart;

/** Class to represent an RFC2445 date and datetime type. These are not stored
 * in separate tables but as components of the including class.
 *
 * <p>DateTime values take 3 forms:
 * <br/>Floating time - not timezone e.g. DTSTART:19980118T230000
 * <br/>UTC time no timezone e.g. DTSTART:19980118T230000Z
 * <br/>Local time with timezone e.g. DTSTART;TZID=US-Eastern:19980119T020000
 *
 * @author Mike Douglass   douglm@rpi.edu
 *  @version 1.0
 */
public class BwDateTime implements Comparable, Comparator, Serializable {
  /** If true this represents a date - not datetime.
   */
  private boolean dateType;

  /** Non-null if one was specified.
   */
  private String tzid;

  private String dtval; // rfc2445 date or datetime value

  /**   */
  public static Dur oneDayForward = new Dur(1, 0, 0, 0);
  /**   */
  public static Dur oneDayBack = new Dur(-1, 0, 0, 0);

  /** This is a UTC datetime value to make searching easier. There are a number of
   * complications to dates, the end date is specified as non-inclusive
   * but there are a number of boundary problems to watch out for.
   *
   * <p>For date only values this field has a zero time appended so that simple
   * string comparisons will work.
   */
  private String date; // For indexing

  private Boolean floatFlag;

  private BwUser tzowner;

  /** Constructor
   */
  public BwDateTime() {
  }

  /** Set the dateType for this timezone
   *
   * @param val   boolean dateType
   */
  public void setDateType(boolean val) {
    dateType = val;
  }

  /** Get the timezone's dateType
   *
   * @return boolean    true for a date type
   */
  public boolean getDateType() {
    return dateType;
  }

  /**  Set the tzid. This should not be used to change the timezone for a value
   * as we may need to recalculate other values based on that change.
   *
   * @param val    String tzid
   */
  public void setTzid(String val) {
    tzid = val;
  }

  /** Get the tzid
   *
   * @return String    tzid
   */
  public String getTzid() {
    return tzid;
  }

  /** Set the dtval - the rfc2445 date or datetime value
   *
   * @param val    String dtval
   */
  private void setDtval(String val) {
    dtval = val;
    if (val == null) {
      setDate(null);
    }
  }

  /** Get the dtval - the rfc2445 date or datetime value
   *
   * @return String   dtval
   */
  public String getDtval() {
    return dtval;
  }

  /** Set the date as a datetime value for comparisons.
   *
   * <p>This is a UTC datetime value to make searching easier. There are a number of
   * complications to dates, the end date is specified as non-inclusive
   * but there are a number of boundary problems to watch out for.
   *
   * <p>For date only values this field has a zero time appended so that simple
   * string comparisons will work.
   *
   * @param val
   */
  public void setDate(String val) {
    date = val;
  }

  /** This is a UTC datetime value to make searching easier. There are a number of
   * complications to dates, the end date is specified as non-inclusive
   * but there are a number of boundary problems to watch out for.
   *
   * <p>For date only values this field has a zero time appended so that simple
   * string comparisons will work.
   *
   * <p>For floating time values this is the same as the dtval made to look like
   * a UTC value.
   *
   * @return String date
   */
  public String getDate() {
    return date;
  }

  /** For non floating values this should be null rather than false. This is
   * sort of a db thing (maybe possible to hide it).
   *
   * <p>Virtually all events are expected to be non-floating but we need to index
   * floating v non-floating.
   *
   * <p>A null value will usually not be indexed so the index will consist of
   * only those that are flaoting time.
   *
   * @param val
   */
  public void setFloatFlag(Boolean val) {
    floatFlag = val;
  }

  /**
   * @return Boolean or null
   */
  public Boolean getFloatFlag() {
    return floatFlag;
  }

  /** This allows us to set the owner from the associated event. We can then use
   * that owner when fetching timezones.
   *
   * @param val
   */
  public void setTzowner(BwUser val) {
    tzowner = val;
  }

  /**
   * @return timezone owner
   */
  public BwUser getTzowner() {
    return tzowner;
  }
  /* ====================================================================
   *                        Conversion methods
   * ==================================================================== */

  /**
   * @param val
   */
  public void setFloating(boolean val) {
    if (!val) {
      setFloatFlag(null);
    } else {
      setFloatFlag(true);
    }
  }

  /**
   * @return boolean
   */
  public boolean getFloating() {
    if (getFloatFlag() == null) {
      return false;
    }
    return floatFlag;
  }

  /**
   * @return true if this represents a valid UTC date
   */
  public boolean isUTC() {
    if (getDateType()) {
      return false;
    }

    try {
      return CalFacadeUtil.isISODateTimeUTC(getDtval());
    } catch (Throwable t) {
      return false;
    }
  }

  /** Make a DtEnd from this object
   *
   * @param timezones
   * @return DtEnd
   * @throws CalFacadeException
   */
  public DtEnd makeDtEnd(CalTimezones timezones) throws CalFacadeException {
    try {
      /*
      String tzid = getTzid();
      ParameterList pl = new ParameterList();

      if (getDateType()) {
        pl.add(Value.DATE);
      } else if (!isUTC() && (tzid != null)) {
        pl.add(new TzId(tzid));
      }

      return new DtEnd(pl, getDtval());*/
      String tzid = getTzid();
      DtEnd dt = new DtEnd();

      ParameterList pl = dt.getParameters();

      if (getDateType()) {
        pl.add(Value.DATE);
      }

      if (tzid != null) {
        dt.setTimeZone(timezones.getTimeZone(tzid, tzowner));
      }

      dt.setValue(getDtval());

      return dt;
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /** Create a copy of this object
   *
   * @param timezones
   * @return BwDateTime
   * @throws CalFacadeException
   */
  public BwDateTime copy(CalTimezones timezones) throws CalFacadeException {
    return makeDateTime(makeDtEnd(timezones), getTzowner(), timezones);
  }

  /** Make a DtStart from this object
   *
   * @param timezones
   * @return DtStart
   * @throws CalFacadeException
   */
  public DtStart makeDtStart(CalTimezones timezones) throws CalFacadeException {
    try {
      /*
      String tzid = null;
      ParameterList pl = new ParameterList();

      if (getDateType()) {
        pl.add(Value.DATE);
      } else if (!isUTC()) {
        tzid = getTzid();
        if (tzid != null) {
          pl.add(new TzId(tzid));
        }
      }

      return new DtStart(pl, getDtval());*/
      String tzid = getTzid();
      DtStart dt = new DtStart();

      ParameterList pl = dt.getParameters();

      if (getDateType()) {
        pl.add(Value.DATE);
      }

      if (tzid != null) {
        dt.setTimeZone(timezones.getTimeZone(tzid, tzowner));
      }

      dt.setValue(getDtval());

      return dt;
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /** Return an ical DateTime or Date object
   *
   * @param timezones
   * @return Date
   * @throws CalFacadeException
   */
  public Date makeDate(CalTimezones timezones) throws CalFacadeException {
    try {
      if (getDateType()) {
        return new Date(getDtval());
      }

      if (tzid != null) {
        return new DateTime(getDtval(), timezones.getTimeZone(tzid, tzowner));
      }

      return new DateTime(getDtval());
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /** Make an ical Dur from a start and end
   *
   * @param start
   * @param end
   * @param timezones
   * @return Dur
   * @throws CalFacadeException
   */
  public static Dur makeDuration(BwDateTime start, BwDateTime end,
                                 CalTimezones timezones)
          throws CalFacadeException {
    return new Dur(start.makeDate(timezones),
                   end.makeDate(timezones));
  }

  /** Make a new date time value based on the dtStart value + the duration.
   *
   * @param dtStart
   * @param dateOnly
   * @param dur
   * @param tzowner
   * @param timezones
   * @return BwDateTime
   * @throws CalFacadeException
   */
  public static BwDateTime makeDateTime(DateProperty dtStart,
                                        boolean dateOnly,
                                        Dur dur, BwUser tzowner,
                                        CalTimezones timezones) throws CalFacadeException {
    DtEnd dtEnd;
    java.util.Date endDt = dur.getTime(dtStart.getDate());

    Parameter tzid = CalFacadeUtil.getIcalParameter(dtStart, "TZID");

    if (dateOnly) {
      dtEnd = new DtEnd(new Date(endDt));
      CalFacadeUtil.addIcalParameter(dtEnd, Value.DATE);
      if (tzid != null) {
        CalFacadeUtil.addIcalParameter(dtEnd, tzid);
      }
    } else {
      DateTime d = new DateTime(endDt);
      if (tzid != null) {
        DateTime sd = (DateTime)dtStart.getDate();

        d.setTimeZone(sd.getTimeZone());
      }
//          dtEnd = new DtEnd(d, dtStart.isUtc());
      dtEnd = new DtEnd(d);
      if (tzid != null) {
        CalFacadeUtil.addIcalParameter(dtEnd, tzid);
      } else if (dtStart.isUtc()) {
        dtEnd.setUtc(true);
      }
    }

    return makeDateTime(dtEnd, tzowner, timezones);
  }

  /** Return a value based on this value plus a duration.
   *
   * @param val
   * @param timezones
   * @return BwDateTime
   * @throws CalFacadeException
   */
  public BwDateTime addDuration(BwDuration val,
                                CalTimezones timezones) throws CalFacadeException {
    DtEnd dtEnd;
    Dur dur = val.makeDuration().getDuration();
    java.util.Date endDt = dur.getTime(makeDate(timezones));
    DtStart dtStart = makeDtStart(timezones);

    if (getDateType()) {
      dtEnd = new DtEnd(new Date(endDt));
      CalFacadeUtil.addIcalParameter(dtEnd, Value.DATE);
    } else {
      DateTime d = new DateTime(endDt);

      Parameter tzid = CalFacadeUtil.getIcalParameter(dtStart, "TZID");
      if (tzid != null) {
        DateTime sd = (DateTime)dtStart.getDate();

        d.setTimeZone(sd.getTimeZone());
      }
//          dtEnd = new DtEnd(d, dtStart.isUtc());
      dtEnd = new DtEnd(d);
      if (tzid != null) {
        CalFacadeUtil.addIcalParameter(dtEnd, tzid);
      } else if (dtStart.isUtc()) {
        dtEnd.setUtc(true);
      }
    }

    return makeDateTime(dtEnd, getTzowner(), timezones);
  }

  /** Make date time based on ical property
   *
   * @param val
   * @param tzowner
   * @param timezones
   * @return BwDateTime
   * @throws CalFacadeException
   */
  public static BwDateTime makeDateTime(DateProperty val,
                                        BwUser tzowner, CalTimezones timezones) throws CalFacadeException {
    BwDateTime dtv = new BwDateTime();
    dtv.initFromDateTime(val, tzowner, timezones);

    return dtv;
  }

  /**
   * @param val
   * @param tzowner
   * @param timezones
   * @throws CalFacadeException
   */
  public void initFromDateTime(DateProperty val,
                               BwUser tzowner, CalTimezones timezones) throws CalFacadeException {
    Parameter par = CalFacadeUtil.getIcalParameter(val, "VALUE");

    init((par != null) && (par.equals(Value.DATE)),
         val.getValue(),
         CalFacadeUtil.getTzid(val), tzowner,
         timezones);
  }

  /** Set utc time
   *
   * @param dateType
   * @param date
   * @throws CalFacadeException
   */
  public void initUTC(boolean dateType, String date) throws CalFacadeException {
    if (!dateType && !date.endsWith("Z")) {
      throw new CalFacadeBadDateException();
    }
    setDateType(dateType);
    setDtval(date);
    setTzid(null);

    if (dateType) {
      setDate(date + "T000000Z");
    } else {
      setDate(date);
    }
  }

  /**
   * @param dateType
   * @param date
   * @param tzid
   * @param tzowner
   * @param timezones
   * @throws CalFacadeException
   */
  public void init(boolean dateType, String date, String tzid,
                   BwUser tzowner,
                   CalTimezones timezones) throws CalFacadeException {
    init(dateType, date, tzid, null, tzowner, timezones);
  }

  /**
   * @param dateType
   * @param date
   * @param tzid
   * @param tz - timezone to use or null
   * @param tzowner
   * @param timezones
   * @throws CalFacadeException
   */
  public void init(boolean dateType, String date, String tzid,
                   TimeZone tz, BwUser tzowner,
                   CalTimezones timezones) throws CalFacadeException {
    if (dateType) {
      if (!CalFacadeUtil.isISODate(date)) {
        throw new CalFacadeException("org.bedework.datetime.expect.dateonly");
      }
    }
    setDateType(dateType);
    setDtval(date);
    setTzid(tzid);
    setTzowner(tzowner);

    if (tzid == null) {
      if (CalFacadeUtil.isISODateTime(date)) {
        setFloatFlag(true);
        setDate(date + "Z");
      }
    }

    if (!getFloating()) {
      setDate(timezones.getUtc(date, tzid, tz, tzowner));
    }
  }

  /** For a date only object returns a date 1 day in advance of this date.
   * Used when moving between displayed and internal values and also when
   * breaking a collection of events up into days.
   *
   * @param timezones
   * @return BwDateTime tomorrow
   * @throws CalFacadeException
   */
  public BwDateTime getNextDay(CalTimezones timezones) throws CalFacadeException {
    if (!getDateType()) {
      throw new CalFacadeException("org.bedework.datetime.expect.dateonly");
    }

    return makeDateTime(makeDtStart(timezones), true, oneDayForward,
                        getTzowner(), timezones);
  }

  /** For a date only object returns a date 1 day previous to this date.
   * Used when moving between displayed and internal values.
   *
   * @param timezones
   * @return BwDateTime yesterday
   * @throws CalFacadeException
   */
  public BwDateTime getPreviousDay(CalTimezones timezones) throws CalFacadeException {
    if (!getDateType()) {
      throw new CalFacadeException("Must be a date only value");
    }

    return makeDateTime(makeDtStart(timezones), true, oneDayBack,
                        getTzowner(), timezones);
  }

  /** Add a duration and return the result
   *
   * @param d      Dur
   * @param timezones
   * @return BwDateTime
   * @throws CalFacadeException
   */
  public BwDateTime addDur(Dur d,
                           CalTimezones timezones) throws CalFacadeException {
    return makeDateTime(makeDtStart(timezones), true, d,
                        getTzowner(), timezones);
  }

  /* ====================================================================
   *                        Object methods
   * ==================================================================== */

  public int compare(Object o1, Object o2) {
    if (o1 == o2) {
      return 0;
    }

    if (!(o1 instanceof BwDateTime)) {
      return -1;
    }

    if (!(o2 instanceof BwDateTime)) {
      return 1;
    }

    BwDateTime dt1 = (BwDateTime)o1;
    BwDateTime dt2 = (BwDateTime)o2;

    return dt1.getDate().compareTo(dt2.getDate());
  }

  public int compareTo(Object o2) {
    return compare(this, o2);
  }

  /** Return true if this is before val
   *
   * @param val
   * @return boolean this before val
   */
  public boolean before(BwDateTime val) {
    return compare(this, val) < 0;
  }

  /** Return true if this is after val
   *
   * @param val
   * @return boolean this after val
   */
  public boolean after(BwDateTime val) {
    return compare(this, val) > 0;
  }

  public int hashCode() {
    int hc = 1;

    if (getDateType()) {
      hc = 3;
    }

    if (getTzid() != null) {
      hc *= getTzid().hashCode();
    }

    if (getDtval() != null) {
      hc *= getDtval().hashCode();
    }

    return hc;
  }

  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }

    if (!(obj instanceof BwDateTime)) {
      return false;
    }

    BwDateTime that = (BwDateTime)obj;

    if (getDateType() != that.getDateType()) {
      return false;
    }

    if (!CalFacadeUtil.eqObjval(getTzid(), that.getTzid())) {
      return false;
    }

    return CalFacadeUtil.eqObjval(getDtval(), that.getDtval());
  }

  public Object clone() {
    BwDateTime ndt = new BwDateTime();

    ndt.setDateType(getDateType());
    ndt.setTzid(getTzid());
    ndt.setDtval(getDtval());
    ndt.setDate(getDate());
    ndt.setFloatFlag(getFloatFlag());

    return ndt;
  }

  public String toString() {
    StringBuffer sb = new StringBuffer();

    sb.append("BwDateTime{");
    if (getDateType()) {
      sb.append("DATE");
    } else {
      sb.append("DATETIME");
    }
    if (getTzid() != null) {
      sb.append(", tzid=");
      sb.append(getTzid());
    }
    sb.append(", dtval=");
    sb.append(getDtval());

    if (getFloating()) {
      sb.append(", floating");
    } else if (isUTC()) {
      sb.append(", UTC");
    } else {
      sb.append(", UTC=");
      sb.append(getDate());
    }
    sb.append("}");

    return sb.toString();
  }
}
