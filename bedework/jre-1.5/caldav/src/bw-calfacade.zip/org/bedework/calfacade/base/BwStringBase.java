/* **********************************************************************
    Copyright 2007 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade.base;

import org.bedework.calfacade.base.BwDbentity;
import org.bedework.calfacade.util.CalFacadeUtil;

import edu.rpi.sss.util.Util;

import net.fortuna.ical4j.model.Parameter;
import net.fortuna.ical4j.model.parameter.Language;

import java.util.Collection;

/** A base class for String values in bedework. This allows for i18n etc.
 * It also allows for moving all long strings to one or two tables.
 *
 * RFC 2445 has the following properties with a language param:
 * <pre>
 * ATTENDEE    (cn param)
 * CATEGORIES
 * COMMENT
 * CONTACT
 * DESCRIPTION
 * LOCATION
 * ORGANIZER   (cn param)
 * REQUEST-STATUS
 * RESOURCES
 * SUMMARY
 * TZNAME
 * </pre>
 * x-properties can also take the language param.
 *.
 *  @version 1.0
 */
public class BwStringBase extends BwDbentity<BwStringBase> {
  private String lang;

  private String value;

  /** Constructor
   */
  public BwStringBase() {
    super();
  }

  /** Create a string by specifying all its fields
   *
   * @param lang        String language code
   * @param value       String value
   */
  public BwStringBase(String lang,
                      String value) {
    super();
    this.lang = lang;
    this.value = value;
  }

  /** Set the lang
   *
   * @param val    String lang
   */
  public void setLang(String val) {
    lang = val;
  }

  /** Get the lang
   *
   * @return String   lang
   */
  public String getLang() {
    return lang;
  }

  /** Set the value
   *
   * @param val    String value
   */
  public void setValue(String val) {
    value = val;
  }

  /** Get the value
   *
   *  @return String   value
   */
  public String getValue() {
    return value;
  }

  /* ====================================================================
   *                        Convenience methods
   * ==================================================================== */

  /** Search the collection for a string that matches the given language code.
   *<p>A supplied lang of null implies the default language code.
   *
   * <p>If the supplied language equals any language in the collection we return
   * with that.
   *
   * <p>Otherwise if if matches the first part of a qualified code we take that,
   * e.g lan="en" could match "en_US"
   *
   * <p>Otherwise we return the first one we found.
   *
   * @param lang
   * @param c
   * @return BwString or null if no strings.
   */
  protected static BwStringBase findLang(String lang,
                                         Collection<? extends BwStringBase> c) {
    if (c == null) {
      return null;
    }

    BwStringBase matched = null;
    BwStringBase def = null;
    int len = 0;
    if (lang != null) {
      len = lang.length();
    }

    for (BwStringBase s: c) {
      if (def == null) {
        // Make sure we get something
        def = s;
      }

      String slang = s.getLang();

      if (lang == null) {
        if ((slang == null) ||
            (CalFacadeUtil.cmpObjval(CalFacadeUtil.defLang, slang) == 0)) {
          return s;
        }
      } else {
        if (CalFacadeUtil.cmpObjval(lang, slang) == 0) {
          return s;
        }

        if ((matched == null) && (len < slang.length()
            && slang.startsWith(lang))) {
          matched = s;
          def = s;
        }
      }
    }

    return def;
  }

  /** Figure out what's different and update it. This should reduce the number
   * of spurious changes to the db.
   *
   * @param from
   * @return true if we changed something.
   */
  public boolean update(BwStringBase from) {
    boolean changed = false;

    if (CalFacadeUtil.cmpObjval(getLang(), from.getLang()) != 0) {
      setLang(from.getLang());
      changed = true;
    }

    if (CalFacadeUtil.cmpObjval(getValue(), from.getValue()) != 0) {
      setValue(from.getValue());
      changed = true;
    }

    return changed;
  }

  /** If there is a language attached return as a parameter else return null
   *
   * @return Language or null
   */
  public Parameter getLangPar() {
    if (getLang() == null) {
      return null;
    }

    return new Language(getLang());
  }

  /** Check this is properly trimmed
   *
   * @return boolean true if changed
   */
  public boolean checkNulls() {
    boolean changed = false;

    String str = Util.checkNull(getLang());
    if (CalFacadeUtil.compareStrings(str, getLang()) != 0) {
      setLang(str);
      changed = true;
    }

    str = Util.checkNull(getValue());
    if (CalFacadeUtil.compareStrings(str, getValue()) != 0) {
      setValue(str);
      changed = true;
    }

    return changed;
  }

  /** Size to use for quotas.
   *
   * @return int
   */
  public int length() {
    return super.length() +
           stringSize(getLang()) +
           stringSize(getValue());
  }

  /* ====================================================================
   *                        Object methods
   * ==================================================================== */

  public int compareTo(BwStringBase that) {
    if (that == this) {
      return 0;
    }

    if (that == null) {
      return -1;
    }

    int res = CalFacadeUtil.cmpObjval(getLang(), that.getLang());

    if (res != 0) {
      return res;
    }

    return CalFacadeUtil.cmpObjval(getValue(), that.getValue());
  }

  public int hashCode() {
    int hc = 7;

    if (getLang() != null) {
      hc *= getLang().hashCode();
    }

    if (getValue() != null) {
      hc *= getValue().hashCode();
    }

    return hc;
  }

  protected void toStringSegment(StringBuilder sb) {
    super.toStringSegment(sb);
    sb.append(", lang=");
    sb.append(getLang());
    sb.append(", value=");
    sb.append(getValue());
  }

  public String toString() {
    StringBuilder sb = new StringBuilder("BwStringBase{");

    toStringSegment(sb);

    return sb.toString();
  }

  public Object clone() {
    return new BwStringBase(getLang(),
                        getValue());
  }
}
