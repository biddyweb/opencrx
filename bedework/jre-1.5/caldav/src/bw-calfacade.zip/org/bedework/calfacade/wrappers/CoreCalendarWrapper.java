/* **********************************************************************
    Copyright 2007 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade.wrappers;

import org.bedework.calfacade.BwCalendar;
import org.bedework.calfacade.BwCategory;
import org.bedework.calfacade.BwProperty;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.util.AccessUtilI;

import edu.rpi.cmt.access.Acl.CurrentAccess;

import java.util.Collection;

/** An object to wrap a calendar entity in Bedework. This allows us to limit
 * access to methods and attach thread or session information to the entity.
 *
 * <p>We should block access to methods if the caller does not have appropriate
 * access.
 *
 *   @author Mike Douglass douglm @ rpi.edu
 *  @version 1.0
 */
public class CoreCalendarWrapper extends BwCalendar {
  private AccessUtilI access;

  private BwCalendar entity;

  private BwCalendar parent;

  /* Current access for the user.
   */
  private CurrentAccess currentAccess;

  // ui support
  private boolean open;

  /** Constructor
   *
   * @param entity
   * @param access
   */
  public CoreCalendarWrapper(BwCalendar entity, AccessUtilI access) {
    this.entity = entity;
    this.access = access;
  }

  /** Not a getter to avoid it being accessible to the world.
   *
   * @return BwCalendar contained entity
   */
  public BwCalendar unwrap() {
    return entity;
  }

  /* ====================================================================
   *                   BwDbentity methods
   * ==================================================================== */

  public void setId(int val) {
    entity.setId(val);
  }

  public int getId() {
    return entity.getId();
  }

  public void setSeq(int val) {
    entity.setSeq(val);
  }

  public int getSeq() {
    return entity.getSeq();
  }

  /* ====================================================================
   *                   BwOwnedDbentity methods
   * ==================================================================== */

  /** Set the owner
   *
   * @param val     UserVO owner of the entity
   */
  public void setOwner(BwUser val) {
    entity.setOwner(val);
  }

  /**
   *
   * @return UserVO    owner of the entity
   */
  public BwUser getOwner() {
    return entity.getOwner();
  }

  /**
   * @param val
   */
  public void setPublick(boolean val) {
    entity.setPublick(val);
  }

  /**
   * @return boolean true for public
   */
  public boolean getPublick() {
    return entity.getPublick();
  }

  /* ====================================================================
   *                   BwShareableDbentity methods
   * ==================================================================== */

  public void setCreator(BwUser val) {
    entity.setCreator(val);
  }

  public BwUser getCreator() {
    return entity.getCreator();
  }

  public void setAccess(String val) {
    entity.setAccess(val);
  }

  public String getAccess() {
    return entity.getAccess();
  }

  /* ====================================================================
   *                   BwShareableContainedDbentity methods
   * ==================================================================== */

  // CALWRAPPER

  public void setCalendar(BwCalendar val) {
    entity.setCalendar(val);
  }

  // CALWRAPPER

  public BwCalendar getCalendar() {
    if (parent == null) {
      if (entity.getCalendar() == null) {
        return null;
      }
      parent = new CoreCalendarWrapper(entity.getCalendar(), access);
    }

    return parent;
  }

  /* ====================================================================
   *                   Bean methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwCalendar#setName(java.lang.String)
   */
  public void setName(String val) {
    entity.setName(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwCalendar#getName()
   */
  public String getName() {
    return entity.getName();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwCalendar#setPath(java.lang.String)
   */
  public void setPath(String val) {
    entity.setPath(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwCalendar#getPath()
   */
  public String getPath() {
    return entity.getPath();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwCalendar#setSummary(java.lang.String)
   */
  public void setSummary(String val) {
    entity.setSummary(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwCalendar#getSummary()
   */
  public String getSummary() {
    return entity.getSummary();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwCalendar#setDescription(java.lang.String)
   */
  public void setDescription(String val) {
    entity.setDescription(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwCalendar#getDescription()
   */
  public String getDescription() {
    return entity.getDescription();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwCalendar#setMailListId(java.lang.String)
   */
  public void setMailListId(String val) {
    entity.setMailListId(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwCalendar#getMailListId()
   */
  public String getMailListId() {
    return entity.getMailListId();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwCalendar#setCalendarCollection(boolean)
   */
  public void setCalendarCollection(boolean val) {
    entity.setCalendarCollection(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwCalendar#getCalendarCollection()
   */
  public boolean getCalendarCollection() {
    return entity.getCalendarCollection();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwCalendar#setChildren(java.util.Collection)
   */
  public void setChildren(Collection<BwCalendar> val) {
    // CALWRAPPER  block this one?
    entity.setChildren(val);
  }

  /**  Get the Collection of children.
   * @see org.bedework.calfacade.BwCalendar#getChildren()
   *
   * <p>This method is blocked as, in general, callers do not have access to all
   * the children. api methods are provided to return the children of a calendar
   * object and these return only those children to which the caller has access.
   *
   * @return Collection   Calendar children for this calendar
   */
  public Collection<BwCalendar> getChildren() {
    throw new RuntimeException("org.bedework.noaccess");
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwCalendar#setCalType(int)
   */
  public void setCalType(int val) {
    entity.setCalType(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwCalendar#getCalType()
   */
  public int getCalType() {
    return entity.getCalType();
  }

  /**
   * @param val
   */
  public void setLastmod(String val) {
    // Can come from constructor
    if (entity != null) {
      entity.setLastmod(val);
    }
  }

  /**
   * @return String lastmod
   */
  public String getLastmod() {
    return entity.getLastmod();
  }

  /** Set the sequence
   *
   * @param val    sequence number
   */
  public void setSequence(int val) {
    entity.setSequence(val);
  }

  /** Get the sequence
   *
   * @return int    the sequence
   */
  public int getSequence() {
    return entity.getSequence();
  }

  /* ====================================================================
   *               CategorisedEntity interface methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#setCategories(java.util.Collection)
   */
  public void setCategories(Collection<BwCategory> val) {
    entity.setCategories(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#getCategories()
   */
  public Collection<BwCategory> getCategories() {
    return entity.getCategories();
  }

  /* ====================================================================
   *                   Property methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwCalendar#setProperties(java.util.Collection)
   */
  public void setProperties(Collection<BwProperty> val) {
    entity.setProperties(val);
  }

  /**
   * @return properties
   */
  public Collection<BwProperty> getProperties() {
    return entity.getProperties();
  }

  /* ====================================================================
   *                   Wrapper object methods
   * ==================================================================== */

  /**
   *
   * @param val CurrentAccess
   */
  public void setCurrentAccess(CurrentAccess val) throws CalFacadeException {
    currentAccess = val;
  }

  /**
   * @return CurrentAccess
   */
  public CurrentAccess getCurrentAccess() throws CalFacadeException {
    if (currentAccess == null) {
      currentAccess = access.checkAccess(entity, AccessUtilI.privAny, true);
    }
    return currentAccess;
  }

  /**
   * @param val ui open state
   */
  public void setOpen(boolean val) {
    open = val;
  }

  /**
   * @return ui open state
   */
  public boolean getOpen() {
    return open;
  }

  /* ====================================================================
   *                   Convenience methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwCalendar#getCollectionInfo()
   */
  public CollectionInfo getCollectionInfo() {
    return collectionInfo[entity.getCalType()];
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwCalendar#addChild(org.bedework.calfacade.BwCalendar)
   */
  public void addChild(BwCalendar val) {
    entity.addChild(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwCalendar#removeChild(org.bedework.calfacade.BwCalendar)
   */
  public void removeChild(BwCalendar val) {
    entity.removeChild(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwCalendar#hasChildren()
   */
  public boolean hasChildren() {
    return entity.hasChildren();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwCalendar#getNumChildren()
   */
  public int getNumChildren() {
    return entity.getNumChildren();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwCalendar#getEncodedPath()
   */
  public String getEncodedPath() throws CalFacadeException {
    return entity.getEncodedPath();
  }

  /** Are we cloning this or the contained entity?
   *
   * @return BwCalendar object
   */
  public BwCalendar shallowClone() {
    return entity.shallowClone();
  }

  /** Update last mod fields
   */
  public void updateLastmod() {
    entity.updateLastmod();
  }

  /* ====================================================================
   *                   Object methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.BwDbentity#compareTo(java.lang.Object)
   */
  public int compareTo(BwCalendar o) {
    return entity.compareTo(o);
  }

  public int hashCode() {
    return entity.hashCode();
  }

  public String toString() {
    StringBuffer sb = new StringBuffer("CoreCalendarWrapper{");

    sb.append(entity.toString());

    try {
      if (getCurrentAccess() != null) {
        sb.append(", currentAccess=");
        sb.append(getCurrentAccess());
      }
    } catch (CalFacadeException cfe) {
      sb.append("exception");
      sb.append(cfe.getMessage());
    }
    sb.append("}");

    return sb.toString();
  }

  public Object clone() {
    return entity.clone();
  }
}
