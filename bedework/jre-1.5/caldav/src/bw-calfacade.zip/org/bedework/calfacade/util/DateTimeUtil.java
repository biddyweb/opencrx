/* **********************************************************************
    Copyright 2007 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade.util;

import org.bedework.calfacade.BwDateTime;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.exc.CalFacadeBadDateException;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.timezones.CalTimezones;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Date and time utilities
 *
 * @author Mike Douglass     douglm - rpi.edu
 *  @version 1.0
 */
public class DateTimeUtil {
  private static final DateFormat isoDateFormat =
      new SimpleDateFormat("yyyyMMdd");

  private static final DateFormat rfcDateFormat =
    new SimpleDateFormat("yyyy'-'MM'-'dd");

  private static final DateFormat isoDateTimeFormat =
      new SimpleDateFormat("yyyyMMdd'T'HHmmss");

  private static final DateFormat rfcDateTimeFormat =
    new SimpleDateFormat("yyyy'-'MM'-'dd'T'HH':'mm':'ss");

  private static final DateFormat isoDateTimeTZFormat =
      new SimpleDateFormat("yyyyMMdd'T'HHmmss");

  private static final DateFormat rfcDateTimeTZFormat =
      new SimpleDateFormat("yyyy'-'MM'-'dd'T'HH':'mm':'ss");

  private static final DateFormat isoDateTimeUTCTZFormat =
      new SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'");

  private static final DateFormat rfcDateTimeUTCTZFormat =
    new SimpleDateFormat("yyyy'-'MM'-'dd'T'HH':'mm':'ss'Z'");

  private static final DateFormat isoDateTimeUTCFormat =
      new SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'");

  private static final DateFormat rfcDateTimeUTCFormat =
    new SimpleDateFormat("yyyy'-'MM'-'dd'T'HH':'mm':'ss'Z'");

  private static final DateFormat rfc822GMTFormat =
    new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss Z");

  static {
    isoDateTimeUTCFormat.setTimeZone(net.fortuna.ical4j.model.TimeZone.getTimeZone(
                                 net.fortuna.ical4j.util.TimeZones.UTC_ID));
    isoDateTimeUTCFormat.setLenient(false);

    rfcDateTimeUTCFormat.setTimeZone(net.fortuna.ical4j.model.TimeZone.getTimeZone(
                                 net.fortuna.ical4j.util.TimeZones.UTC_ID));
    rfcDateTimeUTCFormat.setLenient(false);

    rfc822GMTFormat.setTimeZone(net.fortuna.ical4j.model.TimeZone.getTimeZone(
                                 net.fortuna.ical4j.util.TimeZones.UTC_ID));
  }

  private DateTimeUtil() {
  }

  /**
   * @return Date value for yesterday.
   */
  public static Date yesterday() {
    Calendar cal = Calendar.getInstance();
    cal.add(Calendar.DATE, -1);

    return cal.getTime();
  }

  /** Turn Date into "yyyyMMdd"
   *
   * @param val date
   * @return String "yyyyMMdd"
   */
  public static String isoDate(Date val) {
    synchronized (isoDateFormat) {
      return isoDateFormat.format(val);
    }
  }

  /** Turn Now into "yyyyMMdd"
   *
   * @return String "yyyyMMdd"
   */
  public static String isoDate() {
    return isoDate(new Date());
  }

  /** Turn Date into "yyyy-MM-dd"
   *
   * @param val date
   * @return String "yyyy-MM-dd"
   */
  public static String rfcDate(Date val) {
    synchronized (rfcDateFormat) {
      return rfcDateFormat.format(val);
    }
  }

  /** Turn Now into "yyyy-MM-dd"
   *
   * @return String "yyyy-MM-dd"
   */
  public static String rfcDate() {
    return rfcDate(new Date());
  }

  /** Turn Date into "yyyyMMddTHHmmss"
   *
   * @param val date
   * @return String "yyyyMMddTHHmmss"
   */
  public static String isoDateTime(Date val) {
    synchronized (isoDateTimeFormat) {
      return isoDateTimeFormat.format(val);
    }
  }

  /** Get Now as "yyyyMMddTHHmmss"
   *
   * @return String "yyyyMMddTHHmmss"
   */
  public static String isoDateTime() {
    return  isoDateTime(new Date());
  }

  /** Turn Date into "yyyyMMddTHHmmss" for a given timezone
   *
   * @param val date
   * @param tz TimeZone
   * @return String "yyyyMMddTHHmmss"
   */
  public static String isoDateTime(Date val, TimeZone tz) {
    synchronized (isoDateTimeTZFormat) {
      isoDateTimeTZFormat.setTimeZone(tz);
      return isoDateTimeTZFormat.format(val);
    }
  }

  /** Turn Date into "yyyy-MM-ddTHH:mm:ss"
   *
   * @param val date
   * @return String "yyyy-MM-ddTHH:mm:ss"
   */
  public static String rfcDateTime(Date val) {
    synchronized (rfcDateTimeFormat) {
      return rfcDateTimeFormat.format(val);
    }
  }

  /** Get Now as "yyyy-MM-ddTHH:mm:ss"
   *
   * @return String "yyyy-MM-ddTHH:mm:ss"
   */
  public static String rfcDateTime() {
    return  rfcDateTime(new Date());
  }

  /** Turn Date into "yyyy-MM-ddTHH:mm:ss" for a given timezone
   *
   * @param val date
   * @param tz TimeZone
   * @return String "yyyy-MM-ddTHH:mm:ss"
   */
  public static String rfcDateTime(Date val, TimeZone tz) {
    synchronized (rfcDateTimeTZFormat) {
      rfcDateTimeTZFormat.setTimeZone(tz);
      return rfcDateTimeTZFormat.format(val);
    }
  }

  /** Turn Date into "yyyyMMddTHHmmssZ"
   *
   * @param val date
   * @return String "yyyyMMddTHHmmssZ"
   */
  public static String isoDateTimeUTC(Date val) {
    synchronized (isoDateTimeUTCFormat) {
      return isoDateTimeUTCFormat.format(val);
    }
  }

  /** Turn Date into "yyyy-MM-ddTHH:mm:ssZ"
   *
   * @param val date
   * @return String "yyyy-MM-ddTHH:mm:ssZ"
   */
  public static String rfcDateTimeUTC(Date val) {
    synchronized (rfcDateTimeUTCFormat) {
      return rfcDateTimeUTCFormat.format(val);
    }
  }

  /** Turn Date into "???"
   *
   * @param val date
   * @return String "???"
   */
  public static String rfc822Date(Date val) {
    synchronized (rfc822GMTFormat) {
      return rfc822GMTFormat.format(val);
    }
  }

  /** Get Date from "yyyyMMdd"
   *
   * @param val String "yyyyMMdd"
   * @return Date
   * @throws CalFacadeException
   */
  public static Date fromISODate(String val) throws CalFacadeException {
    try {
      synchronized (isoDateFormat) {
        return isoDateFormat.parse(val);
      }
    } catch (Throwable t) {
      throw new CalFacadeBadDateException();
    }
  }

  /** Get Date from "yyyy-MM-dd"
   *
   * @param val String "yyyy-MM-dd"
   * @return Date
   * @throws CalFacadeException
   */
  public static Date fromRfcDate(String val) throws CalFacadeException {
    try {
      synchronized (rfcDateFormat) {
        return rfcDateFormat.parse(val);
      }
    } catch (Throwable t) {
      throw new CalFacadeBadDateException();
    }
  }

  /** Get Date from "yyyyMMddThhmmss"
   *
   * @param val String "yyyyMMddThhmmss"
   * @return Date
   * @throws CalFacadeException
   */
  public static Date fromISODateTime(String val) throws CalFacadeException {
    try {
      synchronized (isoDateTimeFormat) {
        return isoDateTimeFormat.parse(val);
      }
    } catch (Throwable t) {
      throw new CalFacadeBadDateException();
    }
  }

  /** Get Date from "yyyy-MM-ddThh:mm:ss"
   *
   * @param val String "yyyy-MM-ddThh:mm:ss"
   * @return Date
   * @throws CalFacadeException
   */
  public static Date fromRfcDateTime(String val) throws CalFacadeException {
    try {
      synchronized (rfcDateTimeFormat) {
        return rfcDateTimeFormat.parse(val);
      }
    } catch (Throwable t) {
      throw new CalFacadeBadDateException();
    }
  }

  /** Get Date from "yyyyMMddThhmmss" with timezone
   *
   * @param val String "yyyyMMddThhmmss"
   * @param tz TimeZone
   * @return Date
   * @throws CalFacadeException
   */
  public static Date fromISODateTime(String val,
                                     TimeZone tz) throws CalFacadeException {
    try {
      synchronized (isoDateTimeTZFormat) {
        isoDateTimeTZFormat.setTimeZone(tz);
        return isoDateTimeTZFormat.parse(val);
      }
    } catch (Throwable t) {
      throw new CalFacadeBadDateException();
    }
  }

  /** Get Date from "yyyy-MM-ddThh:mm:ss" with timezone
   *
   * @param val String "yyyy-ddThh:mm:ss"
   * @param tz TimeZone
   * @return Date
   * @throws CalFacadeException
   */
  public static Date fromRfcDateTime(String val,
                                     TimeZone tz) throws CalFacadeException {
    try {
      synchronized (rfcDateTimeTZFormat) {
        rfcDateTimeTZFormat.setTimeZone(tz);
        return rfcDateTimeTZFormat.parse(val);
      }
    } catch (Throwable t) {
      throw new CalFacadeBadDateException();
    }
  }

  /** Get Date from "yyyyMMddThhmmssZ" with timezone
   *
   * @param val String "yyyyMMddThhmmssZ"
   * @param tz TimeZone
   * @return Date
   * @throws CalFacadeException
   */
  public static Date fromISODateTimeUTC(String val,
                                        TimeZone tz) throws CalFacadeException {
    try {
      synchronized (isoDateTimeUTCTZFormat) {
        isoDateTimeUTCTZFormat.setTimeZone(tz);
        return isoDateTimeUTCTZFormat.parse(val);
      }
    } catch (Throwable t) {
      throw new CalFacadeBadDateException();
    }
  }

  /** Get Date from "yyyyMMddThhmmssZ"
   *
   * @param val String "yyyyMMddThhmmssZ"
   * @return Date
   * @throws CalFacadeException
   */
  public static Date fromISODateTimeUTC(String val) throws CalFacadeException {
    try {
      synchronized (isoDateTimeUTCFormat) {
        return isoDateTimeUTCFormat.parse(val);
      }
    } catch (Throwable t) {
      throw new CalFacadeBadDateException();
    }
  }

  /** Get Date from "yyyy-MM-ddThh:mm:ssZ"
   *
   * @param val String "yyyy-MM-ddThh:mm:ssZ"
   * @return Date
   * @throws CalFacadeException
   */
  public static Date fromRfcDateTimeUTC(String val) throws CalFacadeException {
    try {
      synchronized (rfcDateTimeUTCFormat) {
        return rfcDateTimeUTCFormat.parse(val);
      }
    } catch (Throwable t) {
      throw new CalFacadeBadDateException();
    }
  }

  /** Get RFC822 form from "yyyyMMddThhmmssZ"
   *
   * @param val String "yyyyMMddThhmmssZ"
   * @return Date
   * @throws CalFacadeException
   */
  public static String fromISODateTimeUTCtoRfc822(String val) throws CalFacadeException {
    try {
      synchronized (isoDateTimeUTCFormat) {
        return rfc822Date(isoDateTimeUTCFormat.parse(val));
      }
    } catch (Throwable t) {
      throw new CalFacadeBadDateException();
    }
  }

  /** Check Date is "yyyyMMdd"
   *
   * @param val String to check
   * @return boolean
   * @throws CalFacadeException
   */
  public static boolean isISODate(String val) throws CalFacadeException {
    try {
      if (val.length() != 8) {
        return false;
      }
      fromISODate(val);
      return true;
    } catch (Throwable t) {
      return false;
    }
  }

  /** Check Date is "yyyyMMddThhmmddZ"
   *
   * @param val String to check
   * @return boolean
   * @throws CalFacadeException
   */
  public static boolean isISODateTimeUTC(String val) throws CalFacadeException {
    try {
      if (val.length() != 16) {
        return false;
      }
      fromISODateTimeUTC(val);
      return true;
    } catch (Throwable t) {
      return false;
    }
  }

  /** Check Date is "yyyyMMddThhmmdd"
   *
   * @param val String to check
   * @return boolean
   * @throws CalFacadeException
   */
  public static boolean isISODateTime(String val) throws CalFacadeException {
    try {
      if (val.length() != 15) {
        return false;
      }
      fromISODateTime(val);
      return true;
    } catch (Throwable t) {
      return false;
    }
  }

  /** Get a java.util.Date object from the value
   * XXX - this will neeed to be supplied with a tz repository
   *
   * @param val
   * @param timezones
   * @return Date object representing the date
   * @throws CalFacadeException
   */
  public static Date getDate(BwDateTime val,
                             CalTimezones timezones) throws CalFacadeException {
    String dtval = val.getDtval();

    try {
      if (val.getDateType()) {
        return fromISODate(dtval);
      }

      if (dtval.endsWith("Z")) {
        return fromISODateTimeUTC(dtval);
      }

      String tzid = val.getTzid();
      if (tzid == null) {
        return fromISODateTime(dtval);
      }

      return fromISODateTime(dtval,
                             timezones.getTimeZone(tzid, val.getTzowner()));
    } catch (CalFacadeException cfe) {
      throw cfe;
    } catch (Throwable t) {
      throw new CalFacadeBadDateException();
    }
  }

  /** Get a date/time object representing the given date and time
   *
   * @param date       Java Date object
   * @param timezones
   * @return BwDateTime object representing the date
   * @throws CalFacadeException
   */
  public static BwDateTime getDateTime(Date date,
                                       CalTimezones timezones) throws CalFacadeException {
    String dtval = isoDateTime(date);
    return getDateTime(dtval, false, false, false, null, null, null,
                       timezones);
  }

  /** Get a date object representing the given date and flags
   *
   * @param date       String iso date or date/time
   * @param dateOnly
   * @param UTC
   * @param floating    boolean true if this is a floating time
   * @param tzid - String tzid or null for default, UTC or floating.
   * @param tzowner
   * @param timezones
   * @return Date object representing the date
   * @throws CalFacadeException
   */
  public static BwDateTime getDateTime(String date, boolean dateOnly,
                                       boolean UTC, boolean floating,
                                       String tzid, BwUser tzowner,
                                       CalTimezones timezones) throws CalFacadeException {
    return getDateTime(date, dateOnly, UTC, floating, tzid, null, tzowner,
                       timezones);
  }

  /** Get a date object representing the given date and flags
   *
   * @param date       String iso date or date/time
   * @param dateOnly
   * @param UTC
   * @param floating    boolean true if this is a floating time
   * @param tzid - String tzid or null for default, UTC or floating.
   * @param tz - timezone to use
   * @param tzowner
   * @param timezones
   * @return Date object representing the date
   * @throws CalFacadeException
   */
  public static BwDateTime getDateTime(String date, boolean dateOnly,
                                       boolean UTC, boolean floating,
                                       String tzid,
                                       net.fortuna.ical4j.model.TimeZone tz,
                                       BwUser tzowner,
                                       CalTimezones timezones) throws CalFacadeException {
    BwDateTime dtm = new BwDateTime();

    if (dateOnly || UTC || floating) {
      tzid = null;
    }

    if (tz != null) {
      tzid = tz.getID();
    } else if (tzid != null) {
      tz = timezones.getTimeZone(tzid, tzowner);
      if (tz == null) {
        throw new CalFacadeException(CalFacadeException.unknownTimezone, tzid);
      }
    } else if (!UTC && !floating) {
      // Asking for default
      tzid = timezones.getDefaultTimeZoneId();
      tz = timezones.getDefaultTimeZone();
    }

    if (isISODateTimeUTC(date) && !UTC) {
      // Convert to local time (relative to supplied timezone)

      Date dt = fromISODateTimeUTC(date);
      date = isoDateTime(dt, tz);
    }

    dtm.init(dateOnly, date, tzid, tz, tzowner, timezones);

    return dtm;
  }

  /** Get a date object representing the given String UTC date/time
   *
   * @param date
   * @return BwDateTime object representing the date
   * @throws CalFacadeException
   */
  public static BwDateTime getDateTimeUTC(String date) throws CalFacadeException {
    BwDateTime dtm = new BwDateTime();

    dtm.initUTC(false, date);

    return dtm;
  }

  /** */
  public static class DatePeriod {
    /** ISO */
    public BwDateTime start;
    /** ISO */
    public BwDateTime end;
  }

  /** Get a date/time range given by the rfc formatted parameters and limited to
   * the given max range
   *
   * @param start
   * @param end
   * @param defaultField
   * @param defaultVal
   * @param maxField
   * @param maxVal
   * @param tzs
   * @return DatePeriod or null for bad request
   * @throws CalFacadeException
   */
  public static DatePeriod getPeriod(String start, String end,
                               int defaultField, int defaultVal,
                               int maxField, int maxVal,
                               CalTimezones tzs) throws CalFacadeException {
    Locale loc = Locale.getDefault();  // XXX Locale
    Calendar startCal = Calendar.getInstance(loc);
    Calendar endCal = Calendar.getInstance(loc);

    Date jdt;

    if (start != null) {
      if (start.indexOf("T") < 0) {
        jdt = fromRfcDate(start);
      } else {
        jdt = fromRfcDateTimeUTC(start);
      }
      startCal.setTime(jdt);
    }

    if (end == null) {
      // 1 week
      endCal.add(Calendar.WEEK_OF_YEAR, 1);
    } else {
      if (end.indexOf("T") < 0) {
        jdt = fromRfcDate(end);
      } else {
        jdt = fromRfcDateTimeUTC(end);
      }
      endCal.setTime(jdt);
    }

    // Don't allow more than a month
    Calendar check = Calendar.getInstance(loc);
    check.setTime(startCal.getTime());
    check.add(Calendar.DATE, 32);

    if (check.before(endCal)) {
      return null;
    }

    DatePeriod dp = new DatePeriod();

    dp.start = DateTimeUtil.getDateTime(isoDateTime(startCal.getTime()),
                                        false,
                                        false,
                                        false,   // floating
                                        null,   // tzid
                                        null,   // tzowner
                                        tzs);
    dp.end = DateTimeUtil.getDateTime(isoDateTime(endCal.getTime()),
                                      false,
                                      false,
                                      false,   // floating
                                      null,   // tzid
                                      null,   // tzowner
                                      tzs);

    return dp;
  }
}
