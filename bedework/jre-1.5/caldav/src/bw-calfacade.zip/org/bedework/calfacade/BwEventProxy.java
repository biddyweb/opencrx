/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade;

import org.bedework.calfacade.base.OverrideCollection;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.util.CalFacadeUtil;

import java.util.Collection;
import java.util.TreeSet;

/** An event proxy in Bedework.If an event is an alias or reference to another
 * event, this class holds links to both. The referring event will hold user
 * changes, which override the values in the target.
 *
 * <p>For any collection we need to copy the entire collection into the
 * referring event if a change is made. We need a flag to indicate such changes.
 *
 * <p>We cannot just look at the values in the two objects becuase we have to
 * call the getXXX method to allow the persistance engine to retrieve the
 * collection.
 *
 * <p>We could also remove the current mode, that of creating an empty collection
 * in the get methods when none exists.
 *
 * <p>XXX Incomplete. Some fields we can handle easily (String mostly).
 * Problems still arise with fields like locations and recurrence stuff.
 *
 * @author Mike Douglass
 * @version 1.0
 */
public class BwEventProxy extends BwEvent {
  /** The referring event
   */
  private BwEventAnnotation ref;

  private boolean refChanged;

  /** Constructor
   *
   * @param ref
   */
  public BwEventProxy(BwEventAnnotation ref) {
    this.ref = ref;
  }

  /* ====================================================================
   *                      Bean methods
   * ==================================================================== */

  /** Get referenced event
   *
   * @return  BwEventAnnotation
   */
  public BwEventAnnotation getRef() {
    return ref;
  }

  /** Set the event change flag.
   *
   * @param  val     boolean true if event changed.
   */
  public void setRefChanged(boolean val) {
    refChanged = val;
  }

  /** See if the event has changed.
   *
   * @return  boolean   true if event changed.
   */
  public boolean getRefChanged() {
    if (refChanged) {
      return true;
    }

    if (!CalFacadeUtil.eqObjval(ref.getDtstart(), getTarget().getDtstart())) {
      refChanged = true;
      return true;
    }

    if (!CalFacadeUtil.eqObjval(ref.getDtend(), getTarget().getDtend())) {
      refChanged = true;
      return true;
    }

    return false;
  }

  /** Get the target from the ref
   *
   * @return BwEvent target of reference
   */
  public BwEvent getTarget() {
    return ref.getTarget();
  }

  /* ====================================================================
   *                   BwDbentity methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setId(int)
   */
  public void setId(int val) {
    throw new RuntimeException("Immutable");
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getId()
   */
  public int getId() {
    return ref.getId();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setSeq(int)
   */
  public void setSeq(int val) {
    throw new RuntimeException("Immutable");
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getSeq()
   */
  public int getSeq() {
    return ref.getSeq();
  }

  /* ====================================================================
   *                   BwOwnedDbentity methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.BwOwnedDbentity#setOwner(org.bedework.calfacade.BwUser)
   */
  public void setOwner(BwUser val) {
    if (!CalFacadeUtil.eqObjval(getTarget().getOwner(), val)) {
      ref.setOwner(val);
      setRefChanged(true);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.BwOwnedDbentity#getOwner()
   */
  public BwUser getOwner() {
    return ref.getOwner();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.BwOwnedDbentity#setPublick(boolean)
   */
  public void setPublick(boolean val) {
    if (getPublick() != val) {
      ref.setPublick(val);
      setRefChanged(true);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.BwOwnedDbentity#getPublick()
   */
  public boolean getPublick() {
    return ref.getPublick() || getTarget().getPublick();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setCreator(org.bedework.calfacade.BwUser)
   */
  public void setCreator(BwUser val) {
    if (!CalFacadeUtil.eqObjval(getTarget().getCreator(), val)) {
      ref.setCreator(val);
      setRefChanged(true);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getCreator()
   */
  public BwUser getCreator() {
    return getTarget().getCreator();
  }

  /** Set the access
   *
   * @param val    String access
   */
  public void setAccess(String val) {
    if (!CalFacadeUtil.eqObjval(getTarget().getAccess(), val)) {
      ref.setAccess(val);
      setRefChanged(true);
    }
  }

  /** Get the access
   *
   * @return String   access
   */
  public String getAccess() {
    if (!ref.getOverride()) {
      // Always comes from the annotation.
      return ref.getAccess();
    }

    String val = ref.getAccess();
    if (val != null) {
      return val;
    }

    return getTarget().getAccess();
  }

  /** Set the event's calendar
   *
   * @param val    BwCalendar event's calendar
   */
  public void setCalendar(BwCalendar val) {
    ref.setCalendar(val);
  }

  /** Get the event's calendar
   *
   * @return CalendarVO   the event's calendar
   */
  public BwCalendar getCalendar() {
    BwCalendar val = ref.getCalendar();
    if (val != null) {
      return val;
    }

    return getTarget().getCalendar();
  }

  /* ====================================================================
   *                      Bean methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setEntityType(int)
   */
  public void setEntityType(int val) {
    if (getEntityType() != val) {
      throw new RuntimeException("Immutable");
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getEntityType()
   */
  public int getEntityType() {
    return ref.getEntityType();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setName(java.lang.String)
   */
  public void setName(String val) {
    if (!CalFacadeUtil.eqObjval(getTarget().getName(), val)) {
      ref.setName(val);
      setRefChanged(true);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getName()
   */
  public String getName() {
    String val = ref.getName();
    if (val != null) {
      return val;
    }

    return getTarget().getName();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setClassification(java.lang.String)
   */
  public void setClassification(String val) {
    if (!CalFacadeUtil.eqObjval(getTarget().getClassification(), val)) {
      ref.setClassification(val);
      setRefChanged(true);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getClassification()
   */
  public String getClassification() {
    String val = ref.getClassification();
    if (val != null) {
      return val;
    }

    return getTarget().getClassification();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setLink(java.lang.String)
   */
  public void setLink(String val) {
    if (!CalFacadeUtil.eqObjval(getTarget().getLink(), val)) {
      ref.setLink(val);
      setRefChanged(true);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getLink()
   */
  public String getLink() {
    String val = ref.getLink();
    if (val != null) {
      return val;
    }

    return getTarget().getLink();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setGeo(org.bedework.calfacade.BwGeo)
   */
  public void setGeo(BwGeo val) {
    if (!CalFacadeUtil.eqObjval(getTarget().getGeo(), val)) {
      ref.setGeo(val);
      setRefChanged(true);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getGeo()
   */
  public BwGeo getGeo() {
    BwGeo val = ref.getGeo();
    if (val != null) {
      return val;
    }

    return getTarget().getGeo();
  }

  /** Set the event deleted flag
   *
   *  @param val    boolean true if the event is deleted
   */
  public void setDeleted(boolean val) {
    ref.setDeleted(val);
  }

  /** Get the event deleted flag
   *
   *  @return boolean    true if the event is deleted
   */
  public boolean getDeleted() {
    if (getTarget().getDeleted()) {
      return true;
    }
    return ref.getDeleted();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setStatus(char)
   */
  public void setStatus(String val) {
    if (!CalFacadeUtil.eqObjval(getTarget().getStatus(), val)) {
      ref.setStatus(val);
      setRefChanged(true);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getStatus()
   */
  public String getStatus() {
    String val = ref.getStatus();
    if (val != null) {
      return val;
    }

    return getTarget().getStatus();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setCost(java.lang.String)
   */
  public void setCost(String val) {
    if (!CalFacadeUtil.eqObjval(getTarget().getCost(), val)) {
      ref.setCost(val);
      setRefChanged(true);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getCost()
   */
  public String getCost() {
    String val = ref.getCost();
    if (val != null) {
      return val;
    }

    return getTarget().getCost();
  }

  /** Set the event's organizer
   *
   * @param val    BwOrganizer event's organizer
   */
  public void setOrganizer(BwOrganizer val) {
    if (!CalFacadeUtil.eqObjval(getTarget().getOrganizer(), val)) {
      ref.setOrganizer(val);
      setRefChanged(true);
    }
  }

  /** Get the event's organizer
   *
   * @return BwOrganizer   the event's organizer
   */
  public BwOrganizer getOrganizer() {
    BwOrganizer val = ref.getOrganizer();
    if (val != null) {
      return val;
    }

    return getTarget().getOrganizer();
  }

  /* * Get the event's organizerId
   *
   * @return int   the event's organizer id
   * /
  public int getOrganizerId() {
    return getTarget().getOrganizerId();
  }*/

  public void setDtstamp(String val) {
    ref.setDtstamp(val);
  }

  public String getDtstamp() {
    String val = ref.getDtstamp();
    if (val != null) {
      return val;
    }

    return getTarget().getDtstamp();
  }

  public void setLastmod(String val) {
    ref.setLastmod(val);
  }

  public String getLastmod() {
    /* May get called before ref/target set */
    String val = null;
    if (ref != null) {
      val = ref.getLastmod();
      if (val != null) {
        return val;
      }
    }

    if (getTarget() != null) {
      val = getTarget().getLastmod();
    }

    return val;
  }

  public void setCreated(String val) {
    ref.setCreated(val);
  }

  public String getCreated() {
    String val = ref.getCreated();
    if (val != null) {
      return val;
    }

    return getTarget().getCreated();
  }

  /** Set the rfc priority for this event
   *
   * @param val    rfc priority number
   */
  public void setPriority(Integer val) {
    ref.setPriority(val);
  }

  /** Get the events rfc priority
   *
   * @return Integer    the events rfc priority
   */
  public Integer getPriority() {
    Integer val = ref.getPriority();
    if (val != null) {
      return val;
    }

    return getTarget().getPriority();
  }

  /** Set the rfc sequence for this event
   *
   * @param val    rfc sequence number
   */
  public void setSequence(int val) {
    ref.setSequence(val);
  }

  /** Get the events rfc sequence
   *
   * @return int    the events rfc sequence
   */
  public int getSequence() {
    return ref.getSequence();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setLocation(org.bedework.calfacade.BwLocation)
   */
  public void setLocation(BwLocation val) {
    if (!CalFacadeUtil.eqObjval(getTarget().getLocation(), val)) {
      ref.setLocation(val);
      setRefChanged(true);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getLocation()
   */
  public BwLocation getLocation() {
    BwLocation val = ref.getLocation();
    if (val != null) {
      return val;
    }

    return getTarget().getLocation();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setUid(java.lang.String)
   */
  public void setUid(String val) {
    ref.setUid(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getUid()
   */
  public String getUid() {
    String val = ref.getUid();
    if (val != null) {
      return val;
    }

    return getTarget().getUid();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setTransparency(java.lang.String)
   */
  public void setTransparency(String val) {
    ref.setTransparency(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getTransparency()
   */
  public String getTransparency() {
    String val = ref.getTransparency();
    if (val != null) {
      return val;
    }

    return getTarget().getTransparency();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setPercentComplete(java.lang.Integer)
   */
  public void setPercentComplete(Integer val) {
    Integer refval = ref.getPercentComplete();

    if ((refval == null) || !refval.equals(val)) {
      ref.setPercentComplete(val);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getPercentComplete()
   */
  public Integer getPercentComplete() {
    Integer val = ref.getPercentComplete();
    if (val != null) {
      return val;
    }

    return getTarget().getPercentComplete();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setCompleted(java.lang.String)
   */
  public void setCompleted(String val) {
    String refval = ref.getCompleted();

    if ((refval == null) || !refval.equals(val)) {
      ref.setCompleted(val);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getCompleted()
   */
  public String getCompleted() {
    String val = ref.getCompleted();
    if (val != null) {
      return val;
    }

    return getTarget().getCompleted();
  }

  /** Set the scheduleMethod for this event
   *
   * @param val    scheduleMethod
   */
  public void setScheduleMethod(int val) {
    ref.setScheduleMethod(val);
  }

  /** Get the events scheduleMethod
   *
   * @return int    the events scheduleMethod
   */
  public int getScheduleMethod() {
    return ref.getScheduleMethod();
  }

  /** Set the event's originator
   *
   * @param val    String event's originator
   */
  public void setOriginator(String val) {
    if (!CalFacadeUtil.eqObjval(getTarget().getOriginator(), val)) {
      ref.setOriginator(val);
      setRefChanged(true);
    }
  }

  /** Get the event's originator
   *
   * @return String   the event's originator
   */
  public String getOriginator() {
    String val = ref.getOriginator();
    if (val != null) {
      return val;
    }

    return getTarget().getOriginator();
  }

  /** Set the scheduleState for this event
   *
   * @param val    scheduleState
   */
  public void setScheduleState(int val) {
    ref.setScheduleState(val);
  }

  /** Get the events scheduleState
   *
   * @return int    the events scheduleState
   */
  public int getScheduleState() {
    return ref.getScheduleState();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setRelatedTo(org.bedework.calfacade.BwRelatedTo)
   */
  public void setRelatedTo(BwRelatedTo val) {
    if (!CalFacadeUtil.eqObjval(getTarget().getRelatedTo(), val)) {
      ref.setRelatedTo(val);
      setRefChanged(true);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getRelatedTo()
   */
  public BwRelatedTo getRelatedTo() {
    if (ref.getRelatedTo() != null) {
      return ref.getRelatedTo();
    }

    return getTarget().getRelatedTo();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setXproperties(java.util.Collection)
   */
  public void setXproperties(Collection<BwXproperty> val) {
    ref.setXproperties(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getXproperties()
   */
  public Collection<BwXproperty> getXproperties() {
    Collection<BwXproperty> c = super.getXproperties();
    if (c == null) {
      c = new OverrideCollection<BwXproperty>() {
        public void setOverrideCollection(Collection<BwXproperty> val) {
          ref.setXproperties(val);
        }

        public Collection<BwXproperty> getOverrideCollection() {
          return ref.getXproperties();
        }

        public Collection<BwXproperty> getEmptyOverrideCollection() {
          return new TreeSet<BwXproperty>();
        }

        public Collection<BwXproperty> getMasterCollection() {
          return getTarget().getXproperties();
        }

        public void setOverrideIsEmpty(Boolean val) {
          ref.setXpropertiesEmpty(val);
        }

        public Boolean getOverrideIsEmpty() {
          return ref.getXpropertiesEmpty();
        }
      };

      super.setXproperties(c);
    }

    return c;
  }

  /* ====================================================================
   *               Request status methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setRequestStatuses(java.util.Collection)
   */
  public void setRequestStatuses(Collection<BwRequestStatus> val) {
    ref.setRequestStatuses(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getRequestStatuses()
   */
  public Collection<BwRequestStatus> getRequestStatuses() {
    Collection<BwRequestStatus> c = super.getRequestStatuses();
    if (c == null) {
      c = new OverrideCollection<BwRequestStatus>() {
        public void setOverrideCollection(Collection<BwRequestStatus> val) {
          ref.setRequestStatuses(val);
        }

        public Collection<BwRequestStatus> getOverrideCollection() {
          return ref.getRequestStatuses();
        }

        public Collection<BwRequestStatus> getEmptyOverrideCollection() {
          return new TreeSet<BwRequestStatus>();
        }

        public Collection<BwRequestStatus> getMasterCollection() {
          return getTarget().getRequestStatuses();
        }

        public void setOverrideIsEmpty(Boolean val) {
          ref.setRequestStatusesEmpty(val);
        }

        public Boolean getOverrideIsEmpty() {
          return ref.getRequestStatusesEmpty();
        }
      };

      super.setRequestStatuses(c);
    }

    return c;
  }

  /* ====================================================================
   *               RecurrenceEntity interface methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setRecurring(java.lang.Boolean)
   */
  public void setRecurring(Boolean val) {
    ref.setRecurring(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getRecurring()
   */
  public Boolean getRecurring() {
    if (ref.getRecurring() != null) {
      return ref.getRecurring();
    }

    return getTarget().getRecurring();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setRecurrenceId(java.lang.String)
   */
  public void setRecurrenceId(String val) {
     ref.setRecurrenceId(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getRecurrenceId()
   */
  public String getRecurrenceId() {
    if (ref.getRecurrenceId() != null) {
      return ref.getRecurrenceId();
    }

    return getTarget().getRecurrenceId();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setRrules(java.util.Collection)
   */
  public void setRrules(Collection<String> val) {
    ref.setRrules(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getRrules()
   */
  public Collection<String> getRrules() {
    Collection<String> c = super.getRrules();
    if (c == null) {
      c = new OverrideCollection<String>() {
        public void setOverrideCollection(Collection<String> val) {
          ref.setRrules(val);
        }

        public Collection<String> getOverrideCollection() {
          return ref.getRrules();
        }

        public Collection<String> getEmptyOverrideCollection() {
          return new TreeSet<String>();
        }

        public Collection<String> getMasterCollection() {
          return getTarget().getRrules();
        }

        public void setOverrideIsEmpty(Boolean val) {
          ref.setRrulesEmpty(val);
        }

        public Boolean getOverrideIsEmpty() {
          return ref.getRrulesEmpty();
        }
      };

      super.setRrules(c);
    }

    return c;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setExrules(java.util.Collection)
   */
  public void setExrules(Collection<String> val) {
    ref.setExrules(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getExrules()
   */
  public Collection<String> getExrules() {
    Collection<String> c = super.getExrules();
    if (c == null) {
      c = new OverrideCollection<String>() {
        public void setOverrideCollection(Collection<String> val) {
          ref.setExrules(val);
        }

        public Collection<String> getOverrideCollection() {
          return ref.getExrules();
        }

        public Collection<String> getEmptyOverrideCollection() {
          return new TreeSet<String>();
        }

        public Collection<String> getMasterCollection() {
          return getTarget().getExrules();
        }

        public void setOverrideIsEmpty(Boolean val) {
          ref.setExrulesEmpty(val);
        }

        public Boolean getOverrideIsEmpty() {
          return ref.getExrulesEmpty();
        }
      };

      super.setExrules(c);
    }

    return c;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setRdates(java.util.Collection)
   */
  public void setRdates(Collection<BwDateTime> val) {
    ref.setRdates(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getRdates()
   */
  public Collection<BwDateTime> getRdates() {
    Collection<BwDateTime> c = super.getRdates();
    if (c == null) {
      c = new OverrideCollection<BwDateTime>() {
        public void setOverrideCollection(Collection<BwDateTime> val) {
          ref.setRdates(val);
        }

        public Collection<BwDateTime> getOverrideCollection() {
          return ref.getRdates();
        }

        public Collection<BwDateTime> getEmptyOverrideCollection() {
          return new TreeSet<BwDateTime>();
        }

        public Collection<BwDateTime> getMasterCollection() {
          return getTarget().getRdates();
        }

        public void setOverrideIsEmpty(Boolean val) {
          ref.setRdatesEmpty(val);
        }

        public Boolean getOverrideIsEmpty() {
          return ref.getRdatesEmpty();
        }
      };

      super.setRdates(c);
    }

    return c;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setExdates(java.util.Collection)
   */
  public void setExdates(Collection<BwDateTime> val) {
    ref.setExdates(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getExdates()
   */
  public Collection<BwDateTime> getExdates() {
    Collection<BwDateTime> c = super.getExdates();
    if (c == null) {
      c = new OverrideCollection<BwDateTime>() {
        public void setOverrideCollection(Collection<BwDateTime> val) {
          ref.setExdates(val);
        }

        public Collection<BwDateTime> getOverrideCollection() {
          return ref.getExdates();
        }

        public Collection<BwDateTime> getEmptyOverrideCollection() {
          return new TreeSet<BwDateTime>();
        }

        public Collection<BwDateTime> getMasterCollection() {
          return getTarget().getExdates();
        }

        public void setOverrideIsEmpty(Boolean val) {
          ref.setExdatesEmpty(val);
        }

        public Boolean getOverrideIsEmpty() {
          return ref.getExdatesEmpty();
        }
      };

      super.setExdates(c);
    }

    return c;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setLatestDate(java.lang.String)
   */
  public void setLatestDate(String val) {
    ref.setLatestDate(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getLatestDate()
   */
  public String getLatestDate() {
    if (ref.getLatestDate() != null) {
      return ref.getLatestDate();
    }
    return getTarget().getLatestDate();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setExpanded(java.lang.Boolean)
   */
  public void setExpanded(Boolean val) {
    ref.setExpanded(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getExpanded()
   */
  public Boolean getExpanded() {
    if (ref.getExpanded() != null) {
      return ref.getExpanded();
    }
    return getTarget().getExpanded();
  }

  /* ====================================================================
   *                   Recurrence Helper methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#isRecurring()
   */
  public boolean isRecurringEntity() {
    return hasExdates() ||
           hasRdates() ||
           hasExrules() ||
           hasRrules();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#hasRrules()
   */
  public boolean hasRrules() {
    return ref.hasRrules() || getTarget().hasRrules();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#hasExrules()
   */
  public boolean hasExrules() {
    return ref.hasExrules() || getTarget().hasExrules();
  }

  /* ====================================================================
   *               StartEndComponent interface methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setDtstart(org.bedework.calfacade.BwDateTime)
   */
  public void setDtstart(BwDateTime val) {
    if (!CalFacadeUtil.eqObjval(getTarget().getDtstart(), val)) {
      ref.setDtstart(val);
      setRefChanged(true);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getDtstart()
   */
  public BwDateTime getDtstart() {
    /* We need the owner of the timezones for lookups. That owner is the owner
     * of the master event.
     */
    BwDateTime dt = ref.getDtstart();
    if (dt != null) {
      dt.setTzowner(ref.getMaster().getOwner());
    }

    return dt;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setDtend(org.bedework.calfacade.BwDateTime)
   */
  public void setDtend(BwDateTime val) {
    if (!CalFacadeUtil.eqObjval(getTarget().getDtend(), val)) {
      ref.setDtend(val);
      setRefChanged(true);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getDtend()
   */
  public BwDateTime getDtend() {
    BwDateTime dt = ref.getDtend();
    if (dt != null) {
      dt.setTzowner(ref.getMaster().getOwner());
    }

    return dt;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setEndType(char)
   */
  public void setEndType(char val) {
    if (getEndType() != val) {
      ref.setEndType(val);
      setRefChanged(true);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getEndType()
   */
  public char getEndType() {
    return ref.getEndType();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setDuration(java.lang.String)
   */
  public void setDuration(String val) {
    if (!CalFacadeUtil.eqObjval(getTarget().getDuration(), val)) {
      ref.setDuration(val);
      setRefChanged(true);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getDuration()
   */
  public String getDuration() {
    String val = ref.getDuration();
    if (val != null) {
      return val;
    }

    return getTarget().getDuration();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setNoStart(java.lang.Boolean)
   */
  public void setNoStart(Boolean val) {
    ref.setNoStart(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getNoStart()
   */
  public Boolean getNoStart() {
    if (ref.getNoStart() != null) {
      return ref.getNoStart();
    }
    return getTarget().getNoStart();
  }

  /* ====================================================================
   *               AlarmsEntity interface methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AlarmsEntity#setAlarms(java.util.Collection)
   */
  public void setAlarms(Collection<BwAlarm> val) {
    ref.setAlarms(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AlarmsEntity#getAlarms()
   */
  public Collection<BwAlarm> getAlarms() {
    Collection<BwAlarm> c = super.getAlarms();
    if (c == null) {
      c = new OverrideCollection<BwAlarm>() {
        public void setOverrideCollection(Collection<BwAlarm> val) {
          ref.setAlarms(val);
        }

        public Collection<BwAlarm> getOverrideCollection() {
          return ref.getAlarms();
        }

        public Collection<BwAlarm> getEmptyOverrideCollection() {
          return new TreeSet<BwAlarm>();
        }

        public Collection<BwAlarm> getMasterCollection() {
          return getTarget().getAlarms();
        }

        public void setOverrideIsEmpty(Boolean val) {
          ref.setAlarmsEmpty(val);
        }

        public Boolean getOverrideIsEmpty() {
          return ref.getAlarmsEmpty();
        }
      };

      super.setAlarms(c);
    }

    return c;
  }

  /* ====================================================================
   *                   Attendees update and query methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setAttendees(java.util.Collection)
   */
  public void setAttendees(Collection<BwAttendee> val) {
    ref.setAttendees(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getAttendees()
   */
  public Collection<BwAttendee> getAttendees() {
    Collection<BwAttendee> c = super.getAttendees();
    if (c == null) {
      c = new OverrideCollection<BwAttendee>() {
        public void setOverrideCollection(Collection<BwAttendee> val) {
          ref.setAttendees(val);
        }

        public Collection<BwAttendee> getOverrideCollection() {
          return ref.getAttendees();
        }

        public Collection<BwAttendee> getEmptyOverrideCollection() {
          return new TreeSet<BwAttendee>();
        }

        public Collection<BwAttendee> getMasterCollection() {
          return getTarget().getAttendees();
        }

        public void setOverrideIsEmpty(Boolean val) {
          ref.setAttendeesEmpty(val);
        }

        public Boolean getOverrideIsEmpty() {
          return ref.getAttendeesEmpty();
        }
      };

      super.setAttendees(c);
    }

    return c;
  }

  /* ====================================================================
   *               CategorisedEntity interface methods
   * ==================================================================== */

  public void setCategories(Collection<BwCategory> val) {
    ref.setCategories(val);
  }

  public Collection<BwCategory> getCategories() {
    Collection<BwCategory> c = super.getCategories();
    if (c == null) {
      c = new OverrideCollection<BwCategory>() {
        public void setOverrideCollection(Collection<BwCategory> val) {
          ref.setCategories(val);
        }

        public Collection<BwCategory> getOverrideCollection() {
          return ref.getCategories();
        }

        public Collection<BwCategory> getEmptyOverrideCollection() {
          return new TreeSet<BwCategory>();
        }

        public Collection<BwCategory> getMasterCollection() {
          return getTarget().getCategories();
        }

        public void setOverrideIsEmpty(Boolean val) {
          ref.setCategoriesEmpty(val);
        }

        public Boolean getOverrideIsEmpty() {
          return ref.getCategoriesEmpty();
        }
      };

      super.setCategories(c);
    }

    return c;
  }

  /* ====================================================================
   *               CommentedEntity interface methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CommentedEntity#setComments(java.util.Collection)
   */
  public void setComments(Collection<BwString> val) {
    ref.setComments(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CommentedEntity#getComments()
   */
  public Collection<BwString> getComments() {
    Collection<BwString> c = super.getComments();
    if (c == null) {
      c = new OverrideCollection<BwString>() {
        public void setOverrideCollection(Collection<BwString> val) {
          ref.setComments(val);
        }

        public Collection<BwString> getOverrideCollection() {
          return ref.getComments();
        }

        public Collection<BwString> getEmptyOverrideCollection() {
          return new TreeSet<BwString>();
        }

        public Collection<BwString> getMasterCollection() {
          return getTarget().getComments();
        }

        public void setOverrideIsEmpty(Boolean val) {
          ref.setCommentsEmpty(val);
        }

        public Boolean getOverrideIsEmpty() {
          return ref.getCommentsEmpty();
        }
      };

      super.setComments(c);
    }

    return c;
  }

  /* ====================================================================
   *               Contact interface methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#setContacts(java.util.Collection)
   */
  public void setContacts(Collection<BwContact> val) {
    ref.setContacts(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#getContacts()
   */
  public Collection<BwContact> getContacts() {
    Collection<BwContact> c = super.getContacts();
    if (c == null) {
      c = new OverrideCollection<BwContact>() {
        public void setOverrideCollection(Collection<BwContact> val) {
          ref.setContacts(val);
        }

        public Collection<BwContact> getOverrideCollection() {
          return ref.getContacts();
        }

        public Collection<BwContact> getEmptyOverrideCollection() {
          return new TreeSet<BwContact>();
        }

        public Collection<BwContact> getMasterCollection() {
          return getTarget().getContacts();
        }

        public void setOverrideIsEmpty(Boolean val) {
          ref.setContactsEmpty(val);
        }

        public Boolean getOverrideIsEmpty() {
          return ref.getContactsEmpty();
        }
      };

      super.setContacts(c);
    }

    return c;
  }

  /* ====================================================================
   *               DescriptionEntity interface methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setDescriptions(java.util.Collection)
   */
  public void setDescriptions(Collection<BwLongString> val) {
    ref.setDescriptions(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getDescriptions()
   */
  public Collection<BwLongString> getDescriptions() {
    Collection<BwLongString> c = super.getDescriptions();
    if (c == null) {
      c = new OverrideCollection<BwLongString>() {
        public void setOverrideCollection(Collection<BwLongString> val) {
          ref.setDescriptions(val);
        }

        public Collection<BwLongString> getOverrideCollection() {
          return ref.getDescriptions();
        }

        public Collection<BwLongString> getEmptyOverrideCollection() {
          return new TreeSet<BwLongString>();
        }

        public Collection<BwLongString> getMasterCollection() {
          return getTarget().getDescriptions();
        }

        public void setOverrideIsEmpty(Boolean val) {
          ref.setDescriptionsEmpty(val);
        }

        public Boolean getOverrideIsEmpty() {
          return ref.getDescriptionsEmpty();
        }
      };

      super.setDescriptions(c);
    }

    return c;
  }

  /* ====================================================================
   *               ResourcedEntity interface methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.ResourcedEntity#setResources(java.util.Collection)
   */
  public void setResources(Collection<BwString> val) {
    ref.setResources(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.ResourcedEntity#getResources()
   */
  public Collection<BwString> getResources() {
    Collection<BwString> c = super.getResources();
    if (c == null) {
      c = new OverrideCollection<BwString>() {
        public void setOverrideCollection(Collection<BwString> val) {
          ref.setResources(val);
        }

        public Collection<BwString> getOverrideCollection() {
          return ref.getResources();
        }

        public Collection<BwString> getEmptyOverrideCollection() {
          return new TreeSet<BwString>();
        }

        public Collection<BwString> getMasterCollection() {
          return getTarget().getResources();
        }

        public void setOverrideIsEmpty(Boolean val) {
          ref.setResourcesEmpty(val);
        }

        public Boolean getOverrideIsEmpty() {
          return ref.getResourcesEmpty();
        }
      };

      super.setResources(c);
    }

    return c;
  }

  /* ====================================================================
   *               SummaryEntity interface methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#setSummaries(java.util.Collection)
   */
  public void setSummaries(Collection<BwString> val) {
    ref.setSummaries(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getSummaries()
   */
  /* (non-Javadoc)
   * @see org.bedework.calfacade.BwEvent#getSummaries()
   */
  public Collection<BwString> getSummaries() {
    Collection<BwString> c = super.getSummaries();
    if (c == null) {
      c = new OverrideCollection<BwString>() {
        public void setOverrideCollection(Collection<BwString> val) {
          ref.setSummaries(val);
        }

        public Collection<BwString> getOverrideCollection() {
          return ref.getSummaries();
        }

        public Collection<BwString> getEmptyOverrideCollection() {
          return new TreeSet<BwString>();
        }

        public Collection<BwString> getMasterCollection() {
          return getTarget().getSummaries();
        }

        public void setOverrideIsEmpty(Boolean val) {
          ref.setSummariesEmpty(val);
        }

        public Boolean getOverrideIsEmpty() {
          return ref.getSummariesEmpty();
        }
      };

      super.setSummaries(c);
    }

    return c;
  }

  /* ====================================================================
   *                   Recipients methods
   * ==================================================================== */

  /** Set the recipients collection
   *
   * @param val    Collection of (String)recipients
   */
  public void setRecipients(Collection<String> val) {
    ref.setRecipients(val);
  }

  /** Get the recipients
   *
   *  @return Collection     recipients set
   */
  public Collection<String> getRecipients() {
    Collection<String> c = super.getRecipients();
    if (c == null) {
      c = new OverrideCollection<String>() {
        public void setOverrideCollection(Collection<String> val) {
          ref.setRecipients(val);
        }

        public Collection<String> getOverrideCollection() {
          return ref.getRecipients();
        }

        public Collection<String> getEmptyOverrideCollection() {
          return new TreeSet<String>();
        }

        public Collection<String> getMasterCollection() {
          return getTarget().getRecipients();
        }

        public void setOverrideIsEmpty(Boolean val) {
          ref.setRecipientsEmpty(val);
        }

        public Boolean getOverrideIsEmpty() {
          return ref.getRecipientsEmpty();
        }
      };

      super.setRecipients(c);
    }

    return c;
  }

  /* ====================================================================
   *                   Conveniece methods
   * ==================================================================== */

  /** Set the last mod for this event.
   */
  public void updateLastmod() {
    ref.updateLastmod();
  }

  /** Set the dtstamp for this event.
   */
  public void updateDtstamp() {
    ref.updateDtstamp();
  }

  /* ====================================================================
   *                           Factory methods
   * ==================================================================== */

  /** Creates an annotation object for the given event then returns a proxy
   * object to handle it.
   *
   * @param ev  BwEvent object to annotate
   * @param owner
   * @param forInstance      true if this is an overrride or a recurrence instance
   * @return BwEventProxy object
   * @throws CalFacadeException
   */
  public static BwEventProxy makeAnnotation(BwEvent ev, BwUser owner,
                                            boolean forInstance)
          throws CalFacadeException {
    BwEventAnnotation ann = new BwEventAnnotation();

    initAnnotation(ann, ev, owner, forInstance);

    return new BwEventProxy(ann);
  }

  /** Initialise an annotation object from the given event.
   *
   * @param ann  The annotation object
   * @param ev  BwEvent object to annotate
   * @param owner  if null event owner is used
   * @param forInstance      true if this is an overrride or a recurrence instance
   * @throws CalFacadeException
   */
  public static void initAnnotation(BwEventAnnotation ann,
                                    BwEvent ev, BwUser owner,
                                    boolean forInstance)
          throws CalFacadeException {
    ann.setTarget(ev);

    /* XXX This should be a parameter */
    ann.setMaster(ev);

    BwDateTime start = ev.getDtstart();
    BwDateTime end = ev.getDtend();

    ann.setDtstart(start);
    ann.setDtend(end);
    //ann.setDuration(BwDateTime.makeDuration(start, end).toString());
    ann.setDuration(ev.getDuration());
    ann.setEndType(ev.getEndType());
    ann.setCreator(ev.getCreator());
    ann.setUid(ev.getUid());
    ann.setName(ev.getName());
    ann.setOverride(forInstance);

    if (forInstance) {
      // Same calendar as master
      ann.setCalendar(ev.getCalendar());
    }

    if (owner != null) {
      ann.setOwner(owner);
    } else {
      ann.setOwner(ev.getOwner());
    }
  }

  /* ====================================================================
   *                   Recurrence update and query methods
   * ==================================================================== */

  public BwDuration makeDurationBean() throws CalFacadeException {
    String duration = ref.getDuration();
    if (duration == null) {
      duration = getTarget().getDuration();
    }
    return BwDuration.makeDuration(duration);
  }

  /* ====================================================================
   *                   Object methods
   * ==================================================================== */

  public String toString() {
    StringBuffer sb = new StringBuffer("BwEventProxy{");

    sb.append(ref.toString());

    sb.append("}");

    return sb.toString();
  }

  /** When cloning a proxy we generally need to point the cloned annotation at
   * a new target and master.
   *
   * @param master
   * @param target
   * @return cloned proxy.
   */
  public BwEventProxy clone(BwEvent master, BwEvent target) {
    BwEventAnnotation ann = (BwEventAnnotation)ref.clone();

    ann.setMaster(master);
    ann.setTarget(target);

    return new BwEventProxy(ann);
  }

  public Object clone() {
    return new BwEventProxy((BwEventAnnotation)ref.clone());
  }
}
