/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade.base;

import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.TreeSet;

/** A class to allow operations on overriden Collection values which leave the
 * master collection untouched. The problem is to allow an event to be annotated
 * in some manner by a user with no access. We also use this when overriding a
 * recurring instance.
 *
 * <p>Some cases are relatively easy to handle, if we have a master collection
 * with entries A, B, C and we want an override with A nd C we create an override
 * collection with just those two entries.
 *
 *  <p>If we want an override with A, B, C, D we just copy the master collection
 *  and add to the copy.
 *
 *  <p>However, what if we want an override with an empty Collection? Here we
 *  conflict with the need to determine if there is any ovverride at all.
 *  In the database there is no equivalent to a non-null empty Collection.
 *
 *  <p>It's also the case that hibernate appears to return empty Collections for
 *  no members so we never get null Collections. (need to confirm)
 *
 *  <p>To indicate the collection has been removed by the override we need a flag
 *  in the annotation. This is queried by the getOverrideIsEmpty method.
 *
 * @author Mike Douglass douglm - rpi.edu
 * @param <T>
 */
public abstract class OverrideCollection <T> implements Collection<T> {

  /** Set the override Collection
   *
   * @param val
   */
  public abstract void setOverrideCollection(Collection<T> val);

  /** Get the override collection
   * @return Collection<T>
   */
  public abstract Collection<T> getOverrideCollection();

  /** Get a new empty override collection
   * @return empty Collection<T>
   */
  public abstract Collection<T> getEmptyOverrideCollection();

  /** Set the override is explicitly emptied.
   *
   * @param val   Boolean true if collection is explicitly emptied.
   */
  public abstract void setOverrideIsEmpty(Boolean val);

  /** Determine if the override is explicitly emptied.
   *
   * @return Boolean non-null and true if collection is explicitly emptied.
   */
  public abstract Boolean getOverrideIsEmpty();

  /** Get the master collection
   * @return the master Collection
   */
  public abstract Collection<T> getMasterCollection();

  /* (non-Javadoc)
   * @see java.util.Collection#size()
   */
  public int size() {
    Collection<T> c = getCollection();
    if (c == null) {
      return 0;
    }

    return c.size();
  }

  /* (non-Javadoc)
   * @see java.util.Collection#isEmpty()
   */
  public boolean isEmpty() {
    Collection<T> c = getCollection();
    if (c == null) {
      return true;
    }

    return c.isEmpty();
  }

  /* (non-Javadoc)
   * @see java.util.Collection#contains(java.lang.Object)
   */
  public boolean contains(Object o) {
    Collection<T> c = getCollection();
    if (c == null) {
      return false;
    }

    return c.contains(o);
  }

  /**
   * @author douglm
   * @param <E>
   */
  private class EmptyIterator<E> implements Iterator<E> {
    /* (non-Javadoc)
     * @see java.util.Iterator#hasNext()
     */
    public boolean hasNext() {
      return false;
    }

    /* (non-Javadoc)
     * @see java.util.Iterator#next()
     */
    public E next() {
      throw new NoSuchElementException();
    }

    public void remove() {
      throw new IllegalStateException();
    }
  }

  /* (non-Javadoc)
   * @see java.util.Collection#iterator()
   */
  public Iterator<T> iterator() {
    Collection<T> c = getCollection();
    if (c == null) {
      return new EmptyIterator<T>();
    }

    return c.iterator();
  }

  /* (non-Javadoc)
   * @see java.util.Collection#toArray()
   */
  public Object[] toArray() {
    Collection<T> c = getCollection();
    if (c == null) {
      return new Object[]{};
    }

    return c.toArray();
  }

  public <T1> T1[] toArray(T1[] a) {
    Collection<T> c = getCollection();
    if (c == null) {
      return new TreeSet<T>().toArray(a);
    }

    return c.toArray(a);
  }

  // Modification Operations

  /* (non-Javadoc)
   * @see java.util.Collection#add(java.lang.Object)
   */
  public boolean add(T o) {
    Collection<T> c = getModCollection();

    setOverrideEmptyFlag(false);
    return c.add(o);
  }

  /* (non-Javadoc)
   * @see java.util.Collection#remove(java.lang.Object)
   */
  public boolean remove(Object o) {
    Collection<T> c = getModCollection();
    boolean changed = c.remove(o);

    if (c.isEmpty()) {
      setOverrideEmptyFlag(true);
    }

    return changed;
  }

  // Bulk Operations

  /* (non-Javadoc)
   * @see java.util.Collection#containsAll(java.util.Collection)
   */
  public boolean containsAll(Collection<?> c) {
    Collection<T> cc = getCollection();
    if (cc == null) {
      return false;
    }

    return cc.containsAll(c);
  }

  /* (non-Javadoc)
   * @see java.util.Collection#addAll(java.util.Collection)
   */
  public boolean addAll(Collection<? extends T> c){
    Collection<T> cc = getModCollection();

    setOverrideEmptyFlag(false);
    return cc.addAll(c);
  }

  /* (non-Javadoc)
   * @see java.util.Collection#removeAll(java.util.Collection)
   */
  public boolean removeAll(Collection<?> c) {
    Collection<T> cc = getModCollection();

    boolean changed = cc.removeAll(c);

    if (cc.isEmpty()) {
      setOverrideEmptyFlag(true);
    }

    return changed;
  }

  /* (non-Javadoc)
   * @see java.util.Collection#retainAll(java.util.Collection)
   */
  public boolean retainAll(Collection<?> c){
    Collection<T> cc = getModCollection();

    boolean changed = cc.retainAll(c);

    if (cc.isEmpty()) {
      setOverrideEmptyFlag(true);
    }

    return changed;
  }

  /* (non-Javadoc)
   * @see java.util.Collection#clear()
   */
  public void clear() {
    getModCollection().clear();
    setOverrideEmptyFlag(true);
  }

  // Comparison and hashing

  public boolean equals(Object o) {
    return getCollection().equals(o);
  }

  public int hashCode() {
    return getCollection().hashCode();
  }

  private void setOverrideEmptyFlag(boolean val) {
    Boolean emptied = getOverrideIsEmpty();

    if (val) {
      if ((emptied != null) && emptied) {
        return;
      }
    } else if ((emptied == null) || !emptied) {
      return;
    }

    setOverrideIsEmpty(val);
  }

  /* Only call for read operations
   */
  private Collection<T> getCollection() {
    Collection<T> c = getOverrideCollection();

    if ((c != null) && !c.isEmpty()) {
      return c;
    }

    Boolean emptied = getOverrideIsEmpty();
    if ((emptied != null) && emptied) {
      return c;
    }

    return getMasterCollection();
  }

  private Collection<T> getModCollection() {
    Collection<T> over = getOverrideCollection();
    if ((over != null) && !over.isEmpty()) {
      return over;
    }

    if (over == null) {
      over = getEmptyOverrideCollection();
    }

    Boolean emptied = getOverrideIsEmpty();
    if ((emptied != null) && emptied) {
      return over;
    }

    /* Copy master into new override.
     */
    Collection<T> mstr = getMasterCollection();

    if (mstr != null) {
      for (T el: mstr) {
        over.add(el);
      }
    }

    setOverrideCollection(over);
    return over;
  }
}
