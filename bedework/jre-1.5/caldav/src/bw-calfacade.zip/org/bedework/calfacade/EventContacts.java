/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade;

import java.io.Serializable;

/** Allows us to access a join table.
 *
 *   @author Mike Douglass douglm@rpi.edu
 *  @version 1.0
 */
public class EventContacts implements Serializable {
  private BwEvent event;

  private BwContact contact;

  /* ====================================================================
   *                   Bean methods
   * ==================================================================== */

  /** Set the event
   *
   * @param val    event
   */
  public void setEvent(BwEvent val) {
    event = val;
  }

  /** Get the event
   *
   * @return BwEvent    the event
   */
  public BwEvent getEvent() {
    return event;
  }

  /** Set the contact
   *
   * @param val    BwContact contact
   */
  public void setContact(BwContact val) {
    contact = val;
  }

  /** Get the contact
   *
   * @return BwContact    the contact
   */
  public BwContact getContact() {
    return contact;
  }

  /* ====================================================================
   *                   Object methods
   * ==================================================================== */

  /** Compare this and an object
   *
   * @param  o    object to compare.
   * @return int -1, 0, 1
   */
  public int compareTo(Object o) {
    if (o == this) {
      return 0;
    }

    if (o == null) {
      return -1;
    }

    if (!(o instanceof EventContacts)) {
      return -1;
    }

    EventContacts that = (EventContacts)o;

    int res = getEvent().compareTo(that.getEvent());
    if(res != 0) {
      return res;
    }

    return getContact().compareTo(that.getContact());
  }

  public int hashCode() {
    return getEvent().hashCode() * getContact().hashCode();
  }

  public boolean equals(Object obj) {
    return compareTo(obj) == 0;
  }
}
