/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/

package org.bedework.calfacade.util;

import org.bedework.calfacade.BwAlarm;
import org.bedework.calfacade.BwDateTime;
import org.bedework.calfacade.BwFreeBusyComponent;
import org.bedework.calfacade.BwGeo;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.base.TimeRange;

import net.fortuna.ical4j.model.Parameter;
import net.fortuna.ical4j.model.Property;

import java.io.Serializable;
import java.util.HashMap;

/** Define an (arbitrary) index associated with calendar properties
 *
 * @author Mike Douglass   douglm@rpi.edu
 */
public class PropertyIndex implements Serializable {
  private PropertyIndex() {};

  /** */
  public static enum PropertyInfoIndex {
    /** */
    UNKNOWN_PROPERTY,

    /** */
    CLASS,

    /** */
    CREATED,

    /** */
    DESCRIPTION,

    /** */
    DTSTAMP,

    /** */
    DTSTART,

    /** */
    DURATION,

    /** */
    GEO,

    /** */
    LAST_MODIFIED,

    /** */
    LOCATION,

    /** */
    ORGANIZER,

    /** */
    PRIORITY,

    /** */
    RECURRENCE_ID,

    /** */
    SEQUENCE,

    /** */
    STATUS,

    /** */
    SUMMARY,

    /** */
    UID,

    /** */
    URL,

    /* Event only */

    /** */
    DTEND,

    /** */
    TRANSP,

    /* Todo only */

    /** */
    COMPLETED,

    /** */
    DUE,

    /** */
    PERCENT_COMPLETE,

    /* ---------------------------- Multi valued --------------- */

    /* Event and Todo */

    /** */
    ATTACH,

    /** */
    ATTENDEE ,

    /** */
    CATEGORIES,

    /** */
    COMMENT,

    /** */
    CONTACT,

    /** */
    EXDATE,

    /** */
    EXRULE ,

    /** */
    REQUEST_STATUS,

    /** */
    RELATED_TO,

    /** */
    RESOURCES,

    /** */
    RDATE,

    /** */
    RRULE ,

    /* ------------------- VVenue ------------------------------ */

    /** */
    COUNTRY,

    /** */
    EXTENDEDADDRESS,

    /** */
    LOCALITY,

    /** */
    LOCATIONTYPES,

    /** */
    NAME,

    /** */
    POSTALCODE,

    /** */
    REGION,

    /** */
    STREETADDRESS,

    /** */
    TEL,

    /** */
    TYPEDURLS,

    /* -------------- Other non-event, non-todo ---------------- */

    /** */
    FREEBUSY,

    /** */
    TZID,

    /** */
    TZNAME,

    /** */
    TZOFFSETFROM,

    /** */
    TZOFFSETTO,

    /** */
    TZURL,

    /** */
    ACTION,

    /** */
    REPEAT,

    /** */
    TRIGGER,

    /** non ical */
    CREATOR,

    /** non ical */
    OWNER,

    /** non ical */
    ENTITY_TYPE,

    /** treat VALARM sub-component as a property */
    VALARM,

    /** treat x-properties as a single multi-valued property */
    XPROP,

    /** ----------------------------- Following are parameters ----------- */

    /** */
    LANG,

    /** */
    TZIDPAR,
  }

  /** */
  //public static final int maxPropertyIndex = 45;

  /** Represent what we know about properties
   */
  public static class PropertyInfo implements Serializable {
    private PropertyInfoIndex pindex;
    private String name;
    private Class valClass; /* Class of value we expect */
    private boolean multiValued;

    /* event field */
    private String field;

    /* event field we test for presence */
    private String presenceField;

    private boolean param; /* It's a parameter   */

    private boolean eventProperty;
    private boolean todoProperty;
    private boolean journalProperty;
    private boolean freeBusyProperty;
    private boolean timezoneProperty;
    private boolean alarmProperty;
    private boolean venueProperty;

    PropertyInfo(PropertyInfoIndex pindex, String name, String field,
                 Class valClass,
                 boolean multiValued,
                 boolean eventProperty,
                 boolean todoProperty,
                 boolean journalProperty,
                 boolean freeBusyProperty,
                 boolean timezoneProperty,
                 boolean alarmProperty,
                 boolean venueProperty) {
      this.pindex = pindex;
      this.name = name;
      this.field = field;
      this.valClass = valClass;
      this.multiValued = multiValued;
      this.eventProperty = eventProperty;
      this.todoProperty = todoProperty;
      this.journalProperty = journalProperty;
      this.freeBusyProperty = freeBusyProperty;
      this.timezoneProperty = timezoneProperty;
      this.alarmProperty = alarmProperty;
      this.venueProperty = venueProperty;
    }

    PropertyInfo(PropertyInfoIndex pindex, String name,
                 String field, String presenceField,
                 Class valClass,
                 boolean multiValued,
                 boolean eventProperty,
                 boolean todoProperty,
                 boolean journalProperty,
                 boolean freeBusyProperty,
                 boolean timezoneProperty,
                 boolean alarmProperty) {
      this.pindex = pindex;
      this.name = name;
      this.field = field;
      this.presenceField = presenceField;
      this.valClass = valClass;
      this.multiValued = multiValued;
      this.eventProperty = eventProperty;
      this.todoProperty = todoProperty;
      this.journalProperty = journalProperty;
      this.freeBusyProperty = freeBusyProperty;
      this.timezoneProperty = timezoneProperty;
      this.alarmProperty = alarmProperty;
    }

    PropertyInfo(PropertyInfoIndex pindex, String name, String field,
                 Class valClass,
                 boolean multiValued) {
      this.pindex = pindex;
      this.name = name;
      this.field = field;
      this.valClass = valClass;
      this.multiValued = multiValued;
      param = true;
    }

    /** Index of this property
     *
     * @return PropertyInfoIndex
     */
    public PropertyInfoIndex getPindex() {
      return pindex;
    }

    /** Usually the icalendar name
     *
     * @return String
     */
    public String getName() {
      return name;
    }

    /** Class of value we expect
     *
     * @return Class
     */
    public Class getValClass() {
      return valClass;
    }

    /** May need some elaboration
     *
     * @return boolean
     */
    public boolean getMultiValued() {
      return multiValued;
    }

    /** The field this corresponds to
     *
     * @return String field
     */
    public String getField() {
      return field;
    }

    /** The subfield we test for presence
     *
     * @return String presenceField
     */
    public String getPresenceField() {
      return presenceField;
    }

    /** True if it's a parameter
     *
     * @return boolean
     */
    public boolean getParam() {
      return param;
    }

    /** True if it's an event property
     *
     * @return boolean
     */
    public boolean getEventProperty() {
      return eventProperty;
    }

    /** True if it's a todo property
     *
     * @return boolean
     */
    public boolean getTodoProperty() {
      return todoProperty;
    }

    /** True if it's a journal property
     *
     * @return boolean
     */
    public boolean getJournalProperty() {
      return journalProperty;
    }

    /** True if it's a freebusy property
     *
     * @return boolean
     */
    public boolean getFreeBusyProperty() {
      return freeBusyProperty;
    }

    /** True if it's a timezone property
     *
     * @return boolean
     */
    public boolean getTimezoneProperty() {
      return timezoneProperty;
    }

    /** True if it's an alarm property
     *
     * @return boolean
     */
    public boolean getAlarmProperty() {
      return alarmProperty;
    }

    /** True if it's a venue property
     *
     * @return boolean
     */
    public boolean getVenueProperty() {
      return venueProperty;
    }
  }

  /** Information about bedework properties
   */
  public static final HashMap<PropertyInfoIndex, PropertyInfo> propertyInfo =
    new HashMap<PropertyInfoIndex, PropertyInfo>();

  /** Information about bedework properties
   */
  public static final HashMap<String, PropertyInfo> propertyInfoByPname =
    new HashMap<String, PropertyInfo>();

  static { /* ------------------ Properties ---------------------- */

    /* ---------------------------- Single valued --------------- */

    addPinfo(etjProperty(PropertyInfoIndex.CLASS, Property.CLASS,
                         "classification", String.class));

    addPinfo(etjPropertyPlus(PropertyInfoIndex.CREATED, Property.CREATED,
                             "created", TimeRange.class,
                             true, false, false, true));

    addPinfo(etjPropertyPlus(PropertyInfoIndex.DTSTAMP, Property.DTSTAMP,
                             "dtstamp", TimeRange.class,
                             true, false, false, true));


    addPinfo(etjCompoundPropertyPlus(PropertyInfoIndex.DTSTART, Property.DTSTART,
                                     "dtstart", "dtval", BwDateTime.class,
                                     true, true, false));

    addPinfo(new PropertyInfo(PropertyInfoIndex.DURATION, Property.DURATION,
                                        "duration", String.class, false,
                                        true, true, false,
                                        true, false, true, false));

    addPinfo(new PropertyInfo(PropertyInfoIndex.GEO, Property.GEO, "geo",
                              BwGeo.class, false,
                              true, true, false,
                              false, false, false, true));

    addPinfo(etjPropertyPlus(PropertyInfoIndex.LAST_MODIFIED, Property.LAST_MODIFIED,
                                            "lastmod", TimeRange.class,
                                            false, true, false, true));

    addPinfo(new PropertyInfo(PropertyInfoIndex.LOCATION, Property.LOCATION,
                                        "location", String.class, false,
                                        true, true, false,
                                        false, false, false, false));

    addPinfo(etjPropertyPlus(PropertyInfoIndex.ORGANIZER, Property.ORGANIZER,
                                      "organizer", String.class,
                                      true, false, false));

    addPinfo(new PropertyInfo(PropertyInfoIndex.PRIORITY, Property.PRIORITY,
                                        "priority", Integer.class, false,
                                        true, true, false,
                                        false, false, false, false));

    addPinfo(etjPropertyPlus(PropertyInfoIndex.RECURRENCE_ID, Property.RECURRENCE_ID,
                                            "recurrenceId", BwDateTime.class,
                                            true, false, false));

    addPinfo(etjProperty(PropertyInfoIndex.SEQUENCE, Property.SEQUENCE,
                         "sequence", Integer.class));

    addPinfo(etjProperty(PropertyInfoIndex.STATUS, Property.STATUS, "status",
                         String.class));

    addPinfo(etjPropertyPlus(PropertyInfoIndex.UID, Property.UID,
                             "uid", String.class,
                             true, false, false, true));

    addPinfo(etjPropertyPlus(PropertyInfoIndex.URL, Property.URL,
                             "link", String.class,
                             true, false, false));

    addPinfo(new PropertyInfo(PropertyInfoIndex.DTEND, Property.DTEND,
                              "dtend", "dtval",
                              BwDateTime.class, false,
                              true, false, false,
                              true, false, false));

    addPinfo(new PropertyInfo(PropertyInfoIndex.TRANSP, Property.TRANSP,
                                      "transparency", String.class, false,
                                      true, false, false,
                                      false, false, false, false));

    addPinfo(new PropertyInfo(PropertyInfoIndex.COMPLETED, Property.COMPLETED,
                                         "completed", String.class, false,
                                         false, true, false,
                                         false, false, false, false));

    addPinfo(new PropertyInfo(PropertyInfoIndex.DUE, Property.DUE,
                              "dtend", "dtval",
                              BwDateTime.class, false,
                              false, true, false,
                              false, false, false));

    addPinfo(new PropertyInfo(PropertyInfoIndex.PERCENT_COMPLETE,
                                                Property.PERCENT_COMPLETE,
                                                "percentComplete",
                                                Integer.class, false,
                                                false, true, false,
                                                false, false, false, false));

    /* ---------------------------- Multi valued in the db --------------- */

    addPinfo(etjMultiPropertyPlus(PropertyInfoIndex.DESCRIPTION, Property.DESCRIPTION,
                                  "descriptions", String.class,
                                  false, false, true, true));

    addPinfo(etjMultiPropertyPlus(PropertyInfoIndex.SUMMARY, Property.SUMMARY,
                                  "summaries", String.class,
                                  false, false, true));

    /* ---------------------------- Multi valued --------------- */

    // TODO implement attach
    addPinfo(etjMultiPropertyPlus(PropertyInfoIndex.ATTACH, Property.ATTACH, null,
                                  String.class,
                                  false, false, true));

    addPinfo(etjMultiPropertyPlus(PropertyInfoIndex.ATTENDEE, Property.ATTENDEE,
                                            "attendees", String.class,
                                            true, false, true));

    addPinfo(etjMultiPropertyPlus(PropertyInfoIndex.CATEGORIES, Property.CATEGORIES,
                                  "categories", String.class,
                                  false, false, false, true));

    addPinfo(etjMultiPropertyPlus(PropertyInfoIndex.COMMENT, Property.COMMENT,
                                           "comments", String.class,
                                           true, true, false));

    addPinfo(etjMultiPropertyPlus(PropertyInfoIndex.CONTACT, Property.CONTACT,
                                           "contacts", String.class,
                                           true, false, false));

    addPinfo(etjMultiProperty(PropertyInfoIndex.EXDATE, Property.EXDATE,
                                      "recurrence.exdates", BwDateTime.class));

    addPinfo(etjMultiProperty(PropertyInfoIndex.EXRULE, Property.EXRULE,
                                      "recurrence.exrules", String.class));

    addPinfo(etjMultiPropertyPlus(PropertyInfoIndex.REQUEST_STATUS,
                                                  Property.REQUEST_STATUS,
                                                  "requestStatuses",
                                                  String.class,
                                                  true, false, false));
    addPinfo(etjMultiPropertyPlus(PropertyInfoIndex.RELATED_TO, Property.RELATED_TO,
                                  "relatedTo", String.class,
                                  false, false, false, true));

    addPinfo(new PropertyInfo(PropertyInfoIndex.RESOURCES, Property.RESOURCES,
                                         "resources", String.class, true,
                                         true, true, false,
                                         false, false, false, false));

    addPinfo(etjMultiPropertyPlus(PropertyInfoIndex.RDATE, Property.RDATE,
                                         "recurrence.rdates", BwDateTime.class,
                                         false, true, false));

    addPinfo(etjMultiPropertyPlus(PropertyInfoIndex.RRULE, Property.RRULE,
                                         "recurrence.rrules", String.class,
                                         false, true, false));

    addPinfo(etjMultiPropertyPlus(PropertyInfoIndex.XPROP, "XPROP",
                                  "xproperties", String.class,
                                  true, true, true));

    /* -------------------- Alarm only ------------------------ */

    addPinfo(notEtjProperty(PropertyInfoIndex.ACTION, Property.ACTION,
                                         null, String.class,
                                         false, false, true));

    addPinfo(notEtjProperty(PropertyInfoIndex.REPEAT, Property.REPEAT,
                                   "repeatCount", Integer.class,
                                   false, false, true));

    addPinfo(notEtjProperty(PropertyInfoIndex.TRIGGER, Property.TRIGGER,
                                   "trigger", String.class,
                                   false, false, true));

    /* --------------------- Venue only ------------------------ */

    addPinfo(notEtjProperty(PropertyInfoIndex.COUNTRY, Property.COUNTRY,
                            null, String.class,
                            false, false, false, true));

    addPinfo(notEtjProperty(PropertyInfoIndex.EXTENDEDADDRESS, Property.EXTENDED_ADDRESS,
                            null, String.class,
                            false, false, false, true));

    addPinfo(notEtjProperty(PropertyInfoIndex.LOCALITY, Property.LOCALITY,
                            null, String.class,
                            false, false, false, true));

    addPinfo(new PropertyInfo(PropertyInfoIndex.LOCATIONTYPES,
                              Property.LOCATION_TYPE,
                              null, String.class, true,  // multi
                              false, false, false,
                              false, false, false, true));

    addPinfo(notEtjProperty(PropertyInfoIndex.NAME, Property.NAME,
                            null, String.class,
                            false, false, false, true));

    addPinfo(notEtjProperty(PropertyInfoIndex.POSTALCODE, Property.POSTALCODE,
                            null, String.class,
                            false, false, false, true));

    addPinfo(notEtjProperty(PropertyInfoIndex.REGION, Property.REGION,
                            null, String.class,
                            false, false, false, true));

    addPinfo(notEtjProperty(PropertyInfoIndex.STREETADDRESS, Property.STREET_ADDRESS,
                            null, String.class,
                            false, false, false, true));

    addPinfo(notEtjProperty(PropertyInfoIndex.TEL, Property.TEL,
                            null, String.class,
                            false, false, false, true));

    addPinfo(new PropertyInfo(PropertyInfoIndex.TYPEDURLS,
                              "TYPEDURLS",
                              null, String.class, true,  // multi
                              false, false, false,
                              false, false, false, true));

    /* -------------- Other non-event, non-todo ---------------- */


    addPinfo(notEtjProperty(PropertyInfoIndex.FREEBUSY, Property.FREEBUSY,
                                     "times", BwFreeBusyComponent.class,
                                     true, false, false));

    addPinfo(notEtjProperty(PropertyInfoIndex.TZID, Property.TZID,
                            null, String.class,
                            false, true, false, true));

    addPinfo(notEtjProperty(PropertyInfoIndex.TZNAME, Property.TZNAME,
                                     null, String.class,
                                     false, true, false));

    addPinfo(notEtjProperty(PropertyInfoIndex.TZOFFSETFROM, Property.TZOFFSETFROM,
                                     null, Integer.class,
                                     false, true, false));

    addPinfo(notEtjProperty(PropertyInfoIndex.TZOFFSETTO, Property.TZOFFSETTO,
                                     null, Integer.class,
                                     false, true, false));

    addPinfo(notEtjProperty(PropertyInfoIndex.TZURL, Property.TZURL,
                                     null, String.class,
                                     false, true, false));

    /* -------------- Non-rfc bedework properties ---------------- */

    addPinfo(etjProperty(PropertyInfoIndex.CREATOR, "CREATOR", "creator",
                         BwUser.class));

    addPinfo(etjProperty(PropertyInfoIndex.ENTITY_TYPE, "ENTITY_TYPE",
                         "entityType", Integer.class));

    addPinfo(etjProperty(PropertyInfoIndex.OWNER, "OWNER", "owner",
                         BwUser.class));

    addPinfo(etjMultiPropertyPlus(PropertyInfoIndex.VALARM, "VALARM",
                                  "alarms", BwAlarm.class,
                                  false, false, true));
  }

  static { /* ------------------ Parameters ---------------------- */
    addPinfo(new PropertyInfo(PropertyInfoIndex.LANG, Parameter.LANGUAGE,
                             "lang", String.class, false));

    addPinfo(new PropertyInfo(PropertyInfoIndex.TZIDPAR, Parameter.TZID,
                             "tzid", String.class, false));
  }

  /**
   * @param index
   * @return String name of property
   */
  public static String propertyName(PropertyInfoIndex index) {
    PropertyInfo pi = propertyInfo.get(index);
    if (pi == null) {
      return null;
    }

    return pi.name;
  }

  private static void addPinfo(PropertyInfo pinfo) {
    PropertyInfo pinfo1 = propertyInfo.put(pinfo.getPindex(), pinfo);
    if (pinfo1 != null) {
      throw new RuntimeException("Duplicate index " + pinfo.getPindex());
    }

    propertyInfoByPname.put(pinfo.name, pinfo);
  }

  /* A property that appears in event todo journal */
  private static PropertyInfo etjProperty(PropertyInfoIndex pindex, String name,
                                          String field, Class valClass){
    return new PropertyInfo(pindex, name, field, valClass, false,
                            true, true, true, false, false, false, false);
  }

  private static PropertyInfo etjMultiProperty(PropertyInfoIndex pindex,
                                               String name,
                                               String field, Class valClass){
    return new PropertyInfo(pindex, name, field, valClass, true,
                            true, true, true, false, false, false, false);
  }

  private static PropertyInfo etjMultiPropertyPlus(PropertyInfoIndex pindex,
                                                   String name, String field,
                                                   Class valClass,
                                                   boolean freeBusyProperty,
                                                   boolean timezoneProperty,
                                                   boolean alarmProperty){
    return new PropertyInfo(pindex, name, field, valClass, true,
                            true, true, true,
                            freeBusyProperty, timezoneProperty, alarmProperty,
                            false);
  }

  private static PropertyInfo etjMultiPropertyPlus(PropertyInfoIndex pindex,
                                                   String name, String field,
                                                   Class valClass,
                                                   boolean freeBusyProperty,
                                                   boolean timezoneProperty,
                                                   boolean alarmProperty,
                                                   boolean venueProperty){
    return new PropertyInfo(pindex, name, field, valClass, true,
                            true, true, true,
                            freeBusyProperty, timezoneProperty, alarmProperty,
                            venueProperty);
  }

  private static PropertyInfo etjPropertyPlus(PropertyInfoIndex pindex,
                                              String name, String field,
                                              Class valClass,
                                              boolean freeBusyProperty,
                                              boolean timezoneProperty,
                                              boolean alarmProperty){
    return new PropertyInfo(pindex, name, field, valClass, false,
                            true, true, true,
                            freeBusyProperty, timezoneProperty, alarmProperty,
                            false);
  }

  private static PropertyInfo etjPropertyPlus(PropertyInfoIndex pindex,
                                              String name, String field,
                                              Class valClass,
                                              boolean freeBusyProperty,
                                              boolean timezoneProperty,
                                              boolean alarmProperty,
                                              boolean venueProperty){
    return new PropertyInfo(pindex, name, field, valClass, false,
                            true, true, true,
                            freeBusyProperty, timezoneProperty, alarmProperty,
                            venueProperty);
  }

  private static PropertyInfo etjCompoundPropertyPlus(PropertyInfoIndex pindex,
                                              String name, String field,
                                              String presenceField, Class valClass,
                                              boolean freeBusyProperty,
                                              boolean timezoneProperty,
                                              boolean alarmProperty){
    return new PropertyInfo(pindex, name, field, valClass, false,
                            true, true, true,
                            freeBusyProperty, timezoneProperty, alarmProperty,
                            false);
  }

  private static PropertyInfo notEtjProperty(PropertyInfoIndex pindex,
                                             String name, String field,
                                             Class valClass,
                                             boolean freeBusyProperty,
                                             boolean timezoneProperty,
                                             boolean alarmProperty){
    return new PropertyInfo(pindex, name, field, valClass, false,
                            false, false, false,
                            freeBusyProperty, timezoneProperty, alarmProperty,
                            false);
  }

  private static PropertyInfo notEtjProperty(PropertyInfoIndex pindex,
                                             String name, String field,
                                             Class valClass,
                                             boolean freeBusyProperty,
                                             boolean timezoneProperty,
                                             boolean alarmProperty,
                                             boolean venueProperty){
    return new PropertyInfo(pindex, name, field, valClass, false,
                            false, false, false,
                            freeBusyProperty, timezoneProperty, alarmProperty,
                            venueProperty);
  }
}
