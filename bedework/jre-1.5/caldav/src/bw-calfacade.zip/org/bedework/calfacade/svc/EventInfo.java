/* **********************************************************************
    Copyright 2007 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade.svc;

import org.bedework.calfacade.BwAlarm;
import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.BwEventAnnotation;
import org.bedework.calfacade.BwEventProxy;
import org.bedework.calfacade.util.ChangeTable;

import edu.rpi.cmt.access.Acl.CurrentAccess;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.TreeSet;

/** This class provides information about an event for a specific user and
 * session.
 *
 * <p>This class allows us to handle thread, or user, specific information.
 *
 * @author Mike Douglass       douglm @ rpi.edu
 */
public class EventInfo implements Comparable, Comparator, Serializable {
  protected BwEvent event;

  /** editable is set at retrieval to indicate an event owned by the current
   * user. This only has significance for the personal calendar.
   */
  protected boolean editable;

  protected boolean fromRef;

  /* ENUM
   * XXX these need changing
   */

  /** actual event entry */
  public final static int kindEntry = 0;
  /** 'added' event - from a reference */
  public final static int kindAdded = 1;
  /** from a subscription */
  public final static int kindUndeletable = 2;

  private int kind;

  private static final String[] kindStr = {
    "entry",
    "reffed",
    "subscribed",
  };

  private boolean newEvent;

  private String prevLastmod;

  private int prevSeq;

  /** If this event came from a subscription, this provides the object. If
   * selected from a calendar it may be null.
   */
  private BwSubscription subscription;

  /** A Collection of related BwAlarm objects. These may just be the alarms
   * defined in an ical calendar or all alarms for the given event.
   *
   * <p>These are not fetched while fetching the event. Call getAlarms()
   */
  private Collection<BwAlarm> alarms = null;

  /** If the event is a master recurring event and we asked for the master +
   * overides or for fully expanded, this will hold all the overrides for that
   * event in the form of EventInfo objects referencing a BwProxyEvent.
   */
  private Collection<EventInfo> overrides;

  /** If the event is a master recurring event and we asked for a full
   * expansion, this will hold all the instances for that event in the form of
   * EventInfo objects.
   */
  private Collection<EventInfo> instances;

  /** Collection of EventInfo representing AVAILABLE components
   * Only for entityTypeVavailability
   */
  private Collection<EventInfo> available;

  /** If non-null this event comes from a recurrence
   */
  private String recurrenceId;

  /* This object contains information giving the current users access rights to
   * the entity.
   */
  private CurrentAccess currentAccess;

  private ChangeTable changeSet;

  /* Fields set when we are doing a scheduling operation. They indicate the
   * attendee who requested the operation and the name of the inbox event from
   * that attendee.
   */
  private String replyAttendeeURI;
  private String inboxEventName;

  /**
   *
   */
  public EventInfo() {
  }

  /**
   * @param event
   */
  public EventInfo(BwEvent event) {
    setEvent(event);
  }

  /**
   * @param val
   */
  public void setEvent(BwEvent val) {
    event = val;
    fromRef = val instanceof BwEventAnnotation;
    setPrevLastmod(val.getLastmod());
    setPrevSeq(val.getSeq());
  }

  /**
   * @return BwEvent associated with this object
   */
  public BwEvent getEvent() {
    return event;
  }

  /** editable is set at retrieval to indicate an event owned by the current
   * user. This only has significance for the personal calendar.
   *
   * XXX - not applicable in a shared world?
   *
   * @param val
   */
  public void setEditable(boolean val) {
    editable = val;
  }

  /**
   * @return true if object is considered editable
   */
  public boolean getEditable() {
    return editable;
  }

  /** Return true if this event is included as a reference
   *
   * @return true if object is from a ref
   */
  public boolean getFromRef() {
    return fromRef;
  }

  /**
   * @param val
   */
  public void setKind(int val) {
    kind = val;
  }

  /**
   * @return int kind of event
   */
  public int getKind() {
    return kind;
  }

  /** This field is set by those input methods which might need to retrieve
   * an event for update, for example the icalendar translators.
   *
   * <p>They retrieve the event based on the guid. If the guid is not found
   * then we assume a new event. Otherwise this flag is set false.
   *
   *  @param  val    boolean true if a new event
   */
  public void setNewEvent(boolean val) {
    newEvent = val;
  }

  /** Is the event new?
   *
   *  @return boolean    true if the event is new
   */
  public boolean getNewEvent() {
    return newEvent;
  }

  /** Set the event's previous lastmod - used to allow if none match
   *
   *  @param val     lastmod
   */
  public void setPrevLastmod(String val) {
    prevLastmod = val;
  }

  /** Get the event's previous lastmod - used to allow if none match
   *
   * @return the event's lastmod
   */
  public String getPrevLastmod() {
    return prevLastmod;
  }

  /** Set the event's previous seq - used to allow if none match
   *
   *  @param val     sequence number
   */
  public void setPrevSeq(int val) {
    prevSeq = val;
  }

  /** Get the event's previous seq - used to allow if none match
   *
   * @return the event's seq
   */
  public int getPrevSeq() {
    return prevSeq;
  }

  /** This is set in the svci level after retrieval and should always be non-null.
   *
   * @param val
   */
  public void setSubscription(BwSubscription val) {
    subscription = val;
  }

  /**
   * @return BwSubscription causing event retrieval
   */
  public BwSubscription getSubscription() {
    return subscription;
  }

  /** Set the event's recurrence id
   *
   *  @param val     recurrence id
   */
  public void setRecurrenceId(String val) {
     recurrenceId = val;
  }

  /** Get the event's recurrence id
   *
   * @return the event's recurrence id
   */
  public String getRecurrenceId() {
    return recurrenceId;
  }

  /** Set the current users access rights.
   *
   * @param val  CurrentAccess
   */
  public void setCurrentAccess(CurrentAccess val) {
    currentAccess = val;
  }

  /** Get the current users access rights.
   *
   * @return  CurrentAccess
   */
  public CurrentAccess getCurrentAccess() {
    return currentAccess;
  }

  /** Set change set for event recurrences
   *
   * @param val
   */
  public void setChangeset(ChangeTable val) {
    changeSet = val;
  }

  /** Get change set for the event. The absence of a change set does not
   * mean no changes - there may be overrides to apply.
   *
   * @return null for no changes
   */
  public ChangeTable getChangeset() {
    return changeSet;
  }

  /* ====================================================================
   *                   Alarms methods
   * ==================================================================== */

  /**
   * @param val
   */
  public void setAlarms(Collection<BwAlarm> val) {
    alarms = val;
  }

  /**
   * @return Collection of alarms
   */
  public Collection<BwAlarm> getAlarms() {
    return alarms;
  }

  /**
   * @return int number of alarms.
   */
  public int getNumAlarms() {
    Collection<BwAlarm> as = getAlarms();
    if (as == null) {
      return 0;
    }

    return as.size();
  }

  /** clear the event's alarms
   */
  public void clearAlarms() {
    Collection<BwAlarm> as = getAlarms();
    if (as != null) {
      as.clear();
    }
  }

  /**
   * @param val
   */
  public void addAlarm(BwAlarm val) {
    Collection<BwAlarm> as = getAlarms();
    if (as == null) {
      as = new TreeSet<BwAlarm>();
    }

    if (!as.contains(val)) {
      as.add(val);
    }
  }

  /* ====================================================================
   *                   Overrides methods
   * ==================================================================== */

  /** Set the overrides collection
   *
   * @param val    Collection of overrides
   */
  public void setOverrides(Collection<EventInfo> val) {
    overrides = val;
  }

  /** Get the overrides
   *
   *  @return Collection     overrides list
   */
  public Collection<EventInfo> getOverrides() {
    return overrides;
  }

  /**
   * @return int number of overrides.
   */
  public int getNumOverrides() {
    Collection<EventInfo> os = getOverrides();
    if (os == null) {
      return 0;
    }

    return os.size();
  }

  /**
   * @param val
   */
  public void addOverride(EventInfo val) {
    Collection<EventInfo> os = getOverrides();
    if (os == null) {
      os = new TreeSet<EventInfo>();
      setOverrides(os);
    }

    if (!os.contains(val)) {
      os.add(val);
    }
  }

  /**
   * @param val
   * @return boolean true if removed.
   */
  public boolean removeOverride(BwEventAnnotation val) {
    Collection<EventInfo> os = getOverrides();
    if (os == null) {
      return false;
    }

    return os.remove(val);
  }

  /**
   * @return Collection of override proxy events or null
   */
  public Collection<BwEventProxy> getOverrideProxies() {
    if (getNumOverrides() == 0) {
      return null;
    }

    TreeSet<BwEventProxy> proxies = new TreeSet<BwEventProxy>();

    for (EventInfo ei: getOverrides()) {
      BwEventProxy proxy = (BwEventProxy)ei.getEvent();
      proxies.add(proxy);
    }

    return proxies;
  }

  /* ====================================================================
   *                   Instances methods
   * ==================================================================== */

  /** Set the instances collection
   *
   * @param val    Collection of instances
   */
  public void setInstances(Collection<EventInfo> val) {
    instances = val;
  }

  /** Get the instances
   *
   *  @return Collection     instances list
   */
  public Collection<EventInfo> getInstances() {
    return instances;
  }

  /**
   * @return int number of instances.
   */
  public int getNumInstances() {
    Collection<EventInfo> is = getInstances();
    if (is == null) {
      return 0;
    }

    return is.size();
  }

  /**
   * @param val
   */
  public void addInstance(EventInfo val) {
    Collection<EventInfo> is = getInstances();
    if (is == null) {
      is = new TreeSet<EventInfo>();
      setInstances(is);
    }

    if (!is.contains(val)) {
      is.add(val);
    }
  }

  /**
   * @param val
   * @return boolean true if removed.
   */
  public boolean removeInstance(EventInfo val) {
    Collection<EventInfo> is = getInstances();
    if (is == null) {
      return false;
    }

    return is.remove(val);
  }

  /* ====================================================================
   *                   Availability methods
   * ==================================================================== */

  /** set the available times
   *
   * @param val     Collection    of EventInfo all marked as entityTypeAvailable
   */
  public void setAvailable(Collection<EventInfo> val) {
    available = val;
  }

  /** Get the available times
   *
   * @return Collection    of BwEvent
   */
  public Collection<EventInfo> getAvailable() {
    return available;
  }

  /** Add an available component
   *
   * @param val
   */
  public void addAvailable(EventInfo val) {
    Collection<EventInfo> avl = getAvailable();

    if (avl == null) {
      avl = new ArrayList<EventInfo>();
      setAvailable(avl);
    }

    avl.add(val);
    getEvent().addAvailableUid(val.getEvent().getUid());
  }

  /** An attendee we need to send a reply to
   *
   *  @param val     uri
   */
  public void setReplyAttendeeURI(String val) {
    replyAttendeeURI = val;
  }

  /** An attendee we need to send a reply to
   *
   * @return uri
   */
  public String getReplyAttendeeURI() {
    return replyAttendeeURI;
  }

  /**
   *  @param val     event name
   */
  public void setInboxEventName(String val) {
    inboxEventName = val;
  }

  /**
   * @return inbox event name
   */
  public String getInboxEventName() {
    return inboxEventName;
  }

  /* ====================================================================
   *                   Object methods
   * ==================================================================== */

  public int compare(Object o1, Object o2) {
    if (!(o1 instanceof EventInfo)) {
      return -1;
    }

    if (!(o2 instanceof EventInfo)) {
      return 1;
    }

    if (o1 == o2) {
      return 0;
    }

    EventInfo e1 = (EventInfo)o1;
    EventInfo e2 = (EventInfo)o2;

    return e1.getEvent().compare(e1.getEvent(), e2.getEvent());
  }

  public int compareTo(Object o2) {
    return compare(this, o2);
  }

  public int hashCode() {
    return getEvent().hashCode();
  }

  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }

    if (!(obj instanceof EventInfo)) {
      return false;
    }

    return compareTo(obj) == 0;
  }

  public String toString() {
    StringBuffer sb = new StringBuffer();

    sb.append("EventInfo{eventid=");

    if (getEvent() == null) {
      sb.append("UNKNOWN");
    } else {
      sb.append(getEvent().getId());
    }
    sb.append(", editable=");
    sb.append(getEditable());
    sb.append(", kind=");
    sb.append(kindStr[getKind()]);

    if (getAlarms() != null) {
      for (BwAlarm alarm: getAlarms()) {
        sb.append(", alarm=");
        sb.append(alarm);
      }
    }
    sb.append(", recurrenceId=");
    sb.append(getRecurrenceId());
    sb.append("}");

    return sb.toString();
  }
}

