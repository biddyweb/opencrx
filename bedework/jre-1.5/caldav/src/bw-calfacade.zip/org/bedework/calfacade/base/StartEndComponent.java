/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade.base;

import org.bedework.calfacade.BwDateTime;

/** This interface is implemented by entities which have a start and an end.
 *
 * <p>They may also have a duration, though it's meaning differs.
 *
 * <p>For event and todo entities we may have an end specified with a duration
 * or with a date or date/time value, or o end date at all.
 *
 * <p>We always calculate an end date internally, so we do not need to use the
 * duration until we render the object.
 *
 * @author Mike Douglass   douglm - rpi.edu
 *
 */
public interface StartEndComponent {
  /** No end or duration */
  public static final char endTypeNone = 'N';
  /** End specified with a date(time) */
  public static final char endTypeDate = 'E';
  /** Duration specified */
  public static final char endTypeDuration = 'D';

  /** Set the start time for the entity
   *
   *  @param  val   Event's start
   */
  public void setDtstart(BwDateTime val);

  /** Get the start time for the entity
   *
   *  @return The start
   */
  public BwDateTime getDtstart();

  /** Set the end or due date for the entity
   *
   *  @param  val   end
   */
  public void setDtend(BwDateTime val);

  /** Get the event's end
   *
   *  @return The event's end
   */
  public BwDateTime getDtend();

  /** Set the endType flag for an event or todo
   *
   *  @param  val    char endType
   */
  public void setEndType(char val);

  /** get the endType flag for an event or todo
   *
   *  @return char    end Type
   */
  public char getEndType();

  /** Set the duration for the entity if an event or todo, or the requested
   * duration for a free/busy object.
   *
   *  @param val   string duration
   */
  public void setDuration(String val);

  /** Get the duration for the entity if an event or todo, or the requested
   * duration for a free/busy object.
   *
   * @return the event's duration
   */
  public String getDuration();

  /** A todo may have no start/end. If so it always appears in the current day
   * until completed.
   *
   * @param val
   */
  public void setNoStart(Boolean val);

  /** A todo may have no start/end. If so it always appears in the current day
   * until completed.
   *
   * @return true for no start/end
   */
  public Boolean getNoStart();
}
