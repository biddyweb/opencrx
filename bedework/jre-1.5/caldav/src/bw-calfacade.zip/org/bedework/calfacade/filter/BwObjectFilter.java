/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade.filter;

import org.bedework.calfacade.base.TimeRange;
import org.bedework.calfacade.util.PropertyIndex.PropertyInfoIndex;

/** A filter that selects events which match the single object value.
 *
 * The name should be unique at least for a set of filters and unique for a
 * given owner if persisted.
 *
 * @author Mike Douglass douglm
 * @param <T> the type of entity
 */
public class BwObjectFilter<T> extends BwPropertyFilter {
  private T entity;

  private boolean exact = true;

  private boolean caseless = true;

  /** No-arg constructor for restore
   *
   */
  public BwObjectFilter() {
    super();
  }

  /** Match on any of the entities.
   *
   * @param name - null one will be created
   * @param propertyIndex
   */
  public BwObjectFilter(String name, PropertyInfoIndex propertyIndex) {
    super(name, propertyIndex);
  }

  /** Set the entity we're filtering on
   *
   *  @param val     entity
   */
  public void setEntity(T val) {
    entity = val;
  }

  /** Get the entity we're filtering on
   *
   *  @return T     entity we're filtering on
   */
  public T getEntity() {
    return entity;
  }

  /** Set the exact flag
   *
   * @param val
   */
  public void setExact(boolean val) {
    exact = val;
  }

  /** See if we do exact match
   *
   *  @return boolean true if exact
   */
  public boolean getExact() {
    return exact;
  }

  /** Set the caseless flag
   *
   * @param val
   */
  public void setCaseless(boolean val) {
    caseless = val;
  }

  /** See if we do caseless match
   *
   *  @return boolean true if caseless
   */
  public boolean getCaseless() {
    return caseless;
  }

  /** Create a filter for the given index
   *
   * @param name
   * @param propertyIndex
   * @return BwObjectFilter
   */
  public static BwObjectFilter makeFilter(String name,
                                          PropertyInfoIndex propertyIndex) {
    BwObjectFilter filter = null;

    switch (propertyIndex) {
    case CLASS:
      break;

    case CREATED:
      break;

    case DESCRIPTION:
      filter = BwIstringFilter.makeDescriptionFilter(name);
      break;

    case DTSTAMP:
      break;

    case DTSTART:
      break;

    case DURATION:
      break;

    case GEO:
      break;

    case LAST_MODIFIED:
      break;

    case LOCATION:
      filter = new BwLocationFilter(name);
      break;

    case ORGANIZER:
      break;

    case PRIORITY:
      break;

    case RECURRENCE_ID:
      break;

    case SEQUENCE:
      break;

    case STATUS:
      break;

    case SUMMARY:
      filter = BwIstringFilter.makeSummaryFilter(name);
      break;

    case UID:
      break;

    case URL:
      break;

  /* Event only */

    case DTEND:
      break;

    case TRANSP:
      break;

  /* Todo only */

    case COMPLETED:
      break;

    case DUE:
      break;

    case PERCENT_COMPLETE:
      break;

  /* ---------------------------- Multi valued --------------- */

  /* Event and Todo */

    case ATTACH:
      break;

    case ATTENDEE :
      break;

    case CATEGORIES:
      filter = new BwCategoryFilter(name);
      break;

    case COMMENT:
      break;

    case CONTACT:
      filter = new BwContactFilter(name);
      break;

    case EXDATE:
      break;

    case EXRULE :
      break;

    case REQUEST_STATUS:
      break;

    case RELATED_TO:
      break;

    case RESOURCES:
      break;

    case RDATE:
      break;

    case RRULE :
      break;

  /* -------------- Other non-event: non-todo ---------------- */

    case FREEBUSY:
      break;

    case TZID:
      break;

    case TZNAME:
      break;

    case TZOFFSETFROM:
      break;

    case TZOFFSETTO:
      break;

    case TZURL:
      break;

    case ACTION:
      break;

    case REPEAT:
      break;

    case TRIGGER:
      break;

    case CREATOR:
      filter = new BwCreatorFilter(name);
      break;

    case OWNER:
      break;

    case ENTITY_TYPE:
      break;

    }

    return filter;
  }

  /** Create a timerange filter for the given index and value
   *
   * @param name
   * @param propertyIndex
   * @param val     TimeRange
   * @return BwObjectFilter
   */
  public static BwObjectFilter makeFilter(String name,
                                          PropertyInfoIndex propertyIndex,
                                          TimeRange val) {
    BwTimeRangeFilter trf = new BwTimeRangeFilter(name, propertyIndex);

    trf.setEntity(val);

    return trf;
  }

  /* ====================================================================
   *                   Object methods
   * ==================================================================== */

  public String toString() {
    StringBuffer sb = new StringBuffer("BwObjectFilter{");

    super.toStringSegment(sb);
    sb.append("\nobj=");
    sb.append(getEntity());

    sb.append("}");

    return sb.toString();
  }
}
