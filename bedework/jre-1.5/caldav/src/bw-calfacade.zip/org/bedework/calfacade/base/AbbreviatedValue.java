/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade.base;

import org.bedework.calfacade.util.CalFacadeUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

/** A value and its abbreviations
 *
 * @author Mike Douglass
 *
 */
public class AbbreviatedValue implements Comparable<AbbreviatedValue>, Serializable {
  /** */
  public Collection<String> abbrevs;
  /** */
  public String value;

  /** Constructor
   *
   * @param abbrevs
   * @param value
   */
  public AbbreviatedValue(Collection<String>abbrevs, String value) {
    this.abbrevs = abbrevs;
    this.value = value;
  }

  /**
   * @param val
   */
  public void setAbbrevs(Collection<String> val) {
    abbrevs = val;
  }

  /**
   * @return Collection<String>
   */
  public Collection<String> getAbbrevs() {
    return abbrevs;
  }

  /** Set the value
   *
   * @param val    String value
   */
  public void setValue(String val) {
    value = val;
  }

  /** Get the value
   *
   *  @return String   value
   */
  public String getValue() {
    return value;
  }

  /* ====================================================================
   *                        Object methods
   * ==================================================================== */

  public int compareTo(AbbreviatedValue that) {
    if (that == this) {
      return 0;
    }

    if (that == null) {
      return -1;
    }

    int res = CalFacadeUtil.cmpObjval(getAbbrevs(), that.getAbbrevs());

    if (res != 0) {
      return res;
    }

    return CalFacadeUtil.cmpObjval(getValue(), that.getValue());
  }

  public int hashCode() {
    int hc = 7;

    if (getAbbrevs() != null) {
      hc *= getAbbrevs().hashCode();
    }

    if (getValue() != null) {
      hc *= getValue().hashCode();
    }

    return hc;
  }

  public String toString() {
    StringBuilder sb = new StringBuilder("AbbreviatedValue{");

    sb.append("value=");
    sb.append(value);
    sb.append("}");

    return sb.toString();
  }

  public Object clone() {
    return new AbbreviatedValue(new ArrayList<String>(getAbbrevs()),
                                getValue());
  }
}
