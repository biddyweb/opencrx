/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade.base;

import java.io.Serializable;

/** Key to an event or events.
 *
 * @author douglm
 *
 */
public class BwEventKey implements Serializable {
  private String calPath;

  private String guid;

  private String recurrenceId;

  private String name;

  private Boolean recurring;

  /** Constructor
   *
   * @param calPath
   * @param guid
   * @param recurrenceId
   * @param name
   * @param recurring  iformational
   */
  public BwEventKey(String calPath,
                    String guid, String recurrenceId,
                    String name,
                    Boolean recurring) {
    this.calPath = calPath;
    this.guid = guid;
    this.recurrenceId = recurrenceId;
    this.name = name;
    this.recurring = recurring;
  }

  /** Set the event's calendar path
   *
   * @param val    String event's name
   */
  public void setCalPath(String val) {
    calPath = val;
  }

  /** Get the event's calendar path.
   *
   * @return String   event's name
   */
  public String getCalPath() {
    return calPath;
  }

  /** Set the event's guid
   *
   * @param val    String event's guid
   */
  public void setGuid(String val) {
    guid = val;
  }

  /** Get the event's guid
   *
   * @return String   event's guid
   */
  public String getGuid() {
    return guid;
  }

  /** Set the event's recurrence id
   *
   *  @param val     recurrence id
   */
  public void setRecurrenceId(String val) {
     recurrenceId = val;
  }

  /** Get the event's recurrence id
   *
   * @return the event's recurrence id
   */
  public String getRecurrenceId() {
    return recurrenceId;
  }

  /** Set the event's name
   *
   * @param val    String event's name
   */
  public void setName(String val) {
    name = val;
  }

  /** Get the event's name.
   *
   * @return String   event's name
   */
  public String getName() {
    return name;
  }

  /**
   * @param val
   */
  public void setRecurring(Boolean val) {
    recurring = val;
  }

  /**
   * @return Boolean true if a recurring event
   */
  public Boolean getRecurring() {
    return recurring;
  }

  /**
   * @return String
   */
  public String toStringSegment() {
    StringBuffer sb = new StringBuffer();

    sb.append("calPath=");
    sb.append(getCalPath());
    sb.append("guid=");
    sb.append(getGuid());
    sb.append("recurrenceId=");
    sb.append(getRecurrenceId());
    sb.append("name=");
    sb.append(getName());

    return sb.toString();
  }

  public String toString() {
    StringBuffer sb = new StringBuffer("BwEventKey{");
    sb.append(toStringSegment());
    sb.append("}");

    return sb.toString();
  }
}
