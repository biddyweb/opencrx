/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade;

import org.bedework.calfacade.base.BwDbentity;
import org.bedework.calfacade.exc.CalFacadeException;

import java.util.Collection;
import java.util.Iterator;
import java.util.TreeSet;

import net.fortuna.ical4j.model.DateTime;
import net.fortuna.ical4j.model.Dur;
import net.fortuna.ical4j.model.Period;
import net.fortuna.ical4j.model.PeriodList;

/** Class representing a free busy time component. Used in icalendar objects
 *
 * @author Mike Douglass   douglm@rpi.edu
 *  @version 1.0
 */
public class BwFreeBusyComponent extends BwDbentity {
  /** busy time - default */
  public static final int typeBusy = 0;

  /** free time */
  public static final int typeFree = 1;

  /** unavailable time */
  public static final int typeBusyUnavailable = 2;

  /** tentative busy time */
  public static final int typeBusyTentative = 3;

  private int type = typeBusy;

  /** True if each period is start + duration. False for start + end
   */
  public static final boolean emitDurations = true;

  private String value;

  /** Collection of Period
   */
  private Collection<Period> periods;

  /** Constructor
   *
   */
  public BwFreeBusyComponent() {
  }

  /**
   * @param val
   */
  public void setType(int val) {
    type = val;
  }

  /**
   * @return int type of time
   */
  public int getType() {
    return type;
  }

  /**
   * @param val
   */
  public void setValue(String val) {
    value = val;
    periods = null;
  }

  /**
   * @return String representation of list
   * @throws CalFacadeException
   */
  public String getValue() throws CalFacadeException {
    if (value == null) {
      if ((periods == null) || periods.isEmpty()) {
        return null;
      }

      PeriodList pl = new PeriodList();

      for (Period p: getPeriods()) {
        pl.add(p);
      }

      value = pl.toString();
    }

    return value;
  }

  /** Get the free busy periods
   *
   * @return Collection    of Period
   * @throws CalFacadeException
   */
  public Collection<Period> getPeriods() throws CalFacadeException {
    try {
      if (periods == null) {
        periods = new TreeSet<Period>();

        if (getValue() != null) {
          PeriodList pl = new PeriodList(getValue());
          Iterator perit = pl.iterator();

          while (perit.hasNext()) {
            Period per = (Period)perit.next();

            periods.add(per);
          }
        }
      }
      return periods;
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /* ====================================================================
   *                   Convenience methods
   * ==================================================================== */

  /** Merge in a period
   *
   * @param val
   * @throws CalFacadeException
   */
  public void addPeriod(Period val) throws CalFacadeException {
    getPeriods().add(val);
    value = null;
  }

  /** Merge in a period
   *
   * @param start
   * @param end
   * @throws CalFacadeException
   */
  public void addPeriod(DateTime start, DateTime end) throws CalFacadeException {
    Period p;

    if (emitDurations) {
      p = new Period(start, new Dur(start, end));
    } else {
      p = new Period(start, end);
    }

    addPeriod(p);
  }

  /**
   * @return boolean true for empty
   * @throws CalFacadeException
   */
  public boolean getEmpty() throws CalFacadeException {
    return (getPeriods().size() == 0);
  }

  /* ====================================================================
   *                        Object methods
   * ==================================================================== */

  public String toString() {
    StringBuffer sb = new StringBuffer();

    sb.append("BwFreeBusyComponent{type=");
    sb.append(getType());
    sb.append(", ");

    try {
      for (Period p: getPeriods()) {
        sb.append(", (");
        sb.append(p.toString());
        sb.append(")");
      }
    } catch (Throwable t) {
      sb.append("Exception(");
      sb.append(t.getMessage());
      sb.append(")");
    }
    sb.append("}");

    return sb.toString();
  }

  public Object clone() {
    BwFreeBusyComponent fbc = new BwFreeBusyComponent();

    try {
      fbc.setType(getType());
      fbc.setValue(getValue());
    } catch (Throwable t) {
      throw new RuntimeException(t);
    }

    return fbc;
  }
}
