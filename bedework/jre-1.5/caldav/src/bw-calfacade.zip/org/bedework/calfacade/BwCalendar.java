/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade;

import org.bedework.calfacade.base.BwShareableContainedDbentity;
import org.bedework.calfacade.base.CategorisedEntity;
import org.bedework.calfacade.base.CollatableEntity;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.util.CalFacadeUtil;

import edu.rpi.cmt.access.Acl.CurrentAccess;

import net.fortuna.ical4j.model.DateTime;
import net.fortuna.ical4j.model.property.LastModified;

import java.net.URLEncoder;
import java.util.Collection;
import java.util.Date;
import java.util.TreeSet;

/** A calendar in Bedework. This is roughly equivalent to a folder with some
 * rules attached.
 *
 * <p>These objects are used to create two tree structures rooted at the public
 * calendars root and the user calendars root. The names of the roots are defined
 * at system build time.
 *
 * <p>For caldav compatability we currently do not allow calendar collections
 * inside calendar collections. The flag calendarCollection is set true if
 * if this is intended to hold a collection of calendar objects.
 *
 * <p>Calendars are also given a type defined as follows:<ul>
 *
 * <li><em> Normal folder </em>Holds other collections</li>
 *
 * <li><em> Normal calendar collection </em>Normal calendar, holds events, todos etc</li>
 * <li><em> Trash  </em>Holds deleted events</li>
 * <li><em> Deleted  </em>Holds annotations which effectively delete events to
 * which the user does not have write access</li>
 * <li><em> Busy </em>Used to store busy time - acts as a mask for freebusy</li>
 * <li><em> Inbox  </em>Incoming scheduling requests, itip and caldav</li>
 * <li><em> Outbox  </em>Outgoing scheduling requests, itip and caldav</li>
 * </ul>
 *
 * <p>Events have names which must be unique within a calendar collection. An
 * event, either a single non-recurring event, or a master event and all it's
 * overrides, have a single effective name which would corrrespond to the name
 * of an ics file generated for that event.
 *
 * <p>Calendar entities also have guids. These must be unique within normal
 * calendar collections. That requirement is relaxed for all other special
 * calendars.
 *
 *  @author Mike Douglass douglm - rpi.edu
 *  @version 1.0
 */
public class BwCalendar extends BwShareableContainedDbentity<BwCalendar>
        implements CollatableEntity, CategorisedEntity {
  /** The internal name of the calendar
   */
  private String name;

  /** Path to this calendar - including this one.
   * The names concatenated with intervening '/'
   */
  private String path;

  /** A printable (one line) summary for the calendar
   */
  private String summary;

  /** Some sort of description - may be null
   */
  private String description;

  /** This identifies an associated mailing list. Its actual value is set
   * by the mailer interface.
   */
  private String mailListId;

  /** true if this is to 'hold' calendar objects
   */
  private boolean calendarCollection;

  /** The children of this calendar */
  private Collection<BwCalendar> children;

  /* The type of calendar */
  // ENUM
  private int calType;

  /** Indicate unknown type */
  public final static int calTypeUnknown = -1;

  /** Normal folder */
  public final static int calTypeFolder = 0;

  /** Normal calendar collection */
  public final static int calTypeCollection = 1;

  /** Trash  */
  public final static int calTypeTrash = 2;

  /** Deleted  */
  public final static int calTypeDeleted = 3;

  /** Busy */
  public final static int calTypeBusy = 4;

  /** Inbox  */
  public final static int calTypeInbox = 5;

  /** Outbox  */
  public final static int calTypeOutbox = 6;

  /** There are limitations on what may be placed in each type of collection,
   *  e.g folders cannot hold entities, guids must be unique in calendars etc.
   *
   *  <p>This class allows us to create a list of characteristics for each
   *  calendar type.
   */
  public static class CollectionInfo {
    /** Allows us to use this as a parameter */
    public int collectionType;

    /** Store entities in this type */
    public boolean entitiesAllowed;

    /** Guid + recurrence must be unique */
    public boolean uniqueKey;

    /** Allow annotations */
    public boolean allowAnnotations;

    /** Freebusy allowed */
    public boolean allowFreeBusy;

    /**
     * @param collectionType
     * @param entitiesAllowed
     * @param uniqueKey
     * @param allowAnnotations
     * @param allowFreeBusy
     */
    public CollectionInfo(int collectionType,
                          boolean entitiesAllowed,
                          boolean uniqueKey,
                          boolean allowAnnotations,
                          boolean allowFreeBusy) {
      this.collectionType = collectionType;
      this.entitiesAllowed = entitiesAllowed;
      this.uniqueKey = uniqueKey;
      this.allowAnnotations = allowAnnotations;
      this.allowFreeBusy = allowFreeBusy;
    }
  }

  /** The info */
  public static CollectionInfo[] collectionInfo = {
    new CollectionInfo(calTypeFolder, false, false, false, true),
    new CollectionInfo(calTypeCollection, true, true, true, true),
    new CollectionInfo(calTypeTrash, true, false, true, false),
    new CollectionInfo(calTypeDeleted, true, false, true, false),
    new CollectionInfo(calTypeBusy, true, true, true, true),
    new CollectionInfo(calTypeInbox, true, false, false, false),
    new CollectionInfo(calTypeOutbox, true, false, false, false),
  };

  /** UTC datetime */
  private String created;

  /** UTC datetime */
  private String lastmod;

  /** Ensure uniqueness - lastmod only down to second.
   */
  private int sequence;

  private Collection<BwCategory> categories = null;

  private Collection<BwProperty> properties;

  /** Constructor
   */
  public BwCalendar() {
    super();

    /* Set the lastmod and created */

    /*
    DateTime dt = new DateTime(true);
    setLastmod(new LastModified(dt).getValue());
    setCreated(new Created(dt).getValue());
    */
    Date dt = new Date();
    setLastmod(CalFacadeUtil.isoDateTimeUTC(dt));
    setCreated(CalFacadeUtil.isoDateTimeUTC(dt));
  }

  /** Constructor
   *
   * @param owner          BwUser user who owns the entity
   * @param publick       boolean true if the event is viewable by everyone
   * @param creator        BwUser user who created the entity
   * @param access
   * @param name
   * @param path
   * @param summary
   * @param description
   * @param mailListId
   * @param calendarCollection
   * @param parent
   * @param children
   * @param calType
   * @param created
   * @param lastmod
   * @param sequence
   * @param categories
   * @param properties
   */
  public BwCalendar(BwUser owner,
                    boolean publick,
                    BwUser creator,
                    String access,
                    String name,
                    String path,
                    String summary,
                    String description,
                    String mailListId,
                    boolean calendarCollection,
                    BwCalendar parent,
                    Collection<BwCalendar> children,
                    int calType,
                    String created,
                    String lastmod,
                    int sequence,
                    Collection<BwCategory> categories,
                    Collection<BwProperty> properties) {
    super(owner, publick, creator, access);
    setName(name);
    setPath(path);
    setSummary(summary);
    setDescription(description);
    setMailListId(mailListId);
    setCalendarCollection(calendarCollection);
    setCalendar(parent);
    setChildren(children);
    setCalType(calType);
    setCreated(created);
    setLastmod(lastmod);
    setSequence(sequence);
    setCategories(categories);
    setProperties(properties);

    if (getLastmod() == null) {
      updateLastmod();
    }
  }

  /** Set the name
   *
   * @param val    String name
   */
  public void setName(String val) {
    name = val;
  }

  /** Get the name
   *
   * @return String   name
   */
  public String getName() {
    return name;
  }

  /** Set the path
   *
   * @param val    String path
   */
  public void setPath(String val) {
    path = val;
  }

  /** Get the path
   *
   * @return String   path
   */
  public String getPath() {
    return path;
  }

  /** Set the summary
   *
   * @param val    String summary
   */
  public void setSummary(String val) {
    summary = val;
  }

  /** Get the summary
   *
   * @return String   summary
   */
  public String getSummary() {
    if (summary == null) {
      return getName();
    }
    return summary;
  }

  /** Set the description
   *
   * @param val    description
   */
  public void setDescription(String val) {
    description = val;
  }

  /** Get the description
   *
   *  @return String   description
   */
  public String getDescription() {
    return description;
  }

  /** Set the mail list id
   *
   * @param val    String mail list id
   */
  public void setMailListId(String val) {
    mailListId = val;
  }

  /** Get the mail list id
   *
   *  @return String   mail list id
   */
  public String getMailListId() {
    return mailListId;
  }

  /** true if this is to 'hold' calendar objects
   *
   * @param val   boolean true if this is to 'hold' calendar objects
   */
  public void setCalendarCollection(boolean val) {
    calendarCollection = val;
  }

  /** true if this is to 'hold' calendar objects
   *
   * @return boolean  true if this is to 'hold' calendar objects
   */
  public boolean getCalendarCollection() {
    return calendarCollection;
  }

  /**  Set the Collection of children
   *
   * @param   val   SortedSet children for this calendar
   */
  public void setChildren(Collection<BwCalendar> val) {
    children = val;
  }

  /**  Get the Collection of children
   *
   * @return Collection   Calendar children for this calendar
   */
  public Collection<BwCalendar> getChildren() {
    return children;
  }

  /** Set the type
   *
   * @param val    type
   */
  public void setCalType(int val) {
    calType = val;
  }

  /** Get the description
   *
   *  @return String   description
   */
  public int getCalType() {
    return calType;
  }

  /**
   * @param val
   */
  public void setCreated(String val) {
    created = val;
  }

  /**
   * @return String created
   */
  public String getCreated() {
    return created;
  }

  /**
   * @param val
   */
  public void setLastmod(String val) {
    lastmod = val;
  }

  /**
   * @return String lastmod
   */
  public String getLastmod() {
    return lastmod;
  }

  /** Set the sequence
   *
   * @param val    sequence number
   */
  public void setSequence(int val) {
    sequence = val;
  }

  /** Get the sequence
   *
   * @return int    the sequence
   */
  public int getSequence() {
    return sequence;
  }

  /* ====================================================================
   *               CategorisedEntity interface methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#setCategories(java.util.Collection)
   */
  public void setCategories(Collection<BwCategory> val) {
    categories = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#getCategories()
   */
  public Collection<BwCategory> getCategories() {
    return categories;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#getNumCategories()
   */
  public int getNumCategories() {
    Collection<BwCategory> c = getCategories();
    if (c == null) {
      return 0;
    }

    return c.size();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#addCategory(org.bedework.calfacade.BwCategory)
   */
  public void addCategory(BwCategory val) {
    Collection<BwCategory> cats = getCategories();
    if (cats == null) {
      cats = new TreeSet<BwCategory>();
      setCategories(cats);
    }

    if (!cats.contains(val)) {
      cats.add(val);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#removeCategory(org.bedework.calfacade.BwCategory)
   */
  public boolean removeCategory(BwCategory val) {
    Collection<BwCategory> cats = getCategories();
    if (cats == null) {
      return false;
    }

    return cats.remove(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#hasCategory(org.bedework.calfacade.BwCategory)
   */
  public boolean hasCategory(BwCategory val) {
    Collection<BwCategory> cats = getCategories();
    if (cats == null) {
      return false;
    }

    return cats.contains(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#copyCategories()
   */
  public Collection<BwCategory> copyCategories() {
    if (getNumCategories() == 0) {
      return null;
    }
    TreeSet<BwCategory> ts = new TreeSet<BwCategory>();

    for (BwCategory cat: getCategories()) {
      ts.add(cat);
    }

    return ts;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#cloneCategories()
   */
  public Collection<BwCategory> cloneCategories() {
    if (getNumCategories() == 0) {
      return null;
    }
    TreeSet<BwCategory> ts = new TreeSet<BwCategory>();

    for (BwCategory cat: getCategories()) {
      ts.add((BwCategory)cat.clone());
    }

    return ts;
  }

  /* ====================================================================
   *                   Property methods
   * ==================================================================== */

  /**
   * @param val
   */
  public void setProperties(Collection<BwProperty> val) {
    properties = val;
  }

  /**
   * @return properties
   */
  public Collection<BwProperty> getProperties() {
    return properties;
  }

  /**
   * @return int
   */
  public int getNumProperties() {
    Collection<BwProperty> c = getProperties();
    if (c == null) {
      return 0;
    }

    return c.size();
  }

  /**
   * @param name
   * @return property or null
   */
  public BwProperty findProperty(String name) {
    Collection<BwProperty> props = getProperties();

    if (props == null) {
      return null;
    }

    for (BwProperty prop: props) {
      if (name.equals(prop.getName())) {
        return prop;
      }
    }

    return null;
  }

  /**
   * @param val
   */
  public void addProperty(BwProperty val) {
    Collection<BwProperty> c = getProperties();
    if (c == null) {
      c = new TreeSet<BwProperty>();
      setProperties(c);
    }

    if (!c.contains(val)) {
      c.add(val);
    }
  }

  /**
   * @param val
   * @return boolean
   */
  public boolean removeProperty(BwProperty val) {
    Collection<BwProperty> c = getProperties();
    if (c == null) {
      return false;
    }

    return c.remove(val);
  }

  /**
   * @return BwProperty
   */
  public Collection<BwProperty> copyProperties() {
    if (getNumProperties() == 0) {
      return null;
    }
    TreeSet<BwProperty> ts = new TreeSet<BwProperty>();

    for (BwProperty p: getProperties()) {
      ts.add(p);
    }

    return ts;
  }

  /**
   * @return BwProperty
   */
  public Collection<BwProperty> cloneProperties() {
    if (getNumProperties() == 0) {
      return null;
    }
    TreeSet<BwProperty> ts = new TreeSet<BwProperty>();

    for (BwProperty p: getProperties()) {
      ts.add((BwProperty)p.clone());
    }

    return ts;
  }

  /* ====================================================================
   *                   Convenience methods
   * ==================================================================== */

  /**
   * @return CollectionInfo
   */
  public CollectionInfo getCollectionInfo() {
    return collectionInfo[getCalType()];
  }

  /** Get number of children
   *
   * @return int
   */
  public int getNumChildren() {
    Collection<BwCalendar> cals = getChildren();
    if (cals == null) {
      return 0;
    }

    return cals.size();
  }

  /** Add a calendar to the set of children that make up this calendar
   * @param val   BwCalendar to add
   */
  public void addChild(BwCalendar val) {
    Collection<BwCalendar> cals = getChildren();
    if (cals == null) {
      cals = new TreeSet<BwCalendar>();
      setChildren(cals);
    }

    cals.add(val);
  }

  /** Remove a calendar from the set of children
   *
   * @param val   BwCalendar to remove
   */
  public void removeChild(BwCalendar val) {
    Collection<BwCalendar> cals = getChildren();
    if (cals != null) {
      cals.remove(val);
    }
  }

  /**  Any children?
   *
   * @return boolean   true if Calendar has children
   */
  public boolean hasChildren() {
    Collection<BwCalendar> cals = getChildren();
    if (cals == null) {
      return false;
    }

    return cals.size() > 0;
  }

  /** Check a possible name for validity
   *
   * @param val
   * @return  boolean true for valid calendar name
   */
  public static boolean checkName(String val) {
    if ((val == null) || (val.length() == 0)) {
      return false;
    }

    /* First character - letter or digit  */

    if (!Character.isLetterOrDigit(val.charAt(0))) {
      return false;
    }

    for (int i = 1; i < val.length(); i++) {
      char ch = val.charAt(i);

      if (!Character.isLetterOrDigit(ch) &&
          (ch != '_') && (ch != ' ')) {
        return false;
      }
    }

    return true;
  }

  /** Generate an encoded url referring to this calendar.
   *
   * XXX This should not be here
   * @return String encoded url (or path)
   * @throws CalFacadeException
   */
  public String getEncodedPath() throws CalFacadeException {
    if (getPath() == null) {
      return null;
    }
    try {
      return URLEncoder.encode(getPath(), "UTF-8");
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /** Create a copy of this object but do not clone the children
   *
   * @return BwCalendar object
   */
  public BwCalendar shallowClone() {
    BwCalendar cal =  new BwCalendar((BwUser)getOwner().clone(),
                          getPublick(),
                          (BwUser)getCreator().clone(),
                          getAccess(),
                          getName(),
                          getPath(),
                          getSummary(),
                          getDescription(),
                          getMailListId(),
                          getCalendarCollection(),
                          getCalendar(),
                          null,
                          getCalType(),
                          getCreated(),
                          getLastmod(),
                          getSequence(),
                          cloneCategories(),
                          cloneProperties());

    cal.setId(getId()); // Add to constructor
    cal.setSeq(getSeq()); // Add to constructor
    return cal;
  }

  /** Update last mod fields
   */
  public void updateLastmod() {
    setLastmod(new LastModified(new DateTime(true)).getValue());
    setSequence(getSequence() + 1);
  }

  /* ====================================================================
   *                   Wrapper methods
   * ==================================================================== */

  /**
   *
   * @param val CurrentAccess
   * @throws CalFacadeException
   */
  public void setCurrentAccess(CurrentAccess val) throws CalFacadeException {
    throw new CalFacadeException("org.bedework.wrapper.method.called");
  }

  /**
   * @return CurrentAccess
   * @throws CalFacadeException
   */
  public CurrentAccess getCurrentAccess() throws CalFacadeException {
    throw new CalFacadeException("org.bedework.wrapper.method.called");
  }

  /* ====================================================================
   *                   CollatableEntity methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CollatableEntity#getCollateValue()
   */
  public String getCollateValue() {
    return getName();
  }

  /* ====================================================================
   *                   Object methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.BwDbentity#compareTo(java.lang.Object)
   */
  public int compareTo(BwCalendar that) {
    if (that == this) {
      return 0;
    }

    if (that == null) {
      return -1;
    }

    return getPath().compareTo(that.getPath());
  }

  public int hashCode() {
    if (getPath() == null) {
      return 1;
    }
    return getPath().hashCode();
  }

  public String toString() {
    StringBuilder sb = new StringBuilder("BwCalendar{");

    toStringSegment(sb);
    sb.append(", name=");
    sb.append(getName());
    sb.append(", path=");
    sb.append(getPath());
    sb.append(", summary=");
    sb.append(String.valueOf(getSummary()));
    sb.append(",\ndescription=");
    sb.append(String.valueOf(getDescription()));
    sb.append(", mailListId=");
    sb.append(String.valueOf(getMailListId()));
    sb.append(", calendarCollection=");
    sb.append(String.valueOf(getCalendarCollection()));
    sb.append(", calType=");
    sb.append(getCalType());

    /* Forces fetch
    if (hasChildren()) {
      sb.append(",\nchildren(");

      boolean donech = false;

      for (BwCalendar ch: getChildren()) {
        if (!donech) {
          donech = true;
        } else {
          sb.append(",\n");
        }

        sb.append(ch.getPath());
      }
      sb.append(")");
    }
    */

    sb.append(",\ncreated=");
    sb.append(getCreated());
    sb.append(", lastmod=");
    sb.append(getLastmod());
    sb.append(", sequence=");
    sb.append(getSequence());

    if (getNumCategories() > 0) {
      sb.append(",\n categories=");
      for (BwCategory cat: getCategories()) {
        sb.append(cat);
        sb.append(", ");
      }
    }

    sb.append("}");

    return sb.toString();
  }

  public Object clone() {
    BwCalendar cal = new BwCalendar((BwUser)getOwner().clone(),
                          getPublick(),
                          (BwUser)getCreator().clone(),
                          getAccess(),
                          getName(),
                          getPath(),
                          getSummary(),
                          getDescription(),
                          getMailListId(),
                          getCalendarCollection(),
                          getCalendar(),
                          getChildren(),
                          getCalType(),
                          getCreated(),
                          getLastmod(),
                          getSequence(),
                          cloneCategories(),
                          cloneProperties());

    cal.setId(getId()); // Add to constructor
    cal.setSeq(getSeq()); // Add to constructor
    return cal;
  }
}
