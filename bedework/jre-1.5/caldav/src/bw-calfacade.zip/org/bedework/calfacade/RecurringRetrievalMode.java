/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade;

import java.io.Serializable;

/** How recurring events should be retrieved.
 *
 * @author douglm
 */
public class RecurringRetrievalMode implements Serializable {
  /**
   * Values which define how to retrieve recurring events. We have the
   * following choices (derived from caldav)
   */

  // DORECUR instancesOnlyWithTz needs to be dealt with correctly.
  /** return any instances that fall in the range and do not convert to UTC.
   *  Do not chain them together as a single master and instances but return
   *  each as a separate event.    (non-CalDAV)
   * /
  public final static int instancesOnlyWithTz = 0;*/

  public static enum Rmode {
    /** return as if all instances within the time range as
     *  individual events.
     *
     *  <p>For CalDAV, convert all times to UTC. No timezone information
     *  is returned.
     */
    expanded,

    /** return the master event and overrides only (start and end
     *                may be specified)
     */
    overrides,

    /** return the master if any instances fall in the range (non-CalDAV)
     * Also used for getting single event or instance.
     */
    masterOnly,

    /** return the single entity or instance only.
     */
    entityOnly}

  /** One of the above
   */
  public Rmode mode = Rmode.expanded;

  /** Limit expansion and recurrences.
   */
  public BwDateTime start;

  /** Limit expansion and recurrences.
   */
  public BwDateTime end;

  /** Constructor
   */
  public RecurringRetrievalMode() {
  }

  /** Constructor
   *
   * @param mode
   */
  public RecurringRetrievalMode(Rmode mode) {
    this.mode = mode;
  }

  /** Constructor
   *
   * @param mode
   * @param start
   * @param end
   */
  public RecurringRetrievalMode(Rmode mode, BwDateTime start, BwDateTime end) {
    this.mode = mode;
    this.start = start;
    this.end = end;
  }

  public String toString() {
    StringBuffer sb = new StringBuffer("RecurringRetrievalMode{");

    sb.append("mode=");
    sb.append(mode);

    sb.append(", start=");
    sb.append(start);

    sb.append(", end=");
    sb.append(end);

    sb.append("}");
    return sb.toString();
  }
}
