/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade.util;

import net.fortuna.ical4j.model.DateTime;

/**
 * @author douglm
 *
 */

public class EventPeriod implements Comparable {
  DateTime start;
  DateTime end;
  int type;  // from BwFreeBusyComponent

  EventPeriod(DateTime start, DateTime end, int type) {
    this.start = start;
    this.end = end;
    this.type = type;
  }

  public int compareTo(Object o) {
    if (!(o instanceof EventPeriod)) {
      return -1;
    }

    EventPeriod that = (EventPeriod)o;

    /* Sort by type first */
    if (type < that.type) {
      return -1;
    }

    if (type > that.type) {
      return 1;
    }

    int res = start.compareTo(that.start);
    if (res != 0) {
      return res;
    }

    return end.compareTo(that.end);
  }

  public boolean equals(Object o) {
    return compareTo(o) == 0;
  }

  public int hashCode() {
    return 7 * (type + 1) * (start.hashCode() + 1) * (end.hashCode() + 1);
  }

  public String toString() {
    StringBuffer sb = new StringBuffer("EventPeriod{start=");

    sb.append(start);
    sb.append(", end=");
    sb.append(end);
    sb.append(", type=");
    sb.append(type);
    sb.append("}");

    return sb.toString();
  }
}
