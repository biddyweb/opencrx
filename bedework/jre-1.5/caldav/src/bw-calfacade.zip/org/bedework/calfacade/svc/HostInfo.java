/* **********************************************************************
    Copyright 2007 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade.svc;

import org.bedework.calfacade.base.BwDbentity;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;

/** This class provides information about a host. This should eventually come
 * from some form of dns-like lookup based on the CUA. This is currently
 * experimental.
 *
 * @author Mike Douglass       douglm - rpi.edu
 */
public class HostInfo extends BwDbentity<HostInfo> implements Comparator<HostInfo> {
  private String hostname;

  private Integer port;

  private boolean secure;

  private boolean localService;

  /* Hosts come in different flavors */

  /** A bedework server */
  public static final String bedeworkHost = "Bedework";

  /** Supports CalDAV - check options for full details */
  public static final String caldavHost = "CalDAV";

  /** Supports real-time scheduling - no access otherwise */
  public static final String realTimeHost = "RealTime";

  /** Supports standard freebusy  */
  public static final String freebusyHost = "FreeBusy";

  /** Create list of above delimited by this */
  public static final String servicesDelim = ",";

  private String supportedServices;

  private String caldavUrl;
  private String caldavPrincipal;
  private String caldavCredentials;

  private String rtUrl;
  private String rtPrincipal;
  private String rtCredentials;

  private String fbUrl;

  /* derived values */

  private boolean supportsBedework;

  private boolean supportsCaldav;

  private boolean supportsRealtime;

  private boolean supportsFreebusy;

  private boolean servicesParsed;

  /**
   *
   */
  public HostInfo() {
  }

  /** Set the hostname
   *
   *  @param val     hostname
   */
  public void setHostname(String val) {
    hostname = val;
  }

  /**
   *
   * @return String hostname
   */
  public String getHostname() {
    return hostname;
  }

  /**
   * @param val
   */
  public void setPort(Integer val) {
    port = val;
  }

  /**
   * @return int
   */
  public Integer getPort() {
    return port;
  }

  /**
   * @param val
   */
  public void setSecure(boolean val) {
    secure = val;
  }

  /**
   * @return String
   */
  public boolean getSecure() {
    return secure;
  }

  /** Set localService flag
   *
   *  @param val    boolean localService
   */
  public void setLocalService(boolean val) {
    localService = val;
  }

  /**
   *
   * @return boolean localService
   */
  public boolean getLocalService() {
    return localService;
  }

  /**
   *
   *  @param val     String supported services
   */
  public void setSupportedServices(String val) {
    supportedServices = val;
  }

  /**
   *
   * @return String supportedServices
   */
  public String getSupportedServices() {
    return supportedServices;
  }

  /**
   *
   *  @param val    String
   */
  public void setCaldavUrl(String val) {
    caldavUrl = val;
  }

  /**
   *
   * @return String
   */
  public String getCaldavUrl() {
    return caldavUrl;
  }

  /**
   *
   *  @param val    String
   */
  public void setCaldavPrincipal(String val) {
    caldavPrincipal = val;
  }

  /**
   *
   * @return String
   */
  public String getCaldavPrincipal() {
    return caldavPrincipal;
  }

  /**
   *
   *  @param val    String
   */
  public void setCaldavCredentials(String val) {
    caldavCredentials = val;
  }

  /**
   *
   * @return String
   */
  public String getCaldavCredentials() {
    return caldavCredentials;
  }

  /**
   *
   *  @param val    String
   */
  public void setRtUrl(String val) {
    rtUrl = val;
  }

  /**
   *
   * @return String
   */
  public String getRtUrl() {
    return rtUrl;
  }

  /**
   *
   *  @param val    String
   */
  public void setRtPrincipal(String val) {
    rtPrincipal = val;
  }

  /**
   *
   * @return String
   */
  public String getRtPrincipal() {
    return rtPrincipal;
  }

  /**
   *
   *  @param val    String
   */
  public void setRtCredentials(String val) {
    rtCredentials = val;
  }

  /**
   *
   * @return String
   */
  public String getRtCredentials() {
    return rtCredentials;
  }

  /**
   *
   *  @param val    String
   */
  public void setFbUrl(String val) {
    fbUrl = val;
  }

  /**
   *
   * @return String
   */
  public String getFbUrl() {
    return fbUrl;
  }

  /* ====================================================================
   *                   Derived values methods
   * ==================================================================== */

  private void rebuildSupportedServices() {
    StringBuilder sb = new StringBuilder();

    servicesParsed = true; // They will be after this

    if (getSupportsBedework()) {
      sb.append(bedeworkHost);
      sb.append(servicesDelim);
    }

    if (getSupportsCaldav()) {
      sb.append(caldavHost);
      sb.append(servicesDelim);
    }

    if (getSupportsRealtime()) {
      sb.append(realTimeHost);
      sb.append(servicesDelim);
    }

    if (getSupportsFreebusy()) {
      sb.append(freebusyHost);
      sb.append(servicesDelim);
    }

    setSupportedServices(sb.toString());
  }

  private void parseSupportedServices() {
    if (servicesParsed) {
      return;
    }

    String[] ssa = getSupportedServices().split(servicesDelim);
    Collection<String> ss = new ArrayList<String>();

    for (String s: ssa) {
      ss.add(s);
    }

    setSupportsCaldav(ss.contains(caldavHost));
    setSupportsRealtime(ss.contains(realTimeHost));
    setSupportsFreebusy(ss.contains(freebusyHost));

    servicesParsed = true;
  }

  /**
   *  @param  val    boolean true if supports Bedework
   */
  public void setSupportsBedework(boolean val) {
    supportsBedework = val;
    rebuildSupportedServices();
  }

  /**
   *  @return boolean    true if caldav supported
   */
  public boolean getSupportsBedework() {
    parseSupportedServices();
    return supportsBedework;
  }

  /**
   *  @param  val    boolean true if supports CalDAV
   */
  public void setSupportsCaldav(boolean val) {
    supportsCaldav = val;
    rebuildSupportedServices();
  }

  /**
   *  @return boolean    true if caldav supported
   */
  public boolean getSupportsCaldav() {
    parseSupportedServices();
    return supportsCaldav;
  }

  /**
   *  @param  val    boolean true if supports Realtime
   */
  public void setSupportsRealtime(boolean val) {
    supportsRealtime = val;
    rebuildSupportedServices();
  }

  /**
   *  @return boolean    true if caldav supported
   */
  public boolean getSupportsRealtime() {
    parseSupportedServices();
    return supportsRealtime;
  }

  /**
   *  @param  val    boolean true if supports Freebusy
   */
  public void setSupportsFreebusy(boolean val) {
    supportsFreebusy = val;
    rebuildSupportedServices();
  }

  /**
   *  @return boolean    true if Freebusy supported
   */
  public boolean getSupportsFreebusy() {
    parseSupportedServices();
    return supportsFreebusy;
  }

  /* ====================================================================
   *                   Object methods
   * ==================================================================== */

  public int compare(HostInfo o1, HostInfo o2) {
    if (o1 == o2) {
      return 0;
    }

    return o1.getHostname().compareTo(o2.getHostname());
  }

  public int compareTo(HostInfo o2) {
    return compare(this, o2);
  }

  public int hashCode() {
    return getHostname().hashCode();
  }

  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }

    if (!(obj instanceof HostInfo)) {
      return false;
    }

    return compareTo((HostInfo)obj) == 0;
  }

  public String toString() {
    StringBuilder sb = new StringBuilder();

    sb.append("HostInfo{");
    toStringSegment(sb);

    sb.append(", hostname=");
    sb.append(getHostname());
    sb.append("}");

    return sb.toString();
  }
}
