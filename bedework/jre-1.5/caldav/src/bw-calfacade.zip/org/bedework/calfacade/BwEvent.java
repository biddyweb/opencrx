/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2007 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade;

import org.bedework.calfacade.base.AlarmsEntity;
import org.bedework.calfacade.base.AttachmentsEntity;
import org.bedework.calfacade.base.AttendeesEntity;
import org.bedework.calfacade.base.BwShareableContainedDbentity;
import org.bedework.calfacade.base.CategorisedEntity;
import org.bedework.calfacade.base.CommentedEntity;
import org.bedework.calfacade.base.ContactedEntity;
import org.bedework.calfacade.base.DescriptionEntity;
import org.bedework.calfacade.base.RecurrenceEntity;
import org.bedework.calfacade.base.ResourcedEntity;
import org.bedework.calfacade.base.StartEndComponent;
import org.bedework.calfacade.base.SummaryEntity;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.util.CalFacadeUtil;

import net.fortuna.ical4j.model.DateTime;
import net.fortuna.ical4j.model.Period;
import net.fortuna.ical4j.model.property.Created;
import net.fortuna.ical4j.model.property.DtStamp;
import net.fortuna.ical4j.model.property.LastModified;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.TreeSet;

/** An Event in Bedework. The event class is actually used to represent most of
 * the calendaring components as they all require the same sort of searching
 * capabilities.
 *
 * <p>From RFC2445<pre>
 *     A "VEVENT" calendar component is defined by the
 * following notation:
 *
 *   eventc     = "BEGIN" ":" "VEVENT" CRLF
 *                eventprop *alarmc
 *                "END" ":" "VEVENT" CRLF
 *
 *   eventprop  = *(
 *
 *              ; the following are optional,
 *              ; but MUST NOT occur more than once
 *
 *              class / created / description / dtstart / geo /
 *              last-mod / location / organizer / priority /
 *              dtstamp / seq / status / summary / transp /
 *              uid / url / recurid /
 *
 *              ; either 'dtend' or 'duration' may appear in
 *              ; a 'eventprop', but 'dtend' and 'duration'
 *              ; MUST NOT occur in the same 'eventprop'
 *
 *              dtend / duration /
 *
 *              ; the following are optional,
 *              ; and MAY occur more than once
 *
 *              attach / attendee / categories / comment /
 *              contact / exdate / exrule / rstatus / related /
 *              resources / rdate / rrule / x-prop
 *              )
 *
 *         A "VTODO" calendar component is defined by the
       following notation:

         todoc      = "BEGIN" ":" "VTODO" CRLF
                      todoprop *alarmc
                      "END" ":" "VTODO" CRLF

         todoprop   = *(

                    ; the following are optional,
                    ; but MUST NOT occur more than once

                    class / completed / created / description / dtstamp /
                    dtstart / geo / last-mod / location / organizer /
                    percent / priority / recurid / seq / status /
                    summary / uid / url /

                    ; either 'due' or 'duration' may appear in
                    ; a 'todoprop', but 'due' and 'duration'
                    ; MUST NOT occur in the same 'todoprop'

                    due / duration /

                    ; the following are optional,
                    ; and MAY occur more than once
                    attach / attendee / categories / comment / contact /
                    exdate / exrule / rstatus / related / resources /
                    rdate / rrule / x-prop

                    )
        A "VJOURNAL" calendar component is defined by the
       following notation:

         journalc   = "BEGIN" ":" "VJOURNAL" CRLF
                      jourprop
                      "END" ":" "VJOURNAL" CRLF

         jourprop   = *(

                    ; the following are optional,
                    ; but MUST NOT occur more than once

                    class / created / description / dtstart / dtstamp /
                    last-mod / organizer / recurid / seq / status /
                    summary / uid / url /

                    ; the following are optional,
                    ; and MAY occur more than once

                    attach / attendee / categories / comment /
                    contact / exdate / exrule / related / rdate /
                    rrule / rstatus / x-prop
                    )

 Properties common to event, todo and journal
    attach         VEVENT VTODO VJOURNAL    n/a       n/a    VALARM
    attendee       VEVENT VTODO VJOURNAL VFREEBUSY    n/a    VALARM
    categories     VEVENT VTODO VJOURNAL
    class          VEVENT VTODO VJOURNAL
    comment        VEVENT VTODO VJOURNAL VFREEBUSY VTIMEZONE
    contact        VEVENT VTODO VJOURNAL VFREEBUSY
    created        VEVENT VTODO VJOURNAL
    description    VEVENT VTODO VJOURNAL    n/a       n/a    VALARM
    dtstamp        VEVENT VTODO VJOURNAL VFREEBUSY
    dtstart        VEVENT VTODO VJOURNAL VFREEBUSY VTIMEZONE
    exdate         VEVENT VTODO VJOURNAL
    exrule         VEVENT VTODO VJOURNAL
    lastModified   VEVENT VTODO VJOURNAL    n/a    VTIMEZONE
    organizer      VEVENT VTODO VJOURNAL VFREEBUSY
    rdate          VEVENT VTODO VJOURNAL    n/a    VTIMEZONE
    recurrenceId   VEVENT VTODO VJOURNAL    n/a    VTIMEZONE
    relatedTo      VEVENT VTODO VJOURNAL
    requestStatus  VEVENT VTODO VJOURNAL VFREEBUSY
    rrule          VEVENT VTODO VJOURNAL    n/a    VTIMEZONE
    sequence       VEVENT VTODO VJOURNAL
    status         VEVENT VTODO VJOURNAL
    summary        VEVENT VTODO VJOURNAL    n/a       n/a    VALARM
    uid            VEVENT VTODO VJOURNAL VFREEBUSY
    url            VEVENT VTODO VJOURNAL VFREEBUSY

 Properties in one or more of event, todo (all journal fields are in common set)
    completed        n/a  VTODO
    dtend          VEVENT  n/a   n/a     VFREEBUSY
    due              n/a  VTODO                            (same as dtend)
    duration       VEVENT VTODO  n/a     VFREEBUSY    n/a    VALARM
    geo            VEVENT VTODO
    location       VEVENT VTODO
    percentComplete  n/a  VTODO
    priority       VEVENT VTODO
    resources      VEVENT VTODO
    transp         VEVENT

 Alarm only:
    action           n/a   n/a   n/a        n/a       n/a    VALARM
    repeat           n/a   n/a   n/a        n/a       n/a    VALARM
    trigger          n/a   n/a   n/a        n/a       n/a    VALARM

 Freebusy only:
    freebusy         n/a   n/a   n/a     VFREEBUSY

 Timezone only:
    tzid             n/a   n/a   n/a        n/a    VTIMEZONE
    tzname           n/a   n/a   n/a        n/a    VTIMEZONE
    tzoffsetfrom     n/a   n/a   n/a        n/a    VTIMEZONE
    tzoffsetto       n/a   n/a   n/a        n/a    VTIMEZONE
    tzurl            n/a   n/a   n/a        n/a    VTIMEZONE

 In addition, events and todos may contain alarms.

 * Optional:
     class            classification
     created          created
     description      description
     dtstart          dtstart
     geo              geo
     last-mod         lastmod
     location         location
     organizer        organizerId
     priority         priority
     dtstamp          dtstamp
     seq              sequence
     status           status
     summary          summary
     transp           transparency
     uid              uid
     url              link
     recurid          recurrenceId

   One of or neither
     dtend            dtend
     duration         duration

   Optional and repeatable
      alarmc          alarms
      attach
      attendee        attendees
      categories      categories
      comment         comments
      contact         sponsor
      exdate          exdates
      exrule          exrules
      rstatus         requestStatus
      related
      resources       resources
      rdate           rdates
      rrule           rrules
      x-prop

  Extra non-rfc fields:
      private String cost;
      private UserVO creator;
      private boolean isPublic;
      private CalendarVO calendar;
      private RecurrenceVO recurrence;
      private char recurrenceStatus = 'N'; // Derived from above

 * --------------------------------------------------------------------
 *</pre>
 *
 *  @version 1.0
 */
public class BwEvent extends BwShareableContainedDbentity<BwEvent>
        implements AlarmsEntity, AttachmentsEntity, AttendeesEntity,
        CategorisedEntity, CommentedEntity, ContactedEntity,
        DescriptionEntity<BwLongString>, RecurrenceEntity,
        ResourcedEntity, StartEndComponent, SummaryEntity,
        Comparator<BwEvent> {
  private int entityType = CalFacadeDefs.entityTypeEvent;

  private String name;

  private Collection<BwString> summaries;

  private Collection<BwLongString> descriptions;

  private String classification;

  private Collection<BwString> comments;

  private Collection<BwString> resources;

  private BwDateTime dtstart;
  private BwDateTime dtend;

  /** Duration may be calculated or specified. The end will always
         be filled in to provide the calculated end time.
   */
  private String duration;

  private Boolean noStart;

  /** This will be one of the above.
   */
  private char endType = endTypeDate;

  private String link;

  private BwGeo geo;

  /* Status values from rfc
   *      statvalue  = "TENTATIVE"           ;Indicates event is
                                        ;tentative.
                / "CONFIRMED"           ;Indicates event is
                                        ;definite.
                / "CANCELLED"           ;Indicates event was
                                        ;cancelled.
        ;Status values for a "VEVENT"
     statvalue  =/ "NEEDS-ACTION"       ;Indicates to-do needs action.
                / "COMPLETED"           ;Indicates to-do completed.
                / "IN-PROCESS"          ;Indicates to-do in process of
                / "CANCELLED"           ;Indicates to-do was cancelled.
        ;Status values for "VTODO".

     statvalue  =/ "DRAFT"              ;Indicates journal is draft.
                / "FINAL"               ;Indicates journal is final.
                / "CANCELLED"           ;Indicates journal is removed.
        ;Status values for "VJOURNAL".
   */
  // ENUM

  /** Rfc value for a tentative meeting */
  public static final String statusTentative = "TENTATIVE";

  /** Rfc value for a confirmed meeting */
  public static final String statusConfirmed = "CONFIRMED";

  /** Rfc value for a cancelled meeting */
  public static final String statusCancelled = "CANCELLED";

  /** Rfc value for an incomplete task */
  public static final String statusNeedsAction = "NEEDS-ACTION";

  /** Rfc value for a completed task */
  public static final String statusComplete = "COMPLETE";

  /** Rfc value for an in-process task */
  public static final String statusInProcess = "IN-PROCESS";

  /** Rfc value for a draft journal */
  public static final String statusDraft = "DRAFT";

  /** Rfc value for a final? journal */
  public static final String statusFinal = "FINAL";

  /** Rfc value for an unavailable time-period */
  public static final String statusUnavailable = "BUSY-UNAVAILABLE";

  private String status;
  private String cost;

  private boolean deleted;

  /** UTC datetime as specified in rfc */
  private String dtstamp;

  /** UTC datetime as specified in rfc */
  private String lastmod;

  /** UTC datetime as specified in rfc */
  private String created;

  /** RFC priority value
   */
  private Integer priority;

  /** A Set of BwCategory objects
   */
  private Collection<BwCategory> categories = null;

  /** This may or may not be set to populate fully
   */
  private Collection<BwContact> contacts;

  /** This may or may not be set to populate fully
   */
  private BwLocation location;

//  private int organizerId = CalFacadeDefs.unsavedItemKey;
  private BwOrganizer organizer;

  /** */
  public final static String transparencyOpaque = "OPAQUE";
  /** */
  public final static String transparencyTransparent = "TRANSPARENT";
  /** Transparency is used in free/busy time calculation
   *      transp     = "TRANSP" tranparam ":" transvalue CRLF

     tranparam  = *(";" xparam)

     transvalue = "OPAQUE"      ;Blocks or opaque on busy time searches.
                / "TRANSPARENT" ;Transparent on busy time searches.
        ;Default value is OPAQUE
   */
  private String transparency;

  /* VTODO only */
  private Integer percentComplete;

  /* VTODO only */
  private String completed;

  private Collection<BwAttachment> attachments;

  private Collection<BwAttendee> attendees;

  private Boolean recurring;

  /** The uid for the event. Generated by the system or by external sources when
   * imported.
   */
  private String uid;

  private Collection<BwAlarm> alarms;

  /* ------------------- RecurrenceEntity information -------------------- */

  /** recurrence-id for a specific instance.
   */
  private String recurrenceId;

  /** Collection of String rrule values
   */
  private Collection<String> rrules;

  /** Collection of String exrule values
   */
  private Collection<String> exrules;

  /** Collection of BwDateTime rdate values
   */
  private Collection<BwDateTime> rdates;

  /** Collection of BwDateTime exdate values
   */
  private Collection<BwDateTime> exdates;

  /** Where known this will be the absolute latest date for this recurring
   * event. This field will be null for infinite events.
   */
  private String latestDate;

  /** True for a master entry that has expansions in the recurrance
   * instances table. Such an event will have an entry for the master as well
   * as all derived events.
   */
  private Boolean expanded;

  /* ----------------- (CalDAV) scheduling information ------------------- */

  /** RFC sequence value
   */
  private int sequence;

  // ENUM
  private int scheduleMethod;

  private String originator;

  private Collection<String> recipients;

  // ENUM
  /** scheduling message has not been processed
   * <p>(CalDAV) Inbox state on arrival.
   */
  public static final int scheduleStateNotProcessed = 0;

  /** scheduling message has been processed
   * <p>(CalDAV) Inbox state after all processing complete
   */
  public static final int scheduleStateProcessed = 1;

  /** scheduling message has been sent to external users
   * <p>Outbox state after sent to all external recipients. Internal recipients
   * are handled immediately.
   */
  public static final int scheduleStateExternalDone = 2;

  private int scheduleState;

  private Collection<BwRequestStatus> requestStatuses;

  /** Deferred till later e.g. needs mailing */
  public static final String requestStatusDeferred = "1.0;Deferred";

  /**  */
  public static final String requestStatusOK = "2.0;Success";

  /** Append property name */
  public static final String requestStatusInvalidProperty =
           "3.0;Invalid Property Name:";

  /**  */
  public static final String requestStatusUnsupportedCapability =
           "3.14;Unsupported capability";

  /** */
  public static final String requestStatusNoAccess =
           "4.2;No Access";

  private BwRelatedTo relatedTo;

  /** Collection of BwXproperty
   */
  private Collection<BwXproperty> xproperties;

  /* ---------------------------- Temp --------------------------------
   * As a quick fix we will store freebusy information in one of these.
   * It avoids many changes to the searching but is not too efficient
   * space wise.
   *
   * Longer term we probably ought to base all the different types of a
   * single master class.
   */

  /** Collection of BwFreeBusyComponent
   */
  private Collection<BwFreeBusyComponent> freeBusyPeriods;

  /* ====================================================================
   *                      VAvailability fields
   * ==================================================================== */

  /** busy time */
  public static final int busyTypeBusy = 0;

  /** unavailable time */
  public static final int busyTypeBusyUnavailable = 1;

  /** tentative busy time */
  public static final int busyTypeBusyTentative = 2;

  private int busyType = busyTypeBusyUnavailable;

  /* Uids of AVAILABILITY components */
  private Collection<String> availableUids;

  /** Constructor
   */
  protected BwEvent() {
    super();
  }

  /* ====================================================================
   *                      Bean methods
   * ==================================================================== */

  /** Set entity type defined in CalFacadeDefs
   * @param val
   */
  public void setEntityType(int val) {
    entityType = val;
  }

  /**
   * @return entity type defined in CalFacadeDefs
   */
  public int getEntityType() {
    return entityType;
  }

  /** Set the event's name
   *
   * @param val    String event's name
   */
  public void setName(String val) {
    name = val;
  }

  /** Get the event's name.
   *
   * @return String   event's name
   */
  public String getName() {
    return name;
  }

  /** Set the event's classification
   *
   * @param val    String event's description
   */
  public void setClassification(String val) {
    classification = val;
  }

  /** Get the event's classification
   *
   *  @return String   event's classification
   */
  public String getClassification() {
    return classification;
  }

  /** Set the event's URL
   *
   * @bedework_ical_property URL
   *
   * @param val   string URL
   */
  public void setLink(String val) {
    link = val;
  }

  /** Get the event's URL
   *
   * @return the event's URL
   */
  public String getLink() {
    return link;
  }

  /** Set the event's geo
   *
   *  @param val   BwGeo
   */
  public void setGeo(BwGeo val) {
    geo = val;
  }

  /** Get the event's geo
   *
   * @return the event's geo
   */
  public BwGeo getGeo() {
    return geo;
  }

  /** Set the event deleted flag
   *
   *  @param val    boolean true if the event is deleted
   */
  public void setDeleted(boolean val) {
    deleted = val;
  }

  /** Get the event deleted flag
   *
   *  @return boolean    true if the event is deleted
   */
  public boolean getDeleted() {
    return deleted;
  }

  /** Set the event's status - must be one of
   *  CONFIRMED, TENTATIVE, or CANCELLED
   *
   *  @param val     status
   */
  public void setStatus(String val) {
    status = val;
  }

  /** Get the event's status
   *
   * @return String event's status
   */
  public String getStatus() {
    return status;
  }

  /** Set the event's cost
   *
   * @param val    String event's cost
   */
  public void setCost(String val) {
    cost = val;
  }

  /** Get the event's cost
   *
   * @return String   the event's cost
   */
  public String getCost() {
    return cost;
  }

  /** Set the organizer
   *
   * @param val    BwOrganizer organizer
   */
  public void setOrganizer(BwOrganizer val) {
    if (val == null) {
      BwOrganizer eval = getOrganizer();
      if ((eval != null) && !eval.equals(val)) {
        addDeletedEntity(eval);
      }
    }
    organizer = val;
  }

  /** Get the organizer
   *
   * @return BwOrganizer   the organizer
   */
  public BwOrganizer getOrganizer() {
    return organizer;
  }

  /* * Get the event's organizerId
   *
   * @return int   the event's organizer id
   * /
  public int getOrganizerId() {
    return organizerId;
  }*/

  /**
   * @param val
   */
  public void setDtstamp(String val) {
    dtstamp = val;
  }

  /**
   * @return String datestamp
   */
  public String getDtstamp() {
    return dtstamp;
  }

  /**
   * @param val
   */
  public void setLastmod(String val) {
    lastmod = val;
  }

  /**
   * @return String lastmod
   */
  public String getLastmod() {
    return lastmod;
  }

  /**
   * @param val
   */
  public void setCreated(String val) {
    created = val;
  }

  /**
   * @return String created
   */
  public String getCreated() {
    return created;
  }

  /** Set the rfc priority for this event
   *
   * @param val    rfc priority number
   */
  public void setPriority(Integer val) {
    priority = val;
  }

  /** Get the events rfc priority
   *
   * @return Integer    the events rfc priority
   */
  public Integer getPriority() {
    return priority;
  }

  /** Set the rfc sequence for this event
   *
   * @param val    rfc sequence number
   */
  public void setSequence(int val) {
    sequence = val;
  }

  /** Get the events rfc sequence
   *
   * @return int    the events rfc sequence
   */
  public int getSequence() {
    return sequence;
  }

  /**
   * @param val
   */
  public void setLocation(BwLocation val) {
    location = val;
  }

  /**
   * @return  BwLocation or null
   */
  public BwLocation getLocation() {
    return location;
  }

  /** Set the uid
   *
   * @param val    String uid
   */
  public void setUid(String val) {
    uid = val;
  }

  /** Get the uid
   *
   * @return String   uid
   */
  public String getUid() {
    return uid;
  }

  /** Set the event's transparency
   *
   * @param val    String event's transparency
   */
  public void setTransparency(String val) {
    transparency = val;
  }

  /** Get the event's transparency
   *
   * @return String   the event's transparency
   */
  public String getTransparency() {
    return transparency;
  }

  /** todo only - Set the percentComplete
   *
   * @param val    percentComplete
   */
  public void setPercentComplete(Integer val) {
    percentComplete = val;
  }

  /** Get the percentComplete
   *
   * @return Integer    percentComplete
   */
  public Integer getPercentComplete() {
    return percentComplete;
  }

  /** todo only - UTC time completed
   * @param val
   */
  public void setCompleted(String val) {
    completed = val;
  }

  /**
   * @return String completed
   */
  public String getCompleted() {
    return completed;
  }

  /** Set the scheduleMethod for this event. Takes methodType values defined
   * in Icalendar
   *
   * @param val    scheduleMethod
   */
  public void setScheduleMethod(int val) {
    scheduleMethod = val;
  }

  /** Get the events scheduleMethod
   *
   * @return int    the events scheduleMethod
   */
  public int getScheduleMethod() {
    return scheduleMethod;
  }

  /** Set the event's originator
   *
   * @param val    String event's originator
   */
  public void setOriginator(String val) {
    originator = val;
  }

  /** Get the event's originator
   *
   * @return String   the event's originator
   */
  public String getOriginator() {
    return originator;
  }

  /** Set the scheduleState for this event
   *
   * @param val    scheduleState
   */
  public void setScheduleState(int val) {
    if ((val != scheduleStateNotProcessed) &&
        (val != scheduleStateProcessed) &&
        (val != scheduleStateExternalDone)) {
      throw new RuntimeException("org.bedework.badvalue");
    }

    scheduleState = val;
  }

  /** Get the events scheduleState
   *
   * @return int    the events scheduleState
   */
  public int getScheduleState() {
    return scheduleState;
  }

  /** Set the relatedTo property
   *
   * @param val    BwRelatedTo relatedTo property
   */
  public void setRelatedTo(BwRelatedTo val) {
    relatedTo = val;
  }

  /** Get the relatedTo property
   *
   * @return BwRequestStatus   the relatedTo property
   */
  public BwRelatedTo getRelatedTo() {
    return relatedTo;
  }

  /**
   * @param val
   */
  public void setXproperties(Collection<BwXproperty> val) {
    xproperties = val;
  }

  /**
   * @return Collection<BwXproperty>
   */
  public Collection<BwXproperty> getXproperties() {
    return xproperties;
  }

  /**
   * @return int
   */
  public int getNumXproperties() {
    Collection<BwXproperty> c = getXproperties();
    if (c == null) {
      return 0;
    }

    return c.size();
  }

  /**
   * @param val
   */
  public void addXproperty(BwXproperty val) {
    Collection<BwXproperty> c = getXproperties();
    if (c == null) {
      c = new TreeSet<BwXproperty>();
      setXproperties(c);
    }

    if (!c.contains(val)) {
      c.add(val);
    }
  }

  /* ====================================================================
   *               Request status methods
   * ==================================================================== */

  /** Set the requestStatus
   *
   * @param val    BwRequestStatus requestStatus
   */
  public void setRequestStatuses(Collection<BwRequestStatus> val) {
    requestStatuses = val;
  }

  /** Get the requestStatus
   *
   * @return Collection of BwRequestStatus   the requestStatus
   */
  public Collection<BwRequestStatus> getRequestStatuses() {
    return requestStatuses;
  }

  /**
   * @return int
   */
  public int getNumRequestStatuses() {
    Collection<BwRequestStatus> c = getRequestStatuses();
    if (c == null) {
      return 0;
    }

    return c.size();
  }

  /**
   * @param val
   */
  public void addRequestStatus(BwRequestStatus val) {
    Collection<BwRequestStatus> rs = getRequestStatuses();
    if (rs == null) {
      rs = new TreeSet<BwRequestStatus>();
      setRequestStatuses(rs);
    }

    if (!rs.contains(val)) {
      rs.add(val);
    }
  }

  /**
   * @param val
   * @return boolean
   */
  public boolean removeRequestStatus(BwRequestStatus val) {
    Collection<BwRequestStatus> rs = getRequestStatuses();
    if (rs == null) {
      return false;
    }

    return rs.remove(val);
  }

  /** Return a clone of the collection
   *
   * @return Collection of BwAlarm
   */
  public Collection<BwRequestStatus> cloneRequestStatuses() {
    Collection<BwRequestStatus> rs = getRequestStatuses();
    if (rs == null) {
      return null;
    }

    Collection<BwRequestStatus> nrs = new TreeSet<BwRequestStatus>();

    for (BwRequestStatus o: rs) {
      nrs.add((BwRequestStatus)o.clone());
    }

    return nrs;
  }

  /* ====================================================================
   *               RecurrenceEntity interface methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#setRecurring(java.lang.Boolean)
   */
  public void setRecurring(Boolean val) {
    recurring = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#getRecurring()
   */
  public Boolean getRecurring() {
    return recurring;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#setRecurrenceId(java.lang.String)
   */
  public void setRecurrenceId(String val) {
     recurrenceId = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#getRecurrenceId()
   */
  public String getRecurrenceId() {
    return recurrenceId;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#setRrules(java.util.Collection)
   */
  public void setRrules(Collection<String> val) {
    rrules = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#getRrules()
   */
  public Collection<String> getRrules() {
    return rrules;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#setExrules(java.util.Collection)
   */
  public void setExrules(Collection<String> val) {
    exrules = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#getExrules()
   */
  public Collection<String> getExrules() {
    return exrules;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#setRdates(java.util.Collection)
   */
  public void setRdates(Collection<BwDateTime> val) {
    rdates = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#getRdates()
   */
  public Collection<BwDateTime> getRdates() {
    return rdates;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#setExdates(java.util.Collection)
   */
  public void setExdates(Collection<BwDateTime> val) {
    exdates = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#getExdates()
   */
  public Collection<BwDateTime> getExdates() {
    return exdates;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#setLatestDate(java.lang.String)
   */
  public void setLatestDate(String val) {
    latestDate = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#getLatestDate()
   */
  public String getLatestDate() {
    return latestDate;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#setExpanded(boolean)
   */
  public void setExpanded(Boolean val) {
    expanded = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#getExpanded()
   */
  public Boolean getExpanded() {
    return expanded;
  }

  /* ====================================================================
   *                   Recurrence Helper methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#isRecurring()
   */
  public boolean isRecurringEntity() {
    return hasExdates() ||
           hasRdates() ||
           hasExrules() ||
           hasRrules();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#hasRrules()
   */
  public boolean hasRrules() {
    return !isEmpty(getRrules());
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#addRrule(java.lang.String)
   */
  public void addRrule(String val) {
    Collection<String> c = getRrules();

    if (c == null) {
      c = new TreeSet<String>();
      setRrules(c);
    }

    if (!c.contains(val)) {
      c.add(val);
      setRecurring(true);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#hasExrules()
   */
  public boolean hasExrules() {
    return !isEmpty(getExrules());
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#addExrule(java.lang.String)
   */
  public void addExrule(String val) {
    Collection<String> c = getExrules();

    if (c == null) {
      c = new TreeSet<String>();
      setExrules(c);
    }

    if (!c.contains(val)) {
      c.add(val);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#hasRdates()
   */
  public boolean hasRdates() {
    return !isEmpty(getRdates());
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#addRdate(org.bedework.calfacade.BwDateTime)
   */
  public void addRdate(BwDateTime val) {
    Collection<BwDateTime> c = getRdates();

    if (c == null) {
      c = new TreeSet<BwDateTime>();
      setRdates(c);
    }

    if (!c.contains(val)) {
      c.add(val);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#hasExdates()
   */
  public boolean hasExdates() {
    return !isEmpty(getExdates());
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.RecurrenceEntity#addExdate(org.bedework.calfacade.BwDateTime)
   */
  public void addExdate(BwDateTime val) {
    Collection<BwDateTime> c = getExdates();

    if (c == null) {
      c = new TreeSet<BwDateTime>();
      setExdates(c);
    }

    if (!c.contains(val)) {
      c.add(val);
    }
  }

  /* ====================================================================
   *               StartEndComponent interface methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.StartEndComponent#setDtstart(org.bedework.calfacade.BwDateTime)
   */
  public void setDtstart(BwDateTime val) {
    dtstart = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.StartEndComponent#getDtstart()
   */
  public BwDateTime getDtstart() {
    if (dtstart != null) {
      dtstart.setTzowner(getOwner());
    }
    return dtstart;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.StartEndComponent#setDtend(org.bedework.calfacade.BwDateTime)
   */
  public void setDtend(BwDateTime val) {
    dtend = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.StartEndComponent#getDtend()
   */
  public BwDateTime getDtend() {
    if (dtend != null) {
      dtend.setTzowner(getOwner());
    }
    return dtend;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.StartEndComponent#setEndType(char)
   */
  public void setEndType(char val) {
    endType = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.StartEndComponent#getEndType()
   */
  public char getEndType() {
    return endType;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.StartEndComponent#setDuration(java.lang.String)
   */
  public void setDuration(String val) {
   duration = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.StartEndComponent#getDuration()
   */
  public String getDuration() {
    return duration;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.StartEndComponent#setNoStart(java.lang.Boolean)
   */
  public void setNoStart(Boolean val) {
    noStart = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.StartEndComponent#getNoStart()
   */
  public Boolean getNoStart() {
    return noStart;
  }

  /* ====================================================================
   *               AlarmsEntity interface methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AlarmsEntity#setAlarms(java.util.Collection)
   */
  public void setAlarms(Collection<BwAlarm> val) {
    alarms = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AlarmsEntity#getAlarms()
   */
  public Collection<BwAlarm> getAlarms() {
    return alarms;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AlarmsEntity#getNumAlarms()
   */
  public int getNumAlarms() {
    Collection<BwAlarm> c = getAlarms();
    if (c == null) {
      return 0;
    }

    return c.size();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AlarmsEntity#addAlarm(java.lang.String)
   */
  public void addAlarm(BwAlarm val) {
    Collection<BwAlarm> rs = getAlarms();
    if (rs == null) {
      rs = new TreeSet<BwAlarm>();
      setAlarms(rs);
    }

    if (!rs.contains(val)) {
      rs.add(val);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AlarmsEntity#removeAlarm(java.lang.String)
   */
  public boolean removeAlarm(BwAlarm val) {
    Collection<BwAlarm> rs = getAlarms();
    if (rs == null) {
      return false;
    }

    return rs.remove(val);
  }

  /** Return a clone of the collection
   *
   * @return Collection of BwAlarm
   */
  public Collection<BwAlarm> cloneAlarms() {
    Collection<BwAlarm> rs = getAlarms();
    if (rs == null) {
      return null;
    }

    Collection<BwAlarm> nrs = new TreeSet<BwAlarm>();

    for (BwAlarm al: rs) {
      nrs.add((BwAlarm)al.clone());
    }

    return nrs;
  }

  /* ====================================================================
   *                   AttachmentsEntity interface methods
   * ==================================================================== */

  public void setAttachments(Collection<BwAttachment> val) {
    attachments = val;
  }

  public Collection<BwAttachment> getAttachments() {
    return attachments;
  }

  public int getNumAttachments() {
    Collection as = getAttachments();
    if (as == null) {
      return 0;
    }

    return as.size();
  }

  public void addAttachment(BwAttachment val) {
    Collection<BwAttachment> as = getAttachments();
    if (as == null) {
      as = new TreeSet<BwAttachment>();
      setAttachments(as);
    }

    if (!as.contains(val)) {
      as.add(val);
    }
  }

  public boolean removeAttachment(BwAttachment val) {
    Collection as = getAttachments();
    if (as == null) {
      return false;
    }

    return as.remove(val);
  }

  public Collection<BwAttachment> copyAttachments() {
    if (getNumAttachments() == 0) {
      return null;
    }
    TreeSet<BwAttachment> ts = new TreeSet<BwAttachment>();

    for (BwAttachment att: getAttachments()) {
      ts.add(att);
    }

    return ts;
  }

  public Collection<BwAttachment> cloneAttachments() {
    if (getNumAttachments() == 0) {
      return null;
    }
    TreeSet<BwAttachment> ts = new TreeSet<BwAttachment>();

    for (BwAttachment att: getAttachments()) {
      ts.add((BwAttachment)att.clone());
    }

    return ts;
  }

  /* ====================================================================
   *                   AttendeesEntity interface methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#setAttendees(java.util.Collection)
   */
  public void setAttendees(Collection<BwAttendee> val) {
    attendees = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#getAttendees()
   */
  public Collection<BwAttendee> getAttendees() {
    return attendees;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#getNumAttendees()
   */
  public int getNumAttendees() {
    Collection as = getAttendees();
    if (as == null) {
      return 0;
    }

    return as.size();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#addAttendee(org.bedework.calfacade.BwAttendee)
   */
  public void addAttendee(BwAttendee val) {
    Collection<BwAttendee> as = getAttendees();
    if (as == null) {
      as = new TreeSet<BwAttendee>();
      setAttendees(as);
    }

    if (!as.contains(val)) {
      as.add(val);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#removeAttendee(org.bedework.calfacade.BwAttendee)
   */
  public boolean removeAttendee(BwAttendee val) {
    Collection as = getAttendees();
    if (as == null) {
      return false;
    }

    return as.remove(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#copyAttendees()
   */
  public Collection<BwAttendee> copyAttendees() {
    if (getNumAttendees() == 0) {
      return null;
    }
    TreeSet<BwAttendee> ts = new TreeSet<BwAttendee>();

    for (BwAttendee att: getAttendees()) {
      ts.add(att);
    }

    return ts;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#cloneAttendees()
   */
  public Collection<BwAttendee> cloneAttendees() {
    if (getNumAttendees() == 0) {
      return null;
    }
    TreeSet<BwAttendee> ts = new TreeSet<BwAttendee>();

    for (BwAttendee att: getAttendees()) {
      ts.add((BwAttendee)att.clone());
    }

    return ts;
  }

  /** Find an attendee entry for the given uri (calendar address).
   *
   * @param uri
   * @return BwAttendee or null if none exists
   * @throws CalFacadeException
   */
  public BwAttendee findAttendee(String uri) throws CalFacadeException {
    if (getNumAttendees() == 0) {
      return null;
    }

    int uriLen = uri.length();
    while (uri.charAt(uriLen - 1) == '/') {
      uriLen--;
      if (uriLen == 0) {
        return null;
      }
    }

    for (BwAttendee att: getAttendees()) {
      String auri = att.getAttendeeUri();
      int auriLen = auri.length();
      while (auri.charAt(auriLen - 1) == '/') {
        auriLen--;
        if (auriLen == 0) {
          return null;
        }
      }

      if ((auriLen == uriLen) && (uri.regionMatches(0, auri, 0, uriLen))) {
        return att;
      }
    }

    return null;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#setRecipients(java.util.Collection)
   */
  public void setRecipients(Collection<String> val) {
    recipients = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#getRecipients()
   */
  public Collection<String> getRecipients() {
    return recipients;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#getNumRecipients()
   */
  public int getNumRecipients() {
    Collection<String> rs = getRecipients();
    if (rs == null) {
      return 0;
    }

    return rs.size();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#addRecipient(java.lang.String)
   */
  public void addRecipient(String val) {
    Collection<String> rs = getRecipients();
    if (rs == null) {
      rs = new TreeSet<String>();
      setRecipients(rs);
    }

    if (!rs.contains(val)) {
      rs.add(val);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#removeRecipient(java.lang.String)
   */
  public boolean removeRecipient(String val) {
    Collection<String> rs = getRecipients();
    if (rs == null) {
      return false;
    }

    return rs.remove(val);
  }

  /* ====================================================================
   *               CategorisedEntity interface methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#setCategories(java.util.Collection)
   */
  public void setCategories(Collection<BwCategory> val) {
    categories = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#getCategories()
   */
  public Collection<BwCategory> getCategories() {
    return categories;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#getNumCategories()
   */
  public int getNumCategories() {
    Collection<BwCategory> c = getCategories();
    if (c == null) {
      return 0;
    }

    return c.size();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#addCategory(org.bedework.calfacade.BwCategory)
   */
  public void addCategory(BwCategory val) {
    Collection<BwCategory> cats = getCategories();
    if (cats == null) {
      cats = new TreeSet<BwCategory>();
      setCategories(cats);
    }

    if (!cats.contains(val)) {
      cats.add(val);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#removeCategory(org.bedework.calfacade.BwCategory)
   */
  public boolean removeCategory(BwCategory val) {
    Collection cats = getCategories();
    if (cats == null) {
      return false;
    }

    return cats.remove(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#hasCategory(org.bedework.calfacade.BwCategory)
   */
  public boolean hasCategory(BwCategory val) {
    Collection cats = getCategories();
    if (cats == null) {
      return false;
    }

    return cats.contains(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#copyCategories()
   */
  public Collection<BwCategory> copyCategories() {
    if (getNumCategories() == 0) {
      return null;
    }
    TreeSet<BwCategory> ts = new TreeSet<BwCategory>();

    for (BwCategory cat: getCategories()) {
      ts.add(cat);
    }

    return ts;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#cloneCategories()
   */
  public Collection<BwCategory> cloneCategories() {
    if (getNumCategories() == 0) {
      return null;
    }
    TreeSet<BwCategory> ts = new TreeSet<BwCategory>();

    for (BwCategory cat: getCategories()) {
      ts.add((BwCategory)cat.clone());
    }

    return ts;
  }

  /* ====================================================================
   *               CommentedEntity interface methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CommentedEntity#setComments(java.util.Collection)
   */
  public void setComments(Collection<BwString> val) {
    comments = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CommentedEntity#getComments()
   */
  public Collection<BwString> getComments() {
    return comments;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CommentedEntity#getNumComments()
   */
  public int getNumComments() {
    Collection rs = getComments();
    if (rs == null) {
      return 0;
    }

    return rs.size();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CommentedEntity#addComment(java.lang.String, java.lang.String)
   */
  public void addComment(String lang, String val) {
    addComment(new BwString(lang, val));
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CommentedEntity#addComment(org.bedework.calfacade.BwString)
   */
  public void addComment(BwString val) {
    Collection<BwString> rs = getComments();
    if (rs == null) {
      rs = new TreeSet<BwString>();
      setComments(rs);
    }

    if (!rs.contains(val)) {
      rs.add(val);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CommentedEntity#removeComment(org.bedework.calfacade.BwString)
   */
  public boolean removeComment(BwString val) {
    Collection rs = getComments();
    if (rs == null) {
      return false;
    }

    return rs.remove(val);
  }

  /* ====================================================================
   *               Contact interface methods
   * ==================================================================== */

  /** Transition method - replace collection with single value.
   *
   * @param val
   */
  public void setContact(BwContact val) {
    Collection<BwContact> c = getContacts();
    if ((c != null) && (!c.isEmpty())) {
      c.clear();
    }

    addContact(val);
  }

  /** Transition method - return first contact if any available.
   *
   * @return BwContact
   */
  public BwContact getContact() {
    Collection<BwContact> c = getContacts();
    if ((c == null) || (c.isEmpty())) {
      return null;
    }

    return c.iterator().next();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#setContacts(java.util.Collection)
   */
  public void setContacts(Collection<BwContact> val) {
    contacts = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#getContacts()
   */
  public Collection<BwContact> getContacts() {
    return contacts;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#getNumContacts()
   */
  public int getNumContacts() {
    Collection<BwContact> c = getContacts();
    if (c == null) {
      return 0;
    }

    return c.size();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#addContact(org.bedework.calfacade.BwContact)
   */
  public void addContact(BwContact val) {
    Collection<BwContact> cs = getContacts();
    if (cs == null) {
      cs = new TreeSet<BwContact>();
      setContacts(cs);
    }

    if (!cs.contains(val)) {
      cs.add(val);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#removeContact(org.bedework.calfacade.BwContact)
   */
  public boolean removeContact(BwContact val) {
    Collection cs = getContacts();
    if (cs == null) {
      return false;
    }

    return cs.remove(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#hasContact(org.bedework.calfacade.BwContact)
   */
  public boolean hasContact(BwContact val) {
    Collection cs = getContacts();
    if (cs == null) {
      return false;
    }

    return cs.contains(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#copyContacts()
   */
  public Collection<BwContact> copyContacts() {
    if (getNumContacts() == 0) {
      return null;
    }
    TreeSet<BwContact> ts = new TreeSet<BwContact>();

    for (BwContact cat: getContacts()) {
      ts.add(cat);
    }

    return ts;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CategorisedEntity#cloneContacts()
   */
  public Collection<BwContact> cloneContacts() {
    if (getNumContacts() == 0) {
      return null;
    }
    TreeSet<BwContact> ts = new TreeSet<BwContact>();

    for (BwContact cat: getContacts()) {
      ts.add((BwContact)cat.clone());
    }

    return ts;
  }

  /* ====================================================================
   *               DescriptionEntity interface methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.DescriptionEntity#setDescriptions(java.util.Collection)
   */
  public void setDescriptions(Collection<BwLongString> val) {
    descriptions = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.DescriptionEntity#getDescriptions()
   */
  public Collection<BwLongString> getDescriptions() {
    return descriptions;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.DescriptionEntity#getNumDescriptions()
   */
  public int getNumDescriptions() {
    Collection<BwLongString> rs = getDescriptions();
    if (rs == null) {
      return 0;
    }

    return rs.size();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.DescriptionEntity#addDescription(java.lang.String, java.lang.String)
   */
  public void addDescription(String lang, String val) {
    addDescription(new BwLongString(lang, val));
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.DescriptionEntity#addDescription(org.bedework.calfacade.BwString)
   */
  public void addDescription(BwLongString val) {
    Collection<BwLongString> rs = getDescriptions();
    if (rs == null) {
      rs = new TreeSet<BwLongString>();
      setDescriptions(rs);
    }

    if (!rs.contains(val)) {
      rs.add(val);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.DescriptionEntity#removeDescription(org.bedework.calfacade.BwString)
   */
  public boolean removeDescription(BwLongString val) {
    Collection rs = getDescriptions();
    if (rs == null) {
      return false;
    }

    return rs.remove(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.DescriptionEntity#updateDescriptions(java.lang.String, java.lang.String)
   */
  public void updateDescriptions(String lang, String val) {
    BwLongString s = findDescription(lang);
    if (val == null) {
      // Removing
      if (s!= null) {
        removeDescription(s);
      }
    } else if (s == null) {
      addDescription(lang, val);
    } else if ((CalFacadeUtil.cmpObjval(val, s.getValue()) != 0)) {
      // XXX Cannot change value in case this is an override collection.

      //s.setValue(val);
      removeDescription(s);
      addDescription(lang, val);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.DescriptionEntity#findDescription(java.lang.String)
   */
  public BwLongString findDescription(String lang) {
    return BwLongString.findLang(lang, getDescriptions());
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.DescriptionEntity#setDescription(java.lang.String)
   */
  public void setDescription(String val) {
    updateDescriptions(null, val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.DescriptionEntity#getDescription()
   */
  public String getDescription() {
    BwLongString s = findDescription(null);
    if (s == null) {
      return null;
    }
    return s.getValue();
  }

  /* ====================================================================
   *               ResourcedEntity interface methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.ResourcedEntity#setResources(java.util.Collection)
   */
  public void setResources(Collection<BwString> val) {
    resources = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.ResourcedEntity#getResources()
   */
  public Collection<BwString> getResources() {
    return resources;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.ResourcedEntity#getNumResources()
   */
  public int getNumResources() {
    Collection rs = getResources();
    if (rs == null) {
      return 0;
    }

    return rs.size();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.ResourcedEntity#addResource(java.lang.String, java.lang.String)
   */
  public void addResource(String lang, String val) {
    addResource(new BwString(lang, val));
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.ResourcedEntity#addResource(org.bedework.calfacade.BwString)
   */
  public void addResource(BwString val) {
    Collection<BwString> rs = getResources();
    if (rs == null) {
      rs = new TreeSet<BwString>();
      setResources(rs);
    }

    if (!rs.contains(val)) {
      rs.add(val);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.ResourcedEntity#removeResource(org.bedework.calfacade.BwString)
   */
  public boolean removeResource(BwString val) {
    Collection rs = getResources();
    if (rs == null) {
      return false;
    }

    return rs.remove(val);
  }

  /* ====================================================================
   *               SummaryEntity interface methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.SummaryEntity#setSummaries(java.util.Collection)
   */
  public void setSummaries(Collection<BwString> val) {
    summaries = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.SummaryEntity#getSummaries()
   */
  public Collection<BwString> getSummaries() {
    return summaries;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.SummaryEntity#getNumSummaries()
   */
  public int getNumSummaries() {
    Collection rs = getSummaries();
    if (rs == null) {
      return 0;
    }

    return rs.size();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.SummaryEntity#addSummary(java.lang.String, java.lang.String)
   */
  public void addSummary(String lang, String val) {
    addSummary(new BwString(lang, val));
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.SummaryEntity#addSummary(org.bedework.calfacade.BwString)
   */
  public void addSummary(BwString val) {
    Collection<BwString> rs = getSummaries();
    if (rs == null) {
      rs = new TreeSet<BwString>();
      setSummaries(rs);
    }

    if (!rs.contains(val)) {
      rs.add(val);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.SummaryEntity#removeSummary(org.bedework.calfacade.BwString)
   */
  public boolean removeSummary(BwString val) {
    Collection<BwString> c = getSummaries();
    if (c == null) {
      return false;
    }

    return c.remove(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.SummaryEntity#updateSummaries(java.lang.String, java.lang.String)
   */
  public void updateSummaries(String lang, String val) {
    BwString s = findSummary(lang);
    if (val == null) {
      // Removing
      if (s!= null) {
        removeSummary(s);
      }
    } else if (s == null) {
      addSummary(lang, val);
    } else if ((CalFacadeUtil.cmpObjval(val, s.getValue()) != 0)) {
      // XXX Cannot change value in case this is an override collection.

      //s.setValue(val);
      removeSummary(s);
      addSummary(lang, val);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.SummaryEntity#findSummary(java.lang.String)
   */
  public BwString findSummary(String lang) {
    return BwString.findLang(lang, getSummaries());
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.SummaryEntity#setSummary(java.lang.String)
   */
  public void setSummary(String val) {
    updateSummaries(null, val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.SummaryEntity#getSummary()
   */
  public String getSummary() {
    BwString s = findSummary(null);
    if (s == null) {
      return null;
    }
    return s.getValue();
  }

  /* ====================================================================
   *                   Free and busy methods
   * ==================================================================== */

  /** set the free busy periods
   *
   * @param val     Collection    of BwFreeBusyComponent
   */
  public void setFreeBusyPeriods(Collection<BwFreeBusyComponent> val) {
    freeBusyPeriods = val;
  }

  /** Get the free busy times
   *
   * @return Collection    of BwFreeBusyComponent
   */
  public Collection<BwFreeBusyComponent> getFreeBusyPeriods() {
    return freeBusyPeriods;
  }

  /** Add a free/busy component
   *
   * @param val
   */
  public void addFreeBusyPeriod(BwFreeBusyComponent val) {
    Collection<BwFreeBusyComponent> fbps = getFreeBusyPeriods();

    if (fbps == null) {
      fbps = new ArrayList<BwFreeBusyComponent>();
      setFreeBusyPeriods(fbps);
    }

    fbps.add(val);
  }

  /* ====================================================================
   *                   Available methods
   * ==================================================================== */

  /**
   * @param val
   */
  public void setBusyType(int val) {
    busyType = val;
  }

  /**
   * @return int type of time
   */
  public int getBusyType() {
    return busyType;
  }

  /** Set the available uids
   *
   * @param val    Collection<String>
   */
  public void setAvailableUids(Collection<String> val) {
    availableUids = val;
  }

  /** Get the uids
   *
   * @return Collection<String>   uids
   */
  public Collection<String> getAvailableUids() {
    return availableUids;
  }

  /** Add as available uid
   *
   * @param val
   */
  public void addAvailableUid(String val) {
    Collection<String> avls = getAvailableUids();

    if (avls == null) {
      avls = new TreeSet<String>();
      setAvailableUids(avls);
    }

    if (!avls.contains(val)) {
      avls.add(val);
    }
  }

  /* ====================================================================
   *                   Convenience methods
   * ==================================================================== */

  /** Return all timezone ids this event uses. This is used when an event is
   * added by another user to ensure that the target user has a copy of user
   * specific timezones.
   *
   * @return Collection of timezone ids.
   * @throws CalFacadeException
   */
  public Collection<String> getTimeZoneIds() throws CalFacadeException {
    Collection<String> ids = new TreeSet<String>();

    BwDateTime dt = getDtstart();
    if ((dt != null) && (dt.getTzid() != null)) {
      ids.add(dt.getTzid());
    }

    dt = getDtend();
    if ((dt != null) && (dt.getTzid() != null)) {
      ids.add(dt.getTzid());
    }

    for (BwDateTime rdt: getRdates()) {
      if (rdt.getTzid() != null) {
        ids.add(rdt.getTzid());
      }
    }

    for (BwDateTime rdt: getExdates()) {
      if (rdt.getTzid() != null) {
        ids.add(rdt.getTzid());
      }
    }

    for (BwFreeBusyComponent fbc: getFreeBusyPeriods()) {
      for (Period p: fbc.getPeriods()) {
        DateTime fdt = p.getStart();
        if (fdt.getTimeZone() != null) {
          ids.add(fdt.getTimeZone().getID());
        }

        fdt = p.getEnd();
        if (fdt.getTimeZone() != null) {
          ids.add(fdt.getTimeZone().getID());
        }
      }
    }

    return ids;
  }

  /** Can this event be moved into the trash or does it have to be deleted?
   *
   * @return boolean
   */
  public boolean getTrashable() {
    BwCalendar cal = getCalendar();

    if (cal != null) {
      if ((cal.getCalType() == BwCalendar.calTypeTrash) ||
          (cal.getCalType() == BwCalendar.calTypeDeleted)) {
        // Already in trash or deleted
        return false;
      }
    }

    if (getRecurrenceId() != null) {
      // DORECUR Cannot trash recurring instances at the moment
      // An instance - cannot trash
      return false;
    }

    return true;
  }

  /** Set the last mod for this event.
   */
  public void updateLastmod() {
    setLastmod(new LastModified(new DateTime(true)).getValue());
  }

  /** Set the dtstamp for this event.
   */
  public void updateDtstamp() {
    setDtstamp(new DtStamp(new DateTime(true)).getValue());
  }

  /** Set the dtstamp, lastmod and created if they are not set already.
   */
  public void setDtstamps() {
    if (getDtstamp() == null) {
      setDtstamp(new DtStamp(new DateTime(true)).getValue());
    }

    if (getLastmod() == null) {
      setLastmod(new LastModified(new DateTime(true)).getValue());
    }

    if (getCreated() == null) {
      setCreated(new Created(new DateTime(true)).getValue());
    }
  }

  /** Return an object holding just enough for free busy calculation
   *
   * @return BwEvent object.
   */
  public BwEvent makeFreeBusyEvent() {
    BwEvent res = new BwEvent();

    // Fields needed for comparison.
    res.setEntityType(getEntityType());
    res.setCalendar(getCalendar());
    res.setName(getName());
    res.setUid(getUid());
    res.setRecurrenceId(getRecurrenceId());
    res.setRecurring(false);

    res.setDtend(getDtend());
    res.setDtstart(getDtstart());
    res.setDuration(getDuration());
    res.setEndType(getEndType());
    res.setTransparency(getTransparency());
    res.setStatus(getStatus());

    // Need owner to locate some timezones.
    res.setOwner(getOwner());

    if (getEntityType() == CalFacadeDefs.entityTypeFreeAndBusy) {
      Collection<BwFreeBusyComponent> fbcs = getFreeBusyPeriods();
      Collection<BwFreeBusyComponent> newfbcs = new ArrayList<BwFreeBusyComponent>();

      for (BwFreeBusyComponent fbc: fbcs) {
        newfbcs.add((BwFreeBusyComponent)fbc.clone());
      }

      res.setFreeBusyPeriods(newfbcs);
    }

    return res;
  }

  /** Return a BwDuration populated from the String duration.
   *
   * @return BwDuration
   * @throws CalFacadeException
   */
  public BwDuration makeDurationBean() throws CalFacadeException {
    return BwDuration.makeDuration(getDuration());
  }

  /** Calculate a value to be used to limit quotas.
   *
   * @return int
   */
  public int calculateByteSize() {

    int sz = 40; // Overhead for superclasses.
   /*
   sv += 4;   // int entityType = CalFacadeDefs.entityTypeEvent;
   sv += stringSize(name);        // String name;
   sv += collectionSize(nnn);     // Collection<BwString> summaries;
   sv += collectionSize(nnn);     // Collection<BwLongString> descriptions;
   sv += stringSize(classification);   // String classification;
   sv += collectionSize(nnn);     // Collection<BwString> comments;
   sv += collectionSize(nnn);     // Collection<BwString> resources;
    private BwDateTime dtstart;
    private BwDateTime dtend;
   sv += 16;   // String duration;
   sv += 4;    // Boolean noStart;
   sv += 1;    // char endType = endTypeDate;
   sv += stringSize(link);   // String link;
    private BwGeo geo;
   sv += stringSize(status);   // String status;
   sv += stringSize(cost);   // String cost;
   sv += 1;    // boolean deleted;
   sv += 16;   // String dtstamp;
   sv += 16;   // String lastmod;
   sv += 16;   // String created;
   sv += 4;    // integer priority;
    private Collection<BwCategory> categories = null;
    private Collection<BwContact> contacts;
    private BwLocation location;
   sv += stringSize(name);   // String transparency;
   sv += 4;    // integer percentComplete;
   sv += 16;   // String completed;
    private Collection<BwAttendee> attendees;
   sv += 4;   // Boolean recurring;
   sv += stringSize(uid);   // String uid;
    private Collection<BwAlarm> alarms;
   sv += 16;   // String recurrenceId;
    private Collection<String> rrules;
    private Collection<String> exrules;
    private Collection<BwDateTime> rdates;
    private Collection<BwDateTime> exdates;
   sv += 16;   // String latestDate;
   sv += 4;   // Boolean expanded;
   sv += 4;   // int sequence;
   sv += 4;   // int scheduleMethod;
   sv += stringSize(name);   // String originator;
    private Collection<String> recipients;
   sv += 4;   // int scheduleState;
    private Collection<BwRequestStatus> requestStatuses;
    private BwRelatedTo relatedTo;
   sv += 4;   // int byteSize;
    */

    return sz;
  }

  /** Add our stuff to the StringBuffer
   *
   * @param sb    StringBuffer for result
   */
   protected void toStringSegment(StringBuffer sb) {
    super.toStringSegment(sb);
    sb.append(",\n entityType=");
    sb.append(getEntityType());
    sb.append(", deleted=");
    sb.append(getDeleted());
    sb.append(", dtstamp=");
    sb.append(getDtstamp());
    sb.append(", lastmod=");
    sb.append(getLastmod());
    sb.append(", created=");
    sb.append(getCreated());
    sb.append(",\n priority=");
    sb.append(getPriority());

    if (getPercentComplete() != null) {
      sb.append(", percentComplete=");
      sb.append(getPercentComplete());
    }

    if (getCompleted() != null) {
      sb.append(", completed=");
      sb.append(getCompleted());
    }

    sb.append(", classification=");
    sb.append(getClassification());
    if (getGeo() != null) {
      sb.append(", geo=");
      sb.append(getGeo());
    }

    sb.append(",\n dtstart=");
    sb.append(getDtstart());
    sb.append(",\n dtend=");
    sb.append(getDtend());
    sb.append(",\n uid=");
    sb.append(getUid());
    sb.append(",\n name=");
    sb.append(getName());

    /* ---------------- recurrence information */
    if (getRecurrenceId() != null) {
      sb.append(",\n recurrenceId=");
      sb.append(getRecurrenceId());
    }

    sb.append(", getRecurring=");
    sb.append(getRecurring());
    sb.append(", latestDate=");
    sb.append(getLatestDate());

    if (hasRrules()) {
      for (String r: getRrules()) {
        sb.append(", rrule=");
        sb.append(r);
      }
    }

    if (hasExrules()) {
      for (String r: getExrules()) {
        sb.append(", exrule=");
        sb.append(r);
      }
    }

    if (hasExdates()) {
      for (BwDateTime dt: getExdates()) {
        sb.append(", exdate=");
        sb.append(dt);
      }
    }

    if (hasRdates()) {
      for (BwDateTime dt: getRdates()) {
        sb.append(", rdate=");
        sb.append(dt);
      }
    }

    sb.append(",\n organizer=");
    sb.append(getOrganizer());

    if (getNumRecipients() > 0) {
      for (String s: getRecipients()) {
        sb.append(",\n recipient=");
        sb.append(s);
      }
    }

    if (getNumCategories() > 0) {
      sb.append(",\n categories=");
      for (BwCategory cat: getCategories()) {
        sb.append(cat);
        sb.append(", ");
      }
    }

    if (getNumComments() > 0) {
      for (BwString str: getComments()) {
        sb.append(",\n comment={");
        sb.append(str);
      }
    }

    if (getNumContacts() > 0) {
      sb.append(",\n contacts=");
      for (BwContact cat: getContacts()) {
        sb.append(cat);
        sb.append(", ");
      }
    }

    if (getNumSummaries() > 0) {
      for (BwString str: getSummaries()) {
        sb.append(",\n summary={");
        sb.append(str);
      }
    }

    if (getNumDescriptions() > 0) {
      for (BwLongString str: getDescriptions()) {
        sb.append(",\n description={");
        sb.append(str);
      }
    }

    if (getNumResources() > 0) {
      for (BwString str: getResources()) {
        sb.append(",\n resource=");
        sb.append(str);
      }
    }

    if (getNumAttendees() > 0) {
      for (BwAttendee att: getAttendees()) {
        sb.append(",\n attendee=");
        sb.append(att);
      }
    }

    sb.append(",\n sequence=");
    sb.append(getSequence());
    sb.append(", scheduleMethod=");
    sb.append(getScheduleMethod());
    sb.append(", originator=");
    sb.append(getOriginator());
    sb.append(", scheduleState=");
    sb.append(getScheduleState());


    if (getNumRequestStatuses() > 0) {
      for (BwRequestStatus rs: getRequestStatuses()) {
        sb.append(",\n requestStatus=");
        sb.append(rs);
      }
    }

    if (getRelatedTo() != null) {
      sb.append(", relatedTo=");
      sb.append(getRelatedTo());
    }
  }

  /** Copy this objects fields into the parameter
   *
   * @param ev
   */
  public void copyTo(BwEvent ev) {
    super.copyTo(ev);
    ev.setEntityType(getEntityType());
    ev.setName(getName());
    ev.setClassification(getClassification());
    ev.setDtstart(getDtstart());
    ev.setDtend(getDtend());
    ev.setEndType(getEndType());
    ev.setDuration(getDuration());
    ev.setNoStart(getNoStart());

    ev.setLink(getLink());
    ev.setGeo(getGeo());
    ev.setDeleted(getDeleted());
    ev.setStatus(getStatus());
    ev.setCost(getCost());

    BwOrganizer org = getOrganizer();
    if (org != null) {
      org = (BwOrganizer)org.clone();
    }
    ev.setOrganizer(org);

    ev.setDtstamp(getDtstamp());
    ev.setLastmod(getLastmod());
    ev.setCreated(getCreated());
    ev.setPriority(getPriority());
    ev.setSequence(getSequence());

    ev.setLocation(getLocation());

    ev.setUid(getUid());
    ev.setTransparency(getTransparency());
    ev.setPercentComplete(getPercentComplete());
    ev.setCompleted(getCompleted());

    ev.setCategories(copyCategories());

    ev.setContacts(copyContacts());

    ev.setAttendees(cloneAttendees());

    ev.setRecurrenceId(getRecurrenceId());
    ev.setRecurring(getRecurring());
    ev.setRrules(clone(getRrules()));
    ev.setExrules(clone(getExrules()));
    ev.setRdates(clone(getRdates()));
    ev.setExdates(clone(getExdates()));
    ev.setLatestDate(getLatestDate());
    ev.setExpanded(getExpanded());

    ev.setScheduleMethod(getScheduleMethod());
    ev.setOriginator(getOriginator());

    if (getNumRecipients() > 0) {
      ev.setRecipients(new TreeSet<String>());

      for (String s: getRecipients()) {
        ev.addRecipient(s);
      }
    }

    if (getNumComments() > 0) {
      ev.setComments(null);

      for (BwString str: getComments()) {
        ev.addComment((BwString)str.clone());
      }
    }

    if (getNumSummaries() > 0) {
      ev.setSummaries(null);

      for (BwString str: getSummaries()) {
        ev.addSummary((BwString)str.clone());
      }
    }

    if (getNumDescriptions() > 0) {
      ev.setDescriptions(null);

      for (BwLongString str: getDescriptions()) {
        ev.addDescription((BwLongString)str.clone());
      }
    }

    if (getNumResources() > 0) {
      ev.setResources(null);

      for (BwString str: getResources()) {
        ev.addResource((BwString)str.clone());
      }
    }

    ev.setScheduleState(getScheduleState());

    ev.setRequestStatuses(clone(getRequestStatuses()));

    BwRelatedTo rt = getRelatedTo();
    if (rt != null) {
      ev.setRelatedTo((BwRelatedTo)rt.clone());
    }
  }

  /** Copy the parameter into this object - don't use this widely - temp fix.
   *
   * @param ev
   * @deprecated
   */
  public void updateFrom(BwEvent ev) {
    setEntityType(ev.getEntityType());
    setName(ev.getName());
    setSummary(ev.getSummary());
    setDescription(ev.getDescription());
    setDtstart(ev.getDtstart());
    setDtend(ev.getDtend());
    setEndType(ev.getEndType());
    setDuration(ev.getDuration());
    setLink(ev.getLink());
    setDeleted(ev.getDeleted());
    setStatus(ev.getStatus());
    setCost(ev.getCost());

    /*
    BwOrganizer org = getOrganizer();
    if (org != null) {
      org = (BwOrganizer)org.clone();
    }
    setOrganizer(org);
    */

    setDtstamp(ev.getDtstamp());
    setLastmod(ev.getLastmod());
    setCreated(ev.getCreated());
    setPriority(ev.getPriority());
    setSequence(ev.getSequence());

    /*
    BwSponsor sp = getSponsor();
    if (sp != null) {
      sp = (BwSponsor)sp.clone();
    }
    setSponsor(sp);

    BwLocation loc = getLocation();
    if (loc != null) {
      loc = (BwLocation)loc.clone();
    }
    setLocation(loc);
    */

    setUid(ev.getUid());
    setTransparency(ev.getTransparency());
    setPercentComplete(ev.getPercentComplete());
    setCompleted(ev.getCompleted());

    /* categories * /
    Iterator it = iterateCategories();
    TreeSet cs = new TreeSet();

    while (it.hasNext()) {
      BwCategory c = (BwCategory)it.next();

      cs.add((BwCategory)c.clone());
    }

    setCategories(cs);

    setAttendees(cloneAttendees());
    */

    setRecurrenceId(ev.getRecurrenceId());
     /*
    setRecurring(getRecurring());

    if (getRecurrence() != null) {
      setRecurrence((BwRecurrence)getRecurrence().clone());
    }
    */

    setScheduleMethod(ev.getScheduleMethod());
    setOriginator(ev.getOriginator());

    /*
    if (getNumRecipients() > 0) {
      setRecipients(new TreeSet());

      it = iterateRecipients();
      while (it.hasNext()) {
        addRecipient((String)it.next());
      }
    }

    if (getNumComments() > 0) {
      setComments(new TreeSet());

      it = iterateComments();
      while (it.hasNext()) {
        addComment((String)it.next());
      }
    }

    if (getNumResources() > 0) {
      setResources(new TreeSet());

      it = iterateResources();
      while (it.hasNext()) {
        addResource((String)it.next());
      }
    }*/

    setScheduleState(ev.getScheduleState());
  }

  /* ====================================================================
   *                   Object methods
   * ==================================================================== */

  public int compare(BwEvent e1, BwEvent e2) {
    if (e1 == e2) {
      return 0;
    }

    int res = CalFacadeUtil.cmpObjval(e1.getDtstart(), e2.getDtstart());
    if (res != 0) {
      return res;
    }

    /* I think it's OK for null calendars during addition of events. */
    res = CalFacadeUtil.cmpObjval(e1.getCalendar(),
                                  e2.getCalendar());
    if (res != 0) {
      return res;
    }

    /* Compare the names. For scheduling we allow multiple events with the same
     * uid etc in the same calendar.
     */
    res = CalFacadeUtil.cmpObjval(e1.getName(),
                            e2.getName());
    if (res != 0) {
      return res;
    }

    /* Only the same if the recurrence id is equal */
    res = CalFacadeUtil.cmpObjval(e1.getRecurrenceId(),
                                  e2.getRecurrenceId());
    if (res != 0) {
      return res;
    }

    /*
    int thisSeq = e1.getSequence();
    int thatSeq = e2.getSequence();

    if (thisSeq < thatSeq) {
      return -1;
    }

    if (thisSeq > thatSeq) {
      return 1;
    }*/

    return e1.getUid().compareTo(e2.getUid());
  }

  public int compareTo(BwEvent o2) {
    return compare(this, o2);
  }

  public int hashCode() {
    return getUid().hashCode();
  }

  public String toString() {
    StringBuffer sb = new StringBuffer("BwEvent{");

    toStringSegment(sb);

    sb.append("}");

    return sb.toString();
  }

  public Object clone() {
    BwEvent ev = new BwEvent();

    copyTo(ev);

    return ev;
  }

  /* ====================================================================
   *                   Private methods
   *  =================================================================== */

  private boolean isEmpty(Collection c) {
    return (c == null) || (c.size() == 0);
  }

  private <T> Collection<T> clone(Collection<T> c) {
    if (c == null) {
      return null;
    }

    TreeSet<T> ts = new TreeSet<T>();

    for (T ent: c) {
      ts.add(ent);
    }

    return ts;
  }
}
