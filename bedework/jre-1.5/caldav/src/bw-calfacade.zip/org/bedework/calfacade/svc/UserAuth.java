/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade.svc;

import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.exc.CalFacadeException;

import java.io.Serializable;
import java.util.Collection;

/** An interface to define an application based authorisation method.
 *
 * <p>The actual authorisation of the user will be site specific.
 * For example, if we are using a roles based scheme, the implementation of
 * this interface will check the current users role.
 *
 * <p>There is no method to add a user as we are simply giving users certain
 * rights. The underlying implementation may choose to use a database and
 * remove those entries for which there are no special rights.
 *
 * @author Mike Douglass douglm@rpi.edu
 * @version 2.2
 */
public interface UserAuth extends Serializable {
  /** Define the various access levels. Note these are powers of two so
   * we can add them up.
   */
  public static final int noPrivileges = 0;

  /** Not one who stays awake but one who can add alerts
   */
  public static final int alertUser = 2;

  /** A user who can add public events
   */
  public static final int publicEventUser = 64;

  /** A user who can administer any content
   */
  public static final int contentAdminUser = 128;

  /** One who can do everything
   */
  public static final int superUser = 32768;

  /** Useful value.
   */
  public static final int allAuth = alertUser +
                                    publicEventUser +
                                    contentAdminUser +
                                    superUser;

  /** Class to be implemented by caller and passed during init.
   */
  public static abstract class CallBack implements Serializable {
    /**
     * @param account
     * @return BwUser represented by account
     * @throws CalFacadeException
     */
    public abstract BwUser getUser(String account) throws CalFacadeException;

    /**
     * @param user
     * @throws CalFacadeException
     */
    public abstract void addUser(BwUser user) throws CalFacadeException;

    /** Allows this class to be passed to other admin classes
     *
     * @return UserAuth
     * @throws CalFacadeException
     */
    public abstract UserAuth getUserAuth() throws CalFacadeException;

    /** An implementation specific method allowing access to the underlying
     * persistence engine. This may return, for example, a Hibernate session,
     *
     * @return Object    db session
     * @throws CalFacadeException
     */
    public abstract Object getDbSession() throws CalFacadeException;
  }

  /* ====================================================================
   *  The following affect the state of the current user.
   * ==================================================================== */

  /** Initialise the implementing object. This method may be called repeatedly
   * with the same or different classes of object.
   *
   * <p>This is not all that well-defined. This area falls somewhere
   * between the back-end and the front-end, depending upon how a site
   * implements its authorisation.
   *
   * <p>To make this interface independent of any particular implementation
   * we make the parameter an Object. We will call this method early on in
   * the life of a web session giving it the request. This allows
   * a role-driven implementation to determine what roles the user has. The
   * object may choose to adjust that users rights at each request or ignore
   * subsequent calls (though note that some containers recheck a users
   * rights periodically)
   *
   * <p>Any implementation is free to ignore the call
   * altogether.
   *
   * @param  userid    user whose access we are setting
   * @param  cb        CallBack object
   * @param  val        Object
   * @param debug
   * @exception CalFacadeException If there's a problem
   */
  public void initialise(String userid, CallBack cb,
                         Object val,
                         boolean debug) throws CalFacadeException;

  /** Initialise the implementing object with an access level.
   *
   * <p>This is not all that well-defined. This area falls somewhere
   * between the back-end and the front-end, depending upon how a site
   * implements its authorisation.
   *
   * <p>This allows role-based implementations using the standard servlet
   * authorization model to indicate what roles a user has. This may not get
   * called or it may be called and ignored.
   *
   * <p>This method should not update any underlying directory.
   *
   * <p>Any implementation is free to ignore the call altogether.
   * Alternatively an implementation may choose to base the access on the
   * supplied user and ignore the supplied access.
   *
   * @param  userid    user whose access we are setting
   * @param  cb        CallBack object
   * @param  val       int sum  of allowable access.
   * @param debug
   * @exception CalFacadeException If there's a problem
   */
  public void initialise(String userid, CallBack cb,
                         int val,
                         boolean debug) throws CalFacadeException;

  /** ===================================================================
   *  The following return the state of the current user.
   *  =================================================================== */

  /** Return the current userid. If non-null this object has been
   * initialised otherwise one of the initialsie methods must be called.
   *
   * @return String          non-null for initialised object.
   * @exception CalFacadeException If there's a problem
   */
  public String getUserid() throws CalFacadeException;

  /** Return a read only object represeting the state of the current user.
   *
   * @return UserAuthRO        object representing user state
   * @exception CalFacadeException If there's a problem
   */
  public UserAuthRO getUserAuthRO() throws CalFacadeException;

  /** Return the type of the current user.
   *
   * @return int        user type as defined above,
   * @exception CalFacadeException If there's a problem
   */
  public int getUsertype() throws CalFacadeException;

  /** Check for priv user
   *
   * @return boolean    true for super user
   * @exception CalFacadeException If there's a problem
   */
  public boolean isSuperUser() throws CalFacadeException;

  /** Check for alert user
   *
   * @return boolean    true for alert user
   * @exception CalFacadeException If there's a problem
   */
  public boolean isAlertUser() throws CalFacadeException;

  /** Check for public events owner user
   *
   * @return boolean    true for public events owner user
   * @exception CalFacadeException If there's a problem
   */
  public boolean isOwnerUser() throws CalFacadeException;

  /** Check for content admin user
   *
   * @return boolean    true for content admin user
   * @exception CalFacadeException If there's a problem
   */
  public boolean isContentAdminUser() throws CalFacadeException;

  /** ===================================================================
   *  The following should not change the state of the current users
   *  access which is set and retrieved with the above methods.
   *  =================================================================== */

  /** Show whether user entries can be displayed or modified with this
   * class. Some sites may use other mechanisms.
   *
   * <p>This may need supplementing with changes to the jsp. For example,
   * it's hard to deal programmatically with the case of directory/roles
   * based authorisation and db based user information.
   *
   * @return boolean    true if user maintenance is implemented.
   */
  public boolean getUserMaintOK();

  /** Return the type of the user.
   *
   * @param  userid     String user id
   * @return int        user type as defined above,
   * @exception CalFacadeException If there's a problem
   */
  public int getUsertype(String userid) throws CalFacadeException;

  /** Set the type of the user.
   *
   * @param  userid     String user id
   * @param  utype      int user type as defined above,
   * @exception CalFacadeException If there's a problem
   */
  public void setUsertype(String userid, int utype)
          throws CalFacadeException;

  /** Adjust the user type to enure all the super user privileges are
   * set.
   *
   * @param userType    int unadjusted user type.
   * @return int   adjusted user type.
   * @exception CalFacadeException   For invalid usertype values.
   */
  public int adjustUsertype(int userType) throws CalFacadeException;

  /** Just see if the user has any special privileges.
   * Same as getUserType(userid) != noPrivileges;
   *
   * @param  userid     String user id
   * @return boolean true if the user has any special privileges
   * @exception CalFacadeException If there's a problem
   */
  public boolean isAuthorised(String userid) throws CalFacadeException;

  /** Check for priv user
   * Same as getUserType(userid) == superUser;
   *
   * @param  userid     String user id
   * @return boolean    true for super user
   * @exception CalFacadeException If there's a problem
   */
  public boolean isSuperUser(String userid) throws CalFacadeException;

  /** Remove any special authorisation for this user
   *
   * @param  val      AuthUserVO users entry
   * @throws CalFacadeException
   */
  public void removeAuth(BwAuthUser val) throws CalFacadeException;

  /** Update the user entry
   *
   * @param  val      AuthUserVO users entry
   * @throws CalFacadeException
   */
  public void updateUser(BwAuthUser val) throws CalFacadeException;

  /** Return the given authorised user. Will always return an entry (except for
   * exceptional conditions.) An unauthorised user will have a usertype of
   * noPrivileges.
   *
   * @param  userid        String user id
   * @return AuthUserVO    users entry
   * @throws CalFacadeException
   */
  public BwAuthUser getUser(String userid) throws CalFacadeException;

  /** Return the given authorised user. Will always return an entry (except for
   * exceptional conditions.) An unauthorized user will have a usertype of
   * noPrivileges.
   *
   * @param  u             BwUser entry
   * @return AuthUserVO    users entry
   * @throws CalFacadeException
   */
  public BwAuthUser getUser(BwUser u) throws CalFacadeException;

  /** Return a collection of all authorised users
   *
   * @return Collection      of BwAuthUser for users with any special authorisation.
   * @throws CalFacadeException
   */
  public Collection<BwAuthUser> getAll() throws CalFacadeException;

  /* ====================================================================
   *                       Preferences methods
   * ==================================================================== */

  /** Update the prefs after a change.
   *
   * @param user
   * @throws CalFacadeException
   */
  public void updatePrefs(BwAuthUser user) throws CalFacadeException;
}
