/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade.util;

import org.bedework.calfacade.configs.DirConfigProperties;
import org.bedework.calfacade.DirectoryInfo;
import org.bedework.calfacade.env.CalOptionsFactory;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.ifs.Directories;
import org.bedework.calfacade.svc.HostInfo;

import edu.rpi.cmt.access.Ace;
import edu.rpi.cmt.access.PrincipalInfo;

import org.apache.log4j.Logger;

import java.io.Serializable;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.TreeSet;

/** A base implementation of Directories which handles some generic directory
 * methods.
 *
 * <p>One of those is to map an apparently flat identifier space onto a
 * principal hierarchy more appropriate to the needs of webdav. For example we
 * might have a user account "jim" or a ticket "TKT12345". These could be mapped
 * on to "/principals/users/jim" and "/principals/tickets/12345".
 *
 * @author Mike Douglass douglm@rpi.edu
 * @version 1.0
 */
public abstract class AbstractDirImpl implements Directories {
  private DirConfigProperties props;

  /** */
  private static class DomainMatcher implements Serializable {
    /* Only simple wildcard matching *, * + chars or chars */
    String pattern;

    boolean exact;

    DomainMatcher(String pattern) {
      this.pattern = pattern;

      if (!pattern.startsWith("*")) {
        this.pattern = pattern;
        exact = true;
      } else {
        this.pattern = pattern.substring(1);
      }
    }

    boolean matches(String val, int atPos) {
      if (atPos < 0) {
        return false;
      }

      int start = atPos + 1;
      int domainLen = val.length() - start;

      if (exact) {
        if (domainLen != pattern.length()) {
          return false;
        }
      } else if (domainLen < pattern.length()) {
        return false;
      }

      return val.endsWith(pattern);
    }
  }

  private DomainMatcher onlyDomain;
  private boolean anyDomain;
  private String defaultDomain;
  private Collection<DomainMatcher> domains;

  protected CallBack cb;

  private transient Logger log;

  private HashMap<String, Integer> toWho = new HashMap<String, Integer>();
  private HashMap<Integer, String> fromWho = new HashMap<Integer, String>();

  private HashMap<String, String> validUsers = new HashMap<String, String>();
  private long lastFlush;
  private static long flushTime = 60 * 1000;  // 1 minute

  /** Return the appropriate HostInfo record for the given domain.
   *
   * @param domain
   * @return HostInfo entry
   * @throws CalFacadeException
   */
  public abstract HostInfo findHostInfo(String domain) throws CalFacadeException;

  /* (non-Javadoc)
   * @see org.bedework.calfacade.ifs.Directories#init(org.bedework.calfacade.ifs.Directories.CallBack)
   */
  public void init(CallBack cb) throws CalFacadeException {
    this.cb = cb;

    initWhoMaps(getProps().getUserPrincipalRoot(), Ace.whoTypeUser);
    initWhoMaps(getProps().getGroupPrincipalRoot(), Ace.whoTypeGroup);
    initWhoMaps(getProps().getTicketPrincipalRoot(), Ace.whoTypeTicket);
    initWhoMaps(getProps().getResourcePrincipalRoot(), Ace.whoTypeResource);
    initWhoMaps(getProps().getVenuePrincipalRoot(), Ace.whoTypeVenue);
    initWhoMaps(getProps().getHostPrincipalRoot(), Ace.whoTypeHost);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.ifs.Directories#getDirectoryInfo()
   */
  public DirectoryInfo getDirectoryInfo() throws CalFacadeException {
    DirectoryInfo info = new DirectoryInfo();
    DirConfigProperties props = getProps();

    info.setPrincipalRoot(props.getPrincipalRoot());
    info.setUserPrincipalRoot(props.getUserPrincipalRoot());
    info.setGroupPrincipalRoot(props.getGroupPrincipalRoot());
    info.setTicketPrincipalRoot(props.getTicketPrincipalRoot());
    info.setResourcePrincipalRoot(props.getResourcePrincipalRoot());
    info.setVenuePrincipalRoot(props.getVenuePrincipalRoot());
    info.setHostPrincipalRoot(props.getHostPrincipalRoot());

    return info;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.ifs.Directories#validUser(java.lang.String)
   */
  public synchronized boolean validUser(String account) throws CalFacadeException {
    // XXX Not sure how we might use this for admin users.
    if (account == null) {
      return false;
    }

    /* Use a map to avoid the lookup if possible.
     * This does mean that we retain traces of a user who gets deleted until
     * we flush.
     */

    if (lookupUser(account)) {
      return true;
    }

    boolean valid = !account.startsWith("invalid");  // allow some testing

    if (valid) {
      addValidUser(account);
    }

    return valid;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.ifs.Directories#isPrincipal(java.lang.String)
   */
  public boolean isPrincipal(String val) throws CalFacadeException {
    if (val == null) {
      return false;
    }

    return val.startsWith(getProps().getPrincipalRoot() + "/");
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.ifs.Directories#getPrincipalInfo(java.lang.String)
   */
  public PrincipalInfo getPrincipalInfo(String href) throws CalFacadeException {
    PrincipalInfo pi = new PrincipalInfo();

    try {
      String uri = new URI(href).getPath();

      if (!isPrincipal(uri)) {
        return null;
      }

      int start = -1;

      int end = uri.length();
      if (uri.endsWith("/")) {
        end--;
      }

      for (String prefix: toWho.keySet()) {
        if (!uri.startsWith(prefix)) {
          continue;
        }

        pi.prefix = prefix;
        pi.whoType = toWho.get(prefix);
        start = prefix.length();

        if (start == end) {
          // Trying to browse user principals?
          pi.who = null;
        } else if (uri.charAt(start) != '/') {
          throw new CalFacadeException(CalFacadeException.principalNotFound);
        } else if (pi.whoType == Ace.whoTypeUser) {
          /* Strip off the principal prefix for real users.
           */
          pi.who = uri.substring(start + 1, end);
        } else {
          pi.who = uri;
        }

        // XXX do this corrcetly - e.g. see if in directory
        pi.valid = true;

        return pi;
      }

      throw new CalFacadeException(CalFacadeException.principalNotFound);
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  public HostInfo getHostInfo(String val) throws CalFacadeException {
    /* We may have a url with host + poort + path etc or an email like address
     *
     * This is all pretty primitive at the moment and implemented for a demo.
     */
    try {
      URI uri = new URI(val);

      String scheme = uri.getScheme();
      String domain = null;

      if ((scheme == null) || ("mailto".equals(scheme.toLowerCase()))) {
        if (val.indexOf("@") > 0) {
          domain = val.substring(val.indexOf("@") + 1);
        }
      } else {
        domain = uri.getHost();
      }

      if (domain == null) {
        throw new CalFacadeException(CalFacadeException.badCalendarUserAddr);
      }

      return findHostInfo(domain);
    } catch (URISyntaxException use) {
      throw new CalFacadeException(CalFacadeException.badCalendarUserAddr);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.ifs.Directories#makePrincipalUri(java.lang.String, boolean)
   */
  public String makePrincipalUri(String id,
                                 int whoType) throws CalFacadeException {
    if (isPrincipal(id)) {
      return id;
    }

    String root = fromWho.get(whoType);

    if (root == null) {
      throw new CalFacadeException(CalFacadeException.unknownPrincipalType);
    }

    return root + "/" + id;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.ifs.Directories#getPrincipalRoot()
   */
  public String getPrincipalRoot() throws CalFacadeException {
    return getProps().getPrincipalRoot();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.ifs.Directories#getGroups(java.lang.String, java.lang.String)
   */
  public Collection<String>getGroups(String rootUrl,
                                     String principalUrl) throws CalFacadeException {
    Collection<String> urls = new TreeSet<String>();

    if (principalUrl == null) {
      /* for the moment if the root url is the user principal hierarchy root
       * just return the current user principal
       */
      if (rootUrl.endsWith("/")) {
        rootUrl = rootUrl.substring(0, rootUrl.length() - 1);
      }

      /* ResourceUri should be the principals root or user principal root */
      if (!rootUrl.equals(getProps().getPrincipalRoot()) &&
          !rootUrl.equals(getProps().getUserPrincipalRoot())) {
        return urls;
      }

      urls.add(getProps().getUserPrincipalRoot() + "/" +
               cb.getCurrentUser().getAccount());
    } else {
      // XXX incomplete
    }

    return urls;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.ifs.Directories#uriToCaladdr(java.lang.String)
   */
  public String uriToCaladdr(String uri) throws CalFacadeException {
    if (isPrincipal(uri)) {
      // Leave as is
      return uri;
    }

    boolean isAccount = true;

    /* check for something that looks like mailto:somebody@somewhere.com,
       scheduleto:, etc.  If exists, is not an internal Bedework account. */
    int colonPos = uri.indexOf(":");
    int atPos = uri.indexOf("@");

    if (colonPos > 0) {
      if (atPos < colonPos) {
        return null;
      }

      isAccount = false;
    } else if (atPos > 0) {
      uri = "mailto:" + uri;
    }

    String possibleAccount = caladdrToUser(uri);
    if ((possibleAccount != null) &&       // Possible bedework user
        (!validUser(possibleAccount))) {   // but not valid
      return null;
    }

    if (isAccount) {
      uri = userToCaladdr(uri);
    }

    return uri;

  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.ifs.Directories#userToCaladdr(java.lang.String)
   */
  public String userToCaladdr(String val) throws CalFacadeException {
    if (isPrincipal(val)) {
      return val;
    }

    try {
      int atPos = val.indexOf("@");

      boolean hasMailto = val.toLowerCase().startsWith("mailto:");

      if (atPos > 0) {
        if (hasMailto) {
          return val;
        }
        return "mailto:" + val;
      }

      if (defaultDomain == null) {
        throw new CalFacadeException(CalFacadeException.noDefaultDomain);
      }

      StringBuilder sb = new StringBuilder();
      if (!hasMailto) {
        sb.append("mailto:");
      }

      sb.append(val);
      sb.append("@");
      sb.append(defaultDomain);

      return sb.toString();
    } catch (CalFacadeException cfe) {
      throw cfe;
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#caladdrToUser(java.lang.String)
   */
  public String caladdrToUser(String caladdr) throws CalFacadeException {
    try {
      if (caladdr == null) {
        throw new CalFacadeException(CalFacadeException.nullCalendarUserAddr);
      }

      if (isPrincipal(caladdr)) {
        PrincipalInfo pi = getPrincipalInfo(caladdr);

        /*String userRoot = getProps().getUserPrincipalRoot() + "/";

        if (caladdr.startsWith(userRoot)) {
          String u = caladdr.substring(userRoot.length());
          if (u.endsWith("/")) {
            return u.substring(0, u.length() - 1);
          }

          return u;
        } */
        return pi.who;
      }

      String acc = null;
      int atPos = caladdr.indexOf("@");

      if (onlyDomain != null) {
        if (atPos < 0) {
          acc = caladdr;
        }

        if (onlyDomain.matches(caladdr, atPos)) {
          acc = caladdr.substring(0, atPos);
        }
      } else if (atPos < 0) {
        // Assume default domain?
        acc = caladdr;
      } else if (anyDomain) {
        acc = caladdr;
      } else {
        for (DomainMatcher dm: domains) {
          if (dm.matches(caladdr, atPos)) {
            acc = caladdr;
            break;
          }
        }
      }

      if (acc == null) {
        // Not ours
        return null;
      }

      if (acc.toLowerCase().startsWith("mailto:")) {
        acc = acc.substring("mailto:".length());
      }

      //XXX -at this point we should

      return acc;
    } catch (CalFacadeException cfe) {
      throw cfe;
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#fixCalAddr(java.lang.String)
   */
  public String fixCalAddr(String val) throws CalFacadeException {
    if (val == null) {
      throw new CalFacadeException(CalFacadeException.badCalendarUserAddr);
    }

    if (val.startsWith("/")) {
      return val;
    }

    int colonPos = val.indexOf(":");
    int atPos = val.indexOf("@");

    if (colonPos > 0) {
      if (atPos < colonPos) {
        throw new CalFacadeException(CalFacadeException.badCalendarUserAddr);
      }

      return val;
    } else if (atPos > 0) {
      return "mailto:" + val;
    } else {
      // No colon - no at - maybe just userid
      if (defaultDomain == null) {
        throw new CalFacadeException(CalFacadeException.badCalendarUserAddr);
      }
      return "mailto:" + val + "@" + defaultDomain;
    }
  }

  /* ====================================================================
   *  Protected methods.
   * ==================================================================== */

  /** Return the name of the configuration properties for the module,
   * e.g "module.user-ldap-group" or "module.dir-config"
   * @return String
   */
  protected abstract String getConfigName();

  protected synchronized boolean lookupUser(String account) {
    if ((lastFlush != 0) &&
        (System.currentTimeMillis() - lastFlush > flushTime)) {
      validUsers.clear();
    }

    return validUsers.containsKey(account);
  }

  protected void addValidUser(String account) {
    validUsers.put(account, account);
  }

  protected DirConfigProperties getProps() throws CalFacadeException {
    if (props != null) {
      return props;
    }

    try {
      props = (DirConfigProperties)CalOptionsFactory.getOptions(null, false).getGlobalProperty(getConfigName());

      String prDomains = props.getDomains();

      /* Convert domains list to a Collection */
      if (prDomains.equals("*")) {
        anyDomain = true;
      } else if ((prDomains.indexOf(",") < 0) &&
                 (!prDomains.startsWith("*"))) {
        onlyDomain = new DomainMatcher(prDomains);
      } else {
        domains = new ArrayList<DomainMatcher>();

        for (String domain: props.getDomains().split(",")) {
          domains.add(new DomainMatcher(domain));
        }
      }

      defaultDomain = props.getDefaultDomain();
      if ((defaultDomain == null) && (onlyDomain != null)) {
        defaultDomain = prDomains;
      }
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }

    return props;
  }

  /* Get a logger for messages
   */
  protected Logger getLogger() {
    if (log == null) {
      log = Logger.getLogger(this.getClass());
    }

    return log;
  }

  protected void error(Throwable t) {
    getLogger().error(this, t);
  }

  protected void trace(String msg) {
    getLogger().debug(msg);
  }

  /* ====================================================================
   *  Private methods.
   * ==================================================================== */

  private void initWhoMaps(String prefix, int whoType) {
    toWho.put(prefix, whoType);
    fromWho.put(whoType, prefix);
  }
}

