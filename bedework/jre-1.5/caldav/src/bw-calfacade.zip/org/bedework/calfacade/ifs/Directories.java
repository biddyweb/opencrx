/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade.ifs;

import org.bedework.calfacade.BwGroup;
import org.bedework.calfacade.BwPrincipal;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.BwUserInfo;
import org.bedework.calfacade.DirectoryInfo;
import org.bedework.calfacade.exc.CalFacadeException;

import edu.rpi.cmt.access.PrincipalInfo;

import java.io.Serializable;
import java.util.Collection;

/** An interface to handle directory information and groups.
 *
 * <p>Groups may be stored in a site specific manner so the actual
 * implementation used is a build-time configuration option. They may be
 * ldap directory based or implemented by storing in the calendar database.
 *
 * <p>Methods may throw an unimplemented exception if functions are not
 * available.
 *
 * @author Mike Douglass douglm@rpi.edu
 * @version 3.3.2
 */
public interface Directories extends Serializable {

  /** Class to be implemented by caller and passed during init.
   */
  public static abstract class CallBack implements Serializable {
    /** Get a name uniquely.identifying this system. This should take the form <br/>
     *   name@host
     * <br/>where<ul>
     * <li>name identifies the particular calendar system at the site</li>
     * <li>host part identifies the domain of the site.</li>..
     * </ul>
     *
     * @return String    globally unique system identifier.
     * @throws CalFacadeException
     */
    public abstract String getSysid() throws CalFacadeException;

    /**
     * @param account
     * @return BwUser represented by account
     * @throws CalFacadeException
     */
    public abstract BwUser getUser(String account) throws CalFacadeException;

    /**
     * @return BwUser representing current user
     * @throws CalFacadeException
     */
    public abstract BwUser getCurrentUser() throws CalFacadeException;

    /** An implementation specific method allowing access to the underlying
     * persistance engine. This may return, for example, a Hibernate session,
     *
     * @return Object    db session
     * @throws CalFacadeException
     */
    public abstract Object getDbSession() throws CalFacadeException;
  }

  /** Provide the callback object
   *
   * @param cb
   * @throws CalFacadeException
   */
  public void init(CallBack cb) throws CalFacadeException;

  /** Get application visible directory information.
   *
   * @return DirectoryInfo
   * @throws CalFacadeException
   */
  public DirectoryInfo getDirectoryInfo() throws CalFacadeException;

  /** Test for a valid user account in the directory. This may have a number of
   * uses. For example, when organizing meetings we may want to send an
   * invitation to a user who has not yet logged on. This allows us to
   * distinguish between a bad account (spam maybe?) and a real account.
   *
   * @param account
   * @return true if it's a valid user
   * @throws CalFacadeException
   */
  public boolean validUser(String account) throws CalFacadeException;

  /** Does the value appear to represent a valid principal?
   *
   * @param val
   * @return true if it's a (possible) principal
   * @throws CalFacadeException
   */
  public boolean isPrincipal(String val) throws CalFacadeException;

  /** Return principal information for the given href.
   *
   * @param href
   * @return PrincipalInfo
   * @throws CalFacadeException
   */
  public PrincipalInfo getPrincipalInfo(String href) throws CalFacadeException;

  /** The urls should be principal urls. principalUrl can null for the current user.
   * The result is a collection of principal urls of which the given url is a
   * member, based upon rootUrl. For example, if rootUrl points to the base of
   * the user principal hierarchy, then the rsult should be at least the current
   * user's principal url, remembering that user principals are themselves groups
   * and the user is considered a member of their own group.
   *
   * @param rootUrl - url to base search on.
   * @param principalUrl - url of principal or null for current user
   * @return Collection of urls - always non-null
   * @throws CalFacadeException
   */
  public Collection<String>getGroups(String rootUrl,
                                     String principalUrl) throws CalFacadeException;

  /**
   * @param id
   * @param whoType - from WhoDefs
   * @return String principal uri
   * @throws CalFacadeException
   */
  public String makePrincipalUri(String id,
                                 int whoType) throws CalFacadeException;

  /** Used by caldav to return the root of the principal hierarchy
   * @return String principal root
   * @throws CalFacadeException
   */
  public String getPrincipalRoot() throws CalFacadeException;

  /** Given a uri return a calendar address.
   * This should handle actions such as turning<br/>
   *   auser
   * <br/>into the associated calendar address of <br/>
   *   mailto:auser@ahost.org
   *
   * <p>It should also deal with user@somewhere.org to
   * mailto:user@somewhere.org
   *
   * @param val        uri
   * @return caladdr for this system or null for an invalid uri
   * @throws CalFacadeException  for errors
   */
  public abstract String uriToCaladdr(String val) throws CalFacadeException;

  /** Given a user account return a calendar address.
   * For example, we might have an account<br/>
   *   auser
   * <br/>with the associated calendar address of <br/>
   *   mailto:auser@ahost.org
   *
   * @param val        account
   * @return caladdr for this system
   * @throws CalFacadeException  for errors
   */
  public abstract String userToCaladdr(String val) throws CalFacadeException;

  /** Given a calendar address return the associated calendar account.
   * For example, we might have a calendar address<br/>
   *   mailto:auser@ahost.org
   * <br/>with the associated account of <br/>
   * auser<br/>
   *
   * <p>We're also going to allow user principals as we seem to be getting them.
   *
   * <p>Whereever we need a user account use the converted value. Call
   * userToCaladdr for the inverse.
   *
   * @param caladdr      calendar address
   * @return account or null if not caladdr for this system
   * @throws CalFacadeException  for errors
   */
  public abstract String caladdrToUser(String caladdr) throws CalFacadeException;

  /** Ensure we have something that looks like a valid calendar user address.
   * Could be a mailto: or a principal
   *
   * @param val String potential calendar user address
   * @return String valid or null invalid.
   * @throws CalFacadeException
   */
  public abstract String fixCalAddr(String val) throws CalFacadeException;

  /** Return some sort of directory information for the given user
   *
   * @param account         String account name
   * @return BwUserInfo     directory information.
   * @throws CalFacadeException
   */
 public BwUserInfo getDirInfo(String account) throws CalFacadeException;

  /** Return all groups of which the given principal is a member. Never returns null.
   *
   * <p>Does not check the returned groups for membership of other groups.
   *
   * @param val            a principal
   * @return Collection    of BwGroup
   * @throws CalFacadeException
   */
  public Collection<BwGroup> getGroups(BwPrincipal val) throws CalFacadeException;

  /** Return all groups of which the given principal is a member. Never returns null.
   *
   * <p>This does check the groups for membership of other groups so the
   * returned collection gives the groups of which the principal is
   * directly or indirectly a member.
   *
   * @param val            a principal
   * @return Collection    of BwGroup
   * @throws CalFacadeException
   */
  public Collection<BwGroup> getAllGroups(BwPrincipal val) throws CalFacadeException;

  /** Show whether entries can be modified with this
   * class. Some sites may use other mechanisms.
   *
   * @return boolean    true if group maintenance is implemented.
   */
  public boolean getGroupMaintOK();

  /** Return all groups to which this user has some access. Never returns null.
   *
   * @param  populate      boolean populate with members
   * @return Collection    of BwGroup
   * @throws CalFacadeException
   */
  public Collection<BwGroup> getAll(boolean populate) throws CalFacadeException;

  /** Populate the group with a (possibly empty) Collection of members. Does not
   * populate groups which are members.
   *
   * @param  group           BwGroup group object to add
   * @throws CalFacadeException
   */
  public void getMembers(BwGroup group) throws CalFacadeException;

  /* ====================================================================
   *  The following are available if group maintenance is on.
   * ==================================================================== */

  /** Add a group
   *
   * @param  group           BwGroup group object to add
   * @exception CalFacadeException If there's a problem
   */
  public void addGroup(BwGroup group) throws CalFacadeException;

  /** Find a group given its name
   *
   * @param  name           String group name
   * @return BwGroup        group object
   * @exception CalFacadeException If there's a problem
   */
  public BwGroup findGroup(String name) throws CalFacadeException;

  /** Add a principal to a group
   *
   * @param group          a group principal
   * @param val            BwPrincipal new member
   * @exception CalFacadeException   For invalid usertype values.
   */
  public void addMember(BwGroup group, BwPrincipal val) throws CalFacadeException;

  /** Remove a member from a group
   *
   * @param group          a group principal
   * @param val            BwPrincipal new member
   * @exception CalFacadeException   For invalid usertype values.
   */
  public void removeMember(BwGroup group, BwPrincipal val) throws CalFacadeException;

  /** Delete a group
   *
   * @param  group           BwGroup group object to delete
   * @exception CalFacadeException If there's a problem
   */
  public void removeGroup(BwGroup group) throws CalFacadeException;

  /** update a group. This may have no meaning in some directories.
   *
   * @param  group           BwGroup group object to update
   * @exception CalFacadeException If there's a problem
   */
  public void updateGroup(BwGroup group) throws CalFacadeException;

  /**
   * @param group
   * @return Collection
   * @throws CalFacadeException
   */
  public Collection<BwGroup> findGroupParents(BwGroup group) throws CalFacadeException;
}
