/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade;

import org.bedework.calfacade.base.CollatableEntity;
import org.bedework.calfacade.util.CalFacadeUtil;

import java.util.Comparator;

/** Class representing rfc contact onformation. The phone and email is additional
 * for the web clients.
 *
 * @author Mike Douglass
 * @version 1.0
 */
public class BwContact extends BwEventProperty<BwContact>
        implements CollatableEntity, Comparator {
  private String uid;

  private BwString name;  // The rfc value
  private String phone;
  private String email;
  private String link;  // The rfc altrep

  /** Constructor
   *
   */
  public BwContact() {
    super();
  }

  /** Set the uid
   *
   * @param val    String uid
   */
  public void setUid(String val) {
    uid = val;
  }

  /** Get the uid
   *
   * @return String   uid
   */
  public String getUid() {
    return uid;
  }

  /** Set the name
   *
   * @param val    BwString name
   */
  public void setName(BwString val) {
    name = val;
  }

  /** Get the name
   *
   * @return BwString   name
   */
  public BwString getName() {
    return name;
  }

  /**
   * @param val
   */
  public void setPhone(String val) {
    phone = val;
  }

  /**
   * @return String phone number
   */
  public String getPhone() {
    return phone;
  }

  /**
   * @param val
   */
  public void setEmail(String val) {
    email = val;
  }

  /**
   * @return String email
   */
  public String getEmail() {
    return email;
  }

  /** Set the sponsor's URL
   *
   * @param link   String URL
   */
  public void setLink(String link) {
    this.link = link;
  }

  /**
   * @return String url
   */
  public String getLink() {
    return link;
  }

  /**
   * @return sponsor with uid filled in.
   */
  public static BwContact makeContact() {
    BwContact loc = new BwContact();

    loc.setUid(CalFacadeUtil.getUid());
    return loc;
  }

  /** Delete the contact's name - this must be called rather than setting
   * the value to null.
   *
   */
  public void deleteName() {
    this.addDeletedEntity(getName());
    setName(null);
  }

  /* ====================================================================
   *                   EventProperty methods
   * ==================================================================== */

  public BwString getFinderKeyValue() {
    return getName();
  }

  /* ====================================================================
   *                   CollatableEntity methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.CollatableEntity#getCollateValue()
   */
  public String getCollateValue() {
    return getName().getValue();
  }

  /* ====================================================================
   *                   Action methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.BwDbentity#afterDeletion()
   */
  public void afterDeletion() {
    addDeletedEntity(getName());
  }

  /* ====================================================================
   *                   Object methods
   * ==================================================================== */

  public int compare(Object o1, Object o2) {
    if (o1.equals(o2)) {
      return 0;
    }

    if (!(o1 instanceof BwContact)) {
      return -1;
    }

    if (!(o2 instanceof BwContact)) {
      return 1;
    }

    BwContact thisone = (BwContact)o1;
    BwContact thatone = (BwContact)o2;

    return CalFacadeUtil.cmpObjval(thisone.getName().getValue(),
                                   thatone.getName().getValue());
  }

  public int compareTo(BwContact that) {
    if (this == that) {
      return 0;
    }

    int res = CalFacadeUtil.cmpObjval(getOwner(), that.getOwner());

    if (res != 0) {
      return res;
    }

    return CalFacadeUtil.cmpObjval(getUid(), that.getUid());
  }

  public int hashCode() {
    int hc = 1;

    if (getName() != null) {
      hc *= getName().hashCode();
    }

    if (getOwner() != null) {
      hc *= getOwner().hashCode();
    }

    return hc;
  }

  public String toString() {
    StringBuffer sb = new StringBuffer("BwSponsor{");

    toStringSegment(sb);
    sb.append(", uid=");
    sb.append(getUid());
    sb.append(", name=");
    sb.append(getName());
    sb.append(", phone=");
    sb.append(getPhone());
    sb.append(", email=");
    sb.append(getEmail());
    sb.append(", link=");
    sb.append(getLink());
    sb.append("}");

    return sb.toString();
  }

  public Object clone() {
    BwContact sp = new BwContact();

    sp.setOwner((BwUser)getOwner().clone());
    sp.setPublick(getPublick());
    sp.setCreator((BwUser)getCreator().clone());
    sp.setUid(getUid());
    sp.setAccess(getAccess());
    sp.setName((BwString)getName().clone());
    sp.setPhone(getPhone());
    sp.setEmail(getEmail());
    sp.setLink(getLink());

    return sp;
  }
}
