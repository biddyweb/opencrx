/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade;

import org.bedework.calfacade.base.AttendeesEntity;
import org.bedework.calfacade.base.BwOwnedDbentity;
import org.bedework.calfacade.base.DescriptionEntity;
import org.bedework.calfacade.base.SummaryEntity;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.timezones.CalTimezones;
import org.bedework.calfacade.util.CalFacadeUtil;
import org.bedework.calfacade.util.DateTimeUtil;

import net.fortuna.ical4j.model.Dur;
import net.fortuna.ical4j.model.property.Duration;
import net.fortuna.ical4j.model.property.Trigger;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import java.util.TreeSet;

/** An alarm in bedework representing an rfc2445 valarm object.
 *
 *  @version 1.0
 *  @author Mike Douglass   douglm . rpi.edu
 */
public class BwAlarm extends BwOwnedDbentity<BwAlarm>
        implements AttendeesEntity, DescriptionEntity<BwString>, SummaryEntity,
                   Serializable {
  /** The event or todo this refers to.
   */
  private BwEvent event;

  /** audio */
  public final static int alarmTypeAudio = 0;

  /** display*/
  public final static int alarmTypeDisplay = 1;

  /** email */
  public final static int alarmTypeEmail = 2;

  /** procedure */
  public final static int alarmTypeProcedure = 3;

  /** Names for type of alarm */
  public final static String[] alarmTypes = {
    "AUDIO",
    "DISPLAY",
    "EMAIL",
    "PROCEDURE"};

  protected int alarmType;

  protected String trigger;
  protected boolean triggerStart;
  protected boolean triggerDateTime;
  protected String duration;
  protected int repeat;

  protected String triggerTime;
  protected String previousTrigger;
  protected int repeatCount;
  protected boolean expired;

  protected String attach;

  private Collection<BwString> summaries;

  private Collection<BwString> descriptions;

  protected Collection<BwAttendee> attendees;

  /* ------------------------- Non-db fields ---------------------------- */

  /** Calculated on a call to getTriggerDate()
   */
  protected Date triggerDate;

  /** Constructor
   *
   */
  public BwAlarm() {
  }

  /** Constructor for all fields
   *
   * @param event         BwEvent for this alarm
   * @param owner         Owner of alarm
   * @param alarmType     type of alarm
   * @param trigger       This specifies the time for the alarm in rfc format
   * @param triggerStart  true if we trigger off the start
   * @param triggerDateTime  true if trigger is a date time value
   * @param duration      External form of duration
   * @param repeat        number of repetitions
   * @param triggerTime   This specifies the time for the next alarm in UTC
   * @param previousTrigger   Used to determine if we missed an alarm
   * @param repeatCount   Repetition we are currently handling
   * @param expired       Set to true when we're done
   * @param attach        String audio file or attachment or exec
   * @param description   String description
   * @param summary       String summary (email)
   * @param attendees     Collection of attendees
   * @param timezones
   * @throws CalFacadeException
   */
  public BwAlarm(BwEvent event,
                 BwUser owner,
                 int alarmType,
                 String trigger,
                 boolean triggerStart,
                 boolean triggerDateTime,
                 String duration,
                 int repeat,
                 String triggerTime,
                 String previousTrigger,
                 int repeatCount,
                 boolean expired,
                 String attach,
                 String description,
                 String summary,
                 Collection<BwAttendee> attendees,
                 CalTimezones timezones) throws CalFacadeException {
    super(owner, false);
    setEvent(event);
    this.alarmType = alarmType;
    this.trigger = trigger;
    this.triggerStart = triggerStart;
    this.triggerDateTime = triggerDateTime;
    this.duration = duration;
    this.repeat = repeat;
    this.triggerTime = triggerTime;
    this.previousTrigger = previousTrigger;
    this.repeatCount = repeatCount;
    this.expired = expired;
    this.attach = attach;
    addDescription(null, description);
    addSummary(null, summary);
    setAttendees(attendees);

    if (timezones != null) {
      setTriggerTime(DateTimeUtil.isoDateTimeUTC(getTriggerDate(timezones)));
    }
  }

  /* ====================================================================
   *                      Bean methods
   * ==================================================================== */

  /** set the event
   *
   * @param val  BwEvent event
   */
  public void setEvent(BwEvent val) {
    event = val;
  }

  /** Get the event
   *
   * @return BwEvent     event
   */
  public BwEvent getEvent() {
    return event;
  }

  /** Set the alarmType for this event
   *
   * @param val    alarmType
   */
  public void setAlarmType(int val) {
    alarmType = val;
  }

  /** Get the alarmType
   *
   * @return int    alarmType
   */
  public int getAlarmType() {
    return alarmType;
  }

  /** Set the trigger - rfc format
   *
   * @param val    String trigger value
   */
  public void setTrigger(String val) {
    trigger = val;
  }

  /** Get the trigger in rfc format
   *
   *  @return String   trigger value
   */
  public String getTrigger() {
    return trigger;
  }

  /** Set the triggerStart flag
   *
   *  @param val    boolean true if we trigger off start
   */
  public void setTriggerStart(boolean val) {
    triggerStart = val;
  }

  /** Get the triggerStart flag
   *
   *  @return boolean    true if we trigger off start
   */
  public boolean getTriggerStart() {
    return triggerStart;
  }

  /** Set the triggerDateTime flag
   *
   *  @param val    boolean true if we trigger off DateTime
   */
  public void setTriggerDateTime(boolean val) {
    triggerDateTime = val;
  }

  /** Get the triggerDateTime flag
   *
   *  @return boolean    true if we trigger off DateTime
   */
  public boolean getTriggerDateTime() {
    return triggerDateTime;
  }

  /** Set the duration - rfc format
   *
   * @param val    String duration value
   */
  public void setDuration(String val) {
    duration = val;
  }

  /** Get the duration in rfc format
   *
   *  @return String   duration value
   */
  public String getDuration() {
    return duration;
  }

  /** Set the repetition count for this alarm, 0 means no repeat, 1 means
   * 2 alarms will be sent etc.
   *
   * @param val   repetition count
   */
  public void setRepeat(int val) {
    repeat = val;
  }

  /** Get the repetition count
   *
   * @return int    the repetition count
   */
  public int getRepeat() {
    return repeat;
  }

  /** set the trigger time value
   *
   *  @param val     UTC trigger time
   *  @throws CalFacadeException
   */
  public void setTriggerTime(String val) throws CalFacadeException {
    triggerTime = val;
  }

  /** Get the UTC trigger time value. This is the next time for the
   * alarm.
   *
   *  @return String   UTC trigger time
   *  @throws CalFacadeException
   */
  public String getTriggerTime() throws CalFacadeException {
    return triggerTime;
  }

  /** set the UTC previousTrigger time value
   *
   *  @param val     UTC lastTrigger time
   *  @throws CalFacadeException
   */
  public void setPreviousTrigger(String val) throws CalFacadeException {
    previousTrigger = val;
  }

  /** get the UTC previousTrigger time value
   *
   *  @return String    previousTrigger time
   *  @throws CalFacadeException
   */
  public String getPreviousTrigger() throws CalFacadeException {
    return previousTrigger;
  }

  /** Set the current repetition count for this alarm.
   *
   * @param val   repetition count
   */
  public void setRepeatCount(int val) {
    repeatCount = val;
  }

  /** Get the current repetition count
   *
   * @return int    the repetition count
   */
  public int getRepeatCount() {
    return repeatCount;
  }

  /** Set the expired flag
   *
   *  @param val    boolean true if the alarm has expired
   */
  public void setExpired(boolean val) {
    expired = val;
  }

  /** Get the expired flag
   *
   *  @return boolean    true if expired
   */
  public boolean getExpired() {
    return expired;
  }

  /** Set the attachment
   *
   * @param val    String attachment name
   */
  public void setAttach(String val) {
    attach = val;
  }

  /** Get the attachment
   *
   *  @return String   attachment name
   */
  public String getAttach() {
    return attach;
  }

  /**
   * @return type of entity
   */
  public int getEntityType() {
    return CalFacadeDefs.entityTypeAlarm;
  }

  /* ====================================================================
   *                   AttendeesEntity interface methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#setAttendees(java.util.Collection)
   */
  public void setAttendees(Collection<BwAttendee> val) {
    attendees = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#getAttendees()
   */
  public Collection<BwAttendee> getAttendees() {
    return attendees;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#getNumAttendees()
   */
  public int getNumAttendees() {
    Collection<BwAttendee> as = getAttendees();
    if (as == null) {
      return 0;
    }

    return as.size();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#addAttendee(org.bedework.calfacade.BwAttendee)
   */
  public void addAttendee(BwAttendee val) {
    Collection<BwAttendee> as = getAttendees();
    if (as == null) {
      as = new TreeSet<BwAttendee>();
      setAttendees(as);
    }

    if (!as.contains(val)) {
      as.add(val);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#removeAttendee(org.bedework.calfacade.BwAttendee)
   */
  public boolean removeAttendee(BwAttendee val) {
    Collection<BwAttendee> as = getAttendees();
    if (as == null) {
      return false;
    }

    return as.remove(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#copyAttendees()
   */
  public Collection<BwAttendee> copyAttendees() {
    if (getNumAttendees() == 0) {
      return null;
    }
    TreeSet<BwAttendee> ts = new TreeSet<BwAttendee>();

    for (BwAttendee att: getAttendees()) {
      ts.add(att);
    }

    return ts;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#cloneAttendees()
   */
  public Collection<BwAttendee> cloneAttendees() {
    if (getNumAttendees() == 0) {
      return null;
    }
    TreeSet<BwAttendee> ts = new TreeSet<BwAttendee>();

    for (BwAttendee att: getAttendees()) {
      ts.add((BwAttendee)att.clone());
    }

    return ts;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#setRecipients(java.util.Collection)
   */
  public void setRecipients(Collection<String> val) {
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#getRecipients()
   */
  public Collection<String> getRecipients() {
    return null;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#getNumRecipients()
   */
  public int getNumRecipients() {
    return 0;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#addRecipient(java.lang.String)
   */
  public void addRecipient(String val) {
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.AttendeesEntity#removeRecipient(java.lang.String)
   */
  public boolean removeRecipient(String val) {
    return false;
  }

  /* ====================================================================
   *               DescriptionEntity interface methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.DescriptionEntity#setDescriptions(java.util.Collection)
   */
  public void setDescriptions(Collection<BwString> val) {
    descriptions = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.DescriptionEntity#getDescriptions()
   */
  public Collection<BwString> getDescriptions() {
    return descriptions;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.DescriptionEntity#getNumDescriptions()
   */
  public int getNumDescriptions() {
    Collection<BwString> rs = getDescriptions();
    if (rs == null) {
      return 0;
    }

    return rs.size();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.DescriptionEntity#addDescription(java.lang.String, java.lang.String)
   */
  public void addDescription(String lang, String val) {
    addDescription(new BwString(lang, val));
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.DescriptionEntity#addDescription(org.bedework.calfacade.BwString)
   */
  public void addDescription(BwString val) {
    Collection<BwString> rs = getDescriptions();
    if (rs == null) {
      rs = new TreeSet<BwString>();
      setDescriptions(rs);
    }

    if (!rs.contains(val)) {
      rs.add(val);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.DescriptionEntity#removeDescription(org.bedework.calfacade.BwString)
   */
  public boolean removeDescription(BwString val) {
    Collection<BwString> rs = getDescriptions();
    if (rs == null) {
      return false;
    }

    return rs.remove(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.DescriptionEntity#updateDescriptions(java.lang.String, java.lang.String)
   */
  public void updateDescriptions(String lang, String val) {
    BwString s = findDescription(lang);
    if (val == null) {
      // Removing
      if (s!= null) {
        removeDescription(s);
      }
    } else if (s == null) {
      addDescription(lang, val);
    } else if ((CalFacadeUtil.cmpObjval(val, s.getValue()) != 0)) {
      // XXX Cannot change value in case this is an override collection.

      //s.setValue(val);
      removeDescription(s);
      addDescription(lang, val);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.DescriptionEntity#findDescription(java.lang.String)
   */
  public BwString findDescription(String lang) {
    return BwString.findLang(lang, getDescriptions());
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.DescriptionEntity#setDescription(java.lang.String)
   */
  public void setDescription(String val) {
    updateDescriptions(null, val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.DescriptionEntity#getDescription()
   */
  public String getDescription() {
    BwString s = findDescription(null);
    if (s == null) {
      return null;
    }
    return s.getValue();
  }

  /* ====================================================================
   *               SummaryEntity interface methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.SummaryEntity#setSummaries(java.util.Collection)
   */
  public void setSummaries(Collection<BwString> val) {
    summaries = val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.SummaryEntity#getSummaries()
   */
  public Collection<BwString> getSummaries() {
    return summaries;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.SummaryEntity#getNumSummaries()
   */
  public int getNumSummaries() {
    Collection<BwString> rs = getSummaries();
    if (rs == null) {
      return 0;
    }

    return rs.size();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.SummaryEntity#addSummary(java.lang.String, java.lang.String)
   */
  public void addSummary(String lang, String val) {
    addSummary(new BwString(lang, val));
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.SummaryEntity#addSummary(org.bedework.calfacade.BwString)
   */
  public void addSummary(BwString val) {
    Collection<BwString> rs = getSummaries();
    if (rs == null) {
      rs = new TreeSet<BwString>();
      setSummaries(rs);
    }

    if (!rs.contains(val)) {
      rs.add(val);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.SummaryEntity#removeSummary(org.bedework.calfacade.BwString)
   */
  public boolean removeSummary(BwString val) {
    Collection<BwString> c = getSummaries();
    if (c == null) {
      return false;
    }

    return c.remove(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.SummaryEntity#updateSummaries(java.lang.String, java.lang.String)
   */
  public void updateSummaries(String lang, String val) {
    BwString s = findSummary(lang);
    if (val == null) {
      // Removing
      if (s!= null) {
        removeSummary(s);
      }
    } else if (s == null) {
      addSummary(lang, val);
    } else if ((CalFacadeUtil.cmpObjval(val, s.getValue()) != 0)) {
      // XXX Cannot change value in case this is an override collection.

      //s.setValue(val);
      removeSummary(s);
      addSummary(lang, val);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.SummaryEntity#findSummary(java.lang.String)
   */
  public BwString findSummary(String lang) {
    return BwString.findLang(lang, getSummaries());
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.SummaryEntity#setSummary(java.lang.String)
   */
  public void setSummary(String val) {
    updateSummaries(null, val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.base.SummaryEntity#getSummary()
   */
  public String getSummary() {
    BwString s = findSummary(null);
    if (s == null) {
      return null;
    }
    return s.getValue();
  }

  /* ====================================================================
   *                      Convenience methods
   * ==================================================================== */

  /** Get the next trigger Date value. This is the next time for the
   * alarm.
   *
   * <p>This is based on the previous time which will have been set when the
   * alarm was last triggered.
   *
   * <p>Returns null for no more triggers.
   *
   * <p>Can be called repeatedly for the same result. To move to the next
   * trigger time, update repeatCount.
   *
   * @param timezones
   *  @return Date   next trigger time as a date object
   *  @throws CalFacadeException
   */
  public Date getNextTriggerDate(CalTimezones timezones) throws CalFacadeException {
    if (previousTrigger == null) {
      // First time
      return getTriggerDate(timezones);
    }

    triggerTime = null; // Force refresh

    if (repeat == 0) {
      // No next trigger
      return null;
    }

    if (repeatCount == repeat) {
      // No next trigger
      return null;
    }

    Dur dur = new Duration(null, duration).getDuration();
    return dur.getTime(getTriggerDate(timezones));
  }

  /** Get the trigger Date value. This is the earliest time for the
   * alarm.
   *
   * @param timezones
   *  @return Date   trigger time as a date object
   *  @throws CalFacadeException
   */
  public Date getTriggerDate(CalTimezones timezones) throws CalFacadeException {
    try {
      if (triggerDate != null) {
        return triggerDate;
      }

      Trigger tr = new Trigger();
      tr.setValue(getTrigger());

      /* if dt is null then it's a duration????
       */
      Date dt = tr.getDateTime();
      if (dt == null) {
        Dur dur = tr.getDuration();

        if (getEvent() == null) {
          throw new CalFacadeException("No event for alarm " + this);
        }

        dt = dur.getTime(DateTimeUtil.getDate(getEvent().getDtstart(),
                                               timezones));
      }

      triggerDate = dt;

      return dt;
    } catch (CalFacadeException cfe) {
      throw cfe;
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /** Get the next long trigger time value. This is the next time for the
   * alarm and is based on the value in previousTrigger. Set that field with the
   * previous trigger time value and save the new value in triggerTime.
   *
   * @param timezones
   *  @return long   trigger time value in millisecs
   *  @throws CalFacadeException
   */
  public long getNextTriggerTime(CalTimezones timezones) throws CalFacadeException {
    //if (triggerTime != 0) {
    //  return triggerTime;
    //}

    /*triggerTime =*/return getNextTriggerDate(timezones).getTime();

    //return triggerTime;
  }

  /* ====================================================================
   *                      Factory methods
   * ==================================================================== */

  /** Make an audio alarm
   *
   * @param event
   * @param owner
   * @param trigger
   * @param triggerStart
   * @param triggerDateTime
   * @param duration
   * @param repeat
   * @param attach
   * @param timezones
   * @throws CalFacadeException
   * @return BwEventAlarm
   */
  public static BwAlarm audioAlarm(BwEvent event,
                                        BwUser owner,
                                        String trigger,
                                        boolean triggerStart,
                                        boolean triggerDateTime,
                                        String duration,
                                        int repeat,
                                        String attach,
                                        CalTimezones timezones) throws CalFacadeException {
    return new BwAlarm(event, owner, alarmTypeAudio,
                            trigger, triggerStart, triggerDateTime,
                            duration, repeat,
                            null, null, 0, false,
                            attach,
                            null, null, null,
                            timezones);
  }

  /** Make a display alarm
   *
   * @param event
   * @param owner
   * @param trigger
   * @param triggerStart
   * @param triggerDateTime
   * @param duration
   * @param repeat
   * @param description
   * @param timezones
   * @throws CalFacadeException
   * @return BwEventAlarm
   */
  public static BwAlarm displayAlarm(BwEvent event,
                                          BwUser owner,
                                          String trigger,
                                          boolean triggerStart,
                                          boolean triggerDateTime,
                                          String duration,
                                          int repeat,
                                          String description,
                                          CalTimezones timezones) throws CalFacadeException {
    return new BwAlarm(event, owner, alarmTypeDisplay,
                            trigger, triggerStart, triggerDateTime,
                            duration, repeat,
                            null, null, 0, false,
                            null, description, null, null,
                            timezones);
  }

  /** Make an email alarm
   *
   * @param event
   * @param owner
   * @param trigger
   * @param triggerStart
   * @param triggerDateTime
   * @param duration
   * @param repeat
   * @param attach
   * @param description
   * @param summary
   * @param attendees
   * @param timezones
   * @throws CalFacadeException
   * @return BwEventAlarm
   */
  public static BwAlarm emailAlarm(BwEvent event,
                                        BwUser owner,
                                        String trigger,
                                        boolean triggerStart,
                                        boolean triggerDateTime,
                                        String duration,
                                        int repeat,
                                        String attach,
                                        String description,
                                        String summary,
                                        Collection<BwAttendee> attendees,
                                        CalTimezones timezones) throws CalFacadeException {
    return new BwAlarm(event, owner, alarmTypeEmail,
                            trigger, triggerStart, triggerDateTime,
                            duration, repeat,
                            null, null, 0, false,
                            attach,
                            description, summary, attendees,
                            timezones);
  }

  /** Make a procedure alarm
   *
   * @param event
   * @param owner
   * @param trigger
   * @param triggerStart
   * @param triggerDateTime
   * @param duration
   * @param repeat
   * @param attach
   * @param description
   * @param timezones
   * @throws CalFacadeException
   * @return BwEventAlarm
   */
  public static BwAlarm procedureAlarm(BwEvent event,
                                            BwUser owner,
                                            String trigger,
                                            boolean triggerStart,
                                            boolean triggerDateTime,
                                            String duration,
                                            int repeat,
                                            String attach,
                                            String description,
                                            CalTimezones timezones) throws CalFacadeException {
    return new BwAlarm(event, owner, alarmTypeProcedure,
                            trigger, triggerStart, triggerDateTime,
                            duration, repeat,
                            null, null, 0, false,
                            attach,
                            description, null, null,
                            timezones);
  }

  /*
----------------------------------------------------
     dur-value  = (["+"] / "-") "P" (dur-date / dur-time / dur-week)

     dur-date   = dur-day [dur-time]
     dur-time   = "T" (dur-hour / dur-minute / dur-second)
     dur-week   = 1*DIGIT "W"
     dur-hour   = 1*DIGIT "H" [dur-minute]
     dur-minute = 1*DIGIT "M" [dur-second]
     dur-second = 1*DIGIT "S"
     dur-day    = 1*DIGIT "D"


Description

    If the property permits, multiple "duration" values are
   specified by a COMMA character (US-ASCII decimal 44) separated list
   of values. The format is expressed as the [ISO 8601] basic format for
   the duration of time. The format can represent durations in terms of
   weeks, days, hours, minutes, and seconds.
   No additional content value encoding (i.e., BACKSLASH character
   encoding) are defined for this value type.


Example

    A duration of 15 days, 5 hours and 20 seconds would be:

     P15DT5H0M20S

   A duration of 7 weeks would be:

     P7W
--------------------------------------------------------*/

  protected void toStringSegment(StringBuffer sb) {
    super.toStringSegment(sb);
    if (getEvent() != null) {
      sb.append(", eventid=");
      sb.append(getEvent().getId());
    }

    sb.append(", type=");
    sb.append(alarmTypes[getAlarmType()]);

    sb.append(", trigger(");
    if (getTriggerStart()) {
      sb.append("START)=");
    } else {
      sb.append("END)=");
    }
    sb.append(getTrigger());

    if (getDuration() != null) {
      sb.append(", duration=");
      sb.append(getDuration());
      sb.append(", repeat=");
      sb.append(getRepeat());
    }

    if (getAlarmType() == alarmTypeAudio) {
      if (getAttach() != null) {
        sb.append(", attach=");
        sb.append(getAttach());
      }
    } else if (getAlarmType() == alarmTypeDisplay) {
      sb.append(", description=");
      sb.append(getDescription());
    } else if (getAlarmType() == alarmTypeEmail) {
      sb.append(", description=");
      sb.append(getDescription());
      sb.append(", summary=");
      sb.append(getSummary());
      sb.append(", attendees=[");

      if (getNumAttendees() > 0) {
        for (BwAttendee att: getAttendees()) {
          sb.append(att);
        }
      }
      sb.append("]");
      if (attach != null) {
        sb.append(", attach=");
        sb.append(getAttach());
      }
    } else if (getAlarmType() == alarmTypeProcedure) {
      sb.append(", attach=");
      sb.append(getAttach());
      if (getDescription() != null) {
        sb.append(", description=");
        sb.append(getDescription());
      }
    }
  }

  /** An alram is equal for same event, owner, action and trigger.
   *
   * <p>However, we also need to know if a particular alarm has been changed.
   *
   * @param that
   * @return boolean true if this alarm is changed with respect to that
   */
  public boolean changed(BwAlarm that)  {
    if (compareEqFields(that) != 0) {
      return true;
    }

    if (CalFacadeUtil.cmpObjval(getDuration(), that.getDuration()) != 0) {
      return true;
    }

    if (CalFacadeUtil.cmpIntval(getRepeat(), this.getRepeat()) != 0) {
      return true;
    }

    if (getAlarmType() == alarmTypeAudio) {
      if (CalFacadeUtil.cmpObjval(getAttach(), that.getAttach()) != 0) {
        return true;
      }
    } else if (getAlarmType() == alarmTypeDisplay) {
      if (CalFacadeUtil.cmpObjval(getDescription(), that.getDescription()) != 0) {
        return true;
      }
    } else if (getAlarmType() == alarmTypeEmail) {
      if (CalFacadeUtil.cmpObjval(getDescription(), that.getDescription()) != 0) {
        return true;
      }

      if (CalFacadeUtil.cmpObjval(getSummary(), that.getSummary()) != 0) {
        return true;
      }

      if (CalFacadeUtil.cmpObjval(getAttendees(), that.getAttendees()) != 0) {
        return true;
      }

      if (CalFacadeUtil.cmpObjval(getAttach(), that.getAttach()) != 0) {
        return true;
      }
    } else if (getAlarmType() == alarmTypeProcedure) {
      if (CalFacadeUtil.cmpObjval(getAttach(), that.getAttach()) != 0) {
        return true;
      }

      if (CalFacadeUtil.cmpObjval(getDescription(), that.getDescription()) != 0) {
        return true;
      }
    }

    return false;
  }

  /** Compare fields that define equality
   *
   * @param that
   * @return int
   */
  public int compareEqFields(BwAlarm that)  {
    int res = CalFacadeUtil.cmpObjval(getEvent(), that.getEvent());
    if (res != 0) {
      return res;
    }

    res = CalFacadeUtil.cmpObjval(getOwner(), that.getOwner());
    if (res != 0) {
      return res;
    }

    res = CalFacadeUtil.cmpIntval(getAlarmType(), this.getAlarmType());
    if (res != 0) {
      return res;
    }

    res = CalFacadeUtil.cmpObjval(getTrigger(), this.getTrigger());
    if (res != 0) {
      return res;
    }

    res = CalFacadeUtil.cmpBoolval(getTriggerDateTime(), this.getTriggerDateTime());
    if (res != 0) {
      return res;
    }

    return CalFacadeUtil.cmpBoolval(getTriggerStart(), that.getTriggerStart());
  }

  /* ====================================================================
   *                      Object methods
   * ==================================================================== */

  public int compareTo(BwAlarm that)  {
    if (this == that) {
      return 0;
    }

    return compareEqFields(that);
  }

  public int hashCode() {
    int hc = 31 * getAlarmType();

    if (getEvent() != null) {
      hc *= getEvent().hashCode();
    }

    if (getOwner() != null) {
      hc *= getOwner().hashCode();
    }

    hc *= getTrigger().hashCode();
    if (getTriggerStart()) {
      hc *= 2;
    }

    return hc;
  }

  /** Compare two possibly null obects
   *
   * @param o1
   * @param o2
   * @return boolean true for equal
   */
  public boolean eqObj(Object o1, Object o2) {
    if (o1 == null) {
      return o2 == null;
    }

    if (o2 == null) {
      return false;
    }

    return o1.equals(o2);
  }

  public String toString() {
    StringBuffer sb = new StringBuffer("BwAlarm{");

    toStringSegment(sb);
    sb.append("}");

    return sb.toString();
  }


  public Object clone() {
    try {
      BwAlarm a = new BwAlarm(null,  //event
                              null, // user
                              getAlarmType(),
                              getTrigger(),
                              getTriggerStart(),
                              getTriggerDateTime(),
                              getDuration(),
                              getRepeat(),
                              getTriggerTime(),
                              getPreviousTrigger(),
                              getRepeatCount(),
                              getExpired(),
                              getAttach(),
                              getDescription(),
                              getSummary(),
                              cloneAttendees(),
                              null);

      a.setTriggerTime(getTriggerTime());

      // Don't clone event , they are cloning us

      if (getOwner() != null) {
        a.setOwner((BwUser)getOwner().clone());
      }

      return a;
    } catch (Throwable t) {
      throw new RuntimeException(t);
    }
  }
}

