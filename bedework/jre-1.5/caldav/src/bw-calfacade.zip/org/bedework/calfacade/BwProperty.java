/* **********************************************************************
    Copyright 2007 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade;

import org.bedework.calfacade.base.BwDbentity;
import org.bedework.calfacade.util.CalFacadeUtil;

import edu.rpi.sss.util.Util;

import java.util.Collection;

/** An arbitrary property value in bedework. This may be used to support, for
 * example, x-properties. This will probably be subclassed to provide further
 * support.
 *
 *  @version 1.0
 */
public class BwProperty extends BwDbentity {
  private String name;

  private String value;

  /** Constructor
   */
  public BwProperty() {
    super();
  }

  /** Create a string by specifying all its fields
   *
   * @param name        String property name
   * @param value       String value
   */
  public BwProperty(String name,
                    String value) {
    super();
    this.name = name;
    this.value = value;
  }

  /** Set the name
   *
   * @param val    String name
   */
  public void setName(String val) {
    name = val;
  }

  /** Get the name
   *
   * @return String   name
   */
  public String getName() {
    return name;
  }

  /** Set the value
   *
   * @param val    String value
   */
  public void setValue(String val) {
    value = val;
  }

  /** Get the value
   *
   *  @return String   value
   */
  public String getValue() {
    return value;
  }

  /* ====================================================================
   *                        Convenience methods
   * ==================================================================== */

  /** Search the collection for a string that matches the given name.
   *
   * <p>We return the first one we found.
   *
   * @param name
   * @param c
   * @return BwProperty or null if no strings.
   */
  public static BwProperty findName(String name, Collection<BwProperty> c) {
    if (c == null) {
      return null;
    }

    if (name == null) {
      return null;
    }

    for (BwProperty p: c) {
      String pname = p.getName();

      if (CalFacadeUtil.cmpObjval(name, pname) == 0) {
        return p;
      }
    }

    return null;
  }

  /** Figure out what's different and update it. This should reduce the number
   * of spurious changes to the db.
   *
   * @param from
   * @return true if we changed something.
   */
  public boolean update(BwProperty from) {
    if (CalFacadeUtil.cmpObjval(getName(), from.getName()) != 0) {
      return false;
    }

    if (CalFacadeUtil.cmpObjval(getValue(), from.getValue()) != 0) {
      setValue(from.getValue());
      return true;
    }

    return false;
  }

  /** Check this is properly trimmed
   *
   * @return boolean true if changed
   */
  public boolean checkNulls() {
    boolean changed = false;

    String str = Util.checkNull(getName());
    if (CalFacadeUtil.compareStrings(str, getName()) != 0) {
      setName(str);
      changed = true;
    }

    str = Util.checkNull(getValue());
    if (CalFacadeUtil.compareStrings(str, getValue()) != 0) {
      setValue(str);
      changed = true;
    }

    return changed;
  }

  /* ====================================================================
   *                        Object methods
   * ==================================================================== */

  public int compareTo(Object o) {
    if (o == this) {
      return 0;
    }

    if (o == null) {
      return -1;
    }

    if (!(o instanceof BwString)) {
      return -1;
    }

    BwProperty that = (BwProperty)o;

    return CalFacadeUtil.cmpObjval(getName(), that.getName());
  }

  public int hashCode() {
    int hc = 7;

    if (getName() != null) {
      hc *= getName().hashCode();
    }

    return hc;
  }

  protected void toStringSegment(StringBuilder sb) {
    super.toStringSegment(sb);
    sb.append(", name=");
    sb.append(getName());
    sb.append(", value=");
    sb.append(getValue());
  }

  public String toString() {
    StringBuilder sb = new StringBuilder("BwProperty{");

    toStringSegment(sb);
    sb.append("}");

    return sb.toString();
  }

  public Object clone() {
    return new BwProperty(getName(), getValue());
  }
}
