/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/

package org.bedework.calfacade.timezones;

import org.apache.log4j.Logger;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.exc.CalFacadeBadDateException;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.util.CalFacadeUtil;

import net.fortuna.ical4j.model.TimeZone;
import net.fortuna.ical4j.model.component.VTimeZone;
import net.fortuna.ical4j.util.TimeZones;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.TreeSet;

/** Handle caching, retrieval and registration of timezones. There are possibly
 * two sets of timezones, public or system - shared across a system, and user owned,
 * private to the current user.
 *
 * <p>System timezones are typically initialised once per system while user
 * timezones are initialised once per session.
 *
 * <p>As there is a limited set of timezones (currenly around 350) it makes sense
 * to hold all the system timezones in memory. Thus, there will be no updates to
 * the pool of system timezones. Any updates therefore are assumed to be to the
 * set of user timezones.
 *
 * @author Mike Douglass
 *
 */
public abstract class CalTimezones implements Serializable {
  private transient Logger log;

  protected boolean debug;

  protected String defaultTimeZoneId;
  protected transient TimeZone defaultTimeZone;

  protected static class TimezoneInfo implements Serializable {
    TimeZone tz;

    boolean publick;

    boolean newDef;  // true if this is a new definition

    boolean changed; // true if the def has changed

    /**
     * @param tz
     */
    public TimezoneInfo(TimeZone tz) {
      init(tz);
    }

    /** Constructor
     *
     * @param tz
     * @param publick
     */
    public TimezoneInfo(TimeZone tz, boolean publick) {
      init(tz);
      this.publick = publick;
    }

    /** (Re)init the object
     *
     * @param tz
     */
    public void init(TimeZone tz) {
      this.tz = tz;
    }

    /** Get the timezone
     *
     * @return TimeZone
     */
    public TimeZone getTz() {
      return tz;
    }

    /**
     * @return true for public timezone
     */
    public boolean getPublick() {
      return publick;
    }

    /** Set the new flag
     *
     * @param val
     */
    public void setNewDef(boolean val) {
      newDef = val;
    }

    /**
     * @return true for new def
     */
    public boolean getNewDef() {
      return newDef;
    }

    /** Set the changed flag
     *
     * @param val
     */
    public void setChanged(boolean val) {
      changed = val;
    }

    /**
     * @return true for new def
     */
    public boolean getChanged() {
      return changed;
    }
  }

  /* subclasses can use this to trigger a read of stored timezone info. */
  protected static volatile boolean systemTimezonesInitialised = false;

  /* Map of user TimezoneInfo */
  protected HashMap<String, TimezoneInfo> timezones =
    new HashMap<String, TimezoneInfo>();

  /* subclasses can use this to trigger a read of stored timezone info. */
  protected boolean userTimezonesInitialised;

  /* flag which order we look up timezones */
  protected boolean systemHasPrecedence = true;

  /* Cache date only UTC values - we do a lot of those but the number of
   * different dates should be limited.
   *
   * We have one cache per timezone
   */
  private HashMap<String, HashMap<String, String>> dateCaches =
    new HashMap<String, HashMap<String, String>>();

  private HashMap<String, String> defaultDateCache = new HashMap<String, String>();

  private long datesCached;
  private long dateCacheHits;
  private long dateCacheMisses;

  protected CalTimezones(boolean debug) {
    this.debug = debug;
  }

  /** Save a timezone definition in the database. The timezone is in the
   * form of a complete calendar definition containing a single VTimeZone
   * object.
   *
   * <p>The calendar must be on a path from a timezone root
   *
   * @param tzid
   * @param vtz
   * @throws CalFacadeException
   */
  public abstract void saveTimeZone(String tzid, VTimeZone vtz)
          throws CalFacadeException;

  /** Register a timezone object in the current session.
  *
  * @param id
  * @param timezone
  * @throws CalFacadeException
  */
  public void registerTimeZone(String id, TimeZone timezone)
          throws CalFacadeException {
    if (debug) {
      trace("register timezone with id " + id);
    }

    /* Don't lookup - this may be called via lookup overrides */
    TimezoneInfo tzinfo = timezones.get(id);

    if (tzinfo == null) {
      tzinfo = new TimezoneInfo(timezone);
      tzinfo.newDef = true;
      timezones.put(id, tzinfo);
    } else {
      if (!tzinfo.tz.equals(timezone)) {
        // XXX Inadequate - different properties order will trigger this.
        tzinfo.changed = true;
        tzinfo.tz = timezone;
      }
    }
  }

  /* ====================================================================
   *                   Protected methods
   * ==================================================================== */

  /** Called when the lookup method finds that system timezones need to
   * be initialised.
   *
   * @throws CalFacadeException
   */
  protected abstract void initSystemTimeZones() throws CalFacadeException;

  /** Called when the lookup method finds that user timezones need to
   * be initialised.
   *
   * @throws CalFacadeException
   */
  protected abstract void initUserTimeZones() throws CalFacadeException;

  protected TimezoneInfo lookup(String id) throws CalFacadeException {
    if (!systemTimezonesInitialised) {
      initSystemTimeZones();
    }

    if (!userTimezonesInitialised) {
      initUserTimeZones();
    }

    TimezoneInfo tzinfo;

    if (systemHasPrecedence) {
      tzinfo = getSystemTimeZone(id);
    } else {
      tzinfo = timezones.get(id);
    }

    if (tzinfo == null) {
      if (systemHasPrecedence) {
        // Looked in system - try user
        tzinfo = timezones.get(id);
      } else {
        // Looked in user - try system
        tzinfo = getSystemTimeZone(id);
      }
    }

    return tzinfo;
  }

 /** Get a timezone object given the id. This will return transient objects
  * registered in the timezone directory
  *
  * @param id
  * @param tzowner  Needed in case we are looking at an event owned by another
  *                 user, in which case the timezone may be defined in that
  *                 users tz repository.
  * @return TimeZone with id or null
  * @throws CalFacadeException
  */
  public abstract TimeZone getTimeZone(final String id,
                                       BwUser tzowner) throws CalFacadeException;

  /** Get the default timezone for this system.
   *
   * @return default TimeZone or null for none set.
   * @throws CalFacadeException
   */
  public TimeZone getDefaultTimeZone() throws CalFacadeException {
    if ((defaultTimeZone == null) && (defaultTimeZoneId != null)) {
      defaultTimeZone = getTimeZone(defaultTimeZoneId, null);
    }

    return defaultTimeZone;
  }

  /** Set the default timezone id for this system.
   *
   * @param id
   * @throws CalFacadeException
   */
  public void setDefaultTimeZoneId(String id) throws CalFacadeException {
    defaultTimeZone = null;
    defaultTimeZoneId = id;
  }

  /** Get the default timezone id for this system.
   *
   * @return String id
   * @throws CalFacadeException
   */
  public String getDefaultTimeZoneId() throws CalFacadeException {
    return defaultTimeZoneId;
  }

  /** Get a system timezone info object given the id. This will be called
   * frequently so the result should probably be cached.
   *
   * @param id
   * @return TimezoneInfo or null
   * @throws CalFacadeException
   */
  public abstract TimezoneInfo getSystemTimeZone(final String id) throws CalFacadeException;

  /** Find a timezone object in the database given the id.
   *
   * @param id
   * @param owner     event owner or null for current user
   * @return VTimeZone with id or null
   * @throws CalFacadeException
   */
  public abstract VTimeZone findTimeZone(final String id, BwUser owner) throws CalFacadeException;

  /** Store the definition for a timezone object in the database given the id.
   * This will do nothing if the timezone is already stored.
   *
   * @param id
   * @param owner     event owner or null for current user
   * @throws CalFacadeException
   */
  public abstract void storeTimeZone(final String id, BwUser owner) throws CalFacadeException;

  /** Printable (language specific) name + internal id
   */
  public static class TimeZoneName implements Comparable, Serializable {
    /** Name for timezone */
    public String name;
    /** Id for timezone */
    public String id;

    /** true for public timezone */
    public boolean publick;

    /**
     * @return tz name
     */
    public String getName() {
      return name;
    }

    /**
     * @return tz id
     */
    public String getId() {
      return id;
    }

    /** true for public timezone
     * @return publick flag
     */
    public boolean getPublick() {
      return publick;
    }

    public int compareTo(Object o) {
      if (o == this) {
        return 0;
      }

      if (!(o instanceof TimeZoneName)) {
        return -1;
      }

      TimeZoneName that = (TimeZoneName)o;

      if (publick != that.publick) {
        if (publick) {
          return 1;
        }
        return -1;
      }
      return name.compareTo(that.name);
    }

    public boolean equals(Object o) {
      return compareTo(o) == 0;
    }

    public int hashCode() {
      return name.hashCode();
    }
  }

  /** Get a list of timezones for the user
   *
   * @param owner     owner or null for current user
   * @return Collection of timezone names
   * @throws CalFacadeException
   */
  public Collection<TimeZoneName> getTimeZoneNames(BwUser owner) throws CalFacadeException {
    if (!userTimezonesInitialised) {
      initUserTimeZones();
    }

    // XXX For the moment just return the tzids

    Collection<TimeZoneName> nms = new TreeSet<TimeZoneName>();
    for (String id: timezones.keySet()) {
      TimeZoneName tzn = new TimeZoneName();

      tzn.name = id;
      tzn.id = id;

      nms.add(tzn);
    }

    return nms;
  }

  /** Get a list of system timezones
   *
   * @return Collection of timezone names
   * @throws CalFacadeException
   */
 public abstract Collection<TimeZoneName> getTimeZoneNames() throws CalFacadeException;

  /** Clear all public timezone objects. Implementing classes should call this.
   *
   * <p>Will remove all public timezones in preparation for a replacement
   * (presumably)
   *
   * @throws CalFacadeException
   */
  public void clearPublicTimezones() throws CalFacadeException {
    dateCaches.clear();
    defaultDateCache.clear();
  }

  /** Refresh the public timezone table - presumably after a call to clearPublicTimezones.
   * and many calls to saveTimeZone.
   *
   * @throws CalFacadeException
   */
  public abstract void refreshTimezones() throws CalFacadeException;

//  private static DateFormat formatTd  = new SimpleDateFormat("yyyyMMdd'T'HHmmss");
  private static Calendar cal = Calendar.getInstance();
  private static java.util.TimeZone utctz;
  private static java.util.TimeZone lasttz;
  private static String lasttzid;
  static {
    try {
      utctz = TimeZone.getTimeZone(TimeZones.UTC_ID);
    } catch (Throwable t) {
      throw new RuntimeException("Unable to initialise UTC timezone");
    }
    cal.setTimeZone(utctz);
  }

  /** Given a String time value and a possibly null tzid and/or timezone
   *  will return a UTC formatted value. The supplied time should be of the
   *  form yyyyMMdd or yyyyMMddThhmmss or yyyyMMddThhmmssZ
   *
   *  <p>The last form will be returned untouched, it's already UTC.
   *
   *  <p>the first will have T000000 appended to the parameter value then the
   *  first and second will be converted to the equivalent UTC time.
   *
   *  <p>The returned value is used internally as a value for indexes and
   *  recurrence ids.
   *
   *  <p>Both tzid and tz null mean this is local or floating time
   *
   * @param time  String time to convert.
   * @param tzid  String tzid.
   * @param tz    If set used in preference to tzid.
   * @param tzowner
   * @return String always of form yyyyMMddThhmmssZ
   * @throws CalFacadeException for bad parameters or timezone
   */
  public synchronized String getUtc(String time, String tzid, TimeZone tz,
                                    BwUser tzowner)
          throws CalFacadeException {
    //if (debug) {
    //  trace("Get utc for " + time + " tzid=" + tzid + " tz =" + tz);
    //}
    if (CalFacadeUtil.isISODateTimeUTC(time)) {
      // Already UTC
      return time;
    }

    String dateKey = null;
    HashMap<String, String> cache = null;

    if ((time.length() == 8) && CalFacadeUtil.isISODate(time)) {
      /* See if we have it cached */

      if (tzid == null) {
        cache = defaultDateCache;
      } else if (tzid.equals(getDefaultTimeZoneId())) {
        cache = defaultDateCache;
      } else {
        cache = dateCaches.get(tzid);
        if (cache == null) {
          cache = new HashMap<String, String>();
          dateCaches.put(tzid, cache);
        }
      }

      String utc = cache.get(time);

      if (utc != null) {
        dateCacheHits++;
        return utc;
      }

      /* Not in the cache - calculate it */

      dateCacheMisses++;
      dateKey = time;
      time += "T000000";
    } else if (!CalFacadeUtil.isISODateTime(time)) {
      throw new CalFacadeBadDateException(time);
    }

    try {
      boolean tzchanged = false;

      /* If we get a null timezone and id we are being asked for the default.
       * If we get a null tz and the tzid is the default id same again.
       *
       * Otherwise we are asked for something other than the default.
       *
       * So lasttzid is either
       *    1. null - never been called
       *    2. the default tzid
       *    3. Some other tzid.
       */

      if (tz == null) {
        if (tzid == null) {
          tzid = getDefaultTimeZoneId();
        }

        if ((lasttzid == null) || (!lasttzid.equals(tzid))) {
          if (tzid.equals(getDefaultTimeZoneId())) {
            lasttz = getDefaultTimeZone();
          } else {
            lasttz = getTimeZone(tzid, tzowner);
          }

          if (lasttz == null) {
            lasttzid = null;
            throw new CalFacadeException(CalFacadeException.unknownTimezone, tzid);
          }
          tzchanged = true;
          lasttzid = tzid;
        }
      } else {
        // tz supplied
        if (tz != lasttz) {
          /* Yes, that's a !=. I'm looking for it being the same object.
           * If I were sure that equals were correct and fast I'd use
           * that.
           */
          tzchanged = true;
          tzid = tz.getID();
          lasttz = tz;
        }
      }


      if (tzchanged) {
        if (debug) {
          trace("**********tzchanged for tzid " + tzid);
        }
//XX        formatTd.setTimeZone(lasttz);
        lasttzid = tzid;
      }
      DateFormat formatTd  = new SimpleDateFormat("yyyyMMdd'T'HHmmss");
      formatTd.setTimeZone(lasttz);

      java.util.Date date = formatTd.parse(time);

      cal.clear();
      cal.setTime(date);

      //formatTd.setTimeZone(utctz);
      //trace("formatTd with utc: " + formatTd.format(date));

      StringBuffer sb = new StringBuffer();
      digit4(sb, cal.get(Calendar.YEAR));
      digit2(sb, cal.get(Calendar.MONTH) + 1); // Month starts at 0
      digit2(sb, cal.get(Calendar.DAY_OF_MONTH));
      sb.append('T');
      digit2(sb, cal.get(Calendar.HOUR_OF_DAY));
      digit2(sb, cal.get(Calendar.MINUTE));
      digit2(sb, cal.get(Calendar.SECOND));
      sb.append('Z');

      String utc = sb.toString();

      if (dateKey != null) {
        cache.put(dateKey, utc);
        datesCached++;
      }

      return utc;
    } catch (CalFacadeException cfe) {
      throw cfe;
    } catch (Throwable t) {
      t.printStackTrace();
      throw new CalFacadeBadDateException(time);
    }
  }

  /**
   * @return Number of utc values cached
   */
  public long getDatesCached() {
    return datesCached;
  }

  /**
   * @return date cache hits
   */
  public long getDateCacheHits() {
    return dateCacheHits;
  }

  /**
   * @return data cache misses.
   */
  public long getDateCacheMisses() {
    return dateCacheMisses;
  }

  /* ====================================================================
   *                   protected methods
   * ==================================================================== */

  protected void digit2(StringBuffer sb, int val) throws CalFacadeException {
    if (val > 99) {
      throw new CalFacadeBadDateException();
    }
    if (val < 10) {
      sb.append("0");
    }
    sb.append(val);
  }

  protected void digit4(StringBuffer sb, int val) throws CalFacadeException {
    if (val > 9999) {
      throw new CalFacadeBadDateException();
    }
    if (val < 10) {
      sb.append("000");
    } else if (val < 100) {
      sb.append("00");
    } else if (val < 1000) {
      sb.append("0");
    }
    sb.append(val);
  }

  /* Get a logger for messages
   */
  protected Logger getLogger() {
    if (log == null) {
      log = Logger.getLogger(this.getClass());
    }

    return log;
  }

  protected void error(Throwable t) {
    getLogger().error(this, t);
  }

  protected void warn(String msg) {
    getLogger().warn(msg);
  }

  protected void trace(String msg) {
    getLogger().debug(msg);
  }
}
