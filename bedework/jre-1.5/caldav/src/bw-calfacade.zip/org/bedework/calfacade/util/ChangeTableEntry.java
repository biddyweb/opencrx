/* **********************************************************************
    Copyright 2007 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade.util;

import org.bedework.calfacade.util.PropertyIndex.PropertyInfoIndex;

import java.util.Collection;
import java.util.HashMap;
import java.util.TreeSet;

/** Entry class used by ChangeTable
 *
 * @author Mike Douglass
 */
public class ChangeTableEntry {
  /** Immutable */
  public boolean multiValued;

  /** Immutable: Index of the property */
  public PropertyInfoIndex index;

  /** Immutable: Name of the property */
  public String name;

  /** Immutable: True if it's an event property */
  public boolean eventProperty;

  /** Immutable: True if it's a todo property */
  public boolean todoProperty;

  /** We need to hold the values and then adjust the entity collection
   * when we have them all.
   */
  public Collection values;

  /** Values added to entity property
   */
  public Collection addedValues;

  /** Values removed from entity property
   */
  public Collection removedValues;

  /** true if we saw a property value */
  public boolean present;

  /** true if we saw a change */
  public boolean changed;

  /** true if the field was deleted */
  public boolean deleted;

  /** true if the field was added */
  public boolean added;

  /* Used to supply new entries */
  private static HashMap<String, ChangeTableEntry> map =
    new HashMap<String, ChangeTableEntry>();

  static {
    initMap();
  }

  /**
   * @param multiValued
   * @param index
   * @param eventProperty
   * @param todoProperty
   */
  public ChangeTableEntry(boolean multiValued, PropertyInfoIndex index,
                          boolean eventProperty,
                          boolean todoProperty) {
    this.multiValued = multiValued;
    this.index = index;
    this.name = PropertyIndex.propertyName(index);
    this.eventProperty = eventProperty;
    this.todoProperty = todoProperty;
  }

  /**
   * @param multiValued
   * @param name
   * @param eventProperty
   * @param todoProperty
   */
  public ChangeTableEntry(boolean multiValued, String name,
                          boolean eventProperty,
                          boolean todoProperty) {
    this.multiValued = multiValued;
    this.index = PropertyInfoIndex.UNKNOWN_PROPERTY;
    this.name = name;
    this.eventProperty = eventProperty;
    this.todoProperty = todoProperty;
  }

  /**
   * @param index
   * @param eventProperty
   * @param todoProperty
   */
  public ChangeTableEntry(PropertyInfoIndex index, boolean eventProperty,
               boolean todoProperty) {
    this(false, index, eventProperty, todoProperty);
  }

  /** Factory method
   *
   * @param multiValued
   * @param index
   * @return ChangeTableEntry
   */
  public static ChangeTableEntry EventTodoEntry(boolean multiValued,
                                                PropertyInfoIndex index) {
    return new ChangeTableEntry(multiValued, index, true, true);
  }

  /** Factory method
   *
   * @param index
   * @return ChangeTableEntry
   */
  public static ChangeTableEntry EventTodoEntry(PropertyInfoIndex index) {
    return new ChangeTableEntry(index, true, true);
  }

  /** Return a new entry based on this entry.
   *
   * @return ChangeTableEntry
   */
  public ChangeTableEntry newEntry() {
    return new ChangeTableEntry(multiValued, index, eventProperty, todoProperty);
  }

  /** Return a new entry given the property name.
   *
   * @param name
   * @return ChangeTableEntry
   */
  public static ChangeTableEntry newEntry(String name) {
    ChangeTableEntry ent = map.get(name);
    if (ent == null) {
      return null;
    }
    return ent.newEntry();
  }

  /**
   * @param val
   */
  public void addValue(Object val) {
    if (!multiValued) {
      throw new RuntimeException("org.bedework.icalendar.notmultivalued");
    }

    if (values == null) {
      values = new TreeSet();
    }

    values.add(val);
  }

  /**
   * @param val
   */
  public void addValues(Collection val) {
    if (!multiValued) {
      throw new RuntimeException("org.bedework.icalendar.notmultivalued");
    }

    if (values == null) {
      values = new TreeSet();
    }

    values.addAll(val);
  }

  private static void initMap() {
    /* ---------------------------- Single valued --------------- */

    /* Event and Todo */
    put(ChangeTableEntry.EventTodoEntry(PropertyInfoIndex.CLASS));

    put(ChangeTableEntry.EventTodoEntry(PropertyInfoIndex.CREATED));

    put(ChangeTableEntry.EventTodoEntry(PropertyInfoIndex.DESCRIPTION));

    put(ChangeTableEntry.EventTodoEntry(PropertyInfoIndex.DTSTAMP));

    put(ChangeTableEntry.EventTodoEntry(PropertyInfoIndex.DTSTART));

    put(ChangeTableEntry.EventTodoEntry(PropertyInfoIndex.DURATION));

    put(ChangeTableEntry.EventTodoEntry(PropertyInfoIndex.GEO));

    put(ChangeTableEntry.EventTodoEntry(PropertyInfoIndex.LAST_MODIFIED));

    put(ChangeTableEntry.EventTodoEntry(PropertyInfoIndex.LOCATION));

    put(ChangeTableEntry.EventTodoEntry(PropertyInfoIndex.ORGANIZER));

    put(ChangeTableEntry.EventTodoEntry(PropertyInfoIndex.PRIORITY));

    put(ChangeTableEntry.EventTodoEntry(PropertyInfoIndex.RECURRENCE_ID));

    put(ChangeTableEntry.EventTodoEntry(PropertyInfoIndex.SEQUENCE));

    put(ChangeTableEntry.EventTodoEntry(PropertyInfoIndex.STATUS));

    put(ChangeTableEntry.EventTodoEntry(PropertyInfoIndex.SUMMARY));

    put(ChangeTableEntry.EventTodoEntry(PropertyInfoIndex.UID));

    put(ChangeTableEntry.EventTodoEntry(PropertyInfoIndex.URL));

    /* Event only */

    put(new ChangeTableEntry(PropertyInfoIndex.DTEND, true, false));

    put(new ChangeTableEntry(PropertyInfoIndex.TRANSP, true, false));

    /* Todo only */

    put(new ChangeTableEntry(PropertyInfoIndex.COMPLETED, false, true));

    put(new ChangeTableEntry(PropertyInfoIndex.DUE, false, true));

    put(new ChangeTableEntry(PropertyInfoIndex.PERCENT_COMPLETE, false, true));

    /* ---------------------------- Multi valued --------------- */

    put(ChangeTableEntry.EventTodoEntry(true, PropertyInfoIndex.XPROP));

    /* Event and Todo */

    put(ChangeTableEntry.EventTodoEntry(true, PropertyInfoIndex.ATTACH));

    put(ChangeTableEntry.EventTodoEntry(true, PropertyInfoIndex.ATTENDEE));

    put(ChangeTableEntry.EventTodoEntry(true, PropertyInfoIndex.CATEGORIES));

    put(ChangeTableEntry.EventTodoEntry(true, PropertyInfoIndex.COMMENT));

    put(ChangeTableEntry.EventTodoEntry(true, PropertyInfoIndex.CONTACT));

    put(ChangeTableEntry.EventTodoEntry(true, PropertyInfoIndex.REQUEST_STATUS));

    put(ChangeTableEntry.EventTodoEntry(true, PropertyInfoIndex.RELATED_TO));

    put(ChangeTableEntry.EventTodoEntry(true, PropertyInfoIndex.RESOURCES));

    put(ChangeTableEntry.EventTodoEntry(true, PropertyInfoIndex.VALARM));

    /* -------------Recurrence (also multi valued) --------------- */

    put(ChangeTableEntry.EventTodoEntry(true, PropertyInfoIndex.EXDATE));

    put(ChangeTableEntry.EventTodoEntry(true, PropertyInfoIndex.EXRULE));

    put(ChangeTableEntry.EventTodoEntry(true, PropertyInfoIndex.RDATE));

    put(ChangeTableEntry.EventTodoEntry(true, PropertyInfoIndex.RRULE));

    /* ------------------- VVenue ------------------------------ */

    put(new ChangeTableEntry(PropertyInfoIndex.COUNTRY, false, false));

    put(new ChangeTableEntry(PropertyInfoIndex.EXTENDEDADDRESS, false, false));

    put(new ChangeTableEntry(PropertyInfoIndex.LOCALITY, false, false));

    put(new ChangeTableEntry(true, PropertyInfoIndex.LOCATIONTYPES, false, false));

    put(new ChangeTableEntry(PropertyInfoIndex.NAME, false, false));

    put(new ChangeTableEntry(PropertyInfoIndex.POSTALCODE, false, false));

    put(new ChangeTableEntry(PropertyInfoIndex.REGION, false, false));

    put(new ChangeTableEntry(PropertyInfoIndex.STREETADDRESS, false, false));

    put(new ChangeTableEntry(PropertyInfoIndex.TEL, false, false));

    put(new ChangeTableEntry(true, PropertyInfoIndex.TYPEDURLS, false, false));

    /* -------------- Other non-event, non-todo ---------------- */

    put(new ChangeTableEntry(PropertyInfoIndex.FREEBUSY, false, false));

    put(new ChangeTableEntry(PropertyInfoIndex.TZID, false, false));

    put(new ChangeTableEntry(PropertyInfoIndex.TZNAME, false, false));

    put(new ChangeTableEntry(PropertyInfoIndex.TZOFFSETFROM, false, false));

    put(new ChangeTableEntry(PropertyInfoIndex.TZOFFSETTO, false, false));

    put(new ChangeTableEntry(PropertyInfoIndex.TZURL, false, false));

    put(new ChangeTableEntry(PropertyInfoIndex.ACTION, false, false));

    put(new ChangeTableEntry(PropertyInfoIndex.REPEAT, false, false));

    put(new ChangeTableEntry(PropertyInfoIndex.TRIGGER, false, false));
  }

  private static void put(ChangeTableEntry ent) {
    map.put(ent.name, ent);
  }
}
