/**
/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade.base;

import org.bedework.calfacade.BwDateTime;

import java.io.Serializable;
import java.util.Collection;

/**
 * @author Mike Douglass douglm - rpi.edu
 *
 */
public interface RecurrenceEntity extends Serializable {
  /**
   * @param val
   */
  public void setRecurring(Boolean val);

  /**
   * @return Boolean true if a recurring event - only relevant for master event.
   */
  public Boolean getRecurring();

  /** Set the recurrence id
  *
  *  @param val     recurrence id
  */
 public void setRecurrenceId(String val);

 /** Get the recurrence id
  *
  * @return the event's recurrence id
  */
 public String getRecurrenceId();

  /**
   * @param val
   */
  public void setRrules(Collection<String> val);

  /**
   * @return   Collection of String
   */
  public Collection<String> getRrules();

  /**
   * @param val
   */
  public void setExrules(Collection<String> val);

  /**
   * @return   Collection of String
   */
  public Collection<String> getExrules();

  /**
   * @param val
   */
  public void setRdates(Collection<BwDateTime> val);

  /**
   * @return   Collection of String
   */
  public Collection<BwDateTime> getRdates();

  /**
   * @param val
   */
  public void setExdates(Collection<BwDateTime> val);

  /**
   * @return    Collection of String
   */
  public Collection<BwDateTime> getExdates();

  /**
   * @param val
   */
  public void setLatestDate(String val);

  /**
   * @return    String latest date
   */
  public String getLatestDate();

  /**
   * @param val
   */
  public void setExpanded(Boolean val);

  /**
   * @return   Boolean true if expanded
   */
  public Boolean getExpanded();

  /* ====================================================================
   *                   Helper methods
   * ==================================================================== */

  /**
   * @return true if there is any recurring element.
   */
  public boolean isRecurringEntity();

  /** True if we have rrules
   *
   * @return boolean
   */
  public boolean hasRrules();

  /**
   * @param val
   */
  public void addRrule(String val);

  /** True if we have exrules
   *
   * @return boolean
   */
  public boolean hasExrules();

  /**
   * @param val
   */
  public void addExrule(String val);

  /** True if we have rdates
   *
   * @return boolean
   */
  public boolean hasRdates();

  /**
   * @param val
   */
  public void addRdate(BwDateTime val);

  /** True if we have exdates
   *
   * @return boolean
   */
  public boolean hasExdates();

  /**
   * @param val
   */
  public void addExdate(BwDateTime val);
}
