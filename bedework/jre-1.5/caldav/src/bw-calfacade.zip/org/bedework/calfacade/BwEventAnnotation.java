/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade;

/** An Event Annotation in Bedework
 *
 *  @author Mike Douglass
 *  @version 1.0
 */
public class BwEventAnnotation extends BwEvent {
  /** The event this one annotates. (which may itself be an annotation)
   */
  private BwEvent target;

  private BwEvent master;

  private Boolean override;

  /* Empty Collection flags */

  private Boolean alarmsEmpty;

  private Boolean attendeesEmpty;

  private Boolean categoriesEmpty;

  private Boolean commentsEmpty;

  private Boolean contactsEmpty;

  private Boolean descriptionsEmpty;

  private Boolean exdatesEmpty;

  private Boolean exrulesEmpty;

  private Boolean rdatesEmpty;

  private Boolean recipientsEmpty;

  private Boolean requestStatusesEmpty;

  private Boolean resourcesEmpty;

  private Boolean rrulesEmpty;

  private Boolean summariesEmpty;

  private Boolean xpropertiesEmpty;

  /** Constructor
   */
  public BwEventAnnotation() {
    super();
  }

  /* ====================================================================
   *                      Bean methods
   * ==================================================================== */

  /**
   * @param val
   */
  public void setTarget(BwEvent val) {
    target = val;
  }

  /**
   * @return BwEvent target of this reference
   */
  public BwEvent getTarget() {
    return target;
  }

  /** The ultimate master event. This is always a real event. For
   * recurring events it is the master event - for non recurring it is
   * the unannotated original event.
   *
   * <p>This allows us to do a single fetch of all related annotations
   *
   * @param val
   */
  public void setMaster(BwEvent val) {
    master = val;
  }

  /**
   * @return BwEvent master for this reference
   */
  public BwEvent getMaster() {
    return master;
  }

  /** Set the override flag. True if ths is an override for a recurring event,
   * otherwise it is an annotation to an entity or an entity instance
   *
   *  @param val    Boolean true if the event is deleted
   */
  public void setOverride(Boolean val) {
    override = val;
  }

  /** Get the override flag
   *
   *  @return Boolean    true if this is an override
   */
  public Boolean getOverride() {
    return override;
  }

  /** Set an empty Collection flag
   *
   *  @param val    Boolean true if the Collection is empty
   */
  public void setAlarmsEmpty(Boolean val) {
    alarmsEmpty = val;
  }

  /** Get empty Collection flag
   *
   *  @return Boolean    true if empty
   */
  public Boolean getAlarmsEmpty() {
    return alarmsEmpty;
  }

  /** Set an empty Collection flag
   *
   *  @param val    Boolean true if the Collection is empty
   */
  public void setAttendeesEmpty(Boolean val) {
    attendeesEmpty = val;
  }

  /** Get empty Collection flag
   *
   *  @return Boolean    true if empty
   */
  public Boolean getAttendeesEmpty() {
    return attendeesEmpty;
  }

  /** Set an empty Collection flag
   *
   *  @param val    Boolean true if the Collection is empty
   */
  public void setCategoriesEmpty(Boolean val) {
    categoriesEmpty = val;
  }

  /** Get empty Collection flag
   *
   *  @return Boolean    true if empty
   */
  public Boolean getCategoriesEmpty() {
    return categoriesEmpty;
  }

  /** Set an empty Collection flag
   *
   *  @param val    Boolean true if the Collection is empty
   */
  public void setCommentsEmpty(Boolean val) {
    commentsEmpty = val;
  }

  /** Get empty Collection flag
   *
   *  @return Boolean    true if empty
   */
  public Boolean getCommentsEmpty() {
    return commentsEmpty;
  }

  /** Set an empty Collection flag
   *
   *  @param val    Boolean true if the Collection is empty
   */
  public void setContactsEmpty(Boolean val) {
    contactsEmpty = val;
  }

  /** Get empty Collection flag
   *
   *  @return Boolean    true if empty
   */
  public Boolean getContactsEmpty() {
    return contactsEmpty;
  }

  /** Set an empty Collection flag
   *
   *  @param val    Boolean true if the Collection is empty
   */
  public void setDescriptionsEmpty(Boolean val) {
    descriptionsEmpty = val;
  }

  /** Get empty Collection flag
   *
   *  @return Boolean    true if empty
   */
  public Boolean getDescriptionsEmpty() {
    return descriptionsEmpty;
  }

  /** Set an empty Collection flag
   *
   *  @param val    Boolean true if the Collection is empty
   */
  public void setExdatesEmpty(Boolean val) {
    exdatesEmpty = val;
  }

  /** Get empty Collection flag
   *
   *  @return Boolean    true if empty
   */
  public Boolean getExdatesEmpty() {
    return exdatesEmpty;
  }

  /** Set an empty Collection flag
   *
   *  @param val    Boolean true if the Collection is empty
   */
  public void setExrulesEmpty(Boolean val) {
    exrulesEmpty = val;
  }

  /** Get empty Collection flag
   *
   *  @return Boolean    true if empty
   */
  public Boolean getExrulesEmpty() {
    return exrulesEmpty;
  }

  /** Set an empty Collection flag
   *
   *  @param val    Boolean true if the Collection is empty
   */
  public void setRdatesEmpty(Boolean val) {
    rdatesEmpty = val;
  }

  /** Get empty Collection flag
   *
   *  @return Boolean    true if empty
   */
  public Boolean getRdatesEmpty() {
    return rdatesEmpty;
  }

  /** Set an empty Collection flag
   *
   *  @param val    Boolean true if the Collection is empty
   */
  public void setRecipientsEmpty(Boolean val) {
    recipientsEmpty = val;
  }

  /** Get empty Collection flag
   *
   *  @return Boolean    true if empty
   */
  public Boolean getRecipientsEmpty() {
    return recipientsEmpty;
  }

  /** Set an empty Collection flag
   *
   *  @param val    Boolean true if the Collection is empty
   */
  public void setRequestStatusesEmpty(Boolean val) {
    requestStatusesEmpty = val;
  }

  /** Get empty Collection flag
   *
   *  @return Boolean    true if empty
   */
  public Boolean getRequestStatusesEmpty() {
    return requestStatusesEmpty;
  }

  /** Set an empty Collection flag
   *
   *  @param val    Boolean true if the Collection is empty
   */
  public void setResourcesEmpty(Boolean val) {
    resourcesEmpty = val;
  }

  /** Get empty Collection flag
   *
   *  @return Boolean    true if empty
   */
  public Boolean getResourcesEmpty() {
    return resourcesEmpty;
  }

  /** Set an empty Collection flag
   *
   *  @param val    Boolean true if the Collection is empty
   */
  public void setRrulesEmpty(Boolean val) {
    rrulesEmpty = val;
  }

  /** Get empty Collection flag
   *
   *  @return Boolean    true if empty
   */
  public Boolean getRrulesEmpty() {
    return rrulesEmpty;
  }

  /** Set an empty Collection flag
   *
   *  @param val    Boolean true if the Collection is empty
   */
  public void setSummariesEmpty(Boolean val) {
    summariesEmpty = val;
  }

  /** Get empty Collection flag
   *
   *  @return Boolean    true if empty
   */
  public Boolean getSummariesEmpty() {
    return summariesEmpty;
  }

  /** Set an empty Collection flag
   *
   *  @param val    Boolean true if the Collection is empty
   */
  public void setXpropertiesEmpty(Boolean val) {
    xpropertiesEmpty = val;
  }

  /** Get empty Collection flag
   *
   *  @return Boolean    true if empty
   */
  public Boolean getXpropertiesEmpty() {
    return xpropertiesEmpty;
  }

  /* ====================================================================
   *                   Object methods
   * ==================================================================== */

  public String toString() {
    StringBuffer sb = new StringBuffer("BwEventAnnotation{");

    toStringSegment(sb);
    sb.append(", target=");
    sb.append(getTarget().getId());
    sb.append(", master=");
    sb.append(getMaster().getId());
    sb.append(", override=");
    sb.append(getOverride());

    sb.append("}");

    return sb.toString();
  }

  public Object clone() {
    BwEventAnnotation ev = new BwEventAnnotation();

    copyTo(ev);
    ev.setTarget(getTarget());
    ev.setMaster(getMaster());

    return ev;
  }
}
