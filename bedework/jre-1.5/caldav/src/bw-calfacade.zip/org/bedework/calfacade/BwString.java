/* **********************************************************************
    Copyright 2007 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calfacade;

import org.bedework.calfacade.base.BwStringBase;

import java.util.Collection;

/** A String value in bedework. This class is for strings that are not very long
 * usually a max of 2-3k. This is mostly because db systems tend to handle long
 * strings in a different manner. (clobs, no searches etc)
 *
 * <p>Internally there is no difference, this just provides essentially a label
 * for the schema.
 *
 *  @version 1.0
 */
public class BwString extends BwStringBase {
  /** Constructor
   */
  public BwString() {
    super();
  }

  /** Create a string by specifying all its fields
   *
   * @param lang        String language code
   * @param value       String value
   */
  public BwString(String lang,
                  String value) {
    super(lang, value);
  }

  /** Search the collection for a string that matches the given language code.
   *<p>A supplied lang of null implies the default language code.
   *
   * <p>If the supplied language equals any language in the collection we return
   * with that.
   *
   * <p>Otherwise if if matches the first part of a qualified code we take that,
   * e.g lan="en" could match "en_US"
   *
   * <p>Otherwise we return the first one we found.
   *
   * @param lang
   * @param c
   * @return BwString or null if no strings.
   */
  public static BwString findLang(String lang, Collection<BwString> c) {
    return (BwString)BwStringBase.findLang(lang, c);
  }

  public String toString() {
    StringBuilder sb = new StringBuilder("BwString{");

    toStringSegment(sb);

    return sb.toString();
  }

  public Object clone() {
    return new BwString(getLang(),
                        getValue());
  }
}
