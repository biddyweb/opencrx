/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calcorei;

import org.bedework.calfacade.base.BwDbentity;
import org.bedework.calfacade.exc.CalFacadeException;

import org.hibernate.Criteria;
import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import java.io.Serializable;
import java.sql.Connection;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

/** Interface to do hibernate interactions.
 *
 * @author Mike Douglass douglm at rpi.edu
 */
public interface HibSession extends Serializable {
  /** Set up for a hibernate interaction. Throw the object away on exception.
   *
   * @param sessFactory
   * @param log
   * @throws CalFacadeException
   */
  public void init(SessionFactory sessFactory,
                   Logger log) throws CalFacadeException;

  /**
   * @return Session
   * @throws CalFacadeException
   */
  public Session getSession() throws CalFacadeException;

  /**
   * @return boolean true if open
   * @throws CalFacadeException
   */
  public boolean isOpen() throws CalFacadeException;

  /** Clear a session
   *
   * @throws CalFacadeException
   */
  public void clear() throws CalFacadeException;

  /* * Reconnect a session
   *
   * @throws CalFacadeException
   * /
  public void reconnect() throws CalFacadeException;*/

  /** Disconnect a session
   *
   * @throws CalFacadeException
   */
  public void disconnect() throws CalFacadeException;

  /** Get the connection
   *
   * @return Connection
   * @throws CalFacadeException
   */
  public Connection connection() throws CalFacadeException;

  /** set the flushmode
   *
   * @param val
   * @throws CalFacadeException
   */
  public void setFlushMode(FlushMode val) throws CalFacadeException;

  /** Begin a transaction
   *
   * @throws CalFacadeException
   */
  public void beginTransaction() throws CalFacadeException;

  /** Return true if we have a transaction started
   *
   * @return boolean
   */
  public boolean transactionStarted();

  /** Commit a transaction
   *
   * @throws CalFacadeException
   */
  public void commit() throws CalFacadeException;

  /** Rollback a transaction
   *
   * @throws CalFacadeException
   */
  public void rollback() throws CalFacadeException;

  /** Did we rollback the transaction?
   *
   * @return boolean
   * @throws CalFacadeException
   */
  public boolean rolledback() throws CalFacadeException;

  /** Create a Criteria ready for the additon of Criterion.
   *
   * @param cl           Class for criteria
   * @return Criteria    created Criteria
   * @throws CalFacadeException
   */
  public Criteria createCriteria(Class<?> cl) throws CalFacadeException;

  /** Evict an object from the session.
   *
   * @param val          Object to evict
   * @throws CalFacadeException
   */
  public void evict(Object val) throws CalFacadeException;

  /** Create a query ready for parameter replacement or execution.
   *
   * @param s             String hibernate query
   * @throws CalFacadeException
   */
  public void createQuery(String s) throws CalFacadeException;

  /**
   * @return query string
   * @throws CalFacadeException
   */
  public String getQueryString() throws CalFacadeException;

  /** Create a sql query ready for parameter replacement or execution.
   *
   * @param s             String hibernate query
   * @param returnAlias
   * @param returnClass
   * @throws CalFacadeException
   */
  public void createSQLQuery(String s, String returnAlias, Class<?> returnClass)
        throws CalFacadeException;

  /** Create a named query ready for parameter replacement or execution.
   *
   * @param name         String named query name
   * @throws CalFacadeException
   */
  public void namedQuery(String name) throws CalFacadeException;

  /** Mark the query as cacheable
   *
   * @throws CalFacadeException
   */
  public void cacheableQuery() throws CalFacadeException;

  /** Set the named parameter with the given value
   *
   * @param parName     String parameter name
   * @param parVal      String parameter value
   * @throws CalFacadeException
   */
  public void setString(String parName, String parVal) throws CalFacadeException;

  /** Set the named parameter with the given value
   *
   * @param parName     String parameter name
   * @param parVal      Date parameter value
   * @throws CalFacadeException
   */
  public void setDate(String parName, Date parVal) throws CalFacadeException;

  /** Set the named parameter with the given value
   *
   * @param parName     String parameter name
   * @param parVal      boolean parameter value
   * @throws CalFacadeException
   */
  public void setBool(String parName, boolean parVal) throws CalFacadeException;

  /** Set the named parameter with the given value
   *
   * @param parName     String parameter name
   * @param parVal      int parameter value
   * @throws CalFacadeException
   */
  public void setInt(String parName, int parVal) throws CalFacadeException;

  /** Set the named parameter with the given value
   *
   * @param parName     String parameter name
   * @param parVal      long parameter value
   * @throws CalFacadeException
   */
  public void setLong(String parName, long parVal) throws CalFacadeException;

  /** Set the named parameter with the given value
   *
   * @param parName     String parameter name
   * @param parVal      Object parameter value
   * @throws CalFacadeException
   */
  public void setEntity(String parName, Object parVal) throws CalFacadeException;

  /** Set the named parameter with the given value
   *
   * @param parName     String parameter name
   * @param parVal      Object parameter value
   * @throws CalFacadeException
   */
  public void setParameter(String parName, Object parVal) throws CalFacadeException ;

  /** Set the named parameter with the given Collection
   *
   * @param parName     String parameter name
   * @param parVal      Collection parameter value
   * @throws CalFacadeException
   */
  public void setParameterList(String parName, 
                               Collection<?> parVal) throws CalFacadeException ;

  /** Return the single object resulting from the query.
   *
   * @return Object          retrieved object or null
   * @throws CalFacadeException
   */
  public Object getUnique() throws CalFacadeException;

  /** Return a list resulting from the query.
   *
   * @return List          list from query
   * @throws CalFacadeException
   */
  public List getList() throws CalFacadeException;

  /**
   * @return int number updated
   * @throws CalFacadeException
   */
  public int executeUpdate() throws CalFacadeException;

  /** Update an object which may have been loaded in a previous hibernate
   * session
   *
   * @param obj
   * @throws CalFacadeException
   */
  public void update(Object obj) throws CalFacadeException;

  /** Merge and update an object which may have been loaded in a previous hibernate
   * session
   *
   * @param obj
   * @return Object   the persiatent object
   * @throws CalFacadeException
   */
  public Object merge(Object obj) throws CalFacadeException;

  /** Save a new object or update an object which may have been loaded in a
   * previous hibernate session
   *
   * @param obj
   * @throws CalFacadeException
   */
  public void saveOrUpdate(Object obj) throws CalFacadeException;

  /** Copy the state of the given object onto the persistent object with the
   * same identifier. If there is no persistent instance currently associated
   * with the session, it will be loaded. Return the persistent instance.
   * If the given instance is unsaved or does not exist in the database,
   * save it and return it as a newly persistent instance. Otherwise, the
   * given instance does not become associated with the session.
   *
   * @param obj
   * @return Object
   * @throws CalFacadeException
   */
  public Object saveOrUpdateCopy(Object obj) throws CalFacadeException;

  /** Return an object of the given class with the given id if it is
   * already associated with this session. This must be called for specific
   * key queries or we can get a NonUniqueObjectException later.
   *
   * @param  cl    Class of the instance
   * @param  id    A serializable key
   * @return Object
   * @throws CalFacadeException
   */
  public Object get(Class cl, Serializable id) throws CalFacadeException;

  /** Return an object of the given class with the given id if it is
   * already associated with this session. This must be called for specific
   * key queries or we can get a NonUniqueObjectException later.
   *
   * @param  cl    Class of the instance
   * @param  id    int key
   * @return Object
   * @throws CalFacadeException
   */
  public Object get(Class cl, int id) throws CalFacadeException;

  /** Save a new object.
   *
   * @param obj
   * @throws CalFacadeException
   */
  public void save(Object obj) throws CalFacadeException;

  /** Delete an object
   *
   * @param obj
   * @throws CalFacadeException
   */
  public void delete(Object obj) throws CalFacadeException;

  /** Save a new object with the given id. This should only be used for
   * restoring the db from a save.
   *
   * @param obj
   * @throws CalFacadeException
   */
  public void restore(Object obj) throws CalFacadeException;

  /**
   * @param val
   * @throws CalFacadeException
   */
  public void reAttach(BwDbentity<?> val) throws CalFacadeException;

  /**
   * @param o
   * @throws CalFacadeException
   */
  public void lockRead(Object o) throws CalFacadeException;

  /**
   * @param o
   * @throws CalFacadeException
   */
  public void lockUpdate(Object o) throws CalFacadeException;

  /**
   * @throws CalFacadeException
   */
  public void flush() throws CalFacadeException;

  /**
   * @throws CalFacadeException
   */
  public void close() throws CalFacadeException;
}
