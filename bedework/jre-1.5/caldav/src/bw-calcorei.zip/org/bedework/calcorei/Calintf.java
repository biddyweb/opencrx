/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calcorei;

import org.bedework.calfacade.BwAlarm;
import org.bedework.calfacade.BwCalendar;
import org.bedework.calfacade.BwCategory;
import org.bedework.calfacade.BwDateTime;
import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.BwFreeBusy;
import org.bedework.calfacade.BwLocation;
import org.bedework.calfacade.BwPrincipal;
import org.bedework.calfacade.BwContact;
import org.bedework.calfacade.BwStats;
import org.bedework.calfacade.BwString;
import org.bedework.calfacade.BwSystem;
import org.bedework.calfacade.BwTimeZone;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.BwStats.StatsEntry;
import org.bedework.calfacade.base.BwDbentity;
import org.bedework.calfacade.base.BwShareableDbentity;
import org.bedework.calfacade.base.UpdateFromTimeZonesInfo;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.filter.BwFilter;
import org.bedework.calfacade.ifs.Directories;
import org.bedework.calfacade.timezones.CalTimezones;

import edu.rpi.cmt.access.Ace;
import edu.rpi.cmt.access.AceWho;
import edu.rpi.cmt.access.Acl.CurrentAccess;

import java.util.Collection;
import java.util.List;

import net.fortuna.ical4j.model.component.VTimeZone;

/** This is the low level interface to the calendar database.
 *
 * <p>This interface provides a view of the data as seen by the supplied user
 * id. This may or may not be the actual authenticated user of whatever
 * application is driving it.
 *
 * <p>This is of particular use for public events administration. A given
 * authenticated user may be the member of a number of groups, and this module
 * will be initialised with the id of one of those groups. At some point
 * the authenticated user may choose to switch identities to manage a different
 * group.
 *
 * <p>The UserAuth object returned by getUserAuth usually represents the
 * authenticated user and determines the rights that user has.
 *
 * @author Mike Douglass   douglm@rpi.edu
 */
public interface Calintf extends CalendarsI, EventsI {
  /** Must be called to initialise the new object.
   *
   * @param systemName  Used to retrieve configuration about systems.
   * @param url         String url to which we are connecting
   * @param authenticatedUser    String authenticated user of the application
   *                             or null for guest
   * @param user        String user we are acting as. If null we use authUser
   * @param publicAdmin boolean true if this is a public events admin app
   * @param groups      Object allowing interface to determine user groups.
   * @param debug       boolean true to turn on debugging trace
   * @return boolean    true if the authUser was added to the db
   * @throws CalFacadeException
   */
  public boolean init(String systemName,
                      String url,
                      String authenticatedUser,
                      String user,
                      boolean publicAdmin,
                      Directories groups,
                      boolean debug) throws CalFacadeException;

  /** Retrieve systemName supplied at init
   *
   * @return String name
   */
  public String getSystemName();

  /** Can be called after init to flag the arrival of a user.
   *
   * @param val       true for a super user
   * @throws CalFacadeException
   */
  public void logon(BwUser val) throws CalFacadeException;

  /** Called after init to flag this user as a super user.
   *
   * @param val       true for a super user
   */
  public void setSuperUser(boolean val);

  /** Called after init to flag this user as a super user.
   *
   * @return boolean true if super user
   */
  public boolean getSuperUser();

  /** Get the current system (not db) stats
   *
   * @return BwStats object
   * @throws CalFacadeException if not admin
   */
  public BwStats getStats() throws CalFacadeException;

  /** Enable/disable db statistics
   *
   * @param enable       boolean true to turn on db statistics collection
   * @throws CalFacadeException if not admin
   */
  public void setDbStatsEnabled(boolean enable) throws CalFacadeException;

  /**
   *
   * @return boolean true if statistics collection enabled
   * @throws CalFacadeException if not admin
   */
  public boolean getDbStatsEnabled() throws CalFacadeException;

  /** Dump db statistics
   *
   * @throws CalFacadeException if not admin
   */
  public void dumpDbStats() throws CalFacadeException;

  /** Get db statistics
   *
   * @return Collection of BwStats.StatsEntry objects
   * @throws CalFacadeException if not admin
   */
  public Collection<StatsEntry> getDbStats() throws CalFacadeException;

  /** Get the system pars using name supplied at init
   *
   * @return BwSystem object
   * @throws CalFacadeException if not admin
   */
  public BwSystem getSyspars() throws CalFacadeException;

  /** Get the system pars given name
   *
   * @param name
   * @return BwSystem object
   * @throws CalFacadeException if not admin
   */
  public BwSystem getSyspars(String name) throws CalFacadeException;

  /** Update the system pars
   *
   * @param val BwSystem object
   * @throws CalFacadeException if not admin
   */
  public void updateSyspars(BwSystem val) throws CalFacadeException;

  /** Get the timezones cache object
   *
   * @return CalTimezones object
   * @throws CalFacadeException if not admin
   */
  public CalTimezones getTimezonesHandler() throws CalFacadeException;

  /** Get information about this interface
   *
   * @return CalintfInfo
   * @throws CalFacadeException
   */
  public CalintfInfo getInfo() throws CalFacadeException;

  /** Get the state of the debug flag
   *
   * @return boolean
   * @throws CalFacadeException
   */
  public boolean getDebug() throws CalFacadeException;

  /** Switch to the given non-null user. The access rights are determined by
   * the previous call to init.
   *
   * @param val         String user id
   * @throws CalFacadeException
   */
  public void setUser(String val) throws CalFacadeException;

  /** Flush any backend data we may be hanging on to ready for a new
   * sequence of interactions. This is intended to help with web based
   * applications, especially those which follow the action/render url
   * pattern used in portlets.
   *
   * <p>A flushAll can discard a back end session allowing open to get a
   * fresh one. close() can then be either a no-op or something like a
   * hibernate disconnect.
   *
   * <p>This method should be called before calling open (or after calling
   * close).
   *
   * @throws CalFacadeException
   */
  public void flushAll() throws CalFacadeException;

  /** Signal the start of a sequence of operations. These overlap transactions
   * in that there may be 0 to many transactions started and ended within an
   * open/close call and many open/close calls within a transaction.
   *
   * <p>The open close methods are mainly associated with web style requests
   * and open will usually be called early in the incoming request handling
   * and close will always be called on the way out allowing the interface an
   * opportunity to reacquire (on open) and release (on close) any resources
   * such as connections.
   *
   * @throws CalFacadeException
   */
  public void open() throws CalFacadeException;

  /** Call on the way out after handling a request..
   *
   * @throws CalFacadeException
   */
  public void close() throws CalFacadeException;

  /** Start a (possibly long-running) transaction. In the web environment
   * this might do nothing. The endTransaction method should in some way
   * check version numbers to detect concurrent updates and fail with an
   * exception.
   *
   * @throws CalFacadeException
   */
  public void beginTransaction() throws CalFacadeException;

  /** End a (possibly long-running) transaction. In the web environment
   * this should in some way check version numbers to detect concurrent updates
   * and fail with an exception.
   *
   * @throws CalFacadeException
   */
  public void endTransaction() throws CalFacadeException;

  /** Call if there has been an error during an update process.
   *
   * @throws CalFacadeException
   */
  public void rollbackTransaction() throws CalFacadeException;

  /** Flush qeueed operations.
   *
   * @throws CalFacadeException
   */
  public void flush() throws CalFacadeException;

  /** An implementation specific method allowing access to the underlying
   * persisitance engine. This may return, for example, a Hibernate session,
   *
   * @return Object
   * @throws CalFacadeException
   */
  public Object getDbSession() throws CalFacadeException;

  /** Call to reassociate an entity with the current database session
   *
   * @param val
   * @throws CalFacadeException
   */
  public void reAttach(BwDbentity val) throws CalFacadeException;

  /* ====================================================================
   *                   Users
   * ==================================================================== */

  /** Returns a value object representing the current user.
   *
   * @return BwUser       representing the current user
   * @throws CalFacadeException
   */
  public BwUser getUser() throws CalFacadeException;

  /** Update the current user entry
   *
   * @throws CalFacadeException
   */
  public void updateUser() throws CalFacadeException;

  /** Update the given user entry
   *
   * @param user   BwUser object to add.
   * @throws CalFacadeException
   */
  public void updateUser(BwUser user) throws CalFacadeException;

  /** Add a user to the database
   *
   * @param user   BwUser object to add.
   * @throws CalFacadeException
   */
  public void addUser(BwUser user) throws CalFacadeException;

  /** Returns a value object representing the user with the given account name.
   *
   * @param account       string account name of user entry
   * @return UserVO       representing the current user
   * @throws CalFacadeException
   */
  public BwUser getUser(String account) throws CalFacadeException;

  /** Returns a Collection of instance owners.
   *
   * @return Collection    of BwUser
   * @throws CalFacadeException
   */
  public Collection<BwUser> getInstanceOwners() throws CalFacadeException;

  /* ====================================================================
   *                   Global parameters
   * ==================================================================== */

  /** Get the value of the current public events timestamp.
   *
   * @return long       current timestamp value
   * @throws CalFacadeException
   */
  public long getPublicLastmod() throws CalFacadeException;

  /** Get a name uniquely.identifying this system. This should take the form <br/>
   *   name@host
   * <br/>where<ul>
   * <li>name identifies the particular calendar system at the site</li>
   * <li>host part identifies the domain of the site.</li>..
   * </ul>
   *
   * @return String    globally unique system identifier.
   * @throws CalFacadeException
   */
  public String getSysid() throws CalFacadeException;

  /** Get a name uniquely.identifying this instance in the domain.
   * </ul>
   *
   * @return String    globally unique system identifier.
   * @throws CalFacadeException
   */
  public String getSysname() throws CalFacadeException;

  /* ====================================================================
   *                   Access
   * ==================================================================== */

  /** Change the access to the given calendar entity.
   *
   * @param ent      BwShareableDbentity
   * @param aces     Collection of ace
   * @param replaceAll true to replace the entire access list.
   * @throws CalFacadeException
   */
  public void changeAccess(BwShareableDbentity ent,
                           Collection<Ace> aces,
                           boolean replaceAll) throws CalFacadeException;

  /** Remove any explicit access for the given who to the given calendar entity.
  *
  * @param ent      BwShareableDbentity
  * @param who      AceWho
  * @throws CalFacadeException
  */
 public abstract void defaultAccess(BwShareableDbentity ent,
                                    AceWho who) throws CalFacadeException;

  /** Check the access for the given entity. Returns the current access
   * or null or optionally throws a no access exception.
   *
   * @param ent
   * @param desiredAccess
   * @param returnResult
   * @return CurrentAccess
   * @throws CalFacadeException if returnResult false and no access
   */
  public CurrentAccess checkAccess(BwShareableDbentity ent, int desiredAccess,
                                   boolean returnResult) throws CalFacadeException;

  /* ====================================================================
   *                   Timezones
   * ==================================================================== */

  /** Save a timezone definition in the database. The timezone is in the
   * form of a VTimeZone object.
   *
   * @param tzid
   * @param vtz
   * @throws CalFacadeException
   */
  public void saveTimeZone(String tzid, VTimeZone vtz
                           ) throws CalFacadeException;

  /** Get a vtimezone object given the id and the owner of the event.
   *
   * <p>For a user will search local timezone defs first then public defs.
   *
   * <p>For public events searches only public.
   *
   * @param id
   * @param owner     expected owner of private timezone or null for current user
   * @param publick   true for a system timezone (owner not used)
   * @return VTimeZone
   * @throws CalFacadeException
   */
  public VTimeZone getTimeZone(final String id,
                               BwUser owner,
                               boolean publick) throws CalFacadeException;

  /** Get all known vtimezone objects.
   *
   * <p>For a user will replace public defs with local timezone defs with the
   * same id.
   *
   * <p>For public events return only public.
   *
   * @return Collection
   * @throws CalFacadeException
   */
  public Collection<BwTimeZone> getTimeZones() throws CalFacadeException;

  /** Get all user vtimezone objects.
   *
   * @param tzOwner
   * @return Collection
   * @throws CalFacadeException
   */
  public Collection<BwTimeZone> getUserTimeZones(BwUser tzOwner) throws CalFacadeException;

  /** Get all public vtimezone objects.
   *
   * @return Collection
   * @throws CalFacadeException
   */
  public Collection<BwTimeZone> getPublicTimeZones() throws CalFacadeException;

  /** Get all public timezone ids.
   *
   * @return Collection of String
   * @throws CalFacadeException
   */
  public Collection<String> getPublicTimeZoneIds() throws CalFacadeException;

  /** Clear all public timezone collection objects
   *
   * <p>Will remove all public timezones in preparation for a replacement
   * (presumably)
   *
   * @throws CalFacadeException
   */
  public void clearPublicTimezones() throws CalFacadeException;

  /** Get all of the timezone ids.
   *
   * @return List  of TimeZoneInfo
   * @throws CalFacadeException
   */
  public List getTimeZoneIds() throws CalFacadeException;

  /** Update the system after changes to timezones. This is a lengthy process
   * so the method allows the caller to specify how many updates are to take place
   * before returning.
   *
   * <p>To restart the update, call the method again, giving it the result from
   * the last call as a parameter.
   *
   * <p>If called again after all events have been checked the process will be
   * redone using timestamps to limit the check to events added or updated since
   * the first check. Keep calling until the number of updated events is zero.
   *
   * @param limit   -1 for no limit
   * @param checkOnly  don't update if true.
   * @param info    null on first call, returned object from previous calls.
   * @return UpdateFromTimeZonesInfo staus of the update
   * @throws CalFacadeException
   */
  public UpdateFromTimeZonesInfo updateFromTimeZones(int limit,
                                                     boolean checkOnly,
                                                     UpdateFromTimeZonesInfo info
                                                     ) throws CalFacadeException;

  /* ====================================================================
   *                   Filters and search
   * ==================================================================== */

  /** Set a search filter using the suppplied search string
   *
   * @param val    String search parameters
   * @throws CalFacadeException
   */
  public void setSearch(String val) throws CalFacadeException;

  /** Return the current search string.
   *
   * @return  String     search parameters
   * @throws CalFacadeException
   */
  public String getSearch() throws CalFacadeException;

  /** Add a filter to the database. All references must be set.
   *
   * @param val
   * @throws CalFacadeException
   */
  public void addFilter(BwFilter val) throws CalFacadeException;

  /** Update a filter
   *
   * @param  val           FilterVO object to upate
   * @exception CalFacadeException If there's a problem
   */
  public void updateFilter(BwFilter val) throws CalFacadeException;

  /* ====================================================================
   *                   Event Properties
   * ==================================================================== */

  /** Return the categories maintenance object.
   *
   * @return EventProperties
   * @throws CalFacadeException
   */
  public EventProperties<BwCategory, BwString> getCategories()
        throws CalFacadeException;

  /** Return the locations maintenance object.
   *
   * @return EventProperties
   * @throws CalFacadeException
   */
  public EventProperties<BwLocation, String> getLocations()
        throws CalFacadeException;

  /** Return the sponsors maintenance object.
   *
   * @return EventProperties
   * @throws CalFacadeException
   */
  public EventProperties<BwContact, String> getContacts()
        throws CalFacadeException;

  /* ====================================================================
   *                   Free busy
   * ==================================================================== */

  /** Get the fee busy for a calendar (if cal != null) or for a principal.
   *
   * @param cal
   * @param who
   * @param start
   * @param end
   * @param returnAll
   * @param ignoreTransparency
   * @return  BwFreeBusy object representing the calendar (or principal's)
   *          free/busy
   * @throws CalFacadeException
   */
  public BwFreeBusy getFreeBusy(BwCalendar cal, BwPrincipal who,
                                BwDateTime start, BwDateTime end,
                                boolean returnAll,
                                boolean ignoreTransparency)
          throws CalFacadeException;

  /* ====================================================================
   *                   Synchronization
   * ==================================================================== */

  /** XXX temp I think
   * Retrieve event proxies in the given calendar - they will be used to remove events
   * from result sets.
   *
   * @return Collection of CoreEventInfo objects
   * @throws CalFacadeException
   */
  public Collection<CoreEventInfo> getDeletedProxies() throws CalFacadeException;

  /* ====================================================================
   *                       Alarms
   * This is currently under development at RPI
   * ==================================================================== */

  /** Get any alarms for the given event and user.
   *
   * @param event      BwEvent event
   * @param user       UserVO representing user
   * @return Collection of BwAlarm.
   * @throws CalFacadeException
   */
  public Collection<BwAlarm> getAlarms(BwEvent event,
                                       BwUser user) throws CalFacadeException;

  /** Create an alarm.
   *
   * @param val   ValarmVO  object .
   * @throws CalFacadeException
   */
  public void addAlarm(BwAlarm val) throws CalFacadeException;

  /** Update an alarm.
   *
   * @param val   ValarmVO  object .
   * @throws CalFacadeException
   */
  public void updateAlarm(BwAlarm val) throws CalFacadeException;

  /** Return all unexpired alarms. If user is null all unexpired alarms will
   * be retrieved.
   *
   * @param user
   * @return Collection
   * @throws CalFacadeException
   */
  public Collection getUnexpiredAlarms(BwUser user) throws CalFacadeException;

  /** Return all unexpired alarms before a given time. If user is null all
   * unexpired alarms will be retrieved.
   *
   * @param user
   * @param triggerTime
   * @return Collection
   * @throws CalFacadeException
   */
  public Collection getUnexpiredAlarms(BwUser user, long triggerTime)
          throws CalFacadeException;
}

