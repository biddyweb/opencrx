/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calcorei;

import org.bedework.calcorei.CalintfHelper.Callback;
import org.bedework.calcorei.CoreEventInfo;
import org.bedework.calfacade.BwEventProperty;
import org.bedework.calfacade.BwString;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.util.AccessUtilI;

import java.io.Serializable;
import java.util.Collection;

/** Interface which handles manipulation of BwEventProperty subclasses which are
 * treated in the same manner, these being Category, Location and Sponsor.
 *
 * <p>Each has a single field which together with the owner makes a unique
 * key and all operations on those classes are the same.
 *
 * @author Mike Douglass   douglm - rpi.edu
 *
 * @param <T> type of property, Location, Sponsor etc.
 * @param <K> type of key - String or subclass of BwDbentity
 */
public interface EventProperties <T extends BwEventProperty, K> extends Serializable {
  /** Initialise the object
   *
   * @param cb           Calintf object
   * @param access
   * @param currentMode
   * @param keyFieldName  Name of entity keyfield
   * @param finderFieldName Field used for find method.
   * @param className     Class of entity
   * @param refQuery      Name of query which returns referring event ids
   * @param delPrefQuery  Named query to delete all from prefs
   * @param debug
   */
  public void init(Callback cb,
                   AccessUtilI access,
                   int currentMode,
                   String keyFieldName,
                   String finderFieldName,
                   String className,
                   String refQuery,
                   String delPrefQuery,
                   boolean debug);

  /** Return all entities satisfying the conditions and to which the current
   * user has access.
   *
   * <p>Returns an empty collection for none.
   *
   * <p>The returned objects may not be persistant objects but the result of a
   * report query.
   *
   * @param  owner          non-null means limit to this
   * @param  creator        non-null means limit to this
   * @return Collection     of objects
   * @throws CalFacadeException
   */
  public Collection<T> get(BwUser owner, BwUser creator) throws CalFacadeException;

  /** Return an entity with the given id if the user has access
   *
   * @param id            int id of the entity
   * @return BwEventProperty object representing the entity in question
   *                     null if it doesn't exist.
   * @throws CalFacadeException
   */
  public T get(int id) throws CalFacadeException;

  /** Return an entity matching the given keyfeldsif the user has access or null.
   * The combination of key and owner should be guaranteed to produce a
   * single result, for example a uid + owner.
   *
   * @param keyVal       key field value
   * @param owner        BwUser owner
   * @return BwEventProperty object representing the entity in question
   *                     null if it doesn't exist.
   * @throws CalFacadeException
   */
  public T get(K keyVal, BwUser owner) throws CalFacadeException;

  /** Return one or more entities matching the given BwString to which the
   * user has access.
   *
   * <p>All event properties have string values which are used as the external
   * representation in icalendar files. The combination of field and owner should
   * be unique. The field value may change over time while the uid does not.
   *
   * @param val          BwString value
   * @param owner        BwUser owner
   * @return matching BwEventProperty object
   * @throws CalFacadeException
   */
  public T find(BwString val, BwUser owner) throws CalFacadeException;

  /** Return one or more entities matching the given String venue uid to which the
   * user has access.
   *
   * <p>Thus is probably unique to locations.
   *
   * @param val          String value
   * @param owner        BwUser owner
   * @return matching BwEventProperty object
   * @throws CalFacadeException
   */
  public T findVenue(String val, BwUser owner) throws CalFacadeException;

  /** Add an entity to the database. The id will be set in the parameter
   * object.
   *
   * @param val   BwEventProperty object to be added
   * @throws CalFacadeException
   */
  public void add(T val) throws CalFacadeException;

  /** Update an entity in the database.
   *
   * @param val   BwEventProperty object to be updated
   * @throws CalFacadeException
   */
  public void update(T val) throws CalFacadeException;

  /** Delete an entity
   *
   * @param val      BwEventProperty object to be deleted
   * @throws CalFacadeException
   */
  public void delete(T val) throws CalFacadeException;

  /** Return events referencing the given entity
   *
   * @param val      BwEventProperty object to be checked
   * @return Collection of Integer
   * @throws CalFacadeException
   */
  public Collection<CoreEventInfo> getRefs(T val) throws CalFacadeException;

  /** Return count of events referencing the given entity
   *
   * @param val      BwEventProperty object to be checked
   * @return Collection of Integer
   * @throws CalFacadeException
   */
  public int getRefsCount(T val) throws CalFacadeException;
}

