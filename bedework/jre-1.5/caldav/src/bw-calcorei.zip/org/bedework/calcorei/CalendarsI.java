/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calcorei;

import org.bedework.calfacade.BwCalendar;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.exc.CalFacadeException;

import edu.rpi.cmt.access.Ace;
import edu.rpi.cmt.access.AceWho;

import java.io.Serializable;
import java.util.Collection;

/** This is the calendars section of the low level interface to the calendar
 * database.
 *
 * @author Mike Douglass   douglm@rpi.edu
 */
public interface CalendarsI extends Serializable {

  /* ====================================================================
   *                   Calendars
   * ==================================================================== */

  /** Returns the tree of public calendars. The returned objects are those to
   * which the current user has access and are copies of the actual db objects,
   * that is, the actual db objecst will need to be fetched for updates.
   *
   * @return BwCalendar   root with all children attached
   * @throws CalFacadeException
   */
  public BwCalendar getPublicCalendars() throws CalFacadeException;

  /** Return a list of public calendars in which calendar objects can be
   * placed by the current user.
   *
   * <p>Caldav currently does not allow collections inside collections so that
   * calendar collections are the leaf nodes only.
   *
   * @return Collection   of CalendarVO
   * @throws CalFacadeException
   */
  public Collection<BwCalendar> getPublicCalendarCollections() throws CalFacadeException;

  /** Returns calendars owned by the current user.
   *
   * <p>For authenticated, personal access this always returns the user
   * entry in the /user calendar tree, e.g. for user smithj it would return
   * an entry /user/smithj
   *
   * @return BwCalendar   root with all children attached
   * @throws CalFacadeException
   */
  public BwCalendar getCalendars() throws CalFacadeException;

  /** Returns calendars owned by the given user.
   *
   * <p>For authenticated, personal access this always returns the user
   * entry in the /user calendar tree, e.g. for user smithj it would return
   * an entry smithj
   *
   * @param  user         BwUser entry
   * @param  desiredAccess access we need
   * @return BwCalendar   root with all children attached
   * @throws CalFacadeException
   */
  public BwCalendar getCalendars(BwUser user,
                                 int desiredAccess) throws CalFacadeException;

  /** Returns children of the given calendar to which the current user has
   * some access.
   *
   * @param  cal          parent calendar
   * @return Collection   of BwCalendar
   * @throws CalFacadeException
   */
  public Collection<BwCalendar> getCalendars(BwCalendar cal) throws CalFacadeException;

  /** Return a list of user calendars in which calendar objects can be
   * placed by the current user.
   *
   * <p>Caldav currently does not allow collections inside collections so that
   * calendar collections are the leaf nodes only.
   *
   * @return Collection   of BwCalendar
   * @throws CalFacadeException
   */
  public Collection<BwCalendar> getCalendarCollections() throws CalFacadeException;

  /** Return a list of calendars in which calendar objects can be
   * placed by the current user.
   *
   * <p>Caldav currently does not allow collections inside collections so that
   * calendar collections are the leaf nodes only.
   *
   * @return Collection   of BwCalendar
   * @throws CalFacadeException
   */
  public Collection<BwCalendar> getAddContentPublicCalendarCollections()
          throws CalFacadeException;

  /** Return a list of calendars in which calendar objects can be
   * placed by the current user.
   *
   * <p>Caldav currently does not allow collections inside collections so that
   * calendar collections are the leaf nodes only.
   *
   * @return Collection   of BwCalendar
   * @throws CalFacadeException
   */
  public Collection<BwCalendar> getAddContentCalendarCollections()
          throws CalFacadeException;

  /** Get a calendar we are interested in. This is represented by the id
   * of a calendar.
   *
   * @param  val        int id of calendar
   * @return BwCalendar null for unknown calendar
   * @throws CalFacadeException
   */
  public BwCalendar getCalendar(int val) throws CalFacadeException;

  /** Get a calendar given the path. If the path is that of a 'special'
   * calendar, for example the deleted calendar, it may not exist if it has
   * not been used.
   *
   * @param  path          String path of calendar
   * @param  desiredAccess int access we need
   * @return BwCalendar null for unknown calendar
   * @throws CalFacadeException
   */
  public BwCalendar getCalendar(String path,
                                int desiredAccess) throws CalFacadeException;

  /** Get the default calendar path for the given user. This is determined by the
   * name for the default calendar assigned to the system, not by any user
   * preferences. This is normally used at initialisation of a new user.
   *
   * @param  user
   * @return String path
   * @throws CalFacadeException
   */
  public String getDefaultCalendarPath(BwUser user) throws CalFacadeException;

  /** Get the root or home calendar path for the given user. This is determined
   * by the defaults assigned to the system, not by any user
   * preferences. This is normally used at initialisation of a new user.
   *
   * @param  user
   * @return String path
   * @throws CalFacadeException
   */
  public String getUserRootPath(BwUser user) throws CalFacadeException;

  /** Returned by getSpecialCalendar
   */
  public static class GetSpecialCalendarResult {
    /** True if calendar was created
     */
    public boolean created;
    /**
     */
    public BwCalendar cal;
  }
  /** Get a special calendar (e.g. Trash) for the given user. If it does not
   * exist and is supported by the target system it will be created.
   *
   * @param  user
   * @param  calType   int special calendar type.
   * @param  create    true if we should create it if non-existant.
   * @param  access    int desired access - from PrivilegeDefs
   * @return GetSpecialCalendarResult null for unknown calendar
   * @throws CalFacadeException
   */
  public GetSpecialCalendarResult getSpecialCalendar(BwUser user,
                                                     int calType,
                                                     boolean create,
                                                     int access) throws CalFacadeException;

  /** Add a calendar object
   *
   * <p>The new calendar object will be added to the db. If the indicated parent
   * is null it will be added as a root level calendar.
   *
   * <p>Certain restrictions apply, mostly because of interoperability issues.
   * A calendar cannot be added to another calendar which already contains
   * entities, e.g. events etc.
   *
   * <p>Names cannot contain certain characters - (complete this)
   *
   * <p>Name must be unique at this level, i.e. all paths must be unique
   *
   * @param  val     BwCalendar new object
   * @param  parentPath  String path to parent.
   * @return BwCalendar object as added. Parameter val MUST be discarded
   * @throws CalFacadeException
   */
  public BwCalendar addCalendar(BwCalendar val,
                                String parentPath) throws CalFacadeException;

  /** Change the name (path segment) of a calendar object.
   *
   * @param  val         BwCalendar object
   * @param  newName     String name
   * @throws CalFacadeException
   */
  public void renameCalendar(BwCalendar val,
                             String newName) throws CalFacadeException;

  /** Move a calendar object from one parent to another
   *
   * @param  val         BwCalendar object
   * @param  newParent   BwCalendar potential parent
   * @throws CalFacadeException
   */
  public void moveCalendar(BwCalendar val,
                           BwCalendar newParent) throws CalFacadeException;

  /** Update a calendar object
   *
   * @param  val     BwCalendar object
   * @throws CalFacadeException
   */
  public void updateCalendar(BwCalendar val) throws CalFacadeException;

  /** Change the access to the given calendar entity.
   *
   * @param cal      Bwcalendar
   * @param aces     Collection of ace
   * @param replaceAll true to replace the entire access list.
   * @throws CalFacadeException
   */
  public void changeAccess(BwCalendar cal,
                           Collection<Ace> aces,
                           boolean replaceAll) throws CalFacadeException;

  /** Remove any explicit access for the given who to the given calendar entity.
  *
   * @param cal      Bwcalendar
  * @param who      AceWho
  * @throws CalFacadeException
  */
 public abstract void defaultAccess(BwCalendar cal,
                                    AceWho who) throws CalFacadeException;

  /** Delete the given calendar
   *
   * <p>XXX Do we want a recursive flag or do we implement that higher up?
   *
   * @param val      CalendarVO object to be deleted
   * @return boolean false if it didn't exist, true if it was deleted.
   * @throws CalFacadeException
   */
  public boolean deleteCalendar(BwCalendar val) throws CalFacadeException;

  /** Check to see if a calendar is referenced.
   *
   * @param val      CalendarVO object to check
   * @return boolean true if the calendar is referenced somewhere
   * @throws CalFacadeException
   */
  public boolean checkCalendarRefs(BwCalendar val) throws CalFacadeException;
}
