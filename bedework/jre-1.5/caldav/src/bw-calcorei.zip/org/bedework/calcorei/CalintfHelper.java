/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calcorei;

import org.bedework.calfacade.BwCalendar;
import org.bedework.calfacade.BwSystem;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.timezones.CalTimezones;
import org.bedework.calfacade.util.AccessUtilI;
import org.bedework.calfacade.wrappers.CoreCalendarWrapper;

import edu.rpi.cmt.access.PrivilegeDefs;

import org.apache.log4j.Logger;

import java.io.Serializable;
import java.util.Collection;

/** Class used as basis for a number of helper classes.
 *
 * @author Mike Douglass   douglm@rpi.edu
 */
public class CalintfHelper implements CalintfDefs, PrivilegeDefs, Serializable {
  /**
   */
  public static interface Callback extends Serializable {
    /**
     * @throws CalFacadeException
     */
    public void rollback() throws CalFacadeException;

    /**
     * @return BwSystem object
     * @throws CalFacadeException
     */
    public BwSystem getSyspars() throws CalFacadeException;

    /**
     * @return BwUser object for current user
     * @throws CalFacadeException
     */
    public BwUser getUser() throws CalFacadeException;

    /**
     * @return true for super user
     * @throws CalFacadeException
     */
    public boolean getSuperUser() throws CalFacadeException;

    /** Get the timezones cache object
     *
     * @return CalTimezones object
     * @throws CalFacadeException if not admin
     */
    public CalTimezones getTimezonesHandler() throws CalFacadeException;

    /** Returns children of the given calendar to which the current user has
     * some access.
     *
     * @param  cal          parent calendar
     * @return Collection   of BwCalendar
     * @throws CalFacadeException
     */
    public Collection<BwCalendar> getCalendars(BwCalendar cal) throws CalFacadeException;
  }

  protected boolean debug;

  protected Callback cb;

  protected AccessUtilI access;

  protected int currentMode = guestMode;

  private transient Logger log;

  /** Initialise
   *
   * @param cb
   * @param access
   * @param currentMode
   * @param debug
   */
  public void init (Callback cb, AccessUtilI access,
                    int currentMode,
                    boolean debug) {
    this.cb = cb;
    this.access = access;
    this.currentMode = currentMode;
    this.debug = debug;
  }

  protected BwSystem getSyspars() throws CalFacadeException {
    return cb.getSyspars();
  }

  protected BwUser getUser() throws CalFacadeException {
    return cb.getUser();
  }

  protected BwCalendar wrap(BwCalendar val) {
    if (val instanceof CoreCalendarWrapper) {
      // CALWRAPPER get this from getEvents with an internal temp calendar
      return val;
    }
    return new CoreCalendarWrapper(val, access);
  }

  protected BwCalendar unwrap(BwCalendar val) throws CalFacadeException {
    if (val == null) {
      return null;
    }

    if (!(val instanceof CoreCalendarWrapper)) {
      // We get these at the moment - getEvents at svci level
      return val;
      // CALWRAPPER throw new CalFacadeException("org.bedework.not.wrapped");
    }

    return ((CoreCalendarWrapper)val).unwrap();
  }

  /** Get a logger for messages
   *
   * @return Logger
   */
  protected Logger getLogger() {
    if (log == null) {
      log = Logger.getLogger(this.getClass());
    }

    return log;
  }

  protected void debugMsg(String msg) {
    getLogger().debug(msg);
  }

  protected void trace(String msg) {
    getLogger().debug(msg);
  }
}
