package org.bedework.calcorei;

import org.bedework.calfacade.BwCalendar;
import org.bedework.calfacade.BwDateTime;
import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.BwEventProxy;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.RecurringRetrievalMode;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.filter.BwFilter;
import org.bedework.calfacade.util.ChangeTable;

import java.io.Serializable;
import java.util.Collection;

/** This is the events section of the low level interface to the calendar
 * database.
 *
 * @author Mike Douglass   douglm@rpi.edu
 */
public interface EventsI extends Serializable {

  /* ====================================================================
   *                   Events
   * ==================================================================== */

  /** Return calendars which contain
   * @param guid
   * @param rid
   * @return Collection of calendar objects.
   * @throws CalFacadeException
   */
  public Collection<BwCalendar> findCalendars(String guid,
                                              String rid) throws CalFacadeException;

  /** Return one or more events using the calendar, guid and optionally a
   * recurrence-id as a key.
   *
   * <p>For most calendar collections one and only one event should be returned
   * for any given guid. However, for certain special collections (inbox etc)
   * the guid rules are relaxed.
   *
   * <p>For recurring events, the guid defines the 'master' event defining
   * the rules together with any exceptions.
   *
   * <p>The recurrence id defines a particular instance of a recurrence.
   *
   * <p>To specify the master entry provide a null recurrenceId or use the
   * recurRetrieval parameter. One CoreEventInfo object per recurring event will
   * be returned as for getEvent using the name.
   *
   * <p>if the rerieval mode is to expand recurrences, the Collection returned
   * will include all appropriate instances.
   *
   * @param calendar     BwCalendar object restricting search or null.
   * @param   guid      String guid for the event
   * @param   rid       String recurrence id, null for non-recurring, null valued for
   *                    master or non-null-valued for particular occurrence.
   * @param recurRetrieval How recurring event is returned.
   * @return  Collection of CoreEventInfo objects representing event(s).
   * @throws CalFacadeException
   */
  public Collection<CoreEventInfo> getEvent(BwCalendar calendar,
                                            String guid, String rid,
                                            RecurringRetrievalMode recurRetrieval)
          throws CalFacadeException;

  /** Return the events for the current user within the given date/time
   * range.
   *
   * @param calendar     BwCalendar object restricting search or null.
   * @param filter       BwFilter object restricting search or null.
   * @param startDate    BwDateTime start - may be null
   * @param endDate      BwDateTime end - may be null.
   * @param recurRetrieval How recurring event is returned.
   * @param freeBusy     Return skeleton events with date/times and skip
   *                     transparent events.
   * @param allCalendars False - ignore any 'special' calendars.
   * @return Collection  of CoreEventInfo objects
   * @throws CalFacadeException
   */
  public Collection<CoreEventInfo> getEvents(BwCalendar calendar, BwFilter filter,
                                             BwDateTime startDate, BwDateTime endDate,
                                             RecurringRetrievalMode recurRetrieval,
                                             boolean freeBusy,
                                             boolean allCalendars) throws CalFacadeException;

  /** Get an event given the calendar and String name. Return null for not
   * found. For non-recurring there should be only one event. For recurring
   * events, overrides and possibly instances will be returned.
   *
   * @param cal        CalendarVO object
   * @param val        String possible name
   * @param recurRetrieval How recurring event is returned.
   * @return CoreEventInfo or null
   * @throws CalFacadeException
   */
  public CoreEventInfo getEvent(BwCalendar cal, String val,
                                RecurringRetrievalMode recurRetrieval)
          throws CalFacadeException;

  /** Add an event to the database. The id and uid will be set in the parameter
   * object.
   *
   * @param val   BwEvent object to be added
   * @param overrides    Collection of BwEventProxy objects which override instances
   *                     of the new event
   * @param scheduling   True if we are adding an event to an inbox for scheduling.
   * @param rollbackOnError true if we rollback and throw an exception on error
   * @return Collection of overrides which did not match or null if all matched
   * @throws CalFacadeException
   */
  public Collection<BwEventProxy> addEvent(BwEvent val,
                                           Collection<BwEventProxy> overrides,
                                           boolean scheduling,
                                           boolean rollbackOnError) throws CalFacadeException;

  /** Update an event in the database.
   *
   * <p>This method will set any synchronization state entries to modified
   * unless we are synchronizing in which case that belonging to the current
   * user is set to mark the event as synchronized
   *
   * @param val   BwEvent object to be replaced
   * @param overrides
   * @param changes
   * @exception CalFacadeException If there's a db problem or problem with
   *     the event
   */
  public void updateEvent(BwEvent val,
                          Collection<BwEventProxy> overrides,
                          ChangeTable changes) throws CalFacadeException;

  /** This class allows the implementations to pass back some information
   * about what happened. If possible it should fill in the supplied fields.
   *
   * A result of zero for counts does not necessarily indicate nothing
   * happened, for example, the implementation may store elarms as part of
   * the event object and they just go as part of event deletion.
   */
  public static class DelEventResult {
    /**  false if it didn't exist
     */
    public boolean eventDeleted;

    /** Number of alarms deleted
     */
    public int alarmsDeleted;

    /** Constructor
     *
     * @param eventDeleted
     * @param alarmsDeleted
     */
    public DelEventResult(boolean eventDeleted,
                          int alarmsDeleted) {
      this.eventDeleted = eventDeleted;
      this.alarmsDeleted = alarmsDeleted;
    }
  }

  /** Delete an event and any associated alarms
   * Set any referring synch states to deleted.
   *
   * @param val                EventVO object to be deleted
   * @return DelEventResult    result.
   * @exception CalFacadeException If there's a database access problem
   */
  public DelEventResult deleteEvent(BwEvent val) throws CalFacadeException;

  /** XXX temp I think
   * Retrieve event proxies in the given calendar - they will be used to remove events
   * from result sets.
   *
   * @param cal     BwCalendar object restricting search or null.
   * @return Collection of CoreEventInfo objects
   * @throws CalFacadeException
   */
  public Collection<CoreEventInfo> getDeletedProxies(BwCalendar cal)
          throws CalFacadeException;

  /** This represents an internal key to an event.
   *
   */
  public abstract static class InternalEventKey implements Serializable {
    /**
     * @return start time for indexed event
     */
    public abstract BwDateTime getStart();

    /**
     * @return end time for indexed event
     */
    public abstract BwDateTime getEnd();

    /**
     * @return owner for indexed event
     */
    public abstract BwUser getOwner();
  }

  /** Return all keys or all with a lastmod greater than or equal to that supplied.
   * Note the lastmod has a coarse granularity so it may need to be backed off
   * to ensure all events are covered if doing batches.
   *
   * @param lastmod
   * @return collection of opaque key objects.
   * @throws CalFacadeException
   */
  public Collection<? extends InternalEventKey> getEventKeysForTzupdate(String lastmod)
          throws CalFacadeException;

  /** Get an event given the internal key. Returns null if event no longer
   * exists.
   *
   * @param key
   * @return CoreEventInfo
   * @throws CalFacadeException
   */
  public CoreEventInfo getEvent(InternalEventKey key)
          throws CalFacadeException;
}
