/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.apiutil;

import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.exc.CalFacadeException;

import net.fortuna.ical4j.model.Date;
import net.fortuna.ical4j.model.NumberList;
import net.fortuna.ical4j.model.Recur;
import net.fortuna.ical4j.model.WeekDay;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Set;

/** Broken out recurrence rule.
*
   *          recur      = "FREQ"=freq *(

                    ; either UNTIL or COUNT may appear in a 'recur',
                    ; but UNTIL and COUNT MUST NOT occur in the same 'recur'

                    ( ";" "UNTIL" "=" enddate ) /
                    ( ";" "COUNT" "=" 1*DIGIT ) /

                    ; the rest of these keywords are optional,
                    ; but MUST NOT occur more than once

                    ( ";" "INTERVAL" "=" 1*DIGIT )          /
                    ( ";" "BYSECOND" "=" byseclist )        /
                    ( ";" "BYMINUTE" "=" byminlist )        /
                    ( ";" "BYHOUR" "=" byhrlist )           /
                    ( ";" "BYDAY" "=" bywdaylist )          /
                    ( ";" "BYMONTHDAY" "=" bymodaylist )    /
                    ( ";" "BYYEARDAY" "=" byyrdaylist )     /
                    ( ";" "BYWEEKNO" "=" bywknolist )       /
                    ( ";" "BYMONTH" "=" bymolist )          /
                    ( ";" "BYSETPOS" "=" bysplist )         /
                    ( ";" "WKST" "=" weekday )              /
                    ( ";" x-name "=" text )
                    )

         freq       = "SECONDLY" / "MINUTELY" / "HOURLY" / "DAILY"
                    / "WEEKLY" / "MONTHLY" / "YEARLY"

         enddate    = date
         enddate    =/ date-time            ;An UTC value

         byseclist  = seconds / ( seconds *("," seconds) )

         seconds    = 1DIGIT / 2DIGIT       ;0 to 59

         byminlist  = minutes / ( minutes *("," minutes) )

         minutes    = 1DIGIT / 2DIGIT       ;0 to 59

         byhrlist   = hour / ( hour *("," hour) )

         hour       = 1DIGIT / 2DIGIT       ;0 to 23

         bywdaylist = weekdaynum / ( weekdaynum *("," weekdaynum) )

         weekdaynum = [([plus] ordwk / minus ordwk)] weekday

         plus       = "+"

         minus      = "-"

         ordwk      = 1DIGIT / 2DIGIT       ;1 to 53

         weekday    = "SU" / "MO" / "TU" / "WE" / "TH" / "FR" / "SA"
         ;Corresponding to SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY,
         ;FRIDAY, SATURDAY and SUNDAY days of the week.

         bymodaylist = monthdaynum / ( monthdaynum *("," monthdaynum) )

         monthdaynum = ([plus] ordmoday) / (minus ordmoday)

         ordmoday   = 1DIGIT / 2DIGIT       ;1 to 31

         byyrdaylist = yeardaynum / ( yeardaynum *("," yeardaynum) )

         yeardaynum = ([plus] ordyrday) / (minus ordyrday)

         ordyrday   = 1DIGIT / 2DIGIT / 3DIGIT      ;1 to 366

         bywknolist = weeknum / ( weeknum *("," weeknum) )
         weeknum    = ([plus] ordwk) / (minus ordwk)

         bymolist   = monthnum / ( monthnum *("," monthnum) )

         monthnum   = 1DIGIT / 2DIGIT       ;1 to 12

         bysplist   = setposday / ( setposday *("," setposday) )

         setposday  = yeardaynum

* @author Mike Douglass     douglm - rpi.edu
*  @version 1.0
*/
public class RecurRuleComponents {
  private String rule;

  /**
   * @author douglm
   *
   */
  public enum Freq {
    /**      */
    SECONDLY,
    /**      */
    MINUTELY,
    /**      */
    HOURLY,
    /**      */
    DAILY,
    /**      */
    WEEKLY,
    /**      */
    MONTHLY,
    /**      */
    YEARLY }

  private Freq freq;

  private Date until;

  private int count;

  private int interval;

  /**
   * Allows us to group days
   */
  public static class PosDays {
    Integer pos;
    Collection<String> days;

    PosDays(Integer pos, Collection<String> days) {
      this.pos = pos;
      this.days = days;
    }

    /**
     * @return Integer
     */
    public Integer getPos() {
      return pos;
    }

    /**
     * @return  Collection<String> days;

     */
    public Collection<String> getDays() {
      return days;
    }
  }

  private Collection<Integer> bySecond;
  private Collection<Integer> byMinute;
  private Collection<Integer> byHour;
  private Collection<PosDays> byDay;
  private Collection<Integer> byMonthDay;
  private Collection<Integer> byYearDay;
  private Collection<Integer> byWeekNo;
  private Collection<Integer> byMonth;
  private Collection<Integer> bySetPos;
  private String wkst;

  /**
   * @param val String rule this is derived from
   */
  public void setRule(String val) {
    rule = val;
  }

  /**
   * @return String weekstart or null
   */
  public String getRule() {
    return rule;
  }

  /**
   * @param val
   */
  public void setFreq(Freq val) {
    freq = val;
  }

  /**
   * @return Freq
   */
  public Freq getFreq() {
    return freq;
  }

  /**
   * @param val
   */
  public void setUntil(Date val) {
    until = val;
  }

  /**
   * @return Date
   */
  public Date getUntil() {
    return until;
  }

  /**
   * @param val
   */
  public void setCount(int val) {
    count = val;
  }

  /**
   * @return int
   */
  public int getCount() {
    return count;
  }

  /**
   * @param val
   */
  public void setInterval(int val) {
    interval = val;
  }

  /**
   * @return int
   */
  public int getInterval() {
    return interval;
  }

  /**
   * @param val bySecond list
   */
  public void setBySecond(Collection<Integer> val) {
    bySecond = val;
  }

  /**
   * @return bySecond list or null
   */
  public Collection<Integer> getBySecond() {
    return bySecond;
  }

  /**
   * @param val byMinute list
   */
  public void setByMinute(Collection<Integer> val) {
    byMinute = val;
  }

  /**
   * @return byMinute list or null
   */
  public Collection<Integer> getByMinute() {
    return byMinute;
  }

  /**
   * @param val byHour list
   */
  public void setByHour(Collection<Integer> val) {
    byHour = val;
  }

  /**
   * @return byHour list or null
   */
  public Collection<Integer> getByHour() {
    return byHour;
  }

  /**
   * @param val byDay map
   */
  public void setByDay(Collection<PosDays> val) {
    byDay = val;
  }

  /**
   * @return byDay map or null
   */
  public Collection<PosDays> getByDay() {
    return byDay;
  }

  /**
   * @param val byMonthDay list
   */
  public void setByMonthDay(Collection<Integer> val) {
    byMonthDay = val;
  }

  /**
   * @return byMonthDay list or null
   */
  public Collection<Integer> getByMonthDay() {
    return byMonthDay;
  }

  /**
   * @param val byYearDay list
   */
  public void setByYearDay(Collection<Integer> val) {
    byYearDay = val;
  }

  /**
   * @return byYearDay list or null
   */
  public Collection<Integer> getByYearDay() {
    return byYearDay;
  }

  /**
   * @param val byWeekNo list
   */
  public void setByWeekNo(Collection<Integer> val) {
    byWeekNo = val;
  }

  /**
   * @return byWeekNo list or null
   */
  public Collection<Integer> getByWeekNo() {
    return byWeekNo;
  }

  /**
   * @param val byMonth list
   */
  public void setByMonth(Collection<Integer> val) {
    byMonth = val;
  }

  /**
   * @return byMonth list or null
   */
  public Collection<Integer> getByMonth() {
    return byMonth;
  }

  /**
   * @param val bySetPos list
   */
  public void setBySetPos(Collection<Integer> val) {
    bySetPos = val;
  }

  /**
   * @return bySetPos list or null
   */
  public Collection<Integer> getBySetPos() {
    return bySetPos;
  }

  /**
   * @param val String weekstart
   */
  public void setWkst(String val) {
    wkst = val;
  }

  /**
   * @return String weekstart or null
   */
  public String getWkst() {
    return wkst;
  }

  /** Return parsed rrules.
   *
   * @param ev
   * @return Collection of parsed rrules
   * @throws CalFacadeException
   */
  public static Collection<RecurRuleComponents> fromEventRrules(BwEvent ev)
            throws CalFacadeException {
    return fromEventXrules(ev, ev.getRrules());
  }

  private static Collection<RecurRuleComponents> fromEventXrules(BwEvent ev,
                                                                 Collection<String> rules)
            throws CalFacadeException {
    Collection<RecurRuleComponents> rrcs = new ArrayList<RecurRuleComponents>();
    if (!ev.isRecurringEntity()) {
      return rrcs;
    }

    if (rules == null) {
      return rrcs;
    }

    try {
      for (String rule: rules) {
        RecurRuleComponents rrc = new RecurRuleComponents();

        Recur recur = new Recur(rule);

        rrc.setRule(rule);
        rrc.setFreq(Freq.valueOf(recur.getFrequency()));

        Date until = recur.getUntil();
        if (until != null) {
          rrc.setUntil(until);
        } else {
          rrc.setCount(recur.getCount());
        }

        rrc.setInterval(recur.getInterval());

        rrc.setBySecond(checkNumList(recur.getSecondList()));
        rrc.setByMinute(checkNumList(recur.getMinuteList()));
        rrc.setByHour(checkNumList(recur.getHourList()));

        /* Group by position */
        Collection wds = recur.getDayList();
        if (wds != null) {
          HashMap<Integer, Collection<String>> hm =
            new HashMap<Integer, Collection<String>>();

          for (Object o: wds) {
            WeekDay wd = (WeekDay)o;

            Collection<String>c = hm.get(wd.getOffset());
            if (c == null) {
              c = new ArrayList<String>();
              hm.put(wd.getOffset(), c);
            }

            c.add(wd.getDay());
          }

          Collection<PosDays> pds = new ArrayList<PosDays>();

          Set<Integer> poss = hm.keySet();
          for (Integer pos: poss) {
            pds.add(new PosDays(pos, hm.get(pos)));
          }

          rrc.setByDay(pds);
        }

        rrc.setByMonthDay(checkNumList(recur.getMonthDayList()));
        rrc.setByYearDay(checkNumList(recur.getYearDayList()));
        rrc.setByWeekNo(checkNumList(recur.getWeekNoList()));
        rrc.setByMonth(checkNumList(recur.getMonthList()));
        rrc.setBySetPos(checkNumList(recur.getSetPosList()));

        rrc.setWkst(recur.getWeekStartDay());

        rrcs.add(rrc);
      }
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }

    return rrcs;
  }

  @SuppressWarnings("unchecked")
  private static Collection<Integer> checkNumList(NumberList val) {
    if ((val == null) || (val.isEmpty())) {
      return null;
    }

    return val;
  }
}
