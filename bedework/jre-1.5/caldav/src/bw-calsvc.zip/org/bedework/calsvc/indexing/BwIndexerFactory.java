/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/

package org.bedework.calsvc.indexing;

import org.bedework.calfacade.BwSystem;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.exc.CalFacadeException;

import java.io.File;

/** Create an instance of an indexer fro bedework.
 *
 * @author douglm
 *
 */
public class BwIndexerFactory {
  /* No instantiation
   */
  private BwIndexerFactory() {
  }


  /** Factory method
   *
   * @param publick
   * @param user
   * @param writeable
   * @param syspars
   * @param debug
   * @return indexer
   * @throws CalFacadeException
   */
  public static BwIndexer getIndexer(boolean publick,
                                     BwUser user,
                                     boolean writeable,
                                     BwSystem syspars,
                                     boolean debug) throws CalFacadeException {
    try {
      String suffix;

      if (publick) {
        suffix = syspars.getPublicCalendarRoot();
      } else {
        suffix = syspars.getUserCalendarRoot() + "/" + user.getAccount();
      }

      String path = syspars.getIndexRoot() + "/" + suffix;
      File f = new File(path + BwIndexLuceneImpl.getPathSuffix());
      if (f.isFile()) {
        throw new CalFacadeException("org.bedework.error.lucene.notdirectory",
                                     f.getAbsolutePath());
      }

      if (!f.exists()) {
        if (!f.mkdirs()) {
          throw new CalFacadeException("org.bedework.error.lucene.createfailed",
                                       f.getAbsolutePath());
        }
      }

      return new BwIndexLuceneImpl(path, writeable, debug);
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }
}
