/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/

package org.bedework.calsvc.indexing;

import edu.rpi.cct.misc.indexing.IndexLuceneImpl.FieldInfo;

/** Haven't yet figured out how we'll internationalize queries. I think internal
 * lucene field names will have to be fixed and defined below and front end
 * implementors will need to provide a mapping.
 *
 * <p>We can possibly provide a subsclass of the parser to take a mapping table
 * of allowable external names to internal names.
 *
 * <p>In any case, this class defines the names of all the fields we index.
 *
 * @author Mike Douglass douglm @ rpi.edu
 *
 */
public class BwIndexLuceneDefs {
  private BwIndexLuceneDefs() {
    // There'll be no instantiation here
  }

  /* ---------------------------- Calendar fields ------------------------- */

  /** Key field for a calendar - must be stored */
  public static final FieldInfo calendarPath =
    new FieldInfo("calendarPath", true, false, 1);

  /* ------------------Event/todo/journal fields ------------------------- */

  /** */
  public static final FieldInfo comment =
    new FieldInfo("comment", true);

  /** */
  public static final FieldInfo contact =
    new FieldInfo("contact", true);

  /** */
  public static final FieldInfo dueDate =
    new FieldInfo("due", false, 3);

  /** */
  public static final FieldInfo endDate =
    new FieldInfo("end", false);

  /** */
  public static final FieldInfo location =
    new FieldInfo("location", true);

  /** */
  public static final FieldInfo resources =
    new FieldInfo("resources", true);

  /** */
  public static final FieldInfo startDate =
    new FieldInfo("start", false);

  /* ---------------------------- Common fields ------------------------- */

  /** */
  public static final FieldInfo calendar =
    new FieldInfo("calendar", true);

  /** */
  public static final FieldInfo category =
    new FieldInfo("category", true);

  /** */
  public static final FieldInfo created =
    new FieldInfo("created", false);

  /** */
  public static final FieldInfo creator =
    new FieldInfo("creator", false);

  /** */
  public static final FieldInfo description =
    new FieldInfo("description", true);

  /** */
  public static final FieldInfo lastmod =
    new FieldInfo("lastmod", false);

  /** */
  public static final FieldInfo owner =
    new FieldInfo("owner", false);

  /** */
  public static final FieldInfo summary =
    new FieldInfo("summary", true);

  /** */
  public static final FieldInfo defaultFieldInfo =
    new FieldInfo("default", true);

  /* Field names for fields which contain item type and key information.
   */

  /** Field name defining type of item - must be stored */
  public static final FieldInfo itemTypeInfo =
    new FieldInfo("itemType", true, false, 1);

  /** */
  public static final FieldInfo[] fields = {
    itemTypeInfo,

    // ----------------- Calendar
    calendarPath,

    // ----------------- Event/todo/journal
    calendar,
    comment,
    contact,
    dueDate,
    endDate,
    location,

    // ----------------- Common
    category,
    created,
    creator,
    description,
    lastmod,
    owner,
    startDate,
    summary,

    defaultFieldInfo,
  };

  private static final String[] termNames = new String[fields.length];
  static {
    for (int i = 0; i < fields.length; i++) {
      termNames[i] = fields[i].getName();
    }
  }


  /**
   * @return String[]
   */
  public static String[] getTermNames() {
    return termNames;
  }

  /* Item types. We index various item types and these strings define each
   * type.
   */

  /** */
  public static final String itemTypeCalendar = "calendar";

  /** */
  public static final String itemTypeEvent = "event";

  /** Key field for calendar */
  public static final FieldInfo keyCalendar = calendarPath;

  /** Key for an event - must be stored */
  public static final FieldInfo keyEvent =
    new FieldInfo("event", true, false, 1);

}
