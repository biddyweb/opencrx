/* **********************************************************************
    Copyright 2007 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calsvc;

import org.bedework.calcorei.HibSession;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.svc.prefs.BwPreferences;
import org.bedework.calsvci.PreferencesI;

/** This acts as an interface to the database for user preferences.
 *
 * @author Mike Douglass       douglm - rpi.edu
 */
class Preferences extends CalSvcDb implements PreferencesI {
  private BwPreferences prefs;

  /*
   * @param synchId     non-null if this is for synchronization. Identifies the
   *                    client end.
   */
  Preferences(CalSvc svci, BwUser user,
              boolean debug) {
    super(svci, user, debug);
  }

  /** Call at svci open
   *
   */
  public void open() {
    super.open();
    prefs = null;
  }

  /** Call at svci close
   *
   */
  public void close() {
    super.close();
    prefs = null;
  }

  /* ====================================================================
   *                    User preferences methods
   * ==================================================================== */

  /** Get the preferences for the current user
   *
   * @return the preferences for the current user
   * @throws CalFacadeException
   */
  public BwPreferences get() throws CalFacadeException {
    if (prefs != null) {
      return prefs;
    }

    prefs = fetch();

    return prefs;
  }

  public BwPreferences get(BwUser user) throws CalFacadeException {
    return fetch(user);
  }

  /** Update a preferences object
   *
   * @param val
   * @throws CalFacadeException
   */
  public void update(BwPreferences val) throws CalFacadeException {
    getSess().saveOrUpdate(val);
  }

  /** delete a preferences object
   *
   * @param val
   * @throws CalFacadeException
   */
  public void delete(BwPreferences val) throws CalFacadeException {
    getSess().delete(val);
  }

  /** Fetch the preferences for the current user from the db
   *
   * @return the preferences for the current user
   * @throws CalFacadeException
   */
  private BwPreferences fetch() throws CalFacadeException {
    return fetch(getUser());
  }

  /** Fetch the preferences for the given user from the db
   *
   * @param owner
   * @return the preferences for the current user
   * @throws CalFacadeException
   */
  private BwPreferences fetch(BwUser owner) throws CalFacadeException {
    HibSession sess = getSess();

    sess.namedQuery("getOwnerPreferences");
    sess.setEntity("owner", owner);
    sess.cacheableQuery();

    return (BwPreferences)sess.getUnique();
  }
}

