/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calsvc;

import org.bedework.calfacade.BwAttendee;
import org.bedework.calfacade.BwCalendar;
import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.BwFreeBusy;
import org.bedework.calfacade.BwFreeBusyComponent;
import org.bedework.calfacade.RecurringRetrievalMode;
import org.bedework.calfacade.ScheduleResult;
import org.bedework.calfacade.RecurringRetrievalMode.Rmode;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.svc.EventInfo;
import org.bedework.calfacade.svc.prefs.BwPreferences;
import org.bedework.calfacade.util.CalFacadeUtil;
import org.bedework.calsvci.CalSvcFactoryDefault;
import org.bedework.calsvci.CalSvcI;
import org.bedework.calsvci.CalSvcIPars;
import org.bedework.calsvci.SchedulingI;
import org.bedework.icalendar.Icalendar;

import net.fortuna.ical4j.model.Period;
import net.fortuna.ical4j.model.parameter.PartStat;

import org.apache.log4j.Logger;

import java.io.Serializable;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Queue;

/** Handles a queue of scheduling requests we auto process. We need to delay
 * processing until after the initiating request is processed.
 *
 * <p>This queue should probably be persisted and processed by a separate process.
 *
 * @author Mike Douglass
 */
public class AutoScheduler implements Serializable {
  private static class AsEntry implements Serializable {
    String account;
    String eventName;
    String rid;

    AsEntry(String account, String eventName, String rid) {
      this.account = account;
      this.eventName = eventName;
      this.rid = rid;
    }
  }

  private Queue<AsEntry> asq = new LinkedList<AsEntry>();

  private String envPrefix;
  private boolean debug;

  private transient Logger log;

  /**
   * @param envPrefix
   * @param debug
   */
  public AutoScheduler(String envPrefix, boolean debug) {
    this.envPrefix = envPrefix;
    this.debug = debug;
  }

  /**
   * @param account
   * @param eventName
   * @param rid
   * @throws CalFacadeException
   */
  public void add(String account, String eventName,
                  String rid) throws CalFacadeException {
    asq.add(new AsEntry(account, eventName, rid));
  }

  /** Indicate we should process the queue
   *
   */
  public void trigger() {
    process();
  }

  private void process() {
    try {
      while (!asq.isEmpty()) {
        process(asq.remove());
      }
    } catch (Throwable t) {
    }
  }

  private void process(AsEntry ase) {
    CalSvcI svci = null;

    try {
      if (debug) {
        trace("autoSchedule for account " + ase.account);
      }

      svci = getSvci(ase.account);

      EventInfo ei = getEvent(svci, ase.eventName);

      if (ei == null) {
        return;
      }

      ScheduleResult sr = null;
      BwEvent ev = ei.getEvent();
      int method = ev.getScheduleMethod();

      if (debug) {
        trace("autoSchedule event " + ase.eventName +
              " with method " + method);
      }

      if (method == Icalendar.methodTypeCancel) {
        sr = processCancel(svci, ei);
      }

      if (ev.getScheduleMethod() == Icalendar.methodTypeRequest) {
        sr = processRequest(svci, ei);
      }

      if (ev.getScheduleMethod() == Icalendar.methodTypeReply) {
        sr = processReply(svci, ei);
      }

      if (ev.getScheduleMethod() == Icalendar.methodTypeRefresh) {
        sr = processRefresh(svci, ei);
      }

      if (debug) {
        trace("autoSchedule " + sr);
      }
    } catch (Throwable t) {
      error(t);
    } finally {
      try {
        closeSvci(svci);
      } catch (Throwable t) {}
    }
  }

  private ScheduleResult processCancel(CalSvcI svci,
                                       EventInfo ei) throws CalFacadeException {
    BwPreferences prefs = svci.getUserPrefs();
    SchedulingI sched =  svci.getScheduler();

    if (!prefs.getScheduleAutoRespond()) {
      return null;
    }

    int scheduleAutoCancelAction = prefs.getScheduleAutoCancelAction();

    if (scheduleAutoCancelAction == BwPreferences.scheduleAutoCancelNoAction) {
      return null;
    }

    return sched.processCancel(ei, scheduleAutoCancelAction,
                               sched.getMeetingCalendars(ei.getEvent()));
  }

  private ScheduleResult processRequest(CalSvcI svci,
                                        EventInfo ei) throws CalFacadeException {
    BwPreferences prefs = svci.getUserPrefs();
    BwEvent ev = ei.getEvent();

    if (!prefs.getScheduleAutoRespond()) {
      return null;
    }

    if (debug) {
      trace("send response event " + ev.getName());
    }

    SchedulingI sched =  svci.getScheduler();
    String partStat = PartStat.ACCEPTED.getValue();

    if (!prefs.getScheduleDoubleBook()) {
      // See if there are any events booked during this time.
      BwFreeBusy fb = sched.getFreeBusy(null, svci.getUser(),
                                        ev.getDtstart(), ev.getDtend());

      Collection<BwFreeBusyComponent> times = fb.getTimes();

      if ((times != null) && !times.isEmpty()) {
        for (BwFreeBusyComponent fbc: times) {
          if (fbc.getType() != BwFreeBusyComponent.typeFree) {
            Collection<Period> periods = fbc.getPeriods();

            if ((periods != null) && !periods.isEmpty()) {
              partStat = PartStat.DECLINED.getValue();
              break;
            }
          }
        }
      }
    }

    return sched.attendeeRespond(ei,
                                 null,         // delegate
                                 "REPLY",      // method
                                 partStat,
                                 null,         // comment
                                 false,
                                 // Use preferred calendar
                                 svci.getPreferredCalendar(), // newCal
                                 sched.getMeetingCalendars(ev));
  }

  private ScheduleResult processReply(CalSvcI svci,
                                      EventInfo ei) throws CalFacadeException {
    BwPreferences prefs = svci.getUserPrefs();
    SchedulingI sched =  svci.getScheduler();
    BwEvent ev = ei.getEvent();

    int scheduleAutoProcessResponses = prefs.getScheduleAutoProcessResponses();

    /* Reply back from attendee - update our copy
     */
    if (scheduleAutoProcessResponses == BwPreferences.scheduleAutoProcessResponsesNoAction) {
      return null;
    }

    if (scheduleAutoProcessResponses == BwPreferences.scheduleAutoProcessResponsesAccepts) {
      /* Should be exactly one attendee and we only do acceptances. */
      Collection<BwAttendee> atts = ev.getAttendees();
      if ((atts == null) || (atts.size() != 1)) {
        return null;
      }

      BwAttendee att = atts.iterator().next();

      if (!att.getPartstat().equals(PartStat.ACCEPTED.getValue())) {
        return null;
      }
    }

    return sched.processResponse(ei, sched.getMeetingCalendars(ev));
  }

  private ScheduleResult processRefresh(CalSvcI svci,
                                        EventInfo ei) throws CalFacadeException {
//    BwPreferences prefs = svci.getUserPrefs();
    SchedulingI sched =  svci.getScheduler();
    BwEvent ev = ei.getEvent();

//    int scheduleAutoProcessResponses = prefs.getScheduleAutoProcessResponses();

    /* Refresh request from attendee - send our copy
     */

    /* Should be exactly one attendee. */
    Collection<BwAttendee> atts = ev.getAttendees();
    if ((atts == null) || (atts.size() != 1)) {
      return null;
    }

    BwAttendee att = atts.iterator().next();

    /* We can only do this if there is one copy */

    Collection<BwCalendar> cals = sched.getMeetingCalendars(ev);

    if ((cals == null) || (cals.size() != 1)) {
      return null;
    }

    EventInfo calEi = getEvent(svci, cals.iterator().next(), ev.getUid(),
                               ev.getRecurrenceId());
    if (calEi == null) {
      return null;
    }

    /* Just send it to the attendee. */
    ScheduleResult sr = sched.schedule(calEi, att.getAttendeeUri());

    if (sr.errorCode == null) {
      svci.deleteEvent(ev, true);
    }

    return sr;
  }

  private EventInfo getEvent(CalSvcI svci, String eventName) throws CalFacadeException {
    BwCalendar inbox = svci.getSpecialCalendar(BwCalendar.calTypeInbox, false);
    if (inbox == null) {
      return null;
    }

    RecurringRetrievalMode rrm =
      new RecurringRetrievalMode(Rmode.overrides);
    EventInfo ei = svci.getEvent(inbox, eventName, rrm);
    if (ei == null) {
      if (debug) {
        trace("autoSchedule: no event with name " + eventName);
      }
      return null;
    }

    return ei;
  }

  private EventInfo getEvent(CalSvcI svci, BwCalendar cal,
                           String guid,
                           String recurrenceId) throws CalFacadeException {
    RecurringRetrievalMode rrm =
      new RecurringRetrievalMode(Rmode.overrides);
    Collection<EventInfo> eis =  svci.getEvent(null, cal, guid, recurrenceId,
                                               rrm);
    if (CalFacadeUtil.isEmpty(eis)) {
      if (debug) {
        trace("autoSchedule: no event found");
      }
      return null;
    }

    if (eis.size() > 1) {
      return null;
    }

    return eis.iterator().next();
  }

  /* Get an svci object as a different user.
   *
   * @return CalSvcI
   * @throws WebdavException
   */
  private CalSvcI getSvci(String account) throws CalFacadeException {
    CalSvcI svci;

    String runAsUser = account;
    boolean superUser = account.equals("root");

    /* account is what we authenticated with.
     * user, if non-null, is the user calendar we want to access.
     */
    CalSvcIPars runAsPars = new CalSvcIPars(account,
                                            runAsUser,
                                            null,    // calsuite
                                            envPrefix,
                                            false,   // publicAdmin
                                            false,  // adminCanEditAllPublicCategories
                                            false,  // adminCanEditAllPublicLocations
                                            false,  // adminCanEditAllPublicSponsors
                                            true,    // caldav
                                            null, // synchId
                                            debug);
    svci = new CalSvcFactoryDefault().getSvc(runAsPars);

    if (superUser) {
      svci.setSuperUser(true);
    }

    svci.open();
    svci.beginTransaction();

    return svci;
  }

  private void closeSvci(CalSvcI svci) throws CalFacadeException {
    if ((svci == null) || !svci.isOpen()) {
      return;
    }

    svci.endTransaction();
    svci.close();
  }

  /* Get a logger for messages
   */
  private Logger getLogger() {
    if (log == null) {
      log = Logger.getLogger(this.getClass());
    }

    return log;
  }

  private void error(Throwable t) {
    getLogger().error(this, t);
  }

  private void trace(String msg) {
    getLogger().debug(msg);
  }
}
