/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/

package org.bedework.calsvc;

import org.bedework.calcorei.HibSession;
import org.bedework.calfacade.BwCalendar;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.CalFacadeDefs;
import org.bedework.calfacade.exc.CalFacadeAccessException;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.svc.BwSubscription;
import org.bedework.calfacade.svc.prefs.BwPreferences;
import org.bedework.calsvci.SubscriptionsI;

import edu.rpi.cmt.access.PrivilegeDefs;

import java.util.Collection;
import java.util.TreeSet;

/** This acts as an interface to the database for subscriptions.
 *
 * @author Mike Douglass       douglm - rpi.edu
 */
class Subscriptions extends CalSvcDb implements SubscriptionsI {
  Subscriptions(CalSvc svci, BwUser user, boolean debug) {
    super(svci, user, debug);
  }

  public void add(BwSubscription val) throws CalFacadeException {
    BwPreferences prefs = getSvc().getPreferences();
    checkOwnerOrSuper(prefs);

    getSvc().setupOwnedEntity(val, getUser());

    trace("************* add subscription " + val);
    prefs.addSubscription(val);
  }

  public BwSubscription find(String name) throws CalFacadeException {
    if (name == null) {
      return null;
    }

    Collection<BwSubscription> subs = getAll();

    for (BwSubscription sub: subs) {
      if (sub.getName().equals(name)) {
        return sub;
      }
    }

    return null;
  }

  public void delete(BwSubscription val) throws CalFacadeException {
    BwPreferences prefs = getSvc().getPreferences();
    checkOwnerOrSuper(prefs);

    Collection<BwSubscription> c = prefs.getSubscriptions();
    if (c != null) {
      c.remove(val);
    }
    //dbi.updatePreferences(prefs);
  }

  public void update(BwSubscription val) throws CalFacadeException {
    BwPreferences prefs = getSvc().getPreferences();
    BwSubscription sub = find(val.getName());

    if (sub == null) {
      throw new CalFacadeException("Unknown subscription" + val.getName());
    }

    if ((sub.getUnremoveable() != val.getUnremoveable()) &&
         !getSvc().isSuper()) {
      throw new CalFacadeAccessException();
    }

    val.copyTo(sub);
    getSvc().getPrefsHandler().update(prefs);
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SubscriptionsI#getAll()
   */
  public Collection<BwSubscription> getAll() throws CalFacadeException {
    Collection<BwSubscription> c = getSvc().getPreferences().getSubscriptions();
    if (c == null) {
      return new TreeSet<BwSubscription>();
    }

    for (BwSubscription sub: c) {
      getSubCalendar(sub, false);
    }

    return c;
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvc.CalSvcDb#get(int)
   */
  public BwSubscription get(int id) throws CalFacadeException {
    HibSession sess = getSess();

    StringBuilder sb = new StringBuilder();

    sb.append("from ");
    sb.append(BwSubscription.class.getName());
    sb.append(" sub ");
    sb.append(" where sub.id=:id");

    sess.createQuery(sb.toString());

    sess.setInt("id", id);
    sess.cacheableQuery();

    return (BwSubscription)sess.getUnique();
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SubscriptionsI#getSubCalendar(org.bedework.calfacade.svc.BwSubscription, boolean)
   */
  public BwCalendar getSubCalendar(BwSubscription val,
                                    boolean freeBusy) throws CalFacadeException {
    int desiredAccess = PrivilegeDefs.privRead;
    if (freeBusy) {
      desiredAccess = PrivilegeDefs.privReadFreeBusy;
    }

    if (!val.getInternalSubscription() || val.getCalendarDeleted()) {
      return null;
    }

    /* XXX Force refetch - hibernate gripes otherwise
    BwCalendar calendar = val.getCalendar();

    if (calendar != null) {
      // recheck access
      if (getCal().checkAccess(calendar, desiredAccess, true) == null) {
        val.setCalendar(null);
        return null;
      }
      return calendar;
    }
    */
    BwCalendar calendar;

    String path;
    String uri = val.getUri();

    if (uri.startsWith(CalFacadeDefs.bwUriPrefix)) {
      path = uri.substring(CalFacadeDefs.bwUriPrefix.length());
    } else {
      // Shouldn't happen?
      path = uri;
    }

    if (debug) {
      trace("Search for calendar \"" + path + "\"");
    }

    try {
      calendar = getSvc().getCalendar(path, desiredAccess);
    } catch (CalFacadeAccessException cfae) {
      calendar = null;
    }

    if (calendar == null) {
      /* Assume deleted - flag in the subscription if it's ours or a temp.
       */
      if ((val.getId() == CalFacadeDefs.unsavedItemKey) ||
          val.getOwner().equals(getUser())) {
        val.setCalendarDeleted(true);
        if (val.getId() != CalFacadeDefs.unsavedItemKey) {
          // Save the state
          update(val);
        }
      }
    } else {
      val.setCalendar(calendar);
    }

    return calendar;
  }
}
