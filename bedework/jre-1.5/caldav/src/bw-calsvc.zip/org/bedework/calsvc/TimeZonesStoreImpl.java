/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calsvc;

import org.bedework.calcorei.CoreEventInfo;
import org.bedework.calcorei.HibSession;
import org.bedework.calcorei.EventsI.InternalEventKey;
import org.bedework.calfacade.BwDateTime;
import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.BwTimeZone;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.TimeZoneInfo;
import org.bedework.calfacade.base.BwEventKey;
import org.bedework.calfacade.base.UpdateFromTimeZonesInfo;
import org.bedework.calfacade.base.UpdateFromTimeZonesInfo.UnknownTimezoneInfo;
import org.bedework.calfacade.exc.CalFacadeAccessException;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.timezones.CalTimezones;
import org.bedework.calfacade.util.DateTimeUtil;
import org.bedework.calsvci.TimeZonesStoreI;
import org.bedework.icalendar.IcalTranslator;

import net.fortuna.ical4j.model.Calendar;
import net.fortuna.ical4j.model.Component;
import net.fortuna.ical4j.model.DateTime;
import net.fortuna.ical4j.model.component.VTimeZone;
import net.fortuna.ical4j.model.property.LastModified;

import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

/**
 * @author douglm
 *
 */
public class TimeZonesStoreImpl implements TimeZonesStoreI {
  protected boolean debug;

  private boolean publicAdminMode;

  private BwUser publicUser;

  private boolean guestMode;

  private CalSvc svci;

  /** Current user of the system
   */
  private BwUser user;

  private transient Logger log;

  /*
   */
  TimeZonesStoreImpl(CalSvc svci, BwUser user,
                boolean publicAdminMode, BwUser publicUser,
                boolean guestMode,
                boolean debug) {
    this.svci = svci;
    this.publicAdminMode = publicAdminMode;
    this.publicUser = publicUser;
    this.guestMode = guestMode;
    this.user = user;
    this.debug = debug;
  }

  public void saveTimeZone(String tzid, VTimeZone vtz) throws CalFacadeException {
    HibSession sess = (HibSession)getSess();

    BwTimeZone tz = new BwTimeZone();

    if (guestMode) {
      throw new CalFacadeAccessException();
    }

    tz.setTzid(tzid);
    if (publicAdminMode) {
      tz.setPublick(true);
      tz.setOwner(publicUser);
    } else {
      tz.setPublick(false);
      tz.setOwner(user);
    }

    StringBuffer sb = new StringBuffer();

    sb.append("BEGIN:VCALENDAR\n");
    sb.append("PRODID:-//RPI//BEDEWORK//US\n");
    sb.append("VERSION:2.0\n");
    sb.append(vtz.toString());
    sb.append("END:VCALENDAR\n");

    tz.setVtimezone(sb.toString());

    sess.save(tz);
  }

  public VTimeZone getTimeZone(final String id, BwUser owner,
                               boolean publick) throws CalFacadeException {
    HibSession sess = (HibSession)getSess();

    if (publick ||
        (publicAdminMode) ||
        (guestMode)) {
      sess.namedQuery("getPublicTzByTzid");
    } else {
      if (owner == null) {
        owner = user;
      }
      sess.namedQuery("getTzByTzid");
      sess.setEntity("owner", owner);
    }

    sess.setString("tzid", id);

    BwTimeZone tz = (BwTimeZone)sess.getUnique();

    if (tz == null) {
      return null;
    }

    Calendar cal = IcalTranslator.getCalendar(tz.getVtimezone());

    VTimeZone vtz = (VTimeZone)cal.getComponents().getComponent(Component.VTIMEZONE);
    if (vtz == null) {
      throw new CalFacadeException("Incorrectly stored timezone");
    }

    return vtz;
  }

  @SuppressWarnings("unchecked")
  public Collection<BwTimeZone> getTimeZones() throws CalFacadeException {
    HibSession sess = (HibSession)getSess();

    if (publicAdminMode ||
        guestMode) {
      sess.namedQuery("getPublicTimezones");

      return sess.getList();
    }

    sess.namedQuery("getMergedTimezones");
    sess.setEntity("owner", user);

    return sess.getList();
  }

  @SuppressWarnings("unchecked")
  public Collection<BwTimeZone> getUserTimeZones(BwUser tzOwner) throws CalFacadeException {
    HibSession sess = (HibSession)getSess();

    if (publicAdminMode ||
        guestMode) {
      // No user timezones
      return new ArrayList<BwTimeZone>();
    }

    sess.namedQuery("getUserTimezones");
    sess.setEntity("owner", tzOwner);

    return sess.getList();
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.Calintf#getPublicTimeZoneIds()
   */
  @SuppressWarnings("unchecked")
  public Collection<String> getPublicTimeZoneIds() throws CalFacadeException {
    HibSession sess = (HibSession)getSess();

    sess.namedQuery("getPublicTimezoneIds");

    Collection<String> ids = new TreeSet<String>();
    Iterator it = sess.getList().iterator();
    while (it.hasNext()) {
      Object[] info = (Object[])it.next();
      ids.add((String)info[0]);
    }

    return ids;
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.Calintf#getPublicTimeZones()
   */
  @SuppressWarnings("unchecked")
  public Collection<BwTimeZone> getPublicTimeZones() throws CalFacadeException {
    HibSession sess = (HibSession)getSess();

    sess.namedQuery("getPublicTimezones");

    return sess.getList();
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.Calintf#clearPublicTimezones()
   */
  public void clearPublicTimezones() throws CalFacadeException {
    HibSession sess = (HibSession)getSess();

    /* Delete all public timezones */
    sess.namedQuery("deleteAllPublicTzs");
    /*int numDeleted =*/ sess.executeUpdate();
  }

  public List<TimeZoneInfo> getTimeZoneIds() throws CalFacadeException {
    HibSession sess = (HibSession)getSess();

    ArrayList<TimeZoneInfo> l = new ArrayList<TimeZoneInfo>();

    sess.namedQuery("getPublicTimezoneIds");

    Iterator it = sess.getList().iterator();

    while (it.hasNext()) {
      Object[] os = (Object[])it.next();

      String tzid = (String)os[0];

      l.add(new TimeZoneInfo(tzid, true));
    }

    if (publicAdminMode ||
        guestMode) {
      // No user timezones
      return l;
    }

    sess.namedQuery("getUserTimezoneIds");

    it = sess.getList().iterator();

    while (it.hasNext()) {
      Object[] os = (Object[])it.next();

      String tzid = (String)os[0];

      l.add(new TimeZoneInfo(tzid, false));
    }

    return l;
  }

  /** Extended info clas which has internal state information.
   *
   */
  private static class UpdateFromTimeZonesInfoInternal implements
          UpdateFromTimeZonesInfo {
    /* Event ids */
    Collection<? extends InternalEventKey> ids;
    Iterator<? extends InternalEventKey> idIterator;

    long lastmod = 0;

    int totalEventsChecked;

    int totalEventsUpdated;

    Collection<UnknownTimezoneInfo> unknownTzids = new TreeSet<UnknownTimezoneInfo>();

    Collection<BwEventKey> updatedList = new ArrayList<BwEventKey>();

    /* (non-Javadoc)
     * @see org.bedework.calfacade.base.UpdateFromTimeZonesInfo#getTotalEventsToCheck()
     */
    public int getTotalEventsToCheck() {
      return ids.size();
    }

    /* (non-Javadoc)
     * @see org.bedework.calfacade.base.UpdateFromTimeZonesInfo#getTotalEventsChecked()
     */
    public int getTotalEventsChecked() {
      return totalEventsChecked;
    }

    /* (non-Javadoc)
     * @see org.bedework.calfacade.base.UpdateFromTimeZonesInfo#getTotalEventsUpdated()
     */
    public int getTotalEventsUpdated() {
      return totalEventsUpdated;
    }

    public Collection<UnknownTimezoneInfo> getUnknownTzids() {
      return unknownTzids;
    }

    public Collection<BwEventKey> getUpdatedList() {
      return updatedList;
    }

    public String toString() {
      StringBuffer sb = new StringBuffer();

      sb.append("------------------------------------------");
      sb.append("\nUpdateFromTimeZonesInfoInternal:");
      sb.append("\ntotalEventsToCheck: ");
      sb.append(getTotalEventsToCheck());
      sb.append("\ntotalEventsChecked: ");
      sb.append(totalEventsChecked);
      sb.append("\ntotalEventsUpdated: ");
      sb.append(totalEventsUpdated);
      sb.append("\n------------------------------------------");

      return sb.toString();
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.Calintf#updateFromTimeZones(int, boolean, org.bedework.calfacade.base.UpdateFromTimeZonesInfo)
   */
  public UpdateFromTimeZonesInfo updateFromTimeZones(int limit,
                                                     boolean checkOnly,
                                                     UpdateFromTimeZonesInfo info
                                                     ) throws CalFacadeException {
    /* Versions < 3.3 don't have recurrences fully implemented so we'll
     * ignore those.
     *
     * Fields that could be affected:
     * Event start + end
     * rdates and exdates
     * Recurrence instances
     *
     */
    if ((info != null) && !(info instanceof UpdateFromTimeZonesInfoInternal)) {
      throw new CalFacadeException(CalFacadeException.illegalObjectClass);
    }

    boolean redo = false;

    UpdateFromTimeZonesInfoInternal iinfo;

    if (info != null) {
      if (info.getTotalEventsToCheck() == info.getTotalEventsChecked()) {
        redo = true;
      }

      iinfo = (UpdateFromTimeZonesInfoInternal)info;
    } else {
      iinfo = new UpdateFromTimeZonesInfoInternal();
    }

    if (redo || (iinfo.ids == null)) {
      String lastmod = null;

      if (redo) {
        lastmod = new LastModified(new DateTime(iinfo.lastmod - 5000)).getValue();
      }
      // Get event ids from db.
      iinfo.lastmod = System.currentTimeMillis();
      iinfo.ids = svci.getEventKeysForTzupdate(lastmod);

      if (iinfo.ids == null) {
        iinfo.ids = new ArrayList<InternalEventKey>();
      }

      iinfo.totalEventsChecked = 0;
      iinfo.totalEventsUpdated = 0;
      iinfo.idIterator = iinfo.ids.iterator();
    }

    CalTimezones tzs = svci.getTimezones();

    for (int i = 0; i < limit; i++) {
      if (!iinfo.idIterator.hasNext()) {
        break;
      }

      InternalEventKey ikey = iinfo.idIterator.next();

      // See if event needs update
      BwUser owner = ikey.getOwner();

      BwDateTime start = checkDateTimeForTZ(ikey.getStart(), owner, iinfo, tzs);
      BwDateTime end = checkDateTimeForTZ(ikey.getEnd(), owner, iinfo, tzs);

      if ((start != null) || (end != null)) {
        CoreEventInfo cei = svci.getEvent(ikey);
        BwEvent ev = cei.getEvent();

        if (cei != null) {
          iinfo.updatedList.add(new BwEventKey(ev.getCalendar().getPath(),
                                               ev.getUid(),
                                               ev.getRecurrenceId(),
                                               ev.getName(),
                                               ev.getRecurring()));
          if (!checkOnly) {
            if (start != null) {
              BwDateTime evstart = ev.getDtstart();
              if (debug) {
                trace("Updated start: ev.tzid=" + evstart.getTzid() +
                      " ev.dtval=" + evstart.getDtval() +
                      " ev.date=" + evstart.getDate() +
                      " newdate=" + start.getDate());
              }
              evstart.setDate(start.getDate());
            }
            if (end != null) {
              BwDateTime evend = ev.getDtend();
              if (debug) {
                trace("Updated end: ev.tzid=" + evend.getTzid() +
                      " ev.dtval=" + evend.getDtval() +
                      " ev.date=" + evend.getDate() +
                      " newdate=" + end.getDate());
              }
              evend.setDate(end.getDate());
            }
            svci.updateEvent(ev, null, null);
            iinfo.totalEventsUpdated++;
          }
        }
      }

      iinfo.totalEventsChecked++;
    }

    if (debug) {
      trace(iinfo.toString());
    }

    return iinfo;
  }

  /* Recalculate UTC for the given value.
   *
   * Return null if no change needed otherwise return new value
   */
  private BwDateTime checkDateTimeForTZ(BwDateTime val,
                                        BwUser owner,
                                        UpdateFromTimeZonesInfoInternal iinfo,
                                        CalTimezones timezones) throws CalFacadeException {
    if (val.getDateType()) {
      return null;
    }

    if (val.isUTC()) {
      return null;
    }

    if (val.getFloating()) {
      return null;
    }

    try {
      BwDateTime newVal = DateTimeUtil.getDateTime(val.getDtval(), false, false,
                                                   false, val.getTzid(),
                                                   val.getTzowner(),
                                                   timezones);

      if (newVal.getDate().equals(val.getDate())) {
        return null;
      }

      return newVal;
    } catch (CalFacadeException cfe) {
      if (cfe.getMessage().equals(CalFacadeException.unknownTimezone)) {
        iinfo.unknownTzids.add(new UnknownTimezoneInfo(owner, val.getTzid()));
        return null;
      }
      throw cfe;
    }
  }

  /* Get the current db session
   *
   * @return Object
   */
  private HibSession getSess() throws CalFacadeException {
    return (HibSession)svci.getDbSession();
  }

  /* Get a logger for messages
   */
  private Logger getLogger() {
    if (log == null) {
      log = Logger.getLogger(this.getClass());
    }

    return log;
  }

  private void trace(String msg) {
    getLogger().debug("trace: " + msg);
  }
}
