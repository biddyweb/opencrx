/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calsvc.indexing;

import org.bedework.calfacade.BwCalendar;
import org.bedework.calfacade.BwCategory;
import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.BwLocation;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.exc.CalFacadeException;

import edu.rpi.cct.misc.indexing.Index;
import edu.rpi.cct.misc.indexing.IndexException;
import edu.rpi.cct.misc.indexing.IndexLuceneImpl;
import edu.rpi.cct.misc.indexing.SearchLimits;

import org.apache.lucene.document.Document;
import org.apache.lucene.index.Term;
import org.apache.lucene.misc.ChainedFilter;
import org.apache.lucene.search.Filter;
import org.apache.lucene.search.RangeFilter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

/**
 * @author Mike Douglass douglm @ rpi.edu
 *
 */
public class BwIndexLuceneImpl extends IndexLuceneImpl implements BwIndexer {
  private BwIndexKey keyConverter = new BwIndexKey();

  /* Used to batch index */
  private ArrayList<Object> batch;
  private int batchSize = 0;

  /** Constructor
   *
   * @param sysfilePath - Path for the index files - must exist
   * @param writeable
   * @param debug
   * @throws IndexException
   */
  public BwIndexLuceneImpl(String sysfilePath,
                           boolean writeable,
                           boolean debug) throws IndexException {
    super(sysfilePath,
          BwIndexLuceneDefs.defaultFieldInfo.getName(),
          writeable, debug);
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvc.indexing.BwIndexer#setBatchSize(int)
   */
  public void setBatchSize(int val) {
    batchSize = val;
    if (batchSize > 1) {
      batch = new ArrayList<Object>();
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvc.indexing.BwIndexer#endBwBatch()
   */
  public void endBwBatch() throws CalFacadeException {
    try {
      endBatch();
    } catch (IndexException ie) {
      throw new CalFacadeException(ie);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvc.indexing.BwIndexer#flush()
   */
  public void flush() throws CalFacadeException {
    if ((batch == null) || (batch.size() == 0)) {
      return;
    }

    Object[] recs = batch.toArray();
    try {
      indexNewRecs(recs);
    } catch (IndexException ie) {
      if (ie.getMessage().equals(IndexException.noFiles)) {
        // Retry after create
        try {
          create();
          indexNewRecs(recs);
        } catch (Throwable t) {
          throw new CalFacadeException(t);
        }
      }
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }

    batch.clear();
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvc.indexing.BwIndexer#getKeys(int, edu.rpi.cct.misc.indexing.Index.Key[])
   */
  public int getKeys(int n, Index.Key[] keys) throws CalFacadeException {
    try {
      return retrieve(n, keys);
    } catch (IndexException ie) {
      throw new CalFacadeException(ie);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvc.indexing.BwIndexer#indexEntity(java.lang.Object)
   */
  public void indexEntity(Object rec) throws CalFacadeException {
    try {
      if (batchSize > 1) {
        if (batch.size() == batchSize) {
          flush();
        }

        batch.add(makeRec(rec));
        return;
      }
      indexRec(rec);
    } catch (IndexException ie) {
      if (ie.getMessage().equals(IndexException.noFiles)) {
        // Retry after create
        try {
          create();
          indexRec(rec);
        } catch (Throwable t) {
          throw new CalFacadeException(t);
        }
      } else {
        throw new CalFacadeException(ie);
      }
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvc.indexing.BwIndexer#unindexEntity(java.lang.Object)
   */
  public void unindexEntity(Object rec) throws CalFacadeException {
    try {
      unindexRec(rec);
    } catch (IndexException ie) {
      if (ie.getMessage().equals(IndexException.noFiles)) {
        // Ignore
      }
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvc.indexing.BwIndexer#search(java.lang.String, edu.rpi.cct.misc.indexing.SearchLimits)
   */
  public int search(String query, SearchLimits limits) throws CalFacadeException {
    Filter filter = null;

    try {
      if (limits != null) {
        RangeFilter from = null;
        RangeFilter to = null;

        if (limits.fromDate != null) {
          from = RangeFilter.More(BwIndexLuceneDefs.startDate.getName(),
                                  limits.fromDate);
        }

        if (limits.toDate != null) {
          to = RangeFilter.Less(BwIndexLuceneDefs.startDate.getName(),
                                limits.toDate);
        }

        if ((from != null) && (to != null)) {
          filter = new ChainedFilter(new Filter[] {from, to}, ChainedFilter.AND);
        } else if (from != null) {
          filter = from;
        } else if (to != null) {
          filter = to;
        }
      }

      return search(query, filter);
    } catch (IndexException ie) {
      throw new CalFacadeException(ie);
    }
  }

  /** Called to make or fill in a Key object.
   *
   * @param key   Possible Index.Key object for reuse
   * @param doc   The retrieved Document
   * @param score The rating for this entry
   * @return Index.Key  new or reused object
   */
  public Index.Key makeKey(Index.Key key,
                           Document doc,
                           float score) throws IndexException {
    if ((key == null) || (!(key instanceof BwIndexKey))) {
      key = new BwIndexKey();
    }

    BwIndexKey bwkey = (BwIndexKey)key;

    bwkey.setScore(score);

    String itemType = doc.get(BwIndexLuceneDefs.itemTypeInfo.getName());
    bwkey.setItemType(itemType);

    if (itemType == null) {
      throw new IndexException("org.bedework.index.noitemtype");
    }

    if (itemType.equals(BwIndexLuceneDefs.itemTypeCalendar)) {
      bwkey.setCalendarKey(doc.get(BwIndexLuceneDefs.keyCalendar.getName()));
    } else if (itemType.equals(BwIndexLuceneDefs.itemTypeEvent)) {
      bwkey.setEventKey(doc.get(BwIndexLuceneDefs.keyEvent.getName()));
    } else {
      throw new IndexException(IndexException.unknownRecordType,
                               itemType);
    }

    return key;
  }

  /** Called to make a key term for a record.
   *
   * @param   rec      The record
   * @return  Term     Lucene term which uniquely identifies the record
   */
  public Term makeKeyTerm(Object rec) throws IndexException {
    String name = makeKeyName(rec);
    String key = makeKeyVal(rec);

    return new Term(name, key);
  }

  /** Called to make a key value for a record.
   *
   * @param   rec      The record
   * @return  String   String which uniquely identifies the record
   * @throws IndexException
   */
  public String makeKeyVal(Object rec) throws IndexException {
    if (rec instanceof BwCalendar) {
      return ((BwCalendar)rec).getPath();
    }

    if (rec instanceof BwEvent) {
      BwEvent ev = (BwEvent)rec;

      String path = ev.getCalendar().getPath();
      String guid = ev.getUid();
      String recurid = ev.getRecurrenceId();

      return keyConverter.makeEventKey(path, guid, recurid);
    }

    throw new IndexException(IndexException.unknownRecordType,
                             rec.getClass().getName());
  }

  /** Called to make the primary key name for a record.
   *
   * @param   rec      The record
   * @return  String   Name for the field/term
   * @throws IndexException
   */
  public String makeKeyName(Object rec) throws IndexException {
    if (rec instanceof BwCalendar) {
      return BwIndexLuceneDefs.keyCalendar.getName();
    }

    if (rec instanceof BwEvent) {
      return BwIndexLuceneDefs.keyEvent.getName();
    }

    throw new IndexException(IndexException.unknownRecordType,
                             rec.getClass().getName());
  }

  private static class IndexField implements Serializable {
    FieldInfo finfo;
    String val;

    IndexField(FieldInfo finfo,
               String val) {
      this.finfo = finfo;
      this.val = val;
    }
  }

  private static class Rec implements Serializable {
    Collection<IndexField> fields = new ArrayList<IndexField>();

    void addField(FieldInfo finfo,
                  String val) {
      fields.add(new IndexField(finfo, val));
    }
  }

  /** Called to create a rec from an object.
   *
   * @param o     Object to be indexed
   * @return Rec
   * @throws IndexException
   */
  public Rec makeRec(Object o) throws IndexException {
    if (o == null) {
      return null;
    }

    Rec rec = new Rec();

    BwCalendar calendar = null;
    Collection <BwCategory> cats = null;
    String created = null;
    BwUser creator = null;
    String description = null;
    String lastmod = null;
    BwUser owner = null;
    String summary = null;

    String start = null;
    String end = null;

    if (o instanceof BwCalendar) {
      BwCalendar cal = (BwCalendar)o;

      rec.addField(BwIndexLuceneDefs.itemTypeInfo,
                   BwIndexLuceneDefs.itemTypeCalendar);

      /* Path is the key */
      rec.addField(BwIndexLuceneDefs.calendarPath, cal.getPath());

      calendar = cal.getCalendar();
      cats = cal.getCategories();
      created = cal.getCreated();
      creator = cal.getCreator();
      description = cal.getDescription();
      lastmod = cal.getLastmod();
      owner = cal.getOwner();
      summary = cal.getSummary();
    } else if (o instanceof BwEvent) {
      BwEvent ev = (BwEvent)o;

      rec.addField(BwIndexLuceneDefs.itemTypeInfo,
                   BwIndexLuceneDefs.itemTypeEvent);

      rec.addField(BwIndexLuceneDefs.keyEvent, makeKeyVal(ev));

      BwLocation loc = ev.getLocation();
      if (loc != null) {
        if (loc.getAddress() != null) {
          rec.addField(BwIndexLuceneDefs.location, loc.getAddress().getValue());
        }
        if (loc.getSubaddress() != null) {
          rec.addField(BwIndexLuceneDefs.location, loc.getSubaddress().getValue());
        }
      }

      calendar = ev.getCalendar();
      cats = ev.getCategories();
      created = ev.getCreated();
      creator = ev.getCreator();
      description = ev.getDescription();
      lastmod = ev.getLastmod();
      owner = ev.getOwner();
      summary = ev.getSummary();

      if (!ev.getNoStart()) {
        start = ev.getDtstart().getDate();
      }

      if (ev.getDtend() != null) {
        end = ev.getDtend().getDtval();
      }
    } else {
      throw new IndexException(IndexException.unknownRecordType,
                               o.getClass().getName());
    }

    if (calendar != null) {
      rec.addField(BwIndexLuceneDefs.calendar, calendar.getPath());
    }

    if (cats != null) {
      for (BwCategory cat: cats) {
        rec.addField(BwIndexLuceneDefs.category, cat.getWord().getValue());
      }
    }

    rec.addField(BwIndexLuceneDefs.created, created);
    rec.addField(BwIndexLuceneDefs.creator, creator.getAccount());
    rec.addField(BwIndexLuceneDefs.description, description);
    rec.addField(BwIndexLuceneDefs.lastmod, lastmod);
    rec.addField(BwIndexLuceneDefs.owner, owner.getAccount());
    rec.addField(BwIndexLuceneDefs.summary, summary);

    rec.addField(BwIndexLuceneDefs.startDate, start.substring(0, 8));
    rec.addField(BwIndexLuceneDefs.endDate, end.substring(0, 8));
    rec.addField(BwIndexLuceneDefs.dueDate, end.substring(0, 8));

    return rec;
  }

  /** Called to fill in a Document from an object.
   *
   * @param doc   The Document
   * @param o     Object to be indexed
   */
  public void addFields(Document doc,
                        Object o) throws IndexException {
    if (o == null) {
      System.out.println("Tried to index null record");
      return;
    }

    if (o instanceof Rec) {
      Rec r = (Rec)o;

      for (IndexField f: r.fields) {
        addVal(doc, f.finfo, f.val);
      }

      return;
    }

    BwCalendar calendar = null;
    Collection <BwCategory> cats = null;
    String created = null;
    BwUser creator = null;
    String description = null;
    String lastmod = null;
    BwUser owner = null;
    String summary = null;

    String start = null;
    String end = null;

    if (o instanceof BwCalendar) {
      BwCalendar cal = (BwCalendar)o;

      addField(doc, BwIndexLuceneDefs.itemTypeInfo,
               BwIndexLuceneDefs.itemTypeCalendar);

      /* Path is the key */
      addField(doc, BwIndexLuceneDefs.calendarPath, cal.getPath());

      calendar = cal.getCalendar();
      cats = cal.getCategories();
      created = cal.getCreated();
      creator = cal.getCreator();
      description = cal.getDescription();
      lastmod = cal.getLastmod();
      owner = cal.getOwner();
      summary = cal.getSummary();
    } else if (o instanceof BwEvent) {
      BwEvent ev = (BwEvent)o;

      addField(doc, BwIndexLuceneDefs.itemTypeInfo,
               BwIndexLuceneDefs.itemTypeEvent);

      addField(doc, BwIndexLuceneDefs.keyEvent, makeKeyVal(ev));

      BwLocation loc = ev.getLocation();
      if (loc != null) {
        if (loc.getAddress() != null) {
          addVal(doc, BwIndexLuceneDefs.location, loc.getAddress().getValue());
        }
        if (loc.getSubaddress() != null) {
          addVal(doc, BwIndexLuceneDefs.location, loc.getSubaddress().getValue());
        }
      }

      calendar = ev.getCalendar();
      cats = ev.getCategories();
      created = ev.getCreated();
      creator = ev.getCreator();
      description = ev.getDescription();
      lastmod = ev.getLastmod();
      owner = ev.getOwner();
      summary = ev.getSummary();

      if (!ev.getNoStart()) {
        start = ev.getDtstart().getDate();
      }

      if (ev.getDtend() != null) {
        end = ev.getDtend().getDtval();
      }
    } else {
      throw new IndexException(IndexException.unknownRecordType,
                               o.getClass().getName());
    }

    if (calendar != null) {
      addVal(doc, BwIndexLuceneDefs.calendar, calendar.getPath());
    }
    indexCategories(doc, cats);
    addVal(doc, BwIndexLuceneDefs.created, created);
    addVal(doc, BwIndexLuceneDefs.creator, creator.getAccount());
    addVal(doc, BwIndexLuceneDefs.description, description);
    addVal(doc, BwIndexLuceneDefs.lastmod, lastmod);
    addVal(doc, BwIndexLuceneDefs.owner, owner.getAccount());
    addVal(doc, BwIndexLuceneDefs.summary, summary);

    addDate(doc, BwIndexLuceneDefs.startDate, start);
    addDate(doc, BwIndexLuceneDefs.endDate, end);
    addDate(doc, BwIndexLuceneDefs.dueDate, end);
  }

  /** Called to return an array of valid term names.
   *
   * @return  String[]   term names
   */
  public String[] getTermNames() {
    return BwIndexLuceneDefs.getTermNames();
  }

  private void indexCategories(Document doc,
                               Collection <BwCategory> cats) throws IndexException {
    if (cats == null) {
      return;
    }

    for (BwCategory cat: cats) {
      addVal(doc, BwIndexLuceneDefs.category, cat.getWord().getValue());
    }
  }

  private void addVal(Document doc,
                      FieldInfo fld,
                      String val) throws IndexException {
    if (val == null) {
      return;
    }
    addField(doc, fld, val);
    addField(doc, BwIndexLuceneDefs.defaultFieldInfo, val);
  }

  private void addDate(Document doc,
                       FieldInfo fld,
                       String val) throws IndexException {
     if (val == null) {
       return;
     }

     val = val.substring(0, 8); // Date part only
     addVal(doc, fld, val);
  }
}
