/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calsvc;

import org.bedework.calcorei.Calintf;
import org.bedework.calcorei.CalintfFactory;
import org.bedework.calcorei.CoreEventInfo;
import org.bedework.calcorei.CalendarsI.GetSpecialCalendarResult;
import org.bedework.calfacade.BwStats.StatsEntry;
import org.bedework.calfacade.RecurringRetrievalMode.Rmode;
import org.bedework.calfacade.base.BwDbentity;
import org.bedework.calfacade.base.BwOwnedDbentity;
import org.bedework.calfacade.base.BwShareableDbentity;
import org.bedework.calfacade.base.UpdateFromTimeZonesInfo;
import org.bedework.calfacade.BwAlarm;
import org.bedework.calfacade.BwCalendar;
import org.bedework.calfacade.BwCategory;
import org.bedework.calfacade.BwDateTime;
import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.BwEventAnnotation;
import org.bedework.calfacade.BwEventProxy;
import org.bedework.calfacade.BwFreeBusy;
import org.bedework.calfacade.BwLocation;
import org.bedework.calfacade.BwContact;
import org.bedework.calfacade.BwStats;
import org.bedework.calfacade.BwString;
import org.bedework.calfacade.BwSystem;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.BwUserInfo;
import org.bedework.calfacade.CalFacadeDefs;
import org.bedework.calfacade.RecurringRetrievalMode;
import org.bedework.calfacade.env.CalEnvFactory;
import org.bedework.calfacade.env.CalEnvI;
import org.bedework.calfacade.exc.CalFacadeAccessException;
import org.bedework.calfacade.exc.CalFacadeDupNameException;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.filter.BwFilter;
import org.bedework.calfacade.ifs.Directories;
import org.bedework.calfacade.mail.MailerIntf;
import org.bedework.calfacade.svc.BwAdminGroup;
import org.bedework.calfacade.svc.BwAuthUser;
import org.bedework.calfacade.svc.BwCalSuite;
import org.bedework.calfacade.svc.BwSubscription;
import org.bedework.calfacade.svc.BwView;
import org.bedework.calfacade.svc.EventInfo;
import org.bedework.calfacade.svc.UserAuth;
import org.bedework.calfacade.svc.prefs.BwCommonUserPrefs;
import org.bedework.calfacade.svc.prefs.BwPreferences;
import org.bedework.calfacade.svc.prefs.CalendarPref;
import org.bedework.calfacade.svc.prefs.CategoryPref;
import org.bedework.calfacade.svc.prefs.LocationPref;
import org.bedework.calfacade.svc.prefs.ContactPref;
import org.bedework.calfacade.svc.wrappers.BwCalSuiteWrapper;
import org.bedework.calfacade.syncml.BwSynchInfo;
import org.bedework.calfacade.syncml.BwSynchState;
import org.bedework.calfacade.timezones.CalTimezones;
import org.bedework.calfacade.util.CalFacadeUtil;
import org.bedework.calfacade.util.ChangeTable;
import org.bedework.calsvc.indexing.BwIndexKey;
import org.bedework.calsvc.indexing.BwIndexer;
import org.bedework.calsvc.indexing.BwIndexerFactory;
import org.bedework.calsvci.BwIndexSearchResultEntry;
import org.bedework.calsvci.CalSvcI;
import org.bedework.calsvci.CalSvcIPars;
import org.bedework.calsvci.SchedulingI;
import org.bedework.icalendar.IcalCallback;
import org.bedework.icalendar.TimeZoneRegistryImpl;
import org.bedework.icalendar.URIgen;

import edu.rpi.cct.misc.indexing.Index;
import edu.rpi.cct.misc.indexing.IndexException;
import edu.rpi.cct.misc.indexing.SearchLimits;
import edu.rpi.cct.uwcal.resources.Resources;
import edu.rpi.cmt.access.Ace;
import edu.rpi.cmt.access.AceWho;
import edu.rpi.cmt.access.PrincipalInfo;
import edu.rpi.cmt.access.PrivilegeDefs;
import edu.rpi.cmt.access.Acl.CurrentAccess;

import net.fortuna.ical4j.model.component.VTimeZone;
import net.fortuna.ical4j.model.TimeZone;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.TreeSet;

import org.apache.log4j.Logger;

/** This is an implementation of the service level interface to the calendar
 * suite.
 *
 * @author Mike Douglass       douglm@rpi.edu
 */
public class CalSvc extends CalSvcI {
  private String systemName;

  private CalSvcIPars pars;

  transient private BwIndexer publicIndexer;

  transient private BwIndexer userIndexer;

  // XXX - transient might cause intermittent problems
  /* Has to be transient otherwise the session is not serializable.
   * However, we need the inder object to retrieve the search result.
   *
   * Reimplement with a serializable object which allows us to redo the query
   * if we lose the indexer.
   */
  transient private BwIndexer searchIndexer;

  private boolean indexing = true;

  private boolean debug;

  private boolean open;

  private boolean superUser;

  private MailerIntf mailer;

  //private BwFilter currentFilter;

  /* The account that owns public entities
   */
  private BwUser publicUser;

  private BwCalSuiteWrapper currentCalSuite;

  // Set up by call to getCal()
  private String publicUserAccount;

  private BwView currentView;

  private Collection<BwSubscription> currentSubscriptions;

  /** Used to see if applications need to force a refresh
   */
  private long publicLastmod;

  /** Core calendar interface
   */
  private transient Calintf cali;

  /** Db interface for our own data structures.
   */
  private CalSvcDb dbi;

  /** handles timezone info.
   */
  private CalTimezones timezones;

  /** The user authorisation object
   */
  private UserAuth userAuth;

  private transient UserAuth.CallBack uacb;

  private transient Directories.CallBack gcb;

  private Scheduling sched;

  /* If we're doing admin this is the authorised user entry
   */
  BwAuthUser adminUser;

  /** Class used by UseAuth to do calls into CalSvci
   *
   */
  public static class UserAuthCallBack extends UserAuth.CallBack {
    CalSvc svci;

    UserAuthCallBack(CalSvc svci) {
      this.svci = svci;
    }

    public BwUser getUser(String account) throws CalFacadeException {
      return svci.getCal().getUser(account);
    }

    public void addUser(BwUser user) throws CalFacadeException {
      svci.addUser(user);
    }

    public UserAuth getUserAuth() throws CalFacadeException {
      return svci.getUserAuth();
    }

    /* (non-Javadoc)
     * @see org.bedework.calfacade.svc.UserAuth.CallBack#getDbSession()
     */
    public Object getDbSession() throws CalFacadeException {
      return svci.getCal().getDbSession();
    }
  }

  /** Class used by groups implementations for calls into CalSvci
   *
   */
  public static class GroupsCallBack extends Directories.CallBack {
    CalSvc svci;

    GroupsCallBack(CalSvc svci) {
      this.svci = svci;
    }

    public String getSysid() throws CalFacadeException {
      return svci.getSysid();
    }

    public BwUser getUser(String account) throws CalFacadeException {
      return svci.getCal().getUser(account);
    }

    public BwUser getCurrentUser() throws CalFacadeException {
      return svci.getUser();
    }

    /* (non-Javadoc)
     * @see org.bedework.calfacade.svc.UserAuth.CallBack#getDbSession()
     */
    public Object getDbSession() throws CalFacadeException {
      return svci.getCal().getDbSession();
    }
  }

  /** The user groups object.
   */
  private Directories userGroups;

  /** The admin groups object.
   */
  private Directories adminGroups;

  /* The mailer object.
   */
  //private MailerIntf mailer;

  private IcalCallback icalcb;

  /* These are only relevant for the public admin client.
   */
  //private boolean adminAutoDeleteSponsors;
  //private boolean adminAutoDeleteLocations;

  private transient Logger log;

  private CalEnvI env;

  private Resources res = new Resources();

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#init(org.bedework.calsvci.CalSvcIPars)
   */
  public void init(CalSvcIPars parsParam) throws CalFacadeException {
    pars = (CalSvcIPars)parsParam.clone();

    fixUsers();

    debug = pars.getDebug();

    env = CalEnvFactory.getEnv(pars.getEnvPrefix(), debug);
    systemName = env.getGlobalProperty("system.name");

    //if (userAuth != null) {
    //  userAuth.reinitialise(getUserAuthCallBack());
    //}

    try {
      open();
      beginTransaction();

      if (userGroups != null) {
        userGroups.init(getGroupsCallBack());
      }

      if (adminGroups != null) {
        adminGroups.init(getGroupsCallBack());
      }

      try {
        timezones = getCal().getTimezonesHandler();

        /* Nominate our timezone registry */
        System.setProperty("net.fortuna.ical4j.timezone.registry",
        "org.bedework.icalendar.TimeZoneRegistryFactoryImpl");

//        if (pars.getCaldav() && !pars.isGuest()) {
        if (!pars.isGuest()) {
          /* Ensure scheduling resources exist */
          getCal().getSpecialCalendar(getUser(), BwCalendar.calTypeInbox,
                                      true, PrivilegeDefs.privRead);

          getCal().getSpecialCalendar(getUser(), BwCalendar.calTypeOutbox,
                                      true, PrivilegeDefs.privRead);
        }
      } catch (CalFacadeException cfe) {
        cfe.printStackTrace();
        throw cfe;
      } catch (Throwable t) {
        t.printStackTrace();
        throw new CalFacadeException(t);
      }
    } finally {
      try {
        endTransaction();
      } catch (Throwable t1) {}
      try {
        close();
      } catch (Throwable t2) {}
    }
  }

  public void setSuperUser(boolean val) throws CalFacadeException {
    superUser = val;
    getCal().setSuperUser(val);
  }

  public boolean getSuperUser() {
    return superUser;
  }

  public BwStats getStats() throws CalFacadeException {
    //if (!pars.getPublicAdmin()) {
    //  throw new CalFacadeAccessException();
   // }

    return getCal().getStats();
  }

  public void setDbStatsEnabled(boolean enable) throws CalFacadeException {
    //if (!pars.getPublicAdmin()) {
    //  throw new CalFacadeAccessException();
    //}

    getCal().setDbStatsEnabled(enable);
  }

  public boolean getDbStatsEnabled() throws CalFacadeException {
    return getCal().getDbStatsEnabled();
  }

  public void dumpDbStats() throws CalFacadeException {
    //if (!pars.getPublicAdmin()) {
    //  throw new CalFacadeAccessException();
    //}

    trace(getStats().toString());
    getCal().dumpDbStats();
  }

  public Collection<StatsEntry> getDbStats() throws CalFacadeException {
    //if (!pars.getPublicAdmin()) {
    //  throw new CalFacadeAccessException();
    //}

    return getCal().getDbStats();
  }

  public BwSystem getSyspars() throws CalFacadeException {
    return getCal().getSyspars(systemName);
  }

  public void updateSyspars(BwSystem val) throws CalFacadeException {
    if (!isSuper()) {
      throw new CalFacadeAccessException();
    }
    getCal().updateSyspars(val);
  }

  public void logStats() throws CalFacadeException {
    logIt(getStats().toString());
  }

  public void setUser(String val) throws CalFacadeException {
    getCal().setUser(val);
    dbi.setUser(findUser(val, false));
  }

  public BwUser findUser(String val, boolean create) throws CalFacadeException {
    if (val.endsWith("/")) {
      val = val.substring(0, val.length() - 1);
    }
    BwUser u = getCal().getUser(val);
    if ((u == null) && create) {
      u = new BwUser(val);
      addUser(u);
    }

    return u;
  }

  public void addUser(BwUser user) throws CalFacadeException {
    getCal().addUser(user);
    initUser(getCal().getUser(user.getAccount()), getCal());
  }

  public void flushAll() throws CalFacadeException {
    getCal().flushAll();
  }

  public void open() throws CalFacadeException {
    open = true;
    TimeZoneRegistryImpl.setThreadCb(getIcalCallback());
    getCal().open();
    dbi.open();
  }

  public boolean isOpen() {
    return open;
  }

  public void close() throws CalFacadeException {
    open = false;
    getCal().close();
    dbi.close();

    if (sched != null) {
      sched.processAutoResponses();
    }
  }

  public void beginTransaction() throws CalFacadeException {
    getCal().beginTransaction();
  }

  public void endTransaction() throws CalFacadeException {
    getCal().endTransaction();
  }

  public void rollbackTransaction() throws CalFacadeException {
    getCal().rollbackTransaction();
  }

  public void reAttach(BwDbentity val) throws CalFacadeException {
    getCal().reAttach(val);
  }

  public IcalCallback getIcalCallback() {
    if (icalcb == null) {
      icalcb = new IcalCallbackcb();
    }

    return icalcb;
  }

  public String getEnvProperty(String name) throws CalFacadeException {
    return env.getProperty(name);
  }

   public Resources getResources() {
     return res;
   }

  public String getSysid() throws CalFacadeException {
    return getCal().getSysid();
  }

  public boolean refreshNeeded() throws CalFacadeException {
    /* See if the events were updated */
    long lastmod;

    lastmod = getCal().getPublicLastmod();

    if (lastmod == publicLastmod) {
      return false;
    }

    publicLastmod = lastmod;
    return true;
  }

  /* ====================================================================
   *                   Factory methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#getMailer()
   */
  public MailerIntf getMailer() throws CalFacadeException {
    if (mailer != null) {
      return mailer;
    }

    try {
      mailer = (MailerIntf)CalFacadeUtil.getObject(getSyspars().getMailerClass(),
                                                   MailerIntf.class);
      mailer.init(debug);
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }

    return mailer;
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#getScheduler()
   */
  public SchedulingI getScheduler() throws CalFacadeException {
    if (sched == null) {
      sched = new Scheduling(this, pars.getEnvPrefix(), debug);
    }

    return sched;
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#getDirectories()
   */
  public Directories getDirectories() throws CalFacadeException {
    if (isPublicAdmin()) {
      return getAdminDirectories();
    }

    return getUserDirectories();
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#getUserDirectories()
   */
  public Directories getUserDirectories() throws CalFacadeException {
    if (userGroups != null) {
      return userGroups;
    }

    try {
      userGroups = (Directories)CalFacadeUtil.getObject(getSyspars().getUsergroupsClass(), Directories.class);
      userGroups.init(getGroupsCallBack());
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }

    return userGroups;
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#getAdminDirectories()
   */
  public Directories getAdminDirectories() throws CalFacadeException {
    if (adminGroups != null) {
      return adminGroups;
    }

    try {
      adminGroups = (Directories)CalFacadeUtil.getObject(getSyspars().getAdmingroupsClass(), Directories.class);
      adminGroups.init(getGroupsCallBack());
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }

    return adminGroups;
  }

  /* ====================================================================
   *                   Users and accounts
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#getUser()
   */
  public BwUser getUser() throws CalFacadeException {
    if (pars.isGuest()) {
      return getPublicUser();
    }

    return getCal().getUser();
  }

  public Collection<BwUser> getInstanceOwners() throws CalFacadeException {
    return getCal().getInstanceOwners();
  }

  private BwUser getPublicUser() throws CalFacadeException {
    if (publicUser == null) {
      publicUser = getCal().getUser(publicUserAccount);
    }

    if (publicUser == null) {
      throw new CalFacadeException("No guest user proxy account - expected " + publicUserAccount);
    }

    return publicUser;
  }

  public UserAuth getUserAuth(String user, Object par) throws CalFacadeException {
    if (userAuth != null) {
      //userAuth.reinitialise(getUserAuthCallBack());
      return userAuth;
    }

    try {
      userAuth = (UserAuth)CalFacadeUtil.getObject(getSyspars().getUserauthClass(),
                                                  UserAuth.class);
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }

    userAuth.initialise(user, getUserAuthCallBack(), par, debug);

    return userAuth;
  }

  public UserAuth getUserAuth() throws CalFacadeException {
    if (userAuth != null) {
      //userAuth.reinitialise(getUserAuthCallBack());
      return userAuth;
    }

    return getUserAuth(pars.getUser(), null);
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#getDirInfo(java.lang.String)
   */
  public BwUserInfo getDirInfo(String account) throws CalFacadeException {
    return getDirectories().getDirInfo(account);
  }

  /* ====================================================================
   *                   Preferences
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#getUserPrefs()
   */
  public BwPreferences getUserPrefs() throws CalFacadeException {
    return getPreferences();
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#getUserPrefs(org.bedework.calfacade.BwUser)
   */
  public BwPreferences getUserPrefs(BwUser user) throws CalFacadeException {
    return dbi.fetchPreferences(user);
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#updateUserPrefs(org.bedework.calfacade.svc.prefs.BwPreferences)
   */
  public void updateUserPrefs(BwPreferences  val) throws CalFacadeException {
    dbi.updatePreferences(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#updatePrefs(boolean, org.bedework.calfacade.BwCalendar, org.bedework.calfacade.BwCategory, org.bedework.calfacade.BwLocation, org.bedework.calfacade.BwContact)
   */
  public void updatePrefs(boolean remove,
                          BwCalendar cal,
                          BwCategory cat,
                          BwLocation loc,
                          BwContact ctct) throws CalFacadeException {
    BwCommonUserPrefs prefs = null;
    boolean update = false;
    BwAuthUser au = null;

    if (pars.getPublicAdmin()) {
      /* Remove from preferences */
      au = getUserAuth().getUser(pars.getAuthUser());
      prefs = au.getPrefs();
    }

    if (prefs == null) {
      // XXX until we get non admin user preferred calendars etc
      return;
    }

    if (cal != null) {
      CalendarPref p = prefs.getCalendarPrefs();
      if ((remove && p.remove(cal)) ||
          (!remove && p.getAutoAdd() && p.add(cal))) {
        update = true;
      }
    }

    if (cat != null) {
      CategoryPref p = prefs.getCategoryPrefs();
      if ((remove && p.remove(cat)) ||
          (!remove && p.getAutoAdd() && p.add(cat))) {
        update = true;
      }
    }

    if (loc != null) {
      LocationPref p = prefs.getLocationPrefs();
      if ((remove && p.remove(loc)) ||
          (!remove && p.getAutoAdd() && p.add(loc))) {
        update = true;
      }
    }

    if (ctct != null) {
      ContactPref p = prefs.getContactPrefs();
      if ((remove && p.remove(ctct)) ||
          (!remove && p.getAutoAdd() && p.add(ctct))) {
        update = true;
      }
    }

    if (update) {
      if (pars.getPublicAdmin()) {
        getUserAuth().updatePrefs(au);
      }
    }
  }

  /* ====================================================================
   *                   Access
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#changeAccess(org.bedework.calfacade.base.BwShareableDbentity, java.util.Collection)
   */
  public void changeAccess(BwShareableDbentity ent,
                           Collection<Ace> aces,
                           boolean replaceAll) throws CalFacadeException {
    if (ent instanceof BwCalSuiteWrapper) {
      ent = (BwShareableDbentity)((BwCalSuiteWrapper)ent).fetchEntity();
    }
    getCal().changeAccess(ent, aces, replaceAll);
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#defaultAccess(org.bedework.calfacade.base.BwShareableDbentity, edu.rpi.cmt.access.AceWho)
   */
  public void defaultAccess(BwShareableDbentity ent,
                            AceWho who) throws CalFacadeException {
    if (ent instanceof BwCalSuiteWrapper) {
      ent = (BwShareableDbentity)((BwCalSuiteWrapper)ent).fetchEntity();
    }
    getCal().defaultAccess(ent, who);
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#checkAccess(org.bedework.calfacade.base.BwShareableDbentity, int, boolean)
   */
  public CurrentAccess checkAccess(BwShareableDbentity ent, int desiredAccess,
                                   boolean returnResult) throws CalFacadeException {
    return getCal().checkAccess(ent, desiredAccess, returnResult);
  }

  /* ====================================================================
   *                   Timezones
   * ==================================================================== */

  public CalTimezones getTimezones() throws CalFacadeException {
    return getCal().getTimezonesHandler();
  }

  public void saveTimeZone(String tzid, VTimeZone vtz)
          throws CalFacadeException {
    // Not sure we want this. public admins may want to add timezones
    if (isPublicAdmin() && !isSuper()) {
      throw new CalFacadeAccessException();
    }

    timezones.saveTimeZone(tzid, vtz);
  }

  public void registerTimeZone(String id, TimeZone timezone)
      throws CalFacadeException {
    timezones.registerTimeZone(id, timezone);
  }

  public TimeZone getTimeZone(final String id,
                              BwUser tzowner) throws CalFacadeException {
    return timezones.getTimeZone(id, tzowner);
  }

  public VTimeZone findTimeZone(final String id, BwUser owner) throws CalFacadeException {
    return timezones.findTimeZone(id, owner);
  }

  public void clearPublicTimezones() throws CalFacadeException {
    if (isPublicAdmin() && !isSuper()) {
      throw new CalFacadeAccessException();
    }

    timezones.clearPublicTimezones();
  }

  public void refreshTimezones() throws CalFacadeException {
    timezones.refreshTimezones();
  }

  public List getTimeZoneIds() throws CalFacadeException {
    return getCal().getTimeZoneIds();
  }

  public UpdateFromTimeZonesInfo updateFromTimeZones(int limit,
                                                     boolean checkOnly,
                                                     UpdateFromTimeZonesInfo info
                                                     ) throws CalFacadeException {
    return getCal().updateFromTimeZones(limit, checkOnly, info);
  }

  /* ====================================================================
   *                   Calendar suites
   * ==================================================================== */

  public BwCalSuiteWrapper addCalSuite(BwCalSuite val) throws CalFacadeException {
    updateOK(val);

    setupSharableEntity(val, getUser());

    return dbi.addCalSuite(val);
  }

  public BwCalSuiteWrapper getCalSuite() throws CalFacadeException {
    return currentCalSuite;
  }

  public BwCalSuiteWrapper getCalSuite(String name) throws CalFacadeException {
    return dbi.getCalSuite(name);
  }

  public BwCalSuiteWrapper getCalSuite(BwAdminGroup group)
        throws CalFacadeException {
    return dbi.getCalSuite(group);
  }

  public Collection<BwCalSuite> getCalSuites() throws CalFacadeException {
    return dbi.getCalSuites();
  }

  public void updateCalSuite(BwCalSuiteWrapper val) throws CalFacadeException {
    updateOK(val);

    dbi.updateCalSuite(val);
  }

  public void deleteCalSuite(BwCalSuiteWrapper val) throws CalFacadeException {
    updateOK(val);

    dbi.deleteCalSuite(val);
  }

  /* ====================================================================
   *                   Calendars
   * ==================================================================== */

  public BwCalendar getPublicCalendars() throws CalFacadeException {
    return getCal().getPublicCalendars();
  }

  public Collection<BwCalendar> getPublicCalendarCollections() throws CalFacadeException {
    return getCal().getPublicCalendarCollections();
  }

  public boolean getCalendarInuse(BwCalendar val) throws CalFacadeException {
    return getCal().checkCalendarRefs(val);
  }

  public BwCalendar getCalendars() throws CalFacadeException {
    if (pars.isGuest() || isPublicAdmin()) {
      return getCal().getPublicCalendars();
    }

    return getCal().getCalendars();
  }

  public BwCalendar getCalendars(BwUser u) throws CalFacadeException {
    return getCal().getCalendars(u, PrivilegeDefs.privRead);
  }

  public Collection<BwCalendar> getCalendars(BwCalendar cal) throws CalFacadeException {
    return getCal().getCalendars(cal);
  }

  public Collection<BwCalendar> getCalendarCollections() throws CalFacadeException {
    return getCal().getCalendarCollections();
  }

  public Collection<BwCalendar> getAddContentCalendarCollections()
          throws CalFacadeException {
    if (isPublicAdmin()) {
      return getCal().getAddContentPublicCalendarCollections();
    }
    return getCal().getAddContentCalendarCollections();
  }

  public BwCalendar getCalendar(int val) throws CalFacadeException {
    return getCal().getCalendar(val);
  }

  public BwCalendar getCalendar(String path) throws CalFacadeException{
    if (path == null) {
      return null;
    }

    if ((path.length() > 1) &&
        (path.startsWith(CalFacadeDefs.bwUriPrefix))) {
      path = path.substring(CalFacadeDefs.bwUriPrefix.length());
    }

    if ((path.length() > 1) && path.endsWith("/")) {
      path = path.substring(0, path.length() - 1);
    }

    return getCal().getCalendar(path, PrivilegeDefs.privAny);
  }

  public BwCalendar getSpecialCalendar(int calType,
                                       boolean create) throws CalFacadeException {
    return getCal().getSpecialCalendar(getUser(), calType, create,
                                       PrivilegeDefs.privAny).cal;
  }

  public void setPreferredCalendar(BwCalendar  val) throws CalFacadeException {
    getPreferences().setDefaultCalendarPath(val.getPath());
  }

  public BwCalendar getPreferredCalendar() throws CalFacadeException {
    return getCalendar(getPreferences().getDefaultCalendarPath());
  }

  public BwCalendar addCalendar(BwCalendar val,
                                String parentPath) throws CalFacadeException {
    updateOK(val);

    setupSharableEntity(val, getUser());

    val =  getCal().addCalendar(val, parentPath);

    if (indexing) {
      indexCalendar(val);
    }

    return val;
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#renameCalendar(org.bedework.calfacade.BwCalendar, java.lang.String)
   */
  public void renameCalendar(BwCalendar val,
                             String newName) throws CalFacadeException {
    getCal().renameCalendar(val, newName);
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#moveCalendar(org.bedework.calfacade.BwCalendar, org.bedework.calfacade.BwCalendar)
   */
  public void moveCalendar(BwCalendar val,
                           BwCalendar newParent) throws CalFacadeException {
    getCal().moveCalendar(val, newParent);
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#updateCalendar(org.bedework.calfacade.BwCalendar)
   */
  public void updateCalendar(BwCalendar val) throws CalFacadeException {
    /* Ensure it's not in admin prefs if it's a folder.
     * User may have switched from calendar to folder.
     */
    if (!val.getCalendarCollection() && pars.getPublicAdmin()) {
      /* Remove from preferences */
      updatePrefs(true, val, null, null, null);
    }

    if (indexing) {
      indexCalendar(val);
    }

    getCal().updateCalendar(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#deleteCalendar(org.bedework.calfacade.BwCalendar, boolean)
   */
  public int deleteCalendar(BwCalendar val,
                            boolean emptyIt) throws CalFacadeException {
    /** Only allow delete if not in use
     */
    if (getCal().checkCalendarRefs(val)) {
      return 2;
    }

    BwPreferences prefs = getUserPrefs(val.getOwner());
    if (val.getPath().equals(prefs.getDefaultCalendarPath())) {
      return 2;
    }

    /* Remove from preferences */
    updatePrefs(true, val, null, null, null);

    if (indexing) {
      unindexCalendar(val);
    }

    if (emptyIt) {
      BwSubscription sub = BwSubscription.makeSubscription(val);
      RecurringRetrievalMode rrm = new RecurringRetrievalMode(Rmode.overrides);

      for (EventInfo ei: getEvents(sub, rrm)) {
        deleteEvent(ei.getEvent(), true);
      }

      for (BwCalendar cal: getCalendars(val)) {
        int res = deleteCalendar(cal, true);
        if (res != 0) {
          rollbackTransaction();
          return res;
        }
      }
    }

    /* Attempt to delete
     */
    if (getCal().deleteCalendar(val)) {
      return 0;
    }

    return 1; //doesn't exist
  }

  public boolean isUserRoot(BwCalendar cal) throws CalFacadeException {
    if ((cal == null) || (cal.getPath() == null)) {
      return false;
    }

    String[] ss = cal.getPath().split("/");
    int pathLength = ss.length - 1;  // First element is empty string

    return (pathLength == 2) &&
           (ss[1].equals(getSyspars().getUserCalendarRoot()));
  }

  /* ====================================================================
   *                   Views
   * ==================================================================== */

  public boolean addView(BwView val,
                         boolean makeDefault) throws CalFacadeException {
    if (val == null) {
      return false;
    }

    BwPreferences prefs = getPreferences();
    checkOwnerOrSuper(prefs);

    setupOwnedEntity(val, getUser());

    if (!prefs.addView(val)) {
      return false;
    }

    if (makeDefault) {
      prefs.setPreferredView(val.getName());
    }

    dbi.updatePreferences(prefs);

    return true;
  }

  public boolean removeView(BwView val) throws CalFacadeException{
    if (val == null) {
      return false;
    }

    BwPreferences prefs = getPreferences();
    checkOwnerOrSuper(prefs);

    setupOwnedEntity(val, getUser());

    Collection<BwView> views = prefs.getViews();
    if ((views == null) || (!views.contains(val))) {
      return false;
    }

    String name = val.getName();

    views.remove(val);

    if (name.equals(prefs.getPreferredView())) {
      prefs.setPreferredView(null);
    }

    dbi.updatePreferences(prefs);

    return true;
  }

  public BwView findView(String val) throws CalFacadeException {
    if (val == null) {
      BwPreferences prefs = getPreferences();

      val = prefs.getPreferredView();
      if (val == null) {
        return null;
      }
    }

    Collection<BwView> views = getViews();
    for (BwView view: views) {
      if (view.getName().equals(val)) {
        return view;
      }
    }

    return null;
  }

  public boolean addViewSubscription(String name,
                                     BwSubscription sub) throws CalFacadeException {

    BwPreferences prefs = getPreferences();
    checkOwnerOrSuper(prefs);

    BwView view = findView(name);

    if (view == null) {
      return false;
    }

    view.addSubscription(sub);

    dbi.updatePreferences(prefs);

    return true;
  }

  public boolean removeViewSubscription(String name,
                                        BwSubscription sub) throws CalFacadeException {

    BwPreferences prefs = getPreferences();
    checkOwnerOrSuper(prefs);

    BwView view = findView(name);

    if (view == null) {
      return false;
    }

    view.removeSubscription(sub);

    dbi.updatePreferences(prefs);

    return true;
  }

  public Collection<BwView> getViews() throws CalFacadeException {
    Collection<BwView> c = getPreferences().getViews();
    if (c == null) {
      c = new TreeSet<BwView>();
    }
    return c;
  }

  /* ====================================================================
   *                   Current selection
   * This defines how we select events to display.
   * ==================================================================== */

  public boolean setCurrentView(String val) throws CalFacadeException {
    if (val == null) {
      currentView = null;
      return true;
    }

    Collection<BwView> v = getPreferences().getViews();
    if ((v == null) || (v.size() == 0)) {
      return false;
    }

    for (BwView view: v) {
      if (val.equals(view.getName())) {
        currentView = view;
        currentSubscriptions = null;

        if (debug) {
          trace("set view to " + view);
        }
        return true;
      }
    }

    return false;
  }

  public BwView getCurrentView() throws CalFacadeException {
    return currentView;
  }

  public void setCurrentSubscriptions(Collection<BwSubscription> val)
          throws CalFacadeException {
    currentSubscriptions = val;
    if (val != null) {
      currentView = null;
    }
  }

  public Collection<BwSubscription> getCurrentSubscriptions() throws CalFacadeException {
    return currentSubscriptions;
  }

  /* ====================================================================
   *                   Search and filters
   * ==================================================================== */

  public void setSearch(String val) throws CalFacadeException {
    getCal().setSearch(val);
  }

  public String getSearch() throws CalFacadeException {
    return getCal().getSearch();
  }

  public void addFilter(BwFilter val) throws CalFacadeException {
    BwPreferences prefs = getPreferences();
    checkOwnerOrSuper(prefs);

    getCal().addFilter(val);
  }

  public void updateFilter(BwFilter val) throws CalFacadeException {
    BwPreferences prefs = getPreferences();
    checkOwnerOrSuper(prefs);

    getCal().updateFilter(val);
  }

  /*
  public void setFilter(BwFilter val) throws CalFacadeException {
    currentFilter = val;
  }

  public BwFilter getFilter() throws CalFacadeException {
    return currentFilter;
  }

  public void resetFilters() throws CalFacadeException {
    currentFilter = null;
  }
  */

  /* ====================================================================
   *                   Subscriptions
   * ==================================================================== */

  public void addSubscription(BwSubscription val) throws CalFacadeException {
    BwPreferences prefs = getPreferences();
    checkOwnerOrSuper(prefs);

    setupOwnedEntity(val, getUser());

    trace("************* add subscription " + val);
    prefs.addSubscription(val);
  }

  public BwSubscription findSubscription(String name) throws CalFacadeException {
    if (name == null) {
      return null;
    }

    Collection<BwSubscription> subs = getSubscriptions();

    for (BwSubscription sub: subs) {
      if (sub.getName().equals(name)) {
        return sub;
      }
    }

    return null;
  }

  public void removeSubscription(BwSubscription val) throws CalFacadeException {
    BwPreferences prefs = getPreferences();
    checkOwnerOrSuper(prefs);

    Collection<BwSubscription> c = prefs.getSubscriptions();
    if (c != null) {
      c.remove(val);
    }
    //dbi.updatePreferences(prefs);
  }

  public void updateSubscription(BwSubscription val) throws CalFacadeException {
    BwPreferences prefs = getPreferences();
    BwSubscription sub = findSubscription(val.getName());

    if (sub == null) {
      throw new CalFacadeException("Unknown subscription" + val.getName());
    }

    if ((sub.getUnremoveable() != val.getUnremoveable()) &&
         !this.isSuper()) {
      throw new CalFacadeAccessException();
    }

    val.copyTo(sub);
    dbi.updatePreferences(prefs);
  }

  public Collection<BwSubscription> getSubscriptions() throws CalFacadeException {
    Collection<BwSubscription> c = getPreferences().getSubscriptions();
    if (c == null) {
      return new TreeSet<BwSubscription>();
    }

    for (BwSubscription sub: c) {
      getSubCalendar(sub);
    }

    return c;
  }

  public BwSubscription getSubscription(int id) throws CalFacadeException {
    return dbi.getSubscription(id);
  }

  public BwCalendar getSubCalendar(BwSubscription val) throws CalFacadeException {
    return getSubCalendar(val, false);
  }

  /* ====================================================================
   *                   Categories
   * ==================================================================== */

  public Collection<BwCategory> getCategories() throws CalFacadeException {
    if (!isPublicAdmin()) {
      return getCal().getCategories().get(getUser(), null);
    }

    return getCal().getCategories().get(getPublicUser(), null);
  }

  public Collection<BwCategory> getPublicCategories() throws CalFacadeException {
    return getCal().getCategories().get(getPublicUser(), null);
  }

  public Collection<BwCategory> getEditableCategories() throws CalFacadeException {
    if (!isPublicAdmin()) {
      return getCal().getCategories().get(getUser(), null);
    }

    if (isSuper() || pars.getAdminCanEditAllPublicCategories()) {
      return getCal().getCategories().get(getPublicUser(), null);
    }
    return getCal().getCategories().get(getPublicUser(), getUser());
  }

  public BwCategory findCategory(BwString keyVal) throws CalFacadeException {
    BwUser owner;
    if (!isPublicAdmin()) {
      owner = getUser();
    } else {
      owner = getPublicUser();
    }
    return getCal().getCategories().find(keyVal, owner);
  }

  public boolean addCategory(BwCategory val) throws CalFacadeException {
    setupSharableEntity(val, getUser());

    updateOK(val);

    if (findCategory(val.getWord()) != null) {
      return false;
    }

    if (debug) {
      trace("Add category " + val);
    }

    getCal().getCategories().add(val);
    return true;
  }

  public void replaceCategory(BwCategory val) throws CalFacadeException {
    getCal().getCategories().update(val);
  }

  public int deleteCategory(BwCategory val) throws CalFacadeException {
    /** Only allow delete if not in use
     */
    if (getCal().getCategories().getRefsCount(val) > 0) {
      return 2;
    }

    /* Remove from preferences */
    updatePrefs(true, null, val, null, null);

    /* Attempt to delete
     */
    getCal().getCategories().delete(val);
    return 0;
  }

  public EnsureEntityExistsResult<BwCategory> ensureCategoryExists(BwCategory val) throws CalFacadeException {
    EnsureEntityExistsResult<BwCategory> eeer =
      new EnsureEntityExistsResult<BwCategory>();

    if (!val.unsaved()) {
      // We've already checked it exists
      eeer.entity = val;
      return eeer;
    }

    // Assume a new entity
    eeer.entity = findCategory(val.getWord());

    if (eeer.entity != null) {
      return eeer;
    }

    // doesn't exist at this point, so we add it to db table
    eeer.added = addCategory(val);
    eeer.entity = val;

    return eeer;
  }

  public Collection<EventInfo> getCategoryRefs(BwCategory val) throws CalFacadeException {
    return postProcess(getCal().getCategories().getRefs(val), (BwSubscription)null);
  }

  public int getCategoryRefsCount(BwCategory val) throws CalFacadeException {
    return getCal().getCategories().getRefsCount(val);
  }

  /* ====================================================================
   *                   Locations
   * ==================================================================== */

  public Collection<BwLocation> getLocations() throws CalFacadeException {
    BwUser owner;
    if (!isPublicAdmin()) {
      owner = getUser();
    } else {
      owner = getPublicUser();
    }

    return getCal().getLocations().get(owner, null);
  }

  public Collection<BwLocation> getPublicLocations() throws CalFacadeException {
    return getCal().getLocations().get(getPublicUser(), null);
  }

  public Collection<BwLocation> getEditableLocations() throws CalFacadeException {
    if (!isPublicAdmin()) {
      return getCal().getLocations().get(getUser(), null);
    }

    if (isSuper() || pars.getAdminCanEditAllPublicLocations()) {
      return getCal().getLocations().get(getPublicUser(), null);
    }
    return getCal().getLocations().get(getPublicUser(), getUser());
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#addLocation(org.bedework.calfacade.BwLocation)
   */
  public boolean addLocation(BwLocation val) throws CalFacadeException {
    setupSharableEntity(val, getUser());

    if (val.getVenue() != null) {
      setupSharableEntity(val.getVenue(), getUser());
    }

    updateOK(val);

    if (findLocation(val.getAddress(), val.getOwner()) != null) {
      return false;
    }

    if (debug) {
      trace("Add location " + val);
    }

    getCal().getLocations().add(val);
    return true;
  }

  public void replaceLocation(BwLocation val) throws CalFacadeException {
    getCal().getLocations().update(val);
  }

  public BwLocation getLocation(int id) throws CalFacadeException {
    return getCal().getLocations().get(id);
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#getLocation(java.lang.String)
   */
  public BwLocation getLocation(String uid) throws CalFacadeException {
    BwUser owner;
    if (!isPublicAdmin()) {
      owner = getUser();
    } else {
      owner = getPublicUser();
    }

    return getCal().getLocations().get(uid, owner);
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#findLocation(org.bedework.calfacade.BwString)
   */
  private BwLocation findLocation(BwString val, BwUser user) throws CalFacadeException {
    BwUser owner;
    if (!isPublicAdmin()) {
      owner = user;
    } else {
      owner = getPublicUser();
    }
    return getCal().getLocations().find(val, owner);
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#findVenueLocation(java.lang.String)
   */
  public BwLocation findVenueLocation(String uid) throws CalFacadeException {
    BwUser owner;
    if (!isPublicAdmin()) {
      owner = getUser();
    } else {
      owner = getPublicUser();
    }
    return getCal().getLocations().findVenue(uid, owner);
  }

  public int deleteLocation(BwLocation val) throws CalFacadeException {
    deleteOK(val);

    /** Only allow delete if not in use
     */
    if (getCal().getLocations().getRefsCount(val) != 0) {
      return 2;
    }

    /* Remove from preferences */
    updatePrefs(true, null, null, val, null);

    /* Attempt to delete
     */
    getCal().getLocations().delete(val);
    return 0;
  }

  public EnsureEntityExistsResult<BwLocation> ensureLocationExists(BwLocation val,
                                                                   BwUser owner)
      throws CalFacadeException {
    EnsureEntityExistsResult<BwLocation> eeer =
      new EnsureEntityExistsResult<BwLocation>();
/*
    if (!val.unsaved() && (val.getOwner().equals(owner))) {
      // It exists for this user
      eeer.entity = val;
      return eeer;
    }

    eeer.entity = findLocation(val.getAddress(), owner);

    if (eeer.entity != null) {
      return eeer;
    }

    if ((val.getOwner() != null ) && !val.getOwner().equals(owner)) {
      // Clone it
      val = (BwLocation)val.clone();
      setupSharableEntity(val, owner);
    }
    */

    if (!val.unsaved()) {
      // Exists
      eeer.entity = val;
      return eeer;
    }

    eeer.entity = findLocation(val.getAddress(), owner);

    if (eeer.entity != null) {
      // Exists
      return eeer;
    }

    // doesn't exist at this point, so we add it to db table
    setupSharableEntity(val, owner);
    eeer.added = addLocation(val);
    eeer.entity = val;

    return eeer;
  }

  public Collection<EventInfo> getLocationRefs(BwLocation val) throws CalFacadeException {
    return postProcess(getCal().getLocations().getRefs(val), (BwSubscription)null);
  }

  public int getLocationRefsCount(BwLocation val) throws CalFacadeException {
    return getCal().getLocations().getRefsCount(val);
  }

  /* ====================================================================
   *                   Contacts
   * ==================================================================== */

  public Collection<BwContact> getContacts() throws CalFacadeException {
    if (!isPublicAdmin()) {
      return getCal().getContacts().get(getUser(), null);
    }

    return getCal().getContacts().get(getPublicUser(), null);
  }

  public Collection<BwContact> getPublicContacts() throws CalFacadeException {
    return getCal().getContacts().get(getPublicUser(), null);
  }

  public Collection<BwContact> getEditableContacts() throws CalFacadeException {
    if (!isPublicAdmin()) {
      return getCal().getContacts().get(getUser(), null);
    }

    if (isSuper() || pars.getAdminCanEditAllPublicSponsors()) {
      return getCal().getContacts().get(getPublicUser(), null);
    }
    return getCal().getContacts().get(getPublicUser(), getUser());
  }

  public boolean addContact(BwContact val) throws CalFacadeException {
    setupSharableEntity(val, getUser());

    updateOK(val);

    if (findContact(val.getName()) != null) {
      return false;
    }

    if (debug) {
      trace("Add sponsor " + val);
    }

    getCal().getContacts().add(val);
    return true;
  }

  public void replaceContact(BwContact val) throws CalFacadeException {
    updateOK(val);
    getCal().getContacts().update(val);
  }

  public BwContact getContact(int id) throws CalFacadeException {
    return getCal().getContacts().get(id);
  }

  public BwContact getContact(String uid) throws CalFacadeException {
    BwUser owner;
    if (!isPublicAdmin()) {
      owner = getUser();
    } else {
      owner = getPublicUser();
    }

    return getCal().getContacts().get(uid, owner);
  }

  public BwContact findContact(BwString s) throws CalFacadeException {
    BwUser owner;
    if (!isPublicAdmin()) {
      owner = getUser();
    } else {
      owner = getPublicUser();
    }

    return getCal().getContacts().find(s, owner);
  }

  public int deleteContact(BwContact val) throws CalFacadeException {
    deleteOK(val);

    /** Only allow delete if not in use
     */
    if (getCal().getContacts().getRefsCount(val) != 0) {
      return 2;
    }

    updatePrefs(true, null, null, null, val);

    /* Attempt to delete
     */
    getCal().getContacts().delete(val);
    return 0;
  }

  public EnsureEntityExistsResult<BwContact> ensureContactExists(BwContact val)
      throws CalFacadeException {
    EnsureEntityExistsResult<BwContact> eeer =
      new EnsureEntityExistsResult<BwContact>();

    if (!val.unsaved()) {
      // We've already checked it exists
      eeer.entity = val;
      return eeer;
    }

    // Assume a new entity
    eeer.entity = findContact(val.getName());

    if (eeer.entity != null) {
      return eeer;
    }

    // doesn't exist at this point, so we add it to db
    eeer.added = addContact(val);
    eeer.entity = val;

    return eeer;
  }

  public Collection<EventInfo> getContactRefs(BwContact val) throws CalFacadeException {
    return postProcess(getCal().getContacts().getRefs(val), (BwSubscription)null);
  }

  public int getContactRefsCount(BwContact val) throws CalFacadeException {
    return getCal().getContacts().getRefsCount(val);
  }

  /* ====================================================================
   *                   Events
   * ==================================================================== */

  public Collection<EventInfo> getEvent(BwSubscription sub, BwCalendar cal,
                                        String guid, String recurrenceId,
                                        RecurringRetrievalMode recurRetrieval)
          throws CalFacadeException {
    return postProcess(getCal().getEvent(cal, guid, recurrenceId, recurRetrieval),
                       sub);
  }

  public Collection<EventInfo> getEvents(BwSubscription sub,
                                         RecurringRetrievalMode recurRetrieval)
          throws CalFacadeException {
    return getEvents(sub, null, null, null, recurRetrieval);
  }

  public Collection<EventInfo> getEvents(BwSubscription sub, BwFilter filter,
                                         BwDateTime startDate, BwDateTime endDate,
                                         RecurringRetrievalMode recurRetrieval)
          throws CalFacadeException {
    return getEvents(sub, filter, startDate, endDate, recurRetrieval, false);
  }

  public DelEventResult deleteEvent(BwEvent event,
                                    boolean delUnreffedLoc) throws CalFacadeException {
    DelEventResult der = new DelEventResult(false, false, 0);

    if (event == null) {
      return der;
    }

    BwLocation loc = event.getLocation();

    if (indexing) {
      unindexEvent(event);
    }

    Calintf.DelEventResult cider = getCal().deleteEvent(event);

    if (!cider.eventDeleted) {
      return der;
    }

    /* This event was really deleted so we need to set any synch states to
     * indicate this is the case.
     */
    // SYNCH  disabled
    // dbi.setSynchState(event, BwSynchState.DELETED);

    der.eventDeleted = true;
    der.alarmsDeleted = cider.alarmsDeleted;

    if (delUnreffedLoc) {
      if ((loc != null) &&
          (getLocationRefsCount(loc) == 0) &&
          (deleteLocation(loc) == 0)) {
        der.locationDeleted = true;
      }
    }

    return der;
  }

  public EventUpdateResult addEvent(BwCalendar cal,
                                    EventInfo ei,
                                    boolean rollbackOnError) throws CalFacadeException {
    return addEvent(cal, ei, false, rollbackOnError);
  }

  public void updateEvent(BwEvent event,
                          Collection<BwEventProxy> overrides,
                          ChangeTable changes) throws CalFacadeException {
    event.updateLastmod();

    updatEventEntities(new EventUpdateResult(), event);

    getCal().updateEvent(event, overrides, changes);

    if (isPublicAdmin()) {
      /* Mail event to any subscribers */
    }

    if (indexing) {
      indexEvent(event);
    }
  }

  /** For an event to which we have write access we simply mark it deleted.
   *
   * <p>Otherwise we add an annotation maarking the event as deleted.
   *
   * @param event
   * @throws CalFacadeException
   */
  public void markDeleted(BwEvent event) throws CalFacadeException {
    if (getCal().checkAccess(event, PrivilegeDefs.privWrite, true).accessAllowed) {
      // Have write access - just set the flag and move it into the owners trash
      event.setDeleted(true);

      GetSpecialCalendarResult gscr = getCal().getSpecialCalendar(getUser(), //event.getOwner(),
                                          BwCalendar.calTypeTrash,
                                          true,
                                          PrivilegeDefs.privWriteContent);
      if (gscr.created) {
        getCal().flush();
      }
      event.setCalendar(gscr.cal);

      if (!event.getOwner().equals(getUser())) {
        // Claim ownership
        event.setOwner(getUser());
      }

      /* Names have to be unique. Just keep extending the name out till it works. I guess
       * a better approach would be a random suffix.
       */
      int limit = 100;
      for (int i = 0; i < limit; i++) {
        try {
          updateEvent(event, null, null);
          break;
        } catch (CalFacadeDupNameException dup) {
          if ((i + 1) == limit) {
            throw dup;
          }
          event.setName("a" + event.getName());
        }
      }
      return;
    }

    // Need to annotate it as deleted

    BwEventProxy proxy = BwEventProxy.makeAnnotation(event, event.getOwner(),
                                                     false);

    // Where does the ref go? Not in the same calendar - we have no access

    BwCalendar cal = getCal().getSpecialCalendar(getUser(),
                                     BwCalendar.calTypeDeleted,
                                     true, PrivilegeDefs.privRead).cal;
    proxy.setOwner(getUser());
    proxy.setDeleted(true);
    proxy.setCalendar(cal);
    addEvent(cal, new EventInfo(proxy), false);
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#getEvent(org.bedework.calfacade.BwCalendar, java.lang.String, org.bedework.calfacade.RecurringRetrievalMode)
   */
  public EventInfo getEvent(BwCalendar cal, String name,
                            RecurringRetrievalMode recurRetrieval)
          throws CalFacadeException {
    return postProcess(getCal().getEvent(cal, name, recurRetrieval),
                       (BwSubscription)null, null);
  }

  public Collection<BwCalendar> findCalendars(String guid,
                                              String rid) throws CalFacadeException {
    return getCal().findCalendars(guid, rid);
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#copyMoveNamed(org.bedework.calfacade.BwEvent, java.util.Collection, org.bedework.calfacade.BwCalendar, java.lang.String, boolean, boolean)
   */
  public CopyMoveStatus copyMoveNamed(BwEvent from,
                                      Collection<BwEventProxy>overrides,
                                      BwCalendar to,
                                      String name,
                                      boolean copy,
                                      boolean overwrite,
                                      boolean newGuidOK) throws CalFacadeException {
    boolean sameCal = from.getCalendar().equals(to);

    if (name == null) {
      name = from.getName();
    }

    if (sameCal && name.equals(from.getName())) {
      // No-op
      return CopyMoveStatus.noop;
    }

    try {
      // Get the target
      RecurringRetrievalMode rrm =
        new RecurringRetrievalMode(Rmode.overrides);

      EventInfo destEi = getEvent(to, name, rrm);

      if (destEi != null) {
        if (!overwrite) {
          return CopyMoveStatus.destinationExists;
        }

        if (!destEi.getEvent().getUid().equals(from.getUid())) {
          // Not allowed to change uid.
          return CopyMoveStatus.changedUid;
        }

        //deleteEvent(destEi.getEvent(), true);
      }

      BwEvent newEvent = (BwEvent)from.clone();
      newEvent.setName(name);
      EventInfo newEi = new EventInfo(newEvent);

      if (overrides != null) {
        for (BwEventProxy proxy: overrides) {
          newEi.addOverride(new EventInfo(proxy.clone(newEvent, newEvent)));
        }
      }

      if (!copy) {
        // Moving the event.

        if (!sameCal) {
          deleteEvent(from, true);

          if (destEi != null) {
            deleteEvent(destEi.getEvent(), true);
          }

          addEvent(to, newEi, true);
        } else {
          // Just changing name
          from.setName(name);
          updateEvent(from, overrides, null);
        }
      } else {
        // Copying the event.

        if (sameCal && newGuidOK) {
          // Assign a new guid
          newEvent.setUid(null);
          assignGuid(newEvent);
        }

        if (destEi != null) {
          deleteEvent(destEi.getEvent(), true);
        }

        addEvent(to, newEi, true);
      }

      if (destEi != null) {
        return CopyMoveStatus.ok;
      }

      return CopyMoveStatus.created;
    } catch (CalFacadeException cfe) {
      if (cfe.getMessage().equals(CalFacadeException.duplicateGuid)) {
        return CopyMoveStatus.duplicateUid;
      }

      throw cfe;
    }
  }

  /* ====================================================================
   *                   Synchronization
   * ==================================================================== */

  public BwSynchInfo getSynchInfo() throws CalFacadeException {
    return dbi.getSynchInfo();
  }

  public void addSynchInfo(BwSynchInfo val) throws CalFacadeException {
    dbi.addSynchInfo(val);
  }

  public void updateSynchInfo(BwSynchInfo val) throws CalFacadeException {
    dbi.updateSynchInfo(val);
  }

  public BwSynchState getSynchState(BwEvent ev)
      throws CalFacadeException {
    return dbi.getSynchState(ev);
  }

  public Collection<BwSynchState> getDeletedSynchStates() throws CalFacadeException {
    return dbi.getDeletedSynchStates();
  }

  public void addSynchState(BwSynchState val)
      throws CalFacadeException {
    dbi.addSynchState(val);
  }

  public void updateSynchState(BwSynchState val)
      throws CalFacadeException {
    dbi.updateSynchState(val);
  }

  public void getSynchData(BwSynchState val) throws CalFacadeException {
    dbi.getSynchData(val);
  }

  public void setSynchData(BwSynchState val) throws CalFacadeException {
    dbi.setSynchData(val);
  }

  public void updateSynchStates() throws CalFacadeException {
    dbi.updateSynchStates();
  }

  /* ====================================================================
   *                       Alarms
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#getAlarms(org.bedework.calfacade.BwEvent, org.bedework.calfacade.BwUser)
   */
  public Collection<BwAlarm> getAlarms(BwEvent event,
                                       BwUser user) throws CalFacadeException {
    return getCal().getAlarms(event, user);
  }

  public void setAlarm(BwEvent event,
                       BwAlarm alarm) throws CalFacadeException {
    // Do some sort of validation here.
    alarm.setEvent(event);
    alarm.setOwner(getUser());
    getCal().addAlarm(alarm);
  }

  public void updateAlarm(BwAlarm val) throws CalFacadeException {
    getCal().updateAlarm(val);
  }

  public Collection getUnexpiredAlarms(BwUser user) throws CalFacadeException {
    return getCal().getUnexpiredAlarms(user);
  }

  public Collection getUnexpiredAlarms(BwUser user, long triggerTime)
          throws CalFacadeException {
    return getCal().getUnexpiredAlarms(user, triggerTime);
  }

  /* ====================================================================
   *                   indexing methods
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#searchIndex(boolean, org.bedework.calfacade.BwUser, java.lang.String)
   */
  public int searchIndex(boolean publick,
                         BwUser user,
                         String query,
                         SearchLimits limits) throws CalFacadeException {
    searchIndexer = getIndexer(publick, user);

    return searchIndexer.search(query, limits);
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSvcI#getSearchResult(int, int)
   */
  public Collection<BwIndexSearchResultEntry> getSearchResult(int start,
                                                              int num)
        throws CalFacadeException {
    Collection<BwIndexSearchResultEntry> res =
      new ArrayList<BwIndexSearchResultEntry>();

    if (searchIndexer == null) {
      return res;
    }

    if (num > 100) {
      num = 100;
    }
    Index.Key[] keys = new Index.Key[num];

    num = searchIndexer.getKeys(start, keys);

    for (int i = 0; i < num; i++) {
      BwIndexKey key = (BwIndexKey)keys[i];

      Object sres;
      try {
        sres = key.getRecord(this);
      } catch (IndexException ie) {
        throw new CalFacadeException(ie);
      }

      if (sres instanceof Collection) {
        Collection<?> c = (Collection)sres;

        for (Object ent: c) {
          if (ent instanceof EventInfo) {
            res.add(new BwIndexSearchResultEntry((EventInfo)ent, key.score));
          } else {
            throw new CalFacadeException("org.bedework.index.unexpected.class");
          }
        }
      } else if (sres instanceof BwCalendar) {
        BwCalendar cal = (BwCalendar)sres;

        res.add(new BwIndexSearchResultEntry(cal, key.score));
      } else {
        throw new CalFacadeException("org.bedework.index.unexpected.class");
      }
    }

    return res;
  }

  /* ====================================================================
   *                   Access control
   * ==================================================================== */

  /* This provides some limits to shareable entity updates for the
   * admin users. It is applied in addition to the normal access checks
   * applied at the lower levels.
   */
  private void updateOK(Object o) throws CalFacadeException {
    if (isGuest()) {
      throw new CalFacadeAccessException();
    }

    if (isSuper()) {
      // Always ok
      return;
    }

    if (!(o instanceof BwShareableDbentity)) {
      throw new CalFacadeAccessException();
    }

    if (!isPublicAdmin()) {
      // Normal access checks apply
      return;
    }

    BwShareableDbentity ent = (BwShareableDbentity)o;

    if (pars.getAdminCanEditAllPublicSponsors() ||
        ent.getCreator().equals(getUser())) {
      return;
    }

    throw new CalFacadeAccessException();
  }

  /* This checks to see if the current user has owner access based on the
   * supplied object. This is used to limit access to objects not normally
   * shared such as preferences and related objects like veiws and subscriptions.
   */
  private void checkOwnerOrSuper(Object o) throws CalFacadeException {
    if (isGuest()) {
      throw new CalFacadeAccessException();
    }

    if (isSuper()) {
      // Always ok?
      return;
    }

    if (!(o instanceof BwOwnedDbentity)) {
      throw new CalFacadeAccessException();
    }

    BwOwnedDbentity ent = (BwOwnedDbentity)o;

    BwUser u;

    /*if (!isPublicAdmin()) {
      // Expect a different owner - always public-user????
      return;
    }*/

    u = getUser();

    if (u.equals(ent.getOwner())) {
      return;
    }

    throw new CalFacadeAccessException();
  }

  /* ====================================================================
   *                   Private methods
   * ==================================================================== */

  private BwCalendar getSubCalendar(BwSubscription val,
                                    boolean freeBusy) throws CalFacadeException {
    int desiredAccess = PrivilegeDefs.privRead;
    if (freeBusy) {
      desiredAccess = PrivilegeDefs.privReadFreeBusy;
    }

    if (!val.getInternalSubscription() || val.getCalendarDeleted()) {
      return null;
    }

    /* XXX Force refetch - hibernate gripes otherwise
    BwCalendar calendar = val.getCalendar();

    if (calendar != null) {
      // recheck access
      if (getCal().checkAccess(calendar, desiredAccess, true) == null) {
        val.setCalendar(null);
        return null;
      }
      return calendar;
    }
    */
    BwCalendar calendar;

    String path;
    String uri = val.getUri();

    if (uri.startsWith(CalFacadeDefs.bwUriPrefix)) {
      path = uri.substring(CalFacadeDefs.bwUriPrefix.length());
    } else {
      // Shouldn't happen?
      path = uri;
    }

    if (debug) {
      trace("Search for calendar \"" + path + "\"");
    }

    try {
      calendar = getCal().getCalendar(path, desiredAccess);
    } catch (CalFacadeAccessException cfae) {
      calendar = null;
    }

    if (calendar == null) {
      /* Assume deleted - flag in the subscription if it's ours or a temp.
       */
      if ((val.getId() == CalFacadeDefs.unsavedItemKey) ||
          val.getOwner().equals(getUser())) {
        val.setCalendarDeleted(true);
        if (val.getId() != CalFacadeDefs.unsavedItemKey) {
          // Save the state
          updateSubscription(val);
        }
      }
    } else {
      val.setCalendar(calendar);
    }

    return calendar;
  }

  private void deleteOK(Object o) throws CalFacadeException {
    updateOK(o);
  }

  /* Get a mailer object which allows the application to mail Message
   * objects.
   *
   * @return MailerIntf    implementation.
   * /
  private MailerIntf getMailer() throws CalFacadeException {
    if (mailer != null) {
      return mailer;
    }

    try {
      mailer = (MailerIntf)CalEnv.getGlobalObject("mailerclass",
                                                  MailerIntf.class);
      mailer.init(this, debug);
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }

    return mailer;
  }*/

  private void putSublookup(HashMap<Integer, BwSubscription> sublookup,
                            BwSubscription sub,
                            BwCalendar cal) throws CalFacadeException {
    if (cal.getCalendarCollection()) {
      // Leaf node
      sublookup.put(cal.getId(), sub);
      return;
    }

    Collection<BwCalendar> cals = getCal().getCalendars(cal);

    for (BwCalendar c: cals) {
      putSublookup(sublookup, sub, c);
    }
  }

  private EventInfo postProcess(CoreEventInfo cei, BwSubscription sub,
                                HashMap<Integer, BwSubscription> sublookup)
          throws CalFacadeException {
    if (cei == null) {
      return null;
    }

    //trace("ev: " + ev);

    /* If the event is an event reference (an alias) implant it in an event
     * proxy and return that object.
     */
    BwEvent ev = cei.getEvent();

    if (ev instanceof BwEventAnnotation) {
      ev = new BwEventProxy((BwEventAnnotation)ev);
    }

    EventInfo ei = new EventInfo(ev);

    if (sub != null) {
      ei.setSubscription(sub);
    } else if (sublookup != null) {
      BwCalendar cal = ev.getCalendar();
      ei.setSubscription(sublookup.get(cal.getId()));
    }
    ei.setRecurrenceId(ev.getRecurrenceId());
    ei.setCurrentAccess(cei.getCurrentAccess());

    Collection<CoreEventInfo> overrides = cei.getOverrides();
    if (overrides != null) {
      for (CoreEventInfo ocei: overrides) {
        BwEventProxy op = (BwEventProxy)ocei.getEvent();

        ei.addOverride(new EventInfo(op));
      }
    }

    Collection<CoreEventInfo> instances = cei.getInstances();
    if (instances != null) {
      for (CoreEventInfo icei: instances) {
        ei.addInstance(postProcess(icei, sub, sublookup));
      }
    }

    return ei;
  }

  private Collection<EventInfo> postProcess(Collection<CoreEventInfo> ceis,
                                            BwSubscription sub) throws CalFacadeException {
    return postProcess(ceis, sub, null);
  }

  private Collection<EventInfo> postProcess(Collection<CoreEventInfo> ceis,
                                            HashMap<Integer, BwSubscription> sublookup)
          throws CalFacadeException {
    return postProcess(ceis, null, sublookup);
  }

  private Collection<EventInfo> postProcess(Collection<CoreEventInfo> ceis,
                                            BwSubscription sub,
                                            HashMap<Integer, BwSubscription> sublookup)
          throws CalFacadeException {
    TreeSet<EventInfo> eis = new TreeSet<EventInfo>();
    Collection<CoreEventInfo> deleted = null;

    /* XXX possibly not a great idea. We should probably retrieve the
     * deleted events at the same time as we retrieve the desired set.
     *
     * This way we get too many.
     */
    if (!isGuest() && !isPublicAdmin()) {
      deleted = getCal().getDeletedProxies();
    }

    //traceDeleted(deleted);

    for (CoreEventInfo cei: ceis) {
 //     if (!deleted.contains(cei)) {
      if (!isDeleted(deleted, cei)) {
        eis.add(postProcess(cei, sub, sublookup));
      }
    }

    return eis;
  }

  /* See if the event is in the deletedProxies set.
   */
  private boolean isDeleted(Collection<CoreEventInfo> deletedProxies,
                            CoreEventInfo tryCei) {
    if ((deletedProxies == null) || deletedProxies.isEmpty()) {
      return false;
    }

    BwEvent tryEv = tryCei.getEvent();

    for (CoreEventInfo cei: deletedProxies) {
      BwEvent delEvent = cei.getEvent();
      if (delEvent instanceof BwEventProxy) {
        delEvent = ((BwEventProxy)delEvent).getTarget();
      }
      if (delEvent.equals(tryEv)) {
        return true;
      }
    }

    return false;
  }

  private BwPreferences getPreferences() throws CalFacadeException {
    BwPreferences prefs = dbi.getPreferences();

    if (prefs == null) {
      // An uninitialised user?

      initUser(getUser(), getCal());

      prefs = dbi.getPreferences();
    }

    if (prefs == null) {
      throw new CalFacadeException("org.bedework.unable.to.initialise", getUser().getAccount());
    }

    return prefs;
  }

  /*
  private BwDateTime todaysDateTime() {
    return CalFacadeUtil.getDateTime(new java.util.Date(System.currentTimeMillis()),
                                     true, false);
  }*/

  /* This will get a calintf based on the subscription uri.
   */
  Calintf getCal(BwSubscription sub) throws CalFacadeException {
    return getCal();
  }

  /* We need to synchronize this code to prevent stale update exceptions.
   * db locking might be better - this could still fail in a clustered
   * environment for example.
   */
  private static volatile Object synchlock = new Object();

  /* Currently this gets a local calintf only. Later we need to use a par to
   * get calintf from a table.
   */
  Calintf getCal() throws CalFacadeException {
    if (cali != null) {
      return cali;
    }

    synchronized (synchlock) {
      cali = CalintfFactory.getIntf(CalintfFactory.hibernateClass, debug);
      try {
        cali.open(); // Just for the user interactions
        cali.beginTransaction();

        if (pars.getCalSuite() != null) {
          BwCalSuite cs = CalSvcDb.fetchCalSuite(cali.getDbSession(), pars
              .getCalSuite());

          if (cs == null) {
            error("******************************************************");
            error("Unable to fetch calendar suite " + pars.getCalSuite());
            error("Is the database correctly initialised?");
            error("******************************************************");
            throw new CalFacadeException("org.bedework.svci.unknown.calsuite",
                pars.getCalSuite());
          }

          // CALWRAPPER - the clone() call here leads to the only call on
          // CoreCalendarWrapper.clone which in turn leads to a BwCalendar.clone
          // Why did we clone it?

          currentCalSuite = new BwCalSuiteWrapper((BwCalSuite) cs.clone());
          /* For administrative use we use the account of the admin group the user
           * is a direct member of - already set.
           *
           * For public clients we use the calendar suite owning group.
           */
          if (!pars.getPublicAdmin()) {
            pars.setUser(cs.getGroup().getOwner().getAccount());
          }
        }

        boolean userCreated = cali.init(systemName, null, pars.getAuthUser(),
                                        pars.getUser(), pars.getPublicAdmin(),
                                        getDirectories(), debug);

        // Prepare for call below.
        publicUserAccount = cali.getSyspars().getPublicUser();

        BwUser auth;
        // XXX      if (isPublicAdmin() || isGuest()) {
        if (isGuest()) {
          auth = getPublicUser();
        } else {
          auth = cali.getUser(pars.getUser());
        }

        if (debug) {
          trace("Got auth user object " + auth);
        }
        dbi = new CalSvcDb(this, auth, pars.getSynchId(), debug);

        if (userCreated) {
          initUser(auth, cali);
        }

        if (debug) {
          trace("PublicAdmin: " + pars.getPublicAdmin() + " user: "
              + pars.getUser());
        }

        if (pars.getPublicAdmin() || pars.isGuest()) {
          /* We may be running as a different user. The preferences we want to see
           * are those of the user we are running as - i.e. the 'run.as' user for
           * not those of the authenticated user.
           */
          dbi.close();

          BwUser user;

          if (currentCalSuite != null) {
            // Use this user
            user = currentCalSuite.getGroup().getOwner();
          } else {
            user = cali.getUser(pars.getUser());
          }
          dbi = new CalSvcDb(this, user, pars.getSynchId(), debug);
        }

        return cali;
      } finally {
        cali.endTransaction();
        cali.close();
        //cali.flushAll();
      }
    }
  }

  private void initUser(BwUser user, Calintf cali) throws CalFacadeException {
    // Add preferences
    BwPreferences prefs = new BwPreferences();

    prefs.setOwner(user);
    prefs.setDefaultCalendarPath(cali.getDefaultCalendarPath(user));

    // Add default subscription to the user root.
    String uri = CalFacadeDefs.bwUriPrefix + cali.getUserRootPath(user);
    BwSubscription defSub = BwSubscription.makeSubscription(uri,
                                                            user.getAccount(),
                                                            true, true, false);
    defSub.setOwner(user);
    setupOwnedEntity(defSub, getUser());

    prefs.addSubscription(defSub);

    // Add a default view for the default calendar subscription

    BwView view = new BwView();

    view.setName(getSyspars().getDefaultUserViewName());
    view.addSubscription(defSub);
    view.setOwner(user);

    prefs.addView(view);
    prefs.setPreferredView(view.getName());

    prefs.setPreferredViewPeriod("week");
    prefs.setHour24(getSyspars().getDefaultUserHour24());

    PrincipalInfo pi = getDirectories().getPrincipalInfo(user.getAccount());
    if (pi != null) {
      prefs.setScheduleAutoRespond(pi.whoType == Ace.whoTypeResource);
    }

    prefs.setScheduleAutoProcessResponses(BwPreferences.scheduleAutoProcessResponsesAccepts);
    dbi.updatePreferences(prefs);
  }

  /*
  private BwAuthUser getAdminUser() throws CalFacadeException {
    if (adminUser == null) {
      adminUser = getUserAuth().getUser(pars.getAuthUser());
    }

    return adminUser;
  }
  */

  /* See if in public admin mode
   */
  private boolean isPublicAdmin() throws CalFacadeException {
    return pars.getPublicAdmin();
  }

  /* See if current authorised user has super user access.
   */
  private boolean isSuper() throws CalFacadeException {
    return pars.getPublicAdmin() && superUser;
  }

  /* See if current authorised is a guest.
   */
  private boolean isGuest() throws CalFacadeException {
    return pars.isGuest();
  }

  /*
  private boolean checkField(String fld1, String fld2) {
    if (fld1 == null) {
      if (fld2 == null) {
        return true;
      }
    } else if (fld1.equals(fld2)) {
      return true;
    }

    return false;
  }
  */

  private UserAuthCallBack getUserAuthCallBack() {
    if (uacb == null) {
      uacb = new UserAuthCallBack(this);
    }

    return (UserAuthCallBack)uacb;
  }

  private GroupsCallBack getGroupsCallBack() {
    if (gcb == null) {
      gcb = new GroupsCallBack(this);
    }

    return (GroupsCallBack)gcb;
  }

  private class IcalCallbackcb implements IcalCallback {
    private int strictness = conformanceRelaxed;

    public void setStrictness(int val) throws CalFacadeException {
      strictness = val;
    }

    public int getStrictness() throws CalFacadeException {
      return strictness;
    }

    public BwUser getUser() throws CalFacadeException {
      return CalSvc.this.getUser();
    }

    public BwCategory findCategory(BwString val) throws CalFacadeException {
      return CalSvc.this.findCategory(val);
    }

    public void addCategory(BwCategory val) throws CalFacadeException {
      CalSvc.this.addCategory(val);
    }

    public BwContact getContact(String uid) throws CalFacadeException {
      return CalSvc.this.getContact(uid);
    }

    public BwContact findContact(BwString val) throws CalFacadeException {
      return CalSvc.this.findContact(val);
    }

    public void addContact(BwContact val) throws CalFacadeException {
      CalSvc.this.addContact(val);
    }

    public BwLocation getLocation(String uid) throws CalFacadeException {
      return CalSvc.this.getLocation(uid);
    }

    /* (non-Javadoc)
     * @see org.bedework.icalendar.IcalCallback#findLocation(org.bedework.calfacade.BwString)
     */
    public BwLocation findLocation(BwString address) throws CalFacadeException {
      return CalSvc.this.findLocation(address, CalSvc.this.getUser());
    }

    public BwLocation findVenueLocation(String uid) throws CalFacadeException {
      return CalSvc.this.findVenueLocation(uid);
    }

    /* (non-Javadoc)
     * @see org.bedework.icalendar.IcalCallback#addLocation(org.bedework.calfacade.BwLocation)
     */
    public void addLocation(BwLocation val) throws CalFacadeException {
      CalSvc.this.addLocation(val);
    }

    public Collection getEvent(BwCalendar cal, String guid, String rid,
                               RecurringRetrievalMode recurRetrieval)
            throws CalFacadeException {
      return CalSvc.this.getEvent(BwSubscription.makeSubscription(cal), cal, guid,
                                  rid, recurRetrieval);
    }

    public URIgen getURIgen() throws CalFacadeException {
      return null;
    }

    public CalTimezones getTimezones() throws CalFacadeException {
      return getCal().getTimezonesHandler();
    }

    public void saveTimeZone(String tzid,
                             VTimeZone vtz) throws CalFacadeException {
      timezones.saveTimeZone(tzid, vtz);
    }

    public void storeTimeZone(final String id) throws CalFacadeException {
      timezones.storeTimeZone(id, getUser());
    }

    public void registerTimeZone(String id, TimeZone timezone)
        throws CalFacadeException {
      timezones.registerTimeZone(id, timezone);
    }

    public TimeZone getTimeZone(final String id,
                                BwUser tzowner) throws CalFacadeException {
      return timezones.getTimeZone(id, tzowner);
    }

    public VTimeZone findTimeZone(final String id, BwUser owner) throws CalFacadeException {
      return timezones.findTimeZone(id, owner);
    }
  }

  private void fixUsers() {
    String auser = pars.getAuthUser();
    while ((auser != null) && (auser.endsWith("/"))) {
      auser = auser.substring(0, auser.length() - 1);
    }

    pars.setAuthUser(auser);

    auser = pars.getUser();
    while ((auser != null) && (auser.endsWith("/"))) {
      auser = auser.substring(0, auser.length() - 1);
    }

    pars.setUser(auser);
  }

  /* ====================================================================
   *                   Package private methods
   * ==================================================================== */

  /** Get the current db session
   *
   * @return Object
   * @throws CalFacadeException
   */
  Object getDbSession() throws CalFacadeException {
    return getCal().getDbSession();
  }

  Collection<BwSubscription> getSubscriptions(BwUser user)
          throws CalFacadeException {
    Collection<BwSubscription> c = getUserPrefs(user).getSubscriptions();
    if (c == null) {
      return new TreeSet<BwSubscription>();
    }

    for (BwSubscription sub: c) {
      getSubCalendar(sub);
    }

    return c;
  }

  Collection<EventInfo> getEvents(BwSubscription sub, BwFilter filter,
                                  BwDateTime startDate, BwDateTime endDate,
                                  RecurringRetrievalMode recurRetrieval,
                                  boolean freeBusy) throws CalFacadeException {
    TreeSet<EventInfo> ts = new TreeSet<EventInfo>();
    boolean showAllCalendars = true;

    if (sub != null) {
      // Explicitly selected calendar - via a subscription.
      getSubCalendar(sub, freeBusy);

      return postProcess(getCal(sub).getEvents(sub.getCalendar(), filter,
                                               startDate, endDate,
                                               recurRetrieval, freeBusy,
                                               !freeBusy),
                         sub);
    }

    Collection<BwSubscription> subs = null;

    /* Through a view or the complete set of subscriptions. Do not include
     * 'special' calendars.
     */

    if (!isPublicAdmin() && currentView != null) {
      if (debug) {
        trace("Use current view \"" + currentView.getName() + "\"");
      }

      /* Don't show special calendars in views */
      showAllCalendars = false;
      subs = currentView.getSubscriptions();
      if (subs == null) {
        subs = new TreeSet<BwSubscription>();
      }
    } else {
      subs = getCurrentSubscriptions();
      if (subs == null) {
        // Try set of users subscriptions.
        if (debug) {
          trace("Use user subscriptions");
        }

        subs = getSubscriptions();
      } else if (debug) {
        trace("Use current subscriptions");
      }

      if (subs == null) {
        if (debug) {
          trace("Make up ALL events");
        }

        sub = new BwSubscription();
        sub.setName("All events"); // XXX property?
        sub.setDisplay(true);
        sub.setInternalSubscription(true);

        return postProcess(getCal().getEvents(null, filter, startDate,
                                              endDate, recurRetrieval,
                                              freeBusy, false),
                           sub);
      }
    }

    /* Iterate over the subscriptions and merge the results.
     *
     * First we iterate over the subscriptions looking for internal calendars.
     * These we accumulate as children of a single calendar allowing a single
     * query for all calendars.
     *
     * We will then iterate again to handle external calendars. (Not implemented)
     */
    BwCalendar internal = new BwCalendar();
    setupSharableEntity(internal, getUser());

    // For locating subscriptions from calendar
    HashMap<Integer, BwSubscription> sublookup =
      new HashMap<Integer, BwSubscription>();

    for (BwSubscription s: subs) {
      BwCalendar calendar = getSubCalendar(s, freeBusy);

      if (calendar != null) {
        internal.addChild(calendar);
        putSublookup(sublookup, s, calendar);
      }
    }

    if (!internal.hasChildren()) {
      if (debug) {
        trace("No children for internal calendar");
      }

      return ts;
    }

    ts.addAll(postProcess(getCal().getEvents(internal, filter,
                          startDate, endDate,
                          recurRetrieval, freeBusy, showAllCalendars),
                          sublookup));

    return ts;
  }

  void updatEventEntities(EventUpdateResult updResult,
                          BwEvent event) throws CalFacadeException {

    BwContact ct = event.getContact();

    if (ct != null) {
      EnsureEntityExistsResult<BwContact> eeers = ensureContactExists(ct);

      if (eeers.added) {
        updResult.contactsAdded++;
      }

      // XXX only do this if we know it changed
      event.setContact(eeers.entity);
    }

    BwLocation loc = event.getLocation();

    if (loc != null) {
      EnsureEntityExistsResult<BwLocation> eeerl = ensureLocationExists(loc,
                                                                        event.getOwner());

      if (eeerl.added) {
        updResult.locationsAdded++;
      }

      // XXX only do this if we know it changed
      event.setLocation(eeerl.entity);
    }
  }

  EventUpdateResult addEvent(BwCalendar cal,
                             EventInfo ei,
                             boolean scheduling,
                             boolean rollbackOnError) throws CalFacadeException {
    EventUpdateResult updResult = new EventUpdateResult();
    BwEvent event = ei.getEvent();
    Collection<BwEventProxy> overrides = ei.getOverrideProxies();
    BwEventProxy proxy = null;
    BwEvent override = null;

    if (event instanceof BwEventProxy) {
      proxy = (BwEventProxy)event;
      override = proxy.getRef();
      setupSharableEntity(override, getUser());
    } else {
      setupSharableEntity(event, getUser());
    }

    if (!cal.getOwner().equals(getUser())) {
      /* This event is being added to another users calendar. Ensure we add any
       * timezones the target user does not already own.
       */

/*      CalTimezones ctz = getTimezones();

      for (String tzid: event.getTimeZoneIds()) {

      }*/
    }

    updatEventEntities(updResult, event);

    /* If no calendar has been assigned for this event set it to the default
     * calendar for non-public events or reject it for public events.
     */

    if (cal == null) {
      if (event.getPublick()) {
        throw new CalFacadeException("No calendar assigned");
      }

      cal = getPreferredCalendar();
    }

    if (!cal.getCalendarCollection()) {
      throw new CalFacadeAccessException();
    }

    event.setCalendar(cal);
    /* All Overrides go in same calendar */

    if (overrides != null) {
      for (BwEventProxy ovei: overrides) {
        ovei.getRef().setCalendar(cal);
      }
    }

    event.setDtstamps();

    assignGuid(event);

    if (proxy != null) {
      updResult.failedOverrides = getCal().addEvent(override, overrides,
                                                    scheduling,
                                                    rollbackOnError);
    } else {
      updResult.failedOverrides = getCal().addEvent(event, overrides,
                                                    scheduling,
                                                    rollbackOnError);
    }

    if (isPublicAdmin()) {
      /* Mail event to any subscribers */
    }

    if (indexing) {
      indexEvent(event);
    }

    return updResult;
  }

  GetSpecialCalendarResult getSpecialCalendar(BwUser user, int calType,
                                              boolean create,
                                              int access) throws CalFacadeException {
    return getCal().getSpecialCalendar(user, calType, create,
                                       access);
  }

  /** Assign a guid to an event. A noop if this event already has a guid.
   *
   * @param val      BwEvent object
   * @throws CalFacadeException
   */
  void assignGuid(BwEvent val) throws CalFacadeException {
    if (val == null) {
      return;
    }

    if ((val.getName() != null) &&
        (val.getUid() != null)) {
      return;
    }

    String guidPrefix = "CAL-" + CalFacadeUtil.getUid();

    if (val.getName() == null) {
      val.setName(guidPrefix + ".ics");
    }

    if (val.getUid() != null) {
      return;
    }

    val.setUid(guidPrefix + getCal().getSysid());
  }

  /** Assign a guid to a freebusy object. A noop if already has a guid.
   *
   * @param val      BwFreeBusy object
   * @throws CalFacadeException
   */
  void assignGuid(BwFreeBusy val) throws CalFacadeException {
    if (val == null) {
      return;
    }

    if (val.getUid() != null) {
      return;
    }

    String guidPrefix = "CAL-" + CalFacadeUtil.getUid();

    val.setUid(guidPrefix + getCal().getSysid());
  }

  /** Set the owner and creator on a shareable entity.
   *
   * @param entity
   * @param owner - new owner
   * @throws CalFacadeException
   */
  void setupSharableEntity(BwShareableDbentity entity, BwUser owner)
          throws CalFacadeException {
    if (entity.getCreator() == null) {
      entity.setCreator(owner);
    }

    setupOwnedEntity(entity, owner);
  }

  /** Set the owner and publick on an owned entity.
   *
   * @param entity
   * @param owner - new owner
   * @throws CalFacadeException
   */
  void setupOwnedEntity(BwOwnedDbentity entity, BwUser owner)
          throws CalFacadeException {
    entity.setPublick(isPublicAdmin());

    if (entity.getOwner() == null) {
      if (entity.getPublick()) {
        owner = getPublicUser();
      }

      entity.setOwner(owner);
    }
  }

  /* ====================================================================
   *                   Private indexing methods
   * ==================================================================== */

  private BwIndexer getIndexer(BwOwnedDbentity ent) throws CalFacadeException {
    boolean publick = isPublicAdmin();
    BwUser user = getUser();
    if (!publick) {
      user = ent.getOwner();
    }

    return getIndexer(publick, user);
  }

  private BwIndexer getIndexer(boolean publick,
                                       BwUser user) throws CalFacadeException {
    try {
      BwIndexer indexer;

      if (publick) {
        indexer = publicIndexer;
      } else {
        indexer = userIndexer;

        if (user == null) {
          user = getUser();
        }
      }

      boolean writeable = !isGuest();

      if (indexer == null) {
        indexer = BwIndexerFactory.getIndexer(publick, user, writeable,
                                               getSyspars(), debug);
        if (publick) {
          publicIndexer = indexer;
        } else {
          userIndexer = indexer;
        }
      }

      return indexer;
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /* Call to (re)index an event
   */
  private void indexEvent(BwEvent ev) throws CalFacadeException {
    getIndexer(ev).indexEntity(ev);
  }

  private void unindexEvent(BwEvent ev) throws CalFacadeException {
    getIndexer(ev).unindexEntity(ev);
  }

  /* Call to (re)index a calendar
   */
  private void indexCalendar(BwCalendar cal) throws CalFacadeException {
    getIndexer(cal).indexEntity(cal);
  }

  private void unindexCalendar(BwCalendar cal) throws CalFacadeException {
    getIndexer(cal).unindexEntity(cal);
  }

  /* Get a logger for messages
   */
  private Logger getLogger() {
    if (log == null) {
      log = Logger.getLogger(this.getClass());
    }

    return log;
  }

  private void logIt(String msg) {
    getLogger().info(msg);
  }

  private void trace(String msg) {
    getLogger().debug(msg);
  }

  private void error(String msg) {
    getLogger().error(msg);
  }
}

