/* **********************************************************************
    Copyright 2007 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calsvc;

import org.bedework.calcorei.CalendarsI.GetSpecialCalendarResult;
import org.bedework.calfacade.BwAttendee;
import org.bedework.calfacade.BwCalendar;
import org.bedework.calfacade.BwContact;
import org.bedework.calfacade.BwDateTime;
import org.bedework.calfacade.BwDuration;
import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.BwEventAnnotation;
import org.bedework.calfacade.BwEventObj;
import org.bedework.calfacade.BwEventProxy;
import org.bedework.calfacade.BwFreeBusy;
import org.bedework.calfacade.BwFreeBusyComponent;
import org.bedework.calfacade.BwLocation;
import org.bedework.calfacade.BwOrganizer;
import org.bedework.calfacade.BwPrincipal;
import org.bedework.calfacade.BwString;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.CalFacadeDefs;
import org.bedework.calfacade.RecurringRetrievalMode;
import org.bedework.calfacade.ScheduleResult;
import org.bedework.calfacade.RecurringRetrievalMode.Rmode;
import org.bedework.calfacade.ScheduleResult.ScheduleRecipientResult;
import org.bedework.calfacade.exc.CalFacadeAccessException;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.filter.BwEntityTypeFilter;
import org.bedework.calfacade.filter.BwFilter;
import org.bedework.calfacade.filter.BwOrFilter;
import org.bedework.calfacade.ifs.Directories;
import org.bedework.calfacade.svc.BwSubscription;
import org.bedework.calfacade.svc.EventInfo;
import org.bedework.calfacade.svc.prefs.BwPreferences;
import org.bedework.calfacade.util.CalFacadeUtil;
import org.bedework.calfacade.util.EventPeriods;
import org.bedework.calfacade.util.Granulator;
import org.bedework.calfacade.util.Granulator.EventPeriod;
import org.bedework.calfacade.util.Granulator.GetPeriodsPars;
import org.bedework.calsvci.CalSvcI;
import org.bedework.calsvci.SchedulingI;
import org.bedework.icalendar.IcalTranslator;
import org.bedework.icalendar.Icalendar;

import edu.rpi.cmt.access.PrivilegeDefs;

import net.fortuna.ical4j.model.Calendar;
import net.fortuna.ical4j.model.DateTime;
import net.fortuna.ical4j.model.Period;

import org.apache.log4j.Logger;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.TreeSet;

/**
 * @author Mike Douglass
 *
 */
public class Scheduling implements SchedulingI {
  CalSvc svci;
  boolean debug;

  private transient Logger log;

  private AutoScheduler autoSchedule;

  /** Constructor
   *
   * @param svci
   * @param envPrefix
   * @param debug
   */
  Scheduling(CalSvcI svci, String envPrefix, boolean debug) {
    this.svci = (CalSvc)svci;
    this.debug = debug;

    autoSchedule = new AutoScheduler(envPrefix, debug);
  }

  void processAutoResponses() throws CalFacadeException {
    if (autoSchedule != null) {
      autoSchedule.trigger();
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SchedulingI#schedule(org.bedework.calfacade.BwEvent)
   */
  public ScheduleResult schedule(EventInfo ei,
                                 String recipient) throws CalFacadeException {
    /* A request (that is we are (re)sending a meeting request) or a publish
     *
     * Do the usual checks and init
     * For each recipient
     *    If internal to system, add to their inbox
     *    otherwise add to list of external recipients
     *
     * If any external recipients - leave in outbox with unprocessed status.
     */
    ScheduleResult sr = new ScheduleResult();
    BwEvent ev = ei.getEvent();

    try {
      int smethod = ev.getScheduleMethod();

      if (!Icalendar.itipRequestMethodType(smethod)) {
        sr.errorCode = CalFacadeException.schedulingBadMethod;
        return sr;
      }

      /* For each recipient within this system add the event to their inbox.
       *
       * If there are any external users add it to the outbox and it will be
       * mailed to the recipients.
       */

      int outAccess = PrivilegeDefs.privScheduleRequest;

      /* For a request type action the organizer should be the current user. */

      if (!initScheduleEvent(ev, sr)) {
        return sr;
      }

      /* Do this here to check we have access. We might need the outbox later
       */
      BwCalendar outBox = svci.getSpecialCalendar(svci.getUser(),
                                                  BwCalendar.calTypeOutbox,
                                                  true, outAccess).cal;

      Collection<String> externalRcs = sendSchedule(sr, ei, recipient);

      if ((sr.errorCode != null) || sr.ignored) {
        return sr;
      }

      if (externalRcs != null) {
        addToOutBox(ei, outBox, externalRcs);
      }

      return sr;
    } catch (Throwable t) {
      svci.rollbackTransaction();
      if (t instanceof CalFacadeException) {
        throw (CalFacadeException)t;
      }
      throw new CalFacadeException(t);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SchedulingI#declineCounter(org.bedework.calfacade.BwEvent, java.lang.String, java.lang.String)
   */
  public ScheduleResult declineCounter(EventInfo ei,
                                       String comment,
                                       String recipient) throws CalFacadeException {
    BwEvent ev = ei.getEvent();

    int smethod = ev.getScheduleMethod();

    if (smethod != Icalendar.methodTypeCounter) {
      ScheduleResult sr = new ScheduleResult();

      sr.errorCode = CalFacadeException.schedulingBadMethod;
      return sr;
    }

    EventInfo outEi = copyEventInfo(ei, svci.getUser());
    ev = outEi.getEvent();
    ev.setScheduleMethod(Icalendar.methodTypeDeclineCounter);

    if (comment != null) {
      ev.addComment(null, comment);
    }

    return schedule(outEi, recipient);
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SchedulingI#requestRefresh(org.bedework.calfacade.BwEvent, java.lang.String)
   */
  public ScheduleResult requestRefresh(EventInfo ei,
                                       String comment) throws CalFacadeException {
    ScheduleResult sr = new ScheduleResult();
    BwEvent ev = ei.getEvent();

    if (ev.getScheduleMethod() != Icalendar.methodTypeRequest) {
      sr.errorCode = CalFacadeException.schedulingBadMethod;
      return sr;
    }

    BwAttendee att = findUserAttendee(ev);

    if (att == null) {
      throw new CalFacadeException(CalFacadeException.schedulingNotAttendee);
    }

    BwEvent outEv = new BwEventObj();
    EventInfo outEi = new EventInfo(outEv);

    outEv.setScheduleMethod(Icalendar.methodTypeRefresh);

    outEv.addRecipient(ev.getOriginator());
    outEv.setOriginator(att.getAttendeeUri());
    outEv.updateDtstamp();
    outEv.setOrganizer((BwOrganizer)ev.getOrganizer().clone());
    outEv.getOrganizer().setDtstamp(outEv.getDtstamp());
    outEv.addAttendee((BwAttendee)att.clone());
    outEv.setUid(ev.getUid());
    outEv.setRecurrenceId(ev.getRecurrenceId());
    outEv.setNoStart(true);
    outEv.setRecurring(false);

    if (comment != null) {
      outEv.addComment(new BwString(null, comment));
    }

    sr = scheduleResponse(outEi);
    outEv.setScheduleState(BwEvent.scheduleStateProcessed);

    return sr;
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SchedulingI#attendeeRespond(org.bedework.calfacade.BwEvent, org.bedework.calfacade.BwCalendar, java.lang.String, java.lang.String, java.lang.String, org.bedework.calfacade.BwCalendar, java.lang.String, boolean)
   */
  public ScheduleResult attendeeRespond(EventInfo ei,
                                        String delegate,
                                        String meth,
                                        String partStat,
                                        String comment,
                                        boolean rsvp,
                                        BwCalendar newCal,
                                        Collection<BwCalendar> eventCals) throws CalFacadeException {
    ScheduleResult sr = new ScheduleResult();
    BwEvent ev = ei.getEvent();
    BwEventProxy proxy = null;
    if (ev instanceof BwEventProxy) {
      proxy = (BwEventProxy)ev;
    }

    if (ev.getScheduleMethod() != Icalendar.methodTypeRequest) {
      sr.errorCode = CalFacadeException.schedulingBadMethod;
      return sr;
    }

    BwAttendee att = findUserAttendee(ev);

    if (att == null) {
      sr.errorCode = CalFacadeException.schedulingNotAttendee;
      return sr;
    }

    BwCalendar inbox = ev.getCalendar();

    if (inbox.getCalType() != BwCalendar.calTypeInbox) {
      sr.errorCode = CalFacadeException.schedulingBadSourceCalendar;
      return sr;
    }

    if ((newCal != null) && (newCal.getCalType() != BwCalendar.calTypeCollection)) {
      // Cannot copy into non-calendar collection
      sr.errorCode = CalFacadeException.schedulingBadDestinationCalendar;
      return sr;
    }

    if (ev.getOriginator() == null) {
      sr.errorCode = CalFacadeException.schedulingNoOriginator;
      return sr;
    }

    //BwUser cu = inbox.getOwner();
    int method = Icalendar.methodTypeNone;

    if (delegate == null) {
      method = Icalendar.findMethodType(meth);

      if (!Icalendar.itipReplyMethodType(method)) {
        sr.errorCode = CalFacadeException.schedulingBadResponseMethod;
        return sr;
      }
    }

    EventInfo outEi = copyEventInfo(ei, svci.getUser());
    BwEvent outEv = outEi.getEvent();

    if (comment != null) {
      // Just add for the moment
      outEv.addComment(null, comment);
    }

    //String cuAddr = svci.getDirectories().userToCaladdr(cu.getAccount());
    //BwAttendee att = outEv.findAttendee(cuAddr);
    //if (att == null) {
    //  sr.errorCode = CalFacadeException.schedulingUnknownAttendee;
    //  return sr;
    //}

    outEv.setRecipients(new TreeSet<String>());
    outEv.addRecipient(outEv.getOriginator());
    outEv.setOriginator(att.getAttendeeUri());
    outEv.updateDtstamp();
    outEv.getOrganizer().setDtstamp(outEv.getDtstamp());

    if (delegate != null) {
      /* RFC 2446 4.2.5 - Delegating an event
       *
       * When delegating an event request to another "Calendar User", the
       * "Delegator" must both update the "Organizer" with a "REPLY" and send
       * a request to the "Delegate". There is currently no protocol
       * limitation to delegation depth. It is possible for the original
       * delegate to delegate the meeting to someone else, and so on. When a
       * request is delegated from one CUA to another there are a number of
       * responsibilities required of the "Delegator". The "Delegator" MUST:
       *
       *   .  Send a "REPLY" to the "Organizer" with the following updates:
       *   .  The "Delegator's" "ATTENDEE" property "partstat" parameter set
       *      to "delegated" and the "delegated-to" parameter is set to the
       *      address of the "Delegate"
       *   .  Add an additional "ATTENDEE" property for the "Delegate" with
       *      the "delegated-from" property parameter set to the "Delegator"
       *   .  Indicate whether they want to continue to receive updates when
       *      the "Organizer" sends out updated versions of the event.
       *      Setting the "rsvp" property parameter to "TRUE" will cause the
       *      updates to be sent, setting it to "FALSE" causes no further
       *      updates to be sent. Note that in either case, if the "Delegate"
       *      declines the invitation the "Delegator" will be notified.
       *   .  The "Delegator" MUST also send a copy of the original "REQUEST"
       *      method to the "Delegate".
       */

      // outEv is the reply
      outEv.setScheduleMethod(Icalendar.methodTypeReply);

      String dcalAddr = svci.getDirectories().userToCaladdr(delegate);
      att.setParticipationStatus(BwAttendee.partstatdelegated);
      att.setDelegatedTo(dcalAddr);

      // Additional attendee
      BwAttendee delAtt = new BwAttendee();
      delAtt.setAttendeeUri(dcalAddr);
      delAtt.setDelegatedFrom(att.getAttendeeUri());
      delAtt.setParticipationStatus(BwAttendee.partstatNeedsAction);
      delAtt.setRole(att.getRole());
      outEv.addAttendee(delAtt);

      /* The attendee may indicate they wish to continue to receive
       * notification by setting rsvp = true
       */
      att.setRsvp(rsvp);

      // ei is 'original "REQUEST"'. */
      EventInfo delegateEi = copyEventInfo(ei, svci.getUser());
      BwEvent delegateEv = delegateEi.getEvent();

      delegateEv.setRecipients(new TreeSet<String>());
      delegateEv.addRecipient(dcalAddr);
      delegateEv.addAttendee((BwAttendee)delAtt.clone()); // Not in RFC

      BwAttendee delegatorAtt = delegateEv.findAttendee(att.getAttendeeUri());
      if (delegatorAtt == null) {
        sr.errorCode = CalFacadeException.schedulingUnknownAttendee;
        return sr;
      }

      delegatorAtt.setParticipationStatus(BwAttendee.partstatdelegated);
      delegatorAtt.setDelegatedTo(dcalAddr);

      // XXX Not sure if this is correct
      schedule(delegateEi, null);
    } else if (method == Icalendar.methodTypeReply) {
      // Expect a valid partstat for the attendee corresponding to the inbox
      // the event came from.
      int pStat = BwAttendee.checkPartstat(partStat);

      if ((pStat != BwAttendee.partstatAccepted) &&
          (pStat != BwAttendee.partstatDeclined) &&
          (pStat != BwAttendee.partstatTentative)) {
        sr.errorCode = CalFacadeException.schedulingInvalidPartStatus;
        return sr;
      }

      // Update the status - will affect incoming event object.
      if (proxy != null) {
        att = (BwAttendee)att.clone();
        ev.removeAttendee(att);
        ev.addAttendee(att);
      }

      att.setParticipationStatus(pStat);

      // Remove all participants except us

      outEv.setAttendees(null);
      outEv.addAttendee((BwAttendee)att.clone());

      outEv.setScheduleMethod(Icalendar.methodTypeReply);
    } else if (method == Icalendar.methodTypeCounter) {
      // Remove all participants except us

      outEv.setAttendees(null);
      outEv.addAttendee((BwAttendee)att.clone());

      /* Not sure how much we can change - at least times of the meeting.
       */
      outEv.setScheduleMethod(Icalendar.methodTypeCounter);
    } else {
      throw new RuntimeException("Never get here");
    }

    sr = scheduleResponse(outEi);
    outEv.setScheduleState(BwEvent.scheduleStateProcessed);

    if (!updateScheduleCalendar(newCal, eventCals, ei, att, sr, 0)) {
      return sr;
    }

    /* Now delete processed event from inbox */
    //ev.setScheduleState(BwEvent.scheduleStateProcessed);
    //svci.updateEvent(ev, null, null);
    svci.deleteEvent(ev, true);

    return sr;
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SchedulingI#initAttendeeUpdate(org.bedework.calfacade.BwEvent)
   */
  public EventInfo initAttendeeUpdate(EventInfo ei) throws CalFacadeException {
    BwEvent ev = ei.getEvent();
    BwAttendee att = findUserAttendee(ev);

    if (att == null) {
      throw new CalFacadeException(CalFacadeException.schedulingNotAttendee);
    }

    EventInfo updEi = copyEventInfo(ei, ev.getCreator());
    BwEvent updEvent = updEi.getEvent();

/*    updEvent.setAttendees(null);
    updEvent.addAttendee((BwAttendee)att.clone());

    updEvent.setRecipients(null);
    updEvent.addRecipient(att.getAttendeeUri());*/

    updEvent.setScheduleMethod(Icalendar.methodTypeRequest);

    UserInbox ui = new UserInbox();

    ui.user = ev.getCreator();
    ui.inbox = svci.getSpecialCalendar(BwCalendar.calTypeInbox, true);
    updEvent.setCalendar(ui.inbox);

    addToInbox(ui, updEi);

    return updEi;
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SchedulingI#processResponse(org.bedework.calfacade.BwEvent, org.bedework.calfacade.BwCalendar)
   */
  public ScheduleResult processResponse(EventInfo ei,
                                        Collection<BwCalendar> eventCals) throws CalFacadeException {
    ScheduleResult sr = new ScheduleResult();
    BwEvent ev = ei.getEvent();

    /* The event should have a calendar set to the inbox it came from.
     * That inbox may be owned by somebody other than the current user if a
     * calendar user has delegated control of their inbox to some other user
     * e.g. secretary.
     */

    if (ev.getScheduleMethod() != Icalendar.methodTypeReply) {
      sr.errorCode = CalFacadeException.schedulingBadMethod;
      return sr;
    }

    /* Should be exactly one attendee */
    Collection<BwAttendee> atts = ev.getAttendees();
    if ((atts == null) || (atts.size() != 1)) {
      sr.errorCode = CalFacadeException.schedulingExpectOneAttendee;
      return sr;
    }

    BwAttendee att = atts.iterator().next();
    BwCalendar inbox = ev.getCalendar();

    if (inbox.getCalType() != BwCalendar.calTypeInbox) {
      sr.errorCode = CalFacadeException.schedulingBadSourceCalendar;
      return sr;
    }

    if (ev.getOriginator() == null) {
      sr.errorCode = CalFacadeException.schedulingNoOriginator;
      return sr;
    }

    if (!updateScheduleCalendar(null, eventCals, ei, att, sr, 0)) {
      return sr;
    }

    /* Now delete processed event from inbox */
    svci.deleteEvent(ev, true);

    return sr;
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SchedulingI#processCancel(org.bedework.calfacade.BwEvent, int, java.util.Collection)
   */
  public ScheduleResult processCancel(EventInfo ei,
                                     int action,
                                     Collection<BwCalendar> eventCals) throws CalFacadeException {
    ScheduleResult sr = new ScheduleResult();
    BwEvent ev = ei.getEvent();
    BwCalendar inbox = ev.getCalendar();

    if (ev.getScheduleMethod() != Icalendar.methodTypeCancel) {
      sr.errorCode = CalFacadeException.schedulingBadMethod;
      return sr;
    }

    if (inbox.getCalType() != BwCalendar.calTypeInbox) {
      sr.errorCode = CalFacadeException.schedulingBadSourceCalendar;
      return sr;
    }

    if (ev.getOriginator() == null) {
      sr.errorCode = CalFacadeException.schedulingNoOriginator;
      return sr;
    }

    if (!updateScheduleCalendar(null, eventCals, ei, null, sr, action)) {
      return sr;
    }

    /* Now delete processed event from inbox */
    svci.deleteEvent(ev, true);

    return sr;
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SchedulingI#scheduleResponse(org.bedework.calfacade.BwEvent)
   */
  public ScheduleResult scheduleResponse(EventInfo ei) throws CalFacadeException {
    /* Some form of reply
     *    Copy event
     *    remove all attendees and readd this user
     *    Add to organizers inbox if internal
     *    Put in outbox if external.
     */
    ScheduleResult sr = new ScheduleResult();
    BwEvent ev = ei.getEvent();

    try {
      int smethod = ev.getScheduleMethod();

      if (!Icalendar.itipReplyMethodType(smethod)) {
        sr.errorCode = CalFacadeException.schedulingBadMethod;
        return sr;
      }

      /* For each recipient within this system add the event to their inbox.
       *
       * If there are any external users add it to the outbox and it will be
       * mailed to the recipients.
       */

      int outAccess = PrivilegeDefs.privScheduleReply;

      /* There should only be one attendee for a reply */
      if (ev.getNumAttendees() != 1) {
        sr.errorCode = CalFacadeException.schedulingBadAttendees;
        return sr;
      }

      if (!initScheduleEvent(ev, sr)) {
        return sr;
      }

      /* Do this here to check we have access. We might need the outbox later
       */
      GetSpecialCalendarResult gscr = svci.getSpecialCalendar(svci.getUser(),
                                                      BwCalendar.calTypeOutbox,
                                                      true, outAccess);

      BwCalendar outBox = gscr.cal;

      Collection<String> externalRcs = sendSchedule(sr, ei, null);

      if (sr.ignored) {
        return sr;
      }

      if (externalRcs != null) {
        addToOutBox(ei, outBox, externalRcs);
      }

      return sr;
    } catch (Throwable t) {
      svci.rollbackTransaction();
      if (t instanceof CalFacadeException) {
        throw (CalFacadeException)t;
      }
      throw new CalFacadeException(t);
    }
  }
  /* (non-Javadoc)
   * @see org.bedework.calsvci.SchedulingI#getFreeBusy(java.util.Collection, org.bedework.calfacade.BwCalendar, org.bedework.calfacade.BwPrincipal, org.bedework.calfacade.BwDateTime, org.bedework.calfacade.BwDateTime)
   */
  public BwFreeBusy getFreeBusy(BwCalendar cal, BwPrincipal who,
                                BwDateTime start, BwDateTime end)
          throws CalFacadeException {
    if (!(who instanceof BwUser)) {
      throw new CalFacadeException("Unsupported: non user principal for free-busy");
    }

    BwUser u = (BwUser)who;
    Collection<BwSubscription> subs;

    if (cal != null) {
      /* Don't check - we do so at the fetch of events
      getCal().checkAccess(cal, PrivilegeDefs.privReadFreeBusy, false);
      */

      BwSubscription sub = BwSubscription.makeSubscription(cal);

      subs = new ArrayList<BwSubscription>();
      subs.add(sub);
    } else if (svci.getUser().equals(who)) {
      subs = svci.getSubscriptions();
    } else {
      /* First see if we have free busy access to the users calendar */

      /* XXX This needs to be brought into line with CalDAV.

      cal = getCal().getCalendars(u, PrivilegeDefs.privReadFreeBusy);
      if (cal == null) {
        throw new CalFacadeAccessException();
      }

      getCal().checkAccess(cal, PrivilegeDefs.privReadFreeBusy, false);
      */
      /* CalDAV uses Inbox to determine scheduling acccess */
      try {
        svci.getSpecialCalendar(u,
                                BwCalendar.calTypeInbox,
                                true,
                                PrivilegeDefs.privReadFreeBusy);
      } catch (CalFacadeAccessException cae) {
        svci.getSpecialCalendar(u,
                                BwCalendar.calTypeInbox,
                                true,
                                PrivilegeDefs.privScheduleFreeBusy);
      }

      subs = svci.getSubscriptions(u);
    }

    BwFreeBusy fb = new BwFreeBusy(who, start, end);
    svci.assignGuid(fb);

    BwAttendee att = new BwAttendee();
    att.setAttendeeUri(svci.getDirectories().userToCaladdr(who.getAccount()));
    fb.addAttendee(att);

    Collection<EventInfo> events = new TreeSet<EventInfo>();
    /* Only events and freebusy for freebusy reports. */
    BwFilter filter = new BwOrFilter();
    filter.addChild(BwEntityTypeFilter.eventFilter(null, false));
    filter.addChild(BwEntityTypeFilter.freebusyFilter(null, false));

    for (BwSubscription sub: subs) {
      if (!sub.getAffectsFreeBusy()) {
        continue;
      }

      // XXX If it's an external subscription we probably just get free busy and
      // merge it in.

      RecurringRetrievalMode rrm = new RecurringRetrievalMode(
                              Rmode.expanded, start, end);
      Collection<EventInfo> evs = svci.getEvents(sub, filter, start, end, rrm, true);

      // Filter out transparent events
      for (EventInfo ei : evs) {
        BwEvent ev = ei.getEvent();

        if (!sub.getIgnoreTransparency() &&
            BwEvent.transparencyTransparent.equals(ev.getTransparency())) {
          // Ignore this one.
          continue;
        }

        if (BwEvent.statusCancelled.equals(ev.getStatus())) {
          // Ignore this one.
          continue;
        }

        events.add(ei);
      }
    }

    try {
      EventPeriods eventPeriods = new EventPeriods(svci.getTimezones(),
                                                   start, end,
                                                   debug);

      for (EventInfo ei: events) {
        BwEvent ev = ei.getEvent();
        int type;

        if (ev.getEntityType() == CalFacadeDefs.entityTypeEvent) {
          if (BwEvent.statusCancelled.equals(ev.getStatus())) {
            // Ignore this one.
            continue;
          }

          type = BwFreeBusyComponent.typeBusy;

          if (BwEvent.statusTentative.equals(ev.getStatus())) {
            type = BwFreeBusyComponent.typeBusyTentative;
          } else if (BwEvent.statusUnavailable.equals(ev.getStatus())) {
            type = BwFreeBusyComponent.typeBusyUnavailable;
          }

          eventPeriods.addPeriod(ev.getDtstart(), ev.getDtend(), ev.getOwner(),
                                 type);
        } else if (ev.getEntityType() == CalFacadeDefs.entityTypeFreeAndBusy) {
          Collection<BwFreeBusyComponent> fbcs = ev.getFreeBusyPeriods();

          for (BwFreeBusyComponent fbc: fbcs) {
            type = fbc.getType();

            for (Period p: fbc.getPeriods()) {
              eventPeriods.addPeriod(p.getStart(), p.getEnd(), ev.getOwner(),
                                     type);
            }
          }
        }
      }

      /* iterate through the sorted periods combining them where they are
       adjacent or overlap */

      BwFreeBusyComponent fbc = eventPeriods.makeFreeBusyComponent(BwFreeBusyComponent.typeBusy);
      if (fbc != null) {
        fb.addTime(fbc);
      }

      fbc = eventPeriods.makeFreeBusyComponent(BwFreeBusyComponent.typeBusyUnavailable);
      if (fbc != null) {
        fb.addTime(fbc);
      }

      fbc = eventPeriods.makeFreeBusyComponent(BwFreeBusyComponent.typeBusyTentative);
      if (fbc != null) {
        fb.addTime(fbc);
      }
    } catch (Throwable t) {
      if (debug) {
        error(t);
      }
      throw new CalFacadeException(t);
    }

    return fb;
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SchedulingI#getFreebusySet()
   */
  public Collection<BwCalendar>getFreebusySet() throws CalFacadeException {
    Collection<BwSubscription> subs = svci.getSubscriptions();
    Collection<BwCalendar> cals = new ArrayList<BwCalendar>();

    for (BwSubscription sub: subs) {
      if (!sub.getAffectsFreeBusy()) {
        continue;
      }

      BwCalendar cal = svci.getSubCalendar(sub);
      if (cal == null) {
        continue;
      }

      addFbcal(cals, cal);
    }

    return cals;
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SchedulingI#aggregateFreeBusy(org.bedework.calfacade.ScheduleResult, org.bedework.calfacade.BwDateTime, org.bedework.calfacade.BwDateTime, org.bedework.calfacade.BwDuration)
   */
  public FbResponses aggregateFreeBusy(ScheduleResult sr,
                                       BwDateTime start, BwDateTime end,
                                       BwDuration granularity) throws CalFacadeException {
    FbResponses resps = new FbResponses();

    if (start.getDateType() || end.getDateType()) {
      throw new CalFacadeException(CalFacadeException.schedulingBadGranulatorDt);
    }

    resps.setResponses(new ArrayList<FbResponse>());

    /* Combine the responses into one big collection */
    FbResponse allResponses = new FbResponse();

    allResponses.setStart(start);
    allResponses.setEnd(end);
    resps.setAggregatedResponse(allResponses);

    for (ScheduleRecipientResult srr: sr.recipientResults) {
      FbResponse fb = new FbResponse();

      resps.getResponses().add(fb);

      fb.setRespCode(srr.status);
      fb.setNoResponse(srr.freeBusy == null);
      fb.setRecipient(srr.recipient);

      if (!fb.okResponse()) {
        continue;
      }

      if (srr.freeBusy.getNumAttendees() == 1) {
        fb.setAttendee(srr.freeBusy.getAttendees().iterator().next());
      }

      granulateFreeBusy(fb, srr.freeBusy, start, end, granularity);

      if (fb.getStart() == null) {
        continue;
      }

      boolean first = false;

      if (allResponses.eps.isEmpty()) {
        first = true;
      }

      // Merge resp into allResponses - they should have the same start/end
      Iterator<EventPeriod> allIt = allResponses.eps.iterator();

      for (EventPeriod respEp: fb.eps) {
        EventPeriod allEp;
        if (first) {
          // Just set the event period from this first response.
          allResponses.eps.add(respEp);
          allEp = respEp;
          continue;
        }

        // Merge this response period into the corresponding aggregated response
        allEp = allIt.next();

        // Validity check
        if (!allEp.getStart().equals(respEp.getStart()) ||
            !allEp.getEnd().equals(respEp.getEnd())) {
          throw new CalFacadeException(CalFacadeException.schedulingBadResponse);
        }

        if ((respEp.getType() == BwFreeBusyComponent.typeBusy) ||
            (respEp.getType() == BwFreeBusyComponent.typeBusyUnavailable)) {
          allEp.setNumBusy(allEp.getNumBusy() + 1);
        } else if (respEp.getType() == BwFreeBusyComponent.typeBusyTentative) {
          allEp.setNumTentative(allEp.getNumTentative() + 1);
        }

        allEp.setType(typeTable[allEp.getType()][respEp.getType()]);
      }
    }

    return resps;
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SchedulingI#granulateFreeBusy(org.bedework.calfacade.BwFreeBusy, org.bedework.calfacade.BwDateTime, org.bedework.calfacade.BwDateTime, org.bedework.calfacade.BwDuration)
   */
  public FbResponse granulateFreeBusy(BwFreeBusy fb,
                                      BwDateTime start, BwDateTime end,
                                      BwDuration granularity) throws CalFacadeException {
    FbResponse fbresp = new FbResponse();

    granulateFreeBusy(fbresp, fb, start, end, granularity);

    return fbresp;
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SchedulingI#getMeetingCalendars(org.bedework.calfacade.BwEvent)
   */
  public Collection<BwCalendar> getMeetingCalendars(BwEvent ev) throws CalFacadeException {
    Collection<BwCalendar> cals = svci.findCalendars(ev.getUid(), null);
                                                     //ev.getRecurrenceId());

    ArrayList<BwCalendar> evCals = new ArrayList<BwCalendar>();

    for (BwCalendar cal: cals) {
      if (cal.getCalType() == BwCalendar.calTypeCollection) {
        evCals.add(cal);
      }
    }

    return evCals;
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SchedulingI#findUserAttendee(org.bedework.calfacade.BwEvent)
   */
  public BwAttendee findUserAttendee(BwEvent ev) throws CalFacadeException {
    Directories dir = svci.getDirectories();
    String thisAccount = svci.getUser().getAccount();

    for (BwAttendee att: ev.getAttendees()) {
      if (thisAccount.equals(dir.caladdrToUser(att.getAttendeeUri()))) {
        return att;
      }
    }

    return null;
  }

  /* ====================================================================
   *                         Private methods
   * ==================================================================== */

  private void addFbcal(Collection<BwCalendar> cals,
                        BwCalendar cal) throws CalFacadeException {
    if (cal.getCalType() == BwCalendar.calTypeCollection) {
      // Leaf
      cals.add(cal);
      return;
    }

    Collection<BwCalendar> chs = svci.getCalendars(cal);
    for (BwCalendar ch: chs) {
      addFbcal(cals, ch);
    }
  }

  private static final int fbtb = BwFreeBusyComponent.typeBusy;
  private static final int fbtf = BwFreeBusyComponent.typeFree;
  private static final int fbtbu = BwFreeBusyComponent.typeBusyUnavailable;
  private static final int fbtbt = BwFreeBusyComponent.typeBusyTentative;

  private static int[][] typeTable = {
    {fbtb, fbtb, fbtb, fbtb}, // typeto == typeBusy
    {fbtb, fbtf, fbtbu, fbtbt}, // typeto == typeFree
    {fbtb, fbtbu, fbtbu, fbtbu}, // typeto == typeBusyUnavailable
    {fbtb, fbtbt, fbtbu, fbtbt} // typeto == typeBusyTentative
  };

  private void granulateFreeBusy(FbResponse fbresp,
                                 BwFreeBusy fb,
                                 BwDateTime start, BwDateTime end,
                                 BwDuration granularity) throws CalFacadeException {
    DateTime startDt;
    DateTime endDt;
    try {
      startDt = new DateTime(start.getDate());
      endDt = new DateTime(end.getDate());
    } catch (ParseException pe) {
      throw new CalFacadeException(pe);
    }

    if (fb.getDtstart().after(start)) {
      // XXX Should warn - or fill in with tentative?
      //warn("Response start after requested start");
    }

    if (fb.getDtend().before(end)) {
      // XXX Should warn - or fill in with tentative?
      //warn("Response end before requested end");
    }

    fbresp.setStart(start);
    fbresp.setEnd(end);

    Collection<EventPeriod> periods = new ArrayList<EventPeriod>();

    if (fb.getTimes() != null) {
      for (BwFreeBusyComponent fbcomp: fb.getTimes()) {
        for (Period p: fbcomp.getPeriods()) {
          DateTime pstart = p.getStart();
          DateTime pend = p.getEnd();
          if (!pend.isUtc()) {
            pend.setUtc(true);
          }

          /* Adjust for servers sending times outside requested range */
          if (pend.after(endDt)) {
            pend = endDt;
          }

          if (pstart.before(startDt)) {
            pstart = startDt;
          }

          if (!pend.after(pstart)) {
            continue;
          }
          periods.add(new EventPeriod(pstart, pend, fbcomp.getType()));
        }
      }
    }

    GetPeriodsPars gpp = new GetPeriodsPars();

    gpp.periods = periods;
    gpp.startDt = start;
    gpp.dur = granularity;
    gpp.tzcache = svci.getTimezones();

    BwDateTime bwend = end;

    Collection<EventPeriod> respeps = new ArrayList<EventPeriod>();
    fbresp.eps = respeps;

    int limit = 10000; // XXX do this better

    /* endDt is null first time through, then represents end of last
     * segment.
     */
    while ((gpp.endDt == null) || (gpp.endDt.before(bwend))) {
      //if (debug) {
      //  trace("gpp.startDt=" + gpp.startDt + " end=" + end);
      //}
      if (limit < 0) {
        throw new CalFacadeException("org.bedework.svci.limit.exceeded");
      }
      limit--;

      Collection<?> periodEvents = Granulator.getPeriodsEvents(gpp);

      /* Some events fall in the period. Add an entry.
       * We eliminated cancelled events earler. Now we should set the
       * free/busy type based on the events status.
       */

      DateTime psdt;
      DateTime pedt;
      try {
        psdt = new DateTime(gpp.startDt.getDtval());
        pedt = new DateTime(gpp.endDt.getDtval());
      } catch (ParseException pe) {
        throw new CalFacadeException(pe);
      }

      psdt.setUtc(true);
      pedt.setUtc(true);


      EventPeriod ep = new EventPeriod(psdt, pedt, 0);
      setFreeBusyType(ep, periodEvents);
      respeps.add(ep);
    }
  }

  private void setFreeBusyType(EventPeriod ep, Collection<?> periodEvents) {
    int fbtype = BwFreeBusyComponent.typeFree;
    int busy = 0;
    int tentative = 0;

//    Iterator it = periodEvents.iterator();
//    while (it.hasNext()) {
    for (Object o: periodEvents) {
//      int type = ((EventPeriod)it.next()).getType();
      int type = ((EventPeriod)o).getType();

      if (type == BwFreeBusyComponent.typeBusy) {
        fbtype = BwFreeBusyComponent.typeBusy;
        busy++;
      }

      if (type == BwFreeBusyComponent.typeBusyTentative) {
        fbtype = BwFreeBusyComponent.typeBusyTentative;
        tentative++;
      }
    }

    ep.setNumBusy(busy);
    ep.setNumTentative(tentative);
    ep.setType(fbtype);
  }

  private boolean initScheduleEvent(BwEvent event,
                                    ScheduleResult sr) throws CalFacadeException {
    Collection<String> recipients = event.getRecipients();
    if ((recipients == null) || recipients.isEmpty()) {
      sr.errorCode = CalFacadeException.schedulingNoRecipients;
      return false;
    }

    svci.setupSharableEntity(event, svci.getUser());
    event.setDtstamps();

    svci.assignGuid(event); // no-op if already set

    /* Ensure attendees have sequence and dtstamp of event */
    if (event.getNumAttendees() > 0) {
      for (BwAttendee att: event.getAttendees()) {
        att.setSequence(event.getSequence());
        att.setDtstamp(event.getDtstamp());
      }
    }

    return true;
  }

  /* Send the meeting request. If recipient is non-null send only to that recipient
   * (used for REFRESH handling), otherwise send to recipients in event.
   */
  private Collection<String> sendSchedule(ScheduleResult sr,
                                          EventInfo ei,
                                          String recipient) throws CalFacadeException {
    /* Recipients external to the system. */
    Collection<String> externalRcs = null;
    BwEvent ev = ei.getEvent();
    boolean freeBusyRequest = ev.getEntityType() ==
      CalFacadeDefs.entityTypeFreeAndBusy;

    if (recipient != null) {
      externalRcs = getRecipientInbox(recipient, sr, externalRcs);
    } else {
      for (String recip: ev.getRecipients()) {
        externalRcs = getRecipientInbox(recip, sr, externalRcs);
      }
    }

    if (sr.errorCode != null) {
      /* Cannot continue if any disallowed
       */
       return externalRcs;
    }

    for (ScheduleRecipientResult sres: sr.recipientResults) {
      UserInbox ui = (UserInbox)sres;

      if (sr.ignored) {
        ui.status = ScheduleRecipientResult.scheduleIgnored;
        continue;
      }

      if (ui.status == ScheduleRecipientResult.scheduleUnprocessed) {
        try {
          if (freeBusyRequest) {
            sres.freeBusy = getFreeBusy(null, ui.user,
                                        ev.getDtstart(), ev.getDtend());
          } else if (!ui.account.equals(svci.getUser().getAccount())) {
            addToInbox(ui, copyEventInfo(ei, ui.user));
          }

          ui.status = ScheduleRecipientResult.scheduleOk;
        } catch (CalFacadeAccessException cae) {
          ui.status = ScheduleRecipientResult.scheduleNoAccess;
        }
      }

      if (debug) {
        trace("added recipient " + ui.recipient + " status = " + ui.status);
      }

      if (!freeBusyRequest && (autoSchedule != null) &&
          (ui.inboxEvent != null)) {
        autoSchedule.add(ui.account, ui.inboxEvent.getEvent().getName(), null);
      }
    }

    return externalRcs;
  }

  private Collection<String>  getRecipientInbox(String recip,
                                                ScheduleResult sr,
                                                Collection<String> externalRcs)
                                                throws CalFacadeException {
    UserInbox ui = getInbox(recip);

    if (ui.status == ScheduleRecipientResult.scheduleDeferred) {
      if (externalRcs == null) {
        externalRcs = new TreeSet<String>();
      }

      externalRcs.add(recip);
    } else if (ui.status == ScheduleRecipientResult.scheduleNoAccess) {
      sr.errorCode = CalFacadeException.schedulingAttendeeAccessDisallowed;
    }

    sr.recipientResults.add(ui);

    return externalRcs;
  }

  private static class UserInbox extends ScheduleRecipientResult {
    String account;
    BwUser user;
    BwCalendar inbox; // null for our own account

    /* Event we added to the inbox */
    EventInfo inboxEvent;
  }

  /* Return with deferred for external user.
   */
  private UserInbox getInbox(String recipient) throws CalFacadeException {
    UserInbox ui = new UserInbox();
    ui.account = svci.getDirectories().caladdrToUser(recipient);

    ui.recipient = recipient;

    if (ui.account == null) {
      /* External to the system */
      ui.status = ScheduleRecipientResult.scheduleDeferred;

      return ui;
    }

    try {
      if (ui.account.equals(svci.getUser().getAccount())) {
        /* This is our own account. Let's not add it to our inbox.
         */
        ui.user = svci.getUser();
        ui.status = ScheduleRecipientResult.scheduleUnprocessed;
        return ui;
      }

      ui.user = svci.findUser(ui.account, true);

      ui.inbox = svci.getSpecialCalendar(ui.user,
                                         BwCalendar.calTypeInbox,
                                         true,
                                         PrivilegeDefs.privScheduleRequest).cal;
    } catch (CalFacadeAccessException cae) {
      ui.status = ScheduleRecipientResult.scheduleNoAccess;
    }

    return ui;
  }

  /* Add the (already cloned) copy to the users inbox.
   *
   */
  private void addToInbox(UserInbox ui,
                          EventInfo ei) throws CalFacadeException {
    ui.inboxEvent = ei;
    // Recipients should not be able to see other recipients.

    BwEvent ev = ei.getEvent();
    ev.setRecipients(null);
    ev.addRecipient(svci.getDirectories().userToCaladdr(ui.user.getAccount()));

    /* Make up a unique name for the event. */
    ev.setName("In-" + CalFacadeUtil.getUid() + ".ics");
    if (debug) {
      trace("Add event with name " + ev.getName());
    }

    ev.setScheduleState(BwEvent.scheduleStateNotProcessed);

    svci.addEvent(ui.inbox, ei, true, false);
  }

  /*
   * 2.1.5 Message Sequencing

     CUAs that handle the [iTIP] application protocol must often correlate
     a component in a calendar store with a component received in the
     [iTIP] message. For example, an event may be updated with a later
     revision of the same event. To accomplish this, a CUA must correlate
     the version of the event already in its calendar store with the
     version sent in the [iTIP] message. In addition to this correlation,
     there are several factors that can cause [iTIP] messages to arrive in
     an unexpected order.  That is, an "Organizer" could receive a reply
     to an earlier revision of a component AFTER receiving a reply to a
     later revision.

     To maximize interoperability and to handle messages that arrive in an
     unexpected order, use the following rules:

     1.  The primary key for referencing a particular iCalendar component
         is the "UID" property value. To reference an instance of a
         recurring component, the primary key is composed of the "UID" and
         the "RECURRENCE-ID" properties.

     2.  The secondary key for referencing a component is the "SEQUENCE"
         property value.  For components where the "UID" is the same, the
         component with the highest numeric value for the "SEQUENCE"
         property obsoletes all other revisions of the component with
         lower values.

     3.  "Attendees" send "REPLY" messages to the "Organizer".  For
         replies where the "UID" property value is the same, the value of
         the "SEQUENCE" property indicates the revision of the component
         to which the "Attendee" is replying.  The reply with the highest
         numeric value for the "SEQUENCE" property obsoletes all other
         replies with lower values.

     4.  In situations where the "UID" and "SEQUENCE" properties match,
         the "DTSTAMP" property is used as the tie-breaker. The component
         with the latest "DTSTAMP" overrides all others. Similarly, for
         "Attendee" responses where the "UID" property values match and
         the "SEQUENCE" property values match, the response with the
         latest "DTSTAMP" overrides all others.

       We compare two events for order according to the above rules. We retrieved
       the second event from the outbox or inbox using the uid so we know the uids
       match.

       return 0 for equal.
             -1 for event 1 < event 2
              1 for event 1 > event 2
   * /
  private int checkSequence(BwEvent ev1, BwEvent ev2) {
    int seq1 = ev1.getSequence();
    int seq2 = ev2.getSequence();

    if (seq1 < seq2) {
      return -1;
    }

    if (seq1 > seq2) {
      return 1;
    }

    String dtstamp1 = ev1.getDtstamp();
    String dtstamp2 = ev2.getDtstamp();

    return CalFacadeUtil.compareStrings(dtstamp1, dtstamp2);
  }*/

  /* clone it all */
  private EventInfo copyEventInfo(EventInfo ei,
                                  BwUser owner) throws CalFacadeException {
    BwEvent newEv = copyEvent(ei.getEvent(), null, owner);
    EventInfo newEi = new EventInfo(newEv);

    Collection<EventInfo> overrides = ei.getOverrides();
    if (overrides != null) {
      for (EventInfo oei: overrides) {
        newEi.addOverride(new EventInfo(copyEvent(oei.getEvent(), newEv,
                                                  owner)));
      }
    }

    return newEi;
  }

  private BwEvent copyEvent(BwEvent origEv, BwEvent masterEv,
                            BwUser owner) throws CalFacadeException {
    BwEvent newEv;
    BwEventProxy proxy = null;

    if (origEv instanceof BwEventProxy) {
      proxy = (BwEventProxy)origEv;

      svci.reAttach(proxy.getRef());

      if (masterEv == null) {
        /* we are being asked to copy an instance of a recurring event - rather than
         * a complete recurring event + all overrides - clone the master
         */
        newEv = new BwEventObj();
        origEv.copyTo(newEv);
        newEv.setRecurring(false);
        proxy = null; // Return the instance copy
      } else {
        proxy = proxy.clone(masterEv, masterEv); // ANNOTATION
        newEv = proxy.getRef();
      }
    } else {
      svci.reAttach(origEv);

      newEv = (BwEvent)origEv.clone();
    }

    newEv.setOwner(owner);
    newEv.setCreator(owner);
    newEv.setDtstamps();

    if (owner.equals(svci.getUser())) {
      if (proxy != null) {
        return proxy;
      }
      return newEv;
    }

    /* Copy event entities */
    BwLocation loc = newEv.getLocation();
    if (loc != null) {
      loc = (BwLocation)loc.clone();
      loc.setOwner(owner);
      loc.setCreator(owner);
      newEv.setLocation(loc);
    }

    BwContact contact = newEv.getContact();
    if (contact != null) {
      newEv.setContact((BwContact)contact.clone());
      contact.setOwner(owner);
      contact.setCreator(owner);
    }

    if (proxy != null) {
      return proxy;
    }
    return newEv;
  }

  /* Add the event to newcal or update the copies in eventCals
   *
   * action is for cancels only
   *
   * reply is true if we are processing a reply from an attendee
   */
  private boolean updateScheduleCalendar(BwCalendar newCal,
                                         Collection<BwCalendar> eventCals,
                                         EventInfo ei,
                                         BwAttendee att,
                                         ScheduleResult sr,
                                         int action) throws CalFacadeException {
    if (newCal != null) {
      // Adding a copy
      EventInfo calEi = copyEventInfo(ei, svci.getUser());
      BwEvent calEv = calEi.getEvent();
      calEv.setCalendar(newCal);

      for (BwAttendee calAtt: calEv.getAttendees()) {
        if (calAtt.equals(att)) {
          att.copyTo(calAtt);
          break;
        }
      }

      try {
        svci.addEvent(newCal, calEi, false);
      } catch (CalFacadeException cfe) {
        if (CalFacadeException.duplicateGuid.equals(cfe.getMessage())) {
          sr.errorCode = CalFacadeException.schedulingDuplicateUid;
          svci.rollbackTransaction();
          return false;
        }

        throw cfe;
      }

      return true;
    }

    if ((eventCals == null) || eventCals.isEmpty()) {
      return true;
    }

    /* Update the copies in the given calendars. Ignore the inbox copy.
     */

    // DORECUR is this right?
    RecurringRetrievalMode rrm = new RecurringRetrievalMode(Rmode.overrides);

    Collection<EventInfo> evs = new TreeSet<EventInfo>();
    BwEvent ev = ei.getEvent();

    for (BwCalendar eventCal: eventCals) {
      evs.addAll(svci.getEvent(null, eventCal, ev.getUid(),
                               ev.getRecurrenceId(), rrm));
    }

    if (evs.size() == 0) {
      sr.errorCode = CalFacadeException.schedulingUnknownEvent;

      return true;
    }

    for (EventInfo calEi: evs) {
      BwEvent calEv = calEi.getEvent();

      if (ev.equals(calEv) || // The inbox event
         (calEv.getCalendar().getCalType() != BwCalendar.calTypeCollection)) {
        continue;
      }

      if (ev.getScheduleMethod() == Icalendar.methodTypeReply) {
        /* Update the participation status from the incoming attendee */

        BwAttendee outAtt = calEv.findAttendee(att.getAttendeeUri());
        if (outAtt == null) {
          if (debug) {
            trace("Not an attendee of " + calEv);
          }
          sr.errorCode = CalFacadeException.schedulingUnknownAttendee;
          sr.extraInfo = att.getAttendeeUri();
          return false;
        }

        //att.copyTo(outAtt);
        // Replace or we update all recurring instances.
        calEv.removeAttendee(att);
        calEv.addAttendee((BwAttendee)att.clone());
      } else if (ev.getScheduleMethod() == Icalendar.methodTypeRequest) {
        // We are the attendee - update our copy
        // XXX We need some way of determining what changes were made - a
        // change list?
        calEv.updateFrom(ev);

        CalFacadeUtil.updateCollection(ev.getAttendees(), calEv.getAttendees());

        /*
        for (BwAttendee calAtt: calEv.getAttendees()) {
          if (calAtt.equals(att)) {
            att.copyTo(calAtt);
            break;
          }
        }*/
        if (calEv.getAttendees().contains(att)) {
          calEv.removeAttendee(att);
          calEv.addAttendee((BwAttendee)att.clone());
        }
      } else if (ev.getScheduleMethod() == Icalendar.methodTypeCancel) {
        if (action == BwPreferences.scheduleAutoCancelDelete) {
          svci.deleteEvent(calEv, true);
        } else if (action == BwPreferences.scheduleAutoCancelSetStatus) {
          calEv.setStatus(BwEvent.statusCancelled);
          svci.updateEvent(calEv, null, null);
        } else {
          sr.errorCode = CalFacadeException.schedulingBadAction;
          return false;
        }
      } else {
      }

      // XXX Ensure no name change
      if (calEv instanceof BwEventProxy) {
        BwEventProxy pr = (BwEventProxy)calEv;

        BwEventAnnotation ann = pr.getRef();
        ann.setName(null);
      }
      svci.updateEvent(calEv, null, null);
    }

    return true;
  }

  private void addToOutBox(EventInfo ei, BwCalendar outBox,
                           Collection<String> externalRcs) throws CalFacadeException {
    // We have external recipients. Put in the outbox for mailing
    EventInfo outEi = copyEventInfo(ei, svci.getUser());

    BwEvent event = ei.getEvent();
    event.setScheduleState(BwEvent.scheduleStateNotProcessed);
    event.setRecipients(externalRcs);
    /* Make up a unique name for the event. */
    event.setName("Out-" + CalFacadeUtil.getUid() + ".ics");

    /*EventUpdateResult eur =*/ svci.addEvent(outBox, outEi, false);
  //} else {
    // Keep a record in the Outbox
    //event.setScheduleState(BwEvent.scheduleStateExternalDone);
    processOutBox(outBox);
  }

  /* Temporary(?) method to process pending messages in outbox.
   *
   */
  private void processOutBox(BwCalendar outBox) throws CalFacadeException {
    BwSubscription sub = BwSubscription.makeSubscription(outBox);
    RecurringRetrievalMode rrm = new RecurringRetrievalMode(Rmode.overrides);

    IcalTranslator trans = new IcalTranslator(svci.getIcalCallback(), debug);

    for (EventInfo ei: svci.getEvents(sub, rrm)) {
      BwEvent ev = ei.getEvent();
      Calendar cal = trans.toIcal(ei, ev.getScheduleMethod());

      Collection<String> recipients = new ArrayList<String>();
      for (String r: ev.getRecipients()) {
        if (r.startsWith("mailto:")) {
          recipients.add(r.substring(7));
        } else {
          recipients.add(r);
        }
      }

      String orig = ev.getOriginator();
      if (orig.startsWith("mailto:")) {
        orig = orig.substring(7);
      }

      try {
        if (svci.getMailer().mailEntity(cal, orig, recipients,
                               ev.getSummary())) {
          /* Save sent messages somewhere - keep in outbox?
            ev.setScheduleState(BwEvent.scheduleStateExternalDone);
            updateEvent(ev, ei.getOverrideProxies(), null);
           */
          svci.deleteEvent(ev, true);
        }
      } catch (CalFacadeException cfe) {
        // Should count the exceptions and discard after a number of retries.
        error(cfe);
      }
    }
  }

  /* Get a logger for messages
   */
  private Logger getLogger() {
    if (log == null) {
      log = Logger.getLogger(this.getClass());
    }

    return log;
  }

  private void trace(String msg) {
    getLogger().debug(msg);
  }

  private void error(Throwable t) {
    getLogger().error(this, t);
  }
}
