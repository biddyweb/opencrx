/* **********************************************************************
    Copyright 2007 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calsvc.directory;

import org.bedework.calcorei.HibSession;
import org.bedework.calfacade.BwGroup;
import org.bedework.calfacade.BwGroupEntry;
import org.bedework.calfacade.BwPrincipal;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.BwUserInfo;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.svc.HostInfo;
import org.bedework.calfacade.util.AbstractDirImpl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.TreeSet;

/** An implementation of Directories which stores groups in the calendar
 * database. It is assumed a production system will use the ldap implementation
 * or something like it.
 *
 * @author Mike Douglass douglm@rpi.edu
 * @version 1.0
 */
public class GroupsDbImpl extends AbstractDirImpl {
  /* The list of hosts we know about */
  private static Collection<HostInfo> hosts = new ArrayList<HostInfo>();

  private static long maxLife = 1000 * 60 * 5;

  private static volatile long lastRefresh;

  public boolean validUser(String account) throws CalFacadeException {
    // XXX Not sure how we might use this for admin users.
    if (account == null) {
      return false;
    }
    return !account.startsWith("invalid");  // allow some testing
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.util.AbstractDirImpl#findHostInfo(java.lang.String)
   */
  public HostInfo findHostInfo(String domain) throws CalFacadeException {
    HostInfo hi = null;

    synchronized (hosts) {
      if (System.currentTimeMillis() - lastRefresh > maxLife) {
        hosts.clear();

        HibSession sess = getSess();

        StringBuilder sb = new StringBuilder("from ");
        sb.append(HostInfo.class.getName());

        sess.createQuery(sb.toString());

        hosts.addAll(sess.getList());

        lastRefresh = System.currentTimeMillis();
      }

      int matchLen = 0;
      HostInfo curHi = null;
      int domainLen = domain.length();

      for (HostInfo h: hosts) {
        String hostname = h.getHostname();
        int len = hostname.length();

        if (domain.endsWith(hostname)) {
          if (len == domainLen) {
            curHi = h;
            break;
          }

          if (len > matchLen) {
            matchLen = len;
            curHi = h;
          }
        }
      }

      hi = curHi;
    }

    return hi;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.ifs.Directories#getDirInfo(java.lang.String)
   */
  public BwUserInfo getDirInfo(String account) throws CalFacadeException {
    HibSession sess = getSess();

    sess.namedQuery("getUserInfo");
    sess.setEntity("user", new BwUser(account));

    return (BwUserInfo)sess.getUnique();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.ifs.Groups#getGroups(org.bedework.calfacade.BwPrincipal)
   */
  @SuppressWarnings("unchecked")
  public Collection<BwGroup> getGroups(BwPrincipal val) throws CalFacadeException {
    HibSession sess = getSess();

    sess.namedQuery("getGroups");
    sess.setInt("entId", val.getId());

    /* This is what I want to do but it inserts 'true' or 'false'
    sess.setBool("isgroup", (val instanceof BwGroup));
    */
    if (val instanceof BwGroup) {
      sess.setString("isgroup", "T");
    } else {
      sess.setString("isgroup", "F");
    }

    return new TreeSet<BwGroup>(sess.getList());
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.ifs.Groups#getAllGroups(org.bedework.calfacade.BwPrincipal)
   */
  public Collection<BwGroup> getAllGroups(BwPrincipal val) throws CalFacadeException {
    Collection<BwGroup> groups = getGroups(val);
    Collection<BwGroup> allGroups = new TreeSet<BwGroup>(groups);

    for (BwGroup grp: groups) {
      Collection<BwGroup> gg = getAllGroups(grp);
      if (!gg.isEmpty()) {
        allGroups.addAll(gg);
      }
    }

    return allGroups;
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.ifs.Groups#getGroupMaintOK()
   */
  public boolean getGroupMaintOK() {
    return true;
  }

  @SuppressWarnings("unchecked")
  public Collection<BwGroup> getAll(boolean populate) throws CalFacadeException {
    HibSession sess = getSess();

    sess.namedQuery("getAllGroups");

    Collection<BwGroup> gs = sess.getList();

    if (!populate) {
      return gs;
    }

    for (BwGroup grp: gs) {
      getMembers(grp);
    }

    return gs;
  }

  @SuppressWarnings("unchecked")
  public void getMembers(BwGroup group) throws CalFacadeException {
    HibSession sess = getSess();

    sess.namedQuery("getGroupUserMembers");
    sess.setEntity("gr", group);

    Collection ms = sess.getList();

    sess.namedQuery("getGroupGroupMembers");
    sess.setEntity("gr", group);

    ms.addAll(sess.getList());

    group.setGroupMembers(ms);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.ifs.Groups#addGroup(org.bedework.calfacade.BwGroup)
   */
  public void addGroup(BwGroup group) throws CalFacadeException {
    if (findGroup(group.getAccount()) != null) {
      throw new CalFacadeException(CalFacadeException.duplicateAdminGroup);
    }
    getSess().save(group);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.ifs.Groups#findGroup(java.lang.String)
   */
  public BwGroup findGroup(String name) throws CalFacadeException {
    HibSession sess = getSess();

    sess.createQuery("from " + BwGroup.class.getName() + " g " +
                     "where g.account = :account");
    sess.setString("account", name);

    return (BwGroup)sess.getUnique();
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.ifs.Groups#addMember(org.bedework.calfacade.BwGroup, org.bedework.calfacade.BwPrincipal)
   */
  public void addMember(BwGroup group,
                        BwPrincipal val) throws CalFacadeException {
    BwGroup g = findGroup(group.getAccount());

    if (g == null) {
      throw new CalFacadeException("Group " + group + " does not exist");
    }

    if (!checkPathForSelf(group, val)) {
      throw new CalFacadeException(CalFacadeException.alreadyOnGroupPath);
    }

    g.addGroupMember(val);

    BwGroupEntry ent = new BwGroupEntry();

    ent.setGrp(g);
    ent.setMember(val);

    getSess().save(ent);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.ifs.Groups#removeMember(org.bedework.calfacade.BwGroup, org.bedework.calfacade.BwPrincipal)
   */
  public void removeMember(BwGroup group,
                           BwPrincipal val) throws CalFacadeException {
    BwGroup g = findGroup(group.getAccount());
    HibSession sess = getSess();

    if (g == null) {
      throw new CalFacadeException("Group " + group + " does not exist");
    }

    g.removeGroupMember(val);

    //BwAdminGroupEntry ent = new BwAdminGroupEntry();

    //ent.setGrp(ag);
    //ent.setMember(val);

    sess.namedQuery("findGroupEntry");
    sess.setEntity("grp", group);
    sess.setInt("mbrId", val.getId());

    /* This is what I want to do but it inserts 'true' or 'false'
    sess.setBool("isgroup", (val instanceof BwGroup));
    */
    if (val instanceof BwGroup) {
      sess.setString("isgroup", "T");
    } else {
      sess.setString("isgroup", "F");
    }

    BwGroupEntry ent = (BwGroupEntry)sess.getUnique();

    if (ent == null) {
      return;
    }

    getSess().delete(ent);
  }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.ifs.Groups#removeGroup(org.bedework.calfacade.BwGroup)
   */
  public void removeGroup(BwGroup group) throws CalFacadeException {
    // Remove all group members
    HibSession sess = getSess();

    sess.namedQuery("removeAllGroupMembers");
    sess.setEntity("gr", group);
    sess.executeUpdate();

    // Remove from any groups

    sess.namedQuery("removeFromAllGroups");
    sess.setInt("mbrId", group.getId());

    /* This is what I want to do but it inserts 'true' or 'false'
    sess.setBool("isgroup", (val instanceof BwGroup));
    */
    sess.setString("isgroup", "T");
    sess.executeUpdate();

    sess.delete(group);
 }

  /* (non-Javadoc)
   * @see org.bedework.calfacade.ifs.Groups#updateGroup(org.bedework.calfacade.BwGroup)
   */
  public void updateGroup(BwGroup group) throws CalFacadeException {
    getSess().saveOrUpdate(group);
  }

  @SuppressWarnings("unchecked")
  public Collection<BwGroup> findGroupParents(BwGroup group) throws CalFacadeException {
    HibSession sess = getSess();

    /* Want this
    sess.createQuery("from " + BwAdminGroup.class.getName() + " ag " +
                     "where mbr in elements(ag.groupMembers)");
    sess.setEntity("mbr", val);
    */

    sess.namedQuery("getGroupParents");
    sess.setInt("grpid", group.getId());

    return sess.getList();
  }

  /* ====================================================================
   *  Abstract methods.
   * ==================================================================== */

  protected String getConfigName() {
    return "module.dir-config";
  }

  /* ====================================================================
   *  Private methods.
   * ==================================================================== */

  private boolean checkPathForSelf(BwGroup group,
                                   BwPrincipal val) throws CalFacadeException {
    if (group.equals(val)) {
      return false;
    }

    /* get all parents of group and try again */

    for (BwGroup g: findGroupParents(group)) {
      if (!checkPathForSelf(g, val)) {
        return false;
      }
    }

    return true;
  }

  private HibSession getSess() throws CalFacadeException {
    return (HibSession)cb.getDbSession();
  }
}

