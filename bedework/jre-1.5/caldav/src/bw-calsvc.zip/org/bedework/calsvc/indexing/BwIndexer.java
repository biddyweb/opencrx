/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/

package org.bedework.calsvc.indexing;

import org.bedework.calfacade.exc.CalFacadeException;

import edu.rpi.cct.misc.indexing.Index;
import edu.rpi.cct.misc.indexing.SearchLimits;

import java.io.Serializable;

/**
 * @author douglm
 *
 */
public interface BwIndexer extends Serializable {

  /** Called to find entries that match the search string. This string may
   * be a simple sequence of keywords or some sort of query the syntax of
   * which is determined by the underlying implementation.
   *
   * @param   query        Query string
   * @param   limits       Search limits to apply or null
   * @return  int          Number found. 0 means none found,
   *                                -1 means indeterminate
   * @throws CalFacadeException
   */
  public int search(String query, SearchLimits limits) throws CalFacadeException;

  /** Called to unindex a record
   *
   * @param   rec      The record to unindex
   * @throws CalFacadeException
   */
  public void unindexEntity(Object rec) throws CalFacadeException;

  /** Called to index a record
   *
   * @param rec
   * @throws CalFacadeException
   */
  public void indexEntity(Object rec) throws CalFacadeException;

  /** Called to retrieve record keys from the result.
   *
   * @param   n        Starting index
   * @param   keys     Array for the record keys
   * @return  int      Actual number of records
   * @throws CalFacadeException
   */
  public int getKeys(int n, Index.Key[] keys) throws CalFacadeException;


  /** Set to > 1 to enable batching
   *
   * @param val
   */
  public void setBatchSize(int val);

  /** Called at the end of a batch of updates.
   *
   * @throws CalFacadeException
   */
  public void endBwBatch() throws CalFacadeException;

  /** Flush any batched entities.
   * @throws CalFacadeException
   */
  public void flush() throws CalFacadeException;

  /** Indicate if we should try to clean locks.
   *
   * @param val
   */
  public void setCleanLocks(boolean val);
}
