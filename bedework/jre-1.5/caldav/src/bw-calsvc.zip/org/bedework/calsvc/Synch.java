/* **********************************************************************
    Copyright 2007 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calsvc;

import org.bedework.calcorei.HibSession;
import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.syncml.BwSynchData;
import org.bedework.calfacade.syncml.BwSynchInfo;
import org.bedework.calfacade.syncml.BwSynchState;
import org.bedework.calsvci.SynchI;

import java.util.Collection;

/** This acts as an interface to the database for subscriptions.
*
* @author Mike Douglass       douglm - rpi.edu
*/
class Synch extends CalSvcDb implements SynchI {
  /** Non-null if this is for synchronization. Identifies the client end.
   */
  protected String synchId;

  Synch(CalSvc svci, BwUser user, String synchId, boolean debug) {
    super(svci, user, debug);
    this.synchId = synchId;
  }

   /* (non-Javadoc)
   * @see org.bedework.calsvci.SynchI#getInfo()
   */
  public BwSynchInfo getInfo() throws CalFacadeException {
     HibSession sess = getSess();

     if (debug) {
       trace("getSynchInfo for user=" + getUser() +
             " deviceId=" + synchId);
     }

     sess.namedQuery("getSynchInfo");
     sess.setEntity("user", getUser());
     sess.setString("deviceId", synchId);

     BwSynchInfo si = (BwSynchInfo)sess.getUnique();

     return si;
   }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SynchI#addInfo(org.bedework.calfacade.syncml.BwSynchInfo)
   */
  public void addInfo(BwSynchInfo val) throws CalFacadeException {
    HibSession sess = getSess();

    if (debug) {
      trace("addSynchInfo for user=" + val.getUser() +
            " deviceId=" + val.getDeviceId());
    }

    sess.save(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SynchI#updateInfo(org.bedework.calfacade.syncml.BwSynchInfo)
   */
  public void updateInfo(BwSynchInfo val) throws CalFacadeException {
    HibSession sess = getSess();

    sess.saveOrUpdate(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SynchI#getState(org.bedework.calfacade.BwEvent)
   */
  public BwSynchState getState(BwEvent ev) throws CalFacadeException {
    HibSession sess = getSess();

    sess.namedQuery("getSynchState");
    sess.setEntity("event", ev);
    sess.setEntity("user", getUser());
    sess.setString("deviceId", synchId);

    BwSynchState ss = (BwSynchState)sess.getUnique();

    return ss;
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SynchI#getDeleted()
   */
  @SuppressWarnings("unchecked")
  public Collection<BwSynchState> getDeleted() throws CalFacadeException {
    HibSession sess = getSess();

    sess.namedQuery("getDeletedSynchStates");
    sess.setEntity("user", getUser());
    sess.setString("deviceId", synchId);
    sess.setInt("synchState", BwSynchState.DELETED);

    return sess.getList();
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SynchI#addState(org.bedework.calfacade.syncml.BwSynchState)
   */
  public void addState(BwSynchState val) throws CalFacadeException {
    HibSession sess = getSess();

    sess.save(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SynchI#updateState(org.bedework.calfacade.syncml.BwSynchState)
   */
  public void updateState(BwSynchState val) throws CalFacadeException {
    HibSession sess = getSess();

    sess.saveOrUpdate(val);
  }

  /*
  public int setState(BwEvent ev, int state) throws CalFacadeException {
    HibSession sess = getSess();

    sess.namedQuery("setSynchState");
    sess.setInt("state", state);
    sess.setInt("eventid", ev.getId());

    return sess.executeUpdate();
  }*/

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SynchI#getData(org.bedework.calfacade.syncml.BwSynchState)
   */
  public void getData(BwSynchState val) throws CalFacadeException {
    HibSession sess = getSess();

    sess.namedQuery("getSynchData");
    sess.setEntity("user", val.getUser());
    sess.setInt("eventid", val.getEvent().getId());

    BwSynchData sd = (BwSynchData)sess.getUnique();

    val.setSynchData(sd);
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SynchI#setData(org.bedework.calfacade.syncml.BwSynchState)
   */
  public void setData(BwSynchState val) throws CalFacadeException {
    HibSession sess = getSess();

    sess.saveOrUpdate(val);
    setSynchStateUser(val.getEvent(), BwSynchState.CLIENT_MODIFIED_UNDELIVERED);
    sess.saveOrUpdate(val.getSynchData());
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.SynchI#updateStates()
   */
  public void updateStates() throws CalFacadeException {
    HibSession sess = getSess();

    sess.namedQuery("updateSynchStates1");
    sess.setInt("newstate", BwSynchState.SYNCHRONIZED);
    sess.setInt("userid", getUser().getId());
    sess.setString("deviceid", synchId);
    sess.setInt("state", BwSynchState.MODIFIED);

    sess.namedQuery("updateSynchStates2");
    sess.setInt("newstate", BwSynchState.CLIENT_DELETED);
    sess.setInt("userid", getUser().getId());
    sess.setString("deviceid", synchId);
    sess.setInt("state", BwSynchState.CLIENT_DELETED_UNDELIVERED);

    sess.namedQuery("updateSynchStates2");
    sess.setInt("newstate", BwSynchState.CLIENT_MODIFIED);
    sess.setInt("userid", getUser().getId());
    sess.setString("deviceid", synchId);
    sess.setInt("state", BwSynchState.CLIENT_MODIFIED_UNDELIVERED);
  }

  /* ====================================================================
   *                   Private methods
   * ==================================================================== */

  private int setSynchStateUser(BwEvent ev, int state)
        throws CalFacadeException {
    HibSession sess = getSess();

    sess.namedQuery("setSynchStateUser");
    sess.setInt("state", state);
    sess.setEntity("user", getUser());
    sess.setInt("eventid", ev.getId());

    return sess.executeUpdate();
  }
}

