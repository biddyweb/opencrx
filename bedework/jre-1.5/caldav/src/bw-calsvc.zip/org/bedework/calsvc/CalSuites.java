/* **********************************************************************
    Copyright 2007 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calsvc;

import org.bedework.calcorei.HibSession;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.svc.BwAdminGroup;
import org.bedework.calfacade.svc.BwCalSuite;
import org.bedework.calfacade.svc.wrappers.BwCalSuiteWrapper;
import org.bedework.calsvci.CalSuitesI;

import edu.rpi.cmt.access.PrivilegeDefs;
import edu.rpi.cmt.access.Acl.CurrentAccess;

import java.util.Collection;
import java.util.TreeSet;

/** This acts as an interface to the database for calendar uites.
 *
 * @author Mike Douglass       douglm - rpi.edu
 */
class CalSuites extends CalSvcDb implements CalSuitesI {
  private BwCalSuiteWrapper currentCalSuite;

  /** Constructor
   *
   * @param svci
   * @param user
   * @param debug
   */
  CalSuites(CalSvc svci, BwUser user, boolean debug) {
    super(svci, user, debug);
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSuitesI#add(org.bedework.calfacade.svc.BwCalSuite)
   */
  public BwCalSuiteWrapper add(BwCalSuite val) throws CalFacadeException {
    BwCalSuite cs = fetch(getSess(), val.getName());

    if (cs != null) {
      throw new CalFacadeException("org.bedework.duplicate.calsuite");
    }

    HibSession sess = getSess();

    sess.save(val);

    return new BwCalSuiteWrapper(val, checkAccess(val, PrivilegeDefs.privAny, false));
  }

  public void set(BwCalSuiteWrapper val) throws CalFacadeException {
    currentCalSuite = val;
  }

  public BwCalSuiteWrapper get() throws CalFacadeException {
    return currentCalSuite;
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSuitesI#get(java.lang.String)
   */
  public BwCalSuiteWrapper get(String name) throws CalFacadeException {
    BwCalSuite cs = fetch(getSess(), name);

    if (cs == null) {
      return null;
    }

    return new BwCalSuiteWrapper(cs, checkAccess(cs, PrivilegeDefs.privAny, false));
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSuitesI#get(org.bedework.calfacade.svc.BwAdminGroup)
   */
  public BwCalSuiteWrapper get(BwAdminGroup group)
        throws CalFacadeException {
    HibSession sess = (HibSession)getSess();

    sess.namedQuery("getCalSuiteByGroup");
    sess.setEntity("group", group);
    sess.cacheableQuery();

    BwCalSuite cs = (BwCalSuite)sess.getUnique();

    if (cs == null) {
      return null;
    }

    return new BwCalSuiteWrapper(cs, checkAccess(cs, PrivilegeDefs.privAny, false));
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSuitesI#getAll()
   */
  @SuppressWarnings("unchecked")
  public Collection<BwCalSuite> getAll() throws CalFacadeException {
    HibSession sess = getSess();

    StringBuilder sb = new StringBuilder();

    sb.append("from ");
    sb.append(BwCalSuite.class.getName());

    sess.createQuery(sb.toString());

    sess.cacheableQuery();

    Collection<BwCalSuite> css = sess.getList();

    TreeSet<BwCalSuite> retCss = new TreeSet<BwCalSuite>();

    for (BwCalSuite cs: css) {
      CurrentAccess ca = checkAccess(cs, PrivilegeDefs.privAny, true);

      if (ca.accessAllowed) {
        retCss.add(new BwCalSuiteWrapper(cs, ca));
      }
    }

    return retCss;
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSuitesI#update(org.bedework.calfacade.svc.wrappers.BwCalSuiteWrapper)
   */
  public void update(BwCalSuiteWrapper val) throws CalFacadeException {
    HibSession sess = getSess();

    sess.update(val.fetchEntity());
  }

  /* (non-Javadoc)
   * @see org.bedework.calsvci.CalSuitesI#delete(org.bedework.calfacade.svc.wrappers.BwCalSuiteWrapper)
   */
  public void delete(BwCalSuiteWrapper val) throws CalFacadeException {
    HibSession sess = getSess();

    sess.delete(val.fetchEntity());
  }

  /** Allows svc to retrieve the calSuite object used to configure a public
   * client.
   *
   * @param session
   * @param name
   * @return BwCalSuite object or null
   * @throws CalFacadeException
   */
  public static BwCalSuite fetch(Object session,
                                  String name) throws CalFacadeException {
    HibSession sess = (HibSession)session;

    sess.namedQuery("getCalSuite");
    sess.setString("name", name);
    sess.cacheableQuery();

    return (BwCalSuite)sess.getUnique();
  }
}

