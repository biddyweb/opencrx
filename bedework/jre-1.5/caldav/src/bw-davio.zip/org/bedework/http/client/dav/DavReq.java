/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.http.client.dav;

import java.util.ArrayList;
import java.util.Collection;

import org.apache.commons.httpclient.Header;
import org.bedework.http.client.DavioException;

/**
 * @author Mike Douglass douglm at rpi.edu
 *
 */
public class DavReq {
  private String user;
  private String pw;

  boolean auth;

  private String method;
  private String url;

  private String depth;

  private Collection<Header> hdrs;
  private Header[] headers;

  private String contentType;
  Collection<String> contentLines;
  byte[] contentBytes;

  /** Constructor
   *
   */
  public DavReq() {
  }

  /** Constructor
   *
   * @param user
   * @param pw
   */
  public DavReq(String user, String pw) {
    this.user = user;
    this.pw = pw;
    auth = true;
  }

  /**
   * @return String user
   */
  public String getUser() {
    return user;
  }

  /**
   * @return String pw
   */
  public String getPw() {
    return pw;
  }

  /**
   * @return boolean
   */
  public boolean getAuth() {
    return auth;
  }

  /**
   * @param val   String
   */
  public void setMethod(String val) {
    method = val;
  }

  /**
   * @return String
   */
  public String getMethod() {
    return method;
  }

  /**
   * @param val   String
   */
  public void setUrl(String val) {
    url = val;
  }

  /**
   * @return String url
   */
  public String getUrl() {
    return url;
  }

  /**
   * @param val   String
   */
  public void setDepth(String val) {
    depth = val;
  }

  /**
   * @return String
   */
  public String getDepth() {
    return depth;
  }

  /**
   * @param name
   * @param val
   */
  public void addHeader(String name, String val) {
    if (hdrs == null) {
      hdrs = new ArrayList<Header>();
    }

    hdrs.add(new Header(name, val));
  }

  /**
   * @return Header[]
   */
  public Header[] getHeaders() {
    if ((headers == null) && (hdrs != null)) {
      headers = (Header[])hdrs.toArray(new Header[hdrs.size()]);
    }

    return headers;
  }

  /**
   * @param val   String
   */
  public void setContentType(String val) {
    contentType = val;
  }

  /**
   * @return String
   */
  public String getContentType() {
    return contentType;
  }

  /**
   * @param val
   */
  public void addContentLine(String val) {
    if (contentLines == null) {
      contentLines = new ArrayList<String>();
    }

    contentLines.add(val);
    contentBytes = null;
  }

  /**
   * @return int content length
   * @throws DavioException
   */
  public int getContentLength() throws DavioException {
    if (contentLines == null) {
      return 0;
    }

    return getBytes().length;
  }

  /**
   * @return byte[]  content bytes
   * @throws DavioException
   */
  public byte[] getContentBytes() throws DavioException {
    if (contentLines == null) {
      return null;
    }

    return getBytes();
  }

  private byte[] getBytes() {
    if (contentBytes != null) {
      return contentBytes;
    }

    StringBuffer sb = new StringBuffer();

    for (String ln: contentLines) {
      sb.append(ln);
      sb.append("\n");
    }

    contentBytes = sb.toString().getBytes();

    return contentBytes;
  }
}
