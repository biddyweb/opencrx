/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.http.client.dav;

import java.io.InputStream;
import java.io.Serializable;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HostConfiguration;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.contrib.ssl.BaseProtocolSocketFactory;
import org.apache.commons.httpclient.methods.EntityEnclosingMethod;
import org.apache.commons.httpclient.protocol.Protocol;
import org.apache.commons.ssl.TrustMaterial;
import org.apache.log4j.Logger;
import org.bedework.http.client.DavioException;
import org.bedework.http.client.DepthHttpMethod;
import org.bedework.http.client.HttpManager;

import sun.misc.BASE64Encoder;

/** A dav client
*
* @author Mike Douglass  douglm @ rpi.edu
*/
public class DavClient implements Serializable {
  private boolean debug;

  private Logger log;

  private static HttpManager httpManager;

  private DavIo client;

  private int status;

 /**
  * @param host
  * @param port
  * @param timeOut - millisecs, 0 for no timeout
  * @param debug
  * @throws DavioException
  */
 public DavClient(String host, int port, int timeOut,
                  boolean debug) throws DavioException {
   this(host, port, timeOut, false, debug);
 }

 /**
  * @param host
  * @param port
  * @param timeOut - millisecs, 0 for no timeout
  * @param secure
  * @param debug
  * @throws DavioException
  */
  public DavClient(String host, int port, int timeOut, boolean secure,
                   boolean debug) throws DavioException {
    if (httpManager == null) {
      httpManager = new HttpManager(DavIo.class.getName());
    }

    HostConfiguration config = new HostConfiguration();

    if (secure) {
      /*
       ProtocolSocketFactory pfact = new SSLProtocolSocketFactory();
       Protocol pr = new Protocol("https", pfact, port);
       Protocol.registerProtocol( "https", pr);
       */
      Protocol trustHttps;

      try {
        BaseProtocolSocketFactory f = new BaseProtocolSocketFactory();

        warn("Trusting all certificates");
        // might as well trust the usual suspects:
        //f.addTrustMaterial(TrustMaterial.CACERTS);
        f.addTrustMaterial(TrustMaterial.TRUST_ALL);

        // here's where we start trusting usertrust.com's CA:
        //f.addTrustMaterial(new TrustMaterial(pemCert));

        trustHttps = new Protocol("https", f, 443);
        Protocol.registerProtocol("https", trustHttps);
      } catch (Throwable t) {
        throw new DavioException(t);
      }

      config.setHost(host, port, trustHttps);
    } else {
      config.setHost(host, port);
    }
    /*
     if (secure) {
     config.setHost(new URI("https://" + host + ":" + port, false));
     } else {
     config.setHost(new URI("http://" + host + ":" + port, false));
     }
     */
    if (debug) {
      debugMsg("uri set to " + config.getHostURL());
    }

    httpManager.getParams().setConnectionTimeout(timeOut);

    client = (DavIo)httpManager.getClient(config);

    this.debug = debug;
  }

  /** Send an unauthenticated request to the server
   *
   * @param method
   * @param url
   * @param hdrs
   * @param depth
   * @param contentType
   * @param contentLen
   * @param content
   * @return int    status code
   * @throws Throwable
   */
  public int sendRequest(String method, String url,
                         Header[] hdrs, String depth,
                         String contentType, int contentLen,
                         byte[] content) throws Throwable {
    return sendRequest(method, url, null, null, hdrs, depth,
                       contentType, contentLen, content);
  }

  /** Send an authenticated request to the server
   *
   * @param method
   * @param url
   * @param user
   * @param pw
   * @param hdrs
   * @param depth
   * @param contentType
   * @param contentLen
   * @param content
   * @return int    status code
   * @throws DavioException
   */
  public int sendRequest(String method, String url, String user, String pw,
                         Header[] hdrs, String depth,
                         String contentType, int contentLen,
                         byte[] content) throws DavioException {
    int sz = 0;
    if (content != null) {
      sz = content.length;
    }

    if (debug) {
       debugMsg("About to send request: method=" + method +
                " contentLen=" + contentLen +
                " content.length=" + sz +
                " contentType=" + contentType);
    }

    client.setMethodName(method, url);

    HttpMethod meth = client.getMethod();

    if (meth instanceof DepthHttpMethod) {
      ((DepthHttpMethod)meth).setDepth(depth);
    }

    if (user != null) {
      String upw = user + ":" + pw;

      meth.setRequestHeader("Authorization",
                            "Basic " +
                            new String(new BASE64Encoder().encode (upw.getBytes())));
    }

    if (hdrs != null) {
      for (int i = 0; i < hdrs.length; i++) {
        meth.addRequestHeader(hdrs[i]);
      }
    }

    if (meth instanceof EntityEnclosingMethod) {
      if (contentType == null) {
        contentType = "text/xml";
      }

      if (content != null) {
        client.setContent(content, contentType);
      }
    }

    status = client.execute();

    return status;
  }

  /** Get the response to the last request
   *
   * @return DavResp objct representing response
   * @throws DavioException
   */
  public DavResp getResponse() throws DavioException {
    return new Response(client, debug);
  }

  /**
   *
   */
  public void close() {
  }

  private static class Response implements DavResp {
//    private boolean debug;

    DavIo client;

    Response(DavIo client, boolean debug) throws DavioException {
      this.client = client;
//      this.debug = debug;
    }

    public int getRespCode() throws DavioException {
      return client.getStatusCode();
    }

    public String getContentType() throws DavioException {
      return client.getResponseContentType();
    }

    public long getContentLength() throws DavioException {
      return client.getResponseContentLength();
    }

    public String getCharset() throws DavioException {
      return client.getResponseCharSet();
    }

    public InputStream getContentStream() throws DavioException {
      return client.getResponseBodyAsStream();
    }

    public String getResponseBodyAsString() throws DavioException {
      return client.getResponseBodyAsString();
    }
  }

  /** ===================================================================
   *                   Logging methods
   *  =================================================================== */

  /**
   * @return Logger
   */
  protected Logger getLogger() {
    if (log == null) {
      log = Logger.getLogger(this.getClass());
    }

    return log;
  }

  protected void debugMsg(String msg) {
    getLogger().debug(msg);
  }

  protected void error(Throwable t) {
    getLogger().error(this, t);
  }

  protected void warn(String msg) {
    getLogger().warn(msg);
  }

  protected void logIt(String msg) {
    getLogger().info(msg);
  }

  protected void trace(String msg) {
    getLogger().debug(msg);
  }
}
