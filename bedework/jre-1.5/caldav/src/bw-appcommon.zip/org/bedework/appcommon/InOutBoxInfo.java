/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.appcommon;

import org.bedework.calfacade.BwCalendar;
import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.RecurringRetrievalMode;
import org.bedework.calfacade.RecurringRetrievalMode.Rmode;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.svc.BwSubscription;
import org.bedework.calfacade.svc.EventInfo;
import org.bedework.calfacade.timezones.CalTimezones;
import org.bedework.calsvci.CalSvcI;

import edu.rpi.cmt.access.Acl.CurrentAccess;

import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;

/** Class to hold info about a user's inbox or outbox.
 *
 * @author Mike Douglass   douglm@rpi.edu
 *  @version 1.0
 */
public class InOutBoxInfo implements Serializable {
  private CalendarInfo calInfo;
  private CalTimezones ctz;
  private CalSvcI svci;

  private boolean inbox; // false for outbox.

  private boolean changed; // Set true whenever the status changes.

  private String lastmod;

  private int sequence;

  private int numActive;

  private int numProcessed;

  /* Access set for this box */
  private CurrentAccess currentAccess;

  /** The events in the in/outbox
   */
  private FormattedEvents events;

  /** Constructor
   *
   * @param svci
   * @param calInfo
   * @param ctz
   * @param inbox  boolean
   * @throws CalFacadeException
   */
  public InOutBoxInfo(CalSvcI svci,
                      CalendarInfo calInfo, CalTimezones ctz,
                      boolean inbox) throws CalFacadeException {
    this.svci = svci;
    this.calInfo = calInfo;
    this.ctz = ctz;
    this.inbox = inbox;

    refresh(true);
  }

  /** Refresh the information
   *
   * @param all
   * @throws CalFacadeException
   */
  public void refresh(boolean all) throws CalFacadeException {
    int calType;
    if (inbox) {
      calType = BwCalendar.calTypeInbox;
    } else {
      calType = BwCalendar.calTypeOutbox;
    }

    BwCalendar cal = svci.getSpecialCalendar(calType, false);

    if (cal == null) {
      // Cannot go away - never existed - no change.
      changed = false;
      return;
    }

    if (!all) {
      synchronized (this) {
        currentAccess = cal.getCurrentAccess();

        String calLastmod = cal.getLastmod();
        int calSequence = cal.getSequence();

        if ((lastmod != null) && (lastmod.equals(calLastmod))) {
          if (sequence == calSequence) {
            changed = false;
            return;
          }
        }

        lastmod = calLastmod;
        sequence = calSequence;
      }
    }

    // XXX need to be able to store and retrieve other types of info.

    RecurringRetrievalMode rrm =
      new RecurringRetrievalMode(Rmode.overrides);
    Collection<EventInfo> evs = svci.getEvents(BwSubscription.makeSubscription(cal),
                                               null, null, null, rrm);
    Iterator evit = evs.iterator();

    numActive = 0;
    numProcessed = 0;

    while (evit.hasNext()) {
      EventInfo ei = (EventInfo)evit.next();

      BwEvent ev = ei.getEvent();

      if (ev.getScheduleState() == BwEvent.scheduleStateNotProcessed) {
        numActive++;
      }
    }

    events = new FormattedEvents(svci, evs, calInfo, ctz);
    changed = true;
  }

  /**
   * @param val boolean
   */
  public void setInbox(boolean val) {
    inbox = val;
  }

  /**
   * @return boolean
   */
  public boolean getInbox() {
    return inbox;
  }

  /**
   * @param val boolean
   */
  public void setChanged(boolean val) {
    changed = val;
  }

  /**
   * @return boolean
   */
  public boolean getChanged() {
    return changed;
  }

  /** Set the number active.
   *
   * @param val     numactive
   */
  public void setNumActive(int val) {
    numActive = val;
  }

  /** Get the number active.
   *
   * @return val     numactive
   */
  public int getNumActive() {
    return numActive;
  }

  /** Set the number Processed.
   *
   * @param val     numProcessed
   */
  public void setNumProcessed(int val) {
    numProcessed = val;
  }

  /** Get the number Processed.
   *
   * @return val     numProcessed
   */
  public int getNumProcessed() {
    return numProcessed;
  }

  /** Get the boxes current access
   *
   * @return CurrentAccess
   */
  public CurrentAccess getCurrentAccess() {
    return currentAccess;
  }

  /** Get the events. May be null.
   *
   * @return FormattedEvents or null.
   */
  public FormattedEvents getEvents() {
    return events;
  }
}
