/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/

package org.bedework.appcommon;

import org.bedework.calfacade.BwDateTime;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.timezones.CalTimezones;
import org.bedework.calfacade.util.CalFacadeUtil;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.FieldPosition;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.TimeZone;

/** Class to format and provide segments of dates and times.
 *
 * <p>There are 3 different times available to us (though some or all may be
 * equal depending upon your location).
 * <ul>
 * <li>The local time represented by the object</li>
 * <li>The time in the timezone specified by the object</li>
 * <li>UTC time for the object</li>
 * </ul>
 * <p>For example, we might have </br>
 *  EDT date/time of 2006-10-10 at 14:00 </br>
 *  UTC time of 2006-10-10 at 19:00 and a </br>
 *  local time if on the US West coast of 2006-10-10 at 11:00
 *
 * <p>Generally for display to the user we want to display the local time
 * whatever the timezone of the original date time.
 *
 * <p>This class makes two formatted date objects available, one the current
 * timezone representation and the other being the timezone for the date/time
 * object handed to the constructor.
 *
 * <p>If the timezone of the date/time object is the same as the current
 * timezone they are the same object.
 *
 * <ul>
 * <li>getFormattedDate - returns the local form</li>
 * <li>getTzFormattedDate - returns the form in it's specified timezone</li>
 * </ul>
 *
 * <p>The getXXX value and the getTZXXX will only differ if the timezone is
 * not the local timezone.
 *
 * @author Mike Douglass   douglm - rpi.edu
 *  @version 1.0
 */
public class DateTimeFormatter implements Comparable, Comparator, Serializable {
  /** The date/time we are handling.
   */
  private BwDateTime date;

  /* True if the date value has the local timezone */
  private boolean tzIsLocal;

  /* True if the date value is UTC */
  private boolean isUtc;

  /* What we store in the table */
  private static class Formatters implements Serializable {
//    DateFormat dayFormatter;
 ///   DateFormat shortDayFormatter;

    DateFormat longDateFormatter;
    DateFormat shortDateFormatter;
    DateFormat shortTimeFormatter;

    Formatters(Locale loc) {
    //  dayFormatter = new SimpleDateFormat("EEEE", loc);
      //shortDayFormatter = new SimpleDateFormat("E", loc);

      longDateFormatter = DateFormat.getDateInstance(DateFormat.LONG, loc);
      shortDateFormatter = DateFormat.getDateInstance(DateFormat.SHORT, loc);
      shortTimeFormatter = DateFormat.getTimeInstance(DateFormat.SHORT, loc);
    }
  }

  private FormattedDate formatted;

  private FormattedDate tzFormatted;

  /** The date and time fields will be either for the current timezone, usually
   *  the local one, or the timezone in the supplied BwDateTime object..
   *
   * @author douglm
   */
  public static class FormattedDate implements Serializable {
    private static volatile HashMap<Locale, Formatters> formattersTbl =
      new HashMap<Locale, Formatters>();

    private CalendarInfo calInfo;

    private GregorianCalendar cal;

    /* yyyyMMddThhmmss */
    private String isoDateTime;

    private boolean dateOnly;

    private TimeZone tz;

    /** Constructor
     *
     * @param dt
     * @param isoDateTime
     * @param dateOnly   true if date was a date-only value.
     * @param tz
     * @param calInfo
     */
    public FormattedDate(Date dt, String isoDateTime, boolean dateOnly,
                         TimeZone tz, CalendarInfo calInfo) {
      this.isoDateTime = isoDateTime;
      this.dateOnly = dateOnly;
      this.calInfo = calInfo;
      this.tz = tz;

      cal = new GregorianCalendar();
      if (tz != null) {
        cal.setTimeZone(tz);
      }
      cal.setTime(dt);
    }

    /** Return the date part in the rfc format yyyymmdd
     *
     * @return String date part in the rfc format yyyymmdd
     */
    public String getDate() {
      return isoDateTime.substring(0, 8);
    }


    /** Get the year for this object.
     *
     * @return int    year for this object
     */
    public int getYear() {
      try {
        return Integer.parseInt(isoDateTime.substring(0, 4));
      } catch (Throwable t) {
        return -1;
      }
    }

    /** Get a four-digit representation of the year
     *
     * @return String   four-digit representation of the year for this object.
     */
    public String getFourDigitYear() {
      try {
        return isoDateTime.substring(0, 4);
      } catch (Throwable t) {
        return "XXXX";
      }
    }

    /** Get the number of the month for this object. A value between 1-12
     *
     * @return int    month number for this object
     */
    public int getMonth() {
      try {
        return Integer.parseInt(isoDateTime.substring(4, 6));
      } catch (Throwable t) {
        return -1;
      }
    }

    /** Get a two-digit representation of the month of year
     *
     * @return String   two-digit representation of the month of year for
     *                  this object.
     */
    public String getTwoDigitMonth() {
      try {
        return isoDateTime.substring(4, 6);
      } catch (Throwable t) {
        return "XX";
      }
    }

    /** Get the long month name for this object.
     *
     * @return String    month name for this object
     */
    public String getMonthName() {
      Formatters fmt = getFormatters();
      FieldPosition f = new FieldPosition(DateFormat.MONTH_FIELD);
      synchronized (fmt) {
        StringBuffer s = fmt.longDateFormatter.format(cal.getTime(),
                                                      new StringBuffer(), f);
        return s.substring(f.getBeginIndex(), f.getEndIndex());
      }
    }

    /** Get the day of the month for this object. A value between 1-31
     *
     * @return int    day of the month for this object
     */
    public int getDay() {
      try {
        return Integer.parseInt(isoDateTime.substring(6, 8));
      } catch (Throwable t) {
        return -1;
      }
    }

    /** Get the day name for this object.
     *
     * @return String    day name for this object
     */
    public String getDayName() {
      return calInfo.getDayName(getDayOfWeek());
    }

    /** Get the day of the week
     *
     * @return The day of the week for a Calendar
     */
    public int getDayOfWeek() {
      return cal.get(Calendar.DAY_OF_WEEK);
    }

    /** Get a two-digit representation of the day of the month
     *
     * @return String   two-digit representation of the day of the month for
     *                  this object.
     */
    public String getTwoDigitDay() {
      try {
        return isoDateTime.substring(6, 8);
      } catch (Throwable t) {
        return "XX";
      }
    }

    /** Get the hour of the (24 hour) day for this object. A value between 0-23
     *
     * @return int    hour of the day for this object
     */
    public int getHour24() {
      if (dateOnly) {
        return 0;
      }

      try {
        return Integer.parseInt(isoDateTime.substring(9, 11));
      } catch (Throwable t) {
        return -1;
      }
    }

    /** Get a two-digit representation of the 24 hour day hour
     *
     * @return String   two-digit representation of the hour for this object.
     */
    public String getTwoDigitHour24() {
      if (dateOnly) {
        return "00";
      }

      try {
        return isoDateTime.substring(9, 11);
      } catch (Throwable t) {
        return "XX";
      }
    }

    /** Get the hour of the day for this object. A value between 1-12
     *
     * @return int    hour of the day for this object
     */
    public int getHour() {
      int hr = getHour24();

      if (hr == 0) {
        return 12; // midnight+
      }

      if (hr < 13) {
        return hr;
      }

      return hr - 12;
    }

    /** Get a two-digit representation of the hour
     *
     * @return String   two-digit representation of the hour for this object.
     */
    public String getTwoDigitHour() {
      String hr = String.valueOf(getHour());

      if (hr.length() == 2) {
        return hr;
      }

      return "0" + hr;
    }

    /** Get the minute of the hour for this object. A value between 0-59
     *
     * @return int    minute of the hour for this object
     */
    public int getMinute() {
      if (dateOnly) {
        return 0;
      }

      try {
        return Integer.parseInt(isoDateTime.substring(11, 13));
      } catch (Throwable t) {
        return -1;
      }
    }

    /** Get a two-digit representation of the minutes
     *
     * @return String   two-digit representation of the minutes for this object.
     */
    public String getTwoDigitMinute() {
      if (dateOnly) {
        return "00";
      }

      try {
        return isoDateTime.substring(11, 13);
      } catch (Throwable t) {
        return "XX";
      }
    }

    /** Get the am/pm value
     *
     * @return int   am/pm for this object.
     */
    public int getAmPm() {
      return cal.get(Calendar.AM_PM);
    }

    /**  Get a short String representation of the date
     *
     * @return String        Short representation of the date
     *            represented by this object.
     */
    public String getDateString() {
      Formatters fmt = getFormatters();

      synchronized (fmt) {
        DateFormat df = fmt.shortDateFormatter;
        df.setTimeZone(tz);
        return df.format(cal.getTime());
      }
    }

    /**  Get a long String representation of the date
     *
     * @return String        long representation of the date
     *            represented by this object.
     */
    public String getLongDateString() {
      Formatters fmt = getFormatters();

      synchronized (fmt) {
        DateFormat df = fmt.longDateFormatter;
        df.setTimeZone(tz);
        return df.format(cal.getTime());
      }
    }

    /**  Get a short String representation of the time of day
     *
     * @return String        Short representation of the time of day
     *            represented by this object.
     *            If there is no time, returns a zero length string.
     */
    public String getTimeString() {
      Formatters fmt = getFormatters();

      synchronized (fmt) {
        DateFormat df = fmt.shortTimeFormatter;
        df.setTimeZone(tz);
        return df.format(cal.getTime());
      }
    }

    private Formatters getFormatters() {
      Locale loc = calInfo.getLocale();

      return getFormatters(loc);
    }

    private static Formatters getFormatters(Locale loc) {
      synchronized (formattersTbl) {
        Formatters fmt = formattersTbl.get(loc);

        if (fmt == null) {
          fmt = new Formatters(loc);
          formattersTbl.put(loc, fmt);
        }

        return fmt;
      }
    }
  }

  /** Constructor
   *
   * @param calInfo
   * @param date
   * @param ctz
   * @throws CalFacadeException
   */
  public DateTimeFormatter(CalendarInfo calInfo, BwDateTime date, CalTimezones ctz)
          throws CalFacadeException {
    this.date = date;

    isUtc = date.isUTC();
    if (isUtc) {
      tzIsLocal = false;
    } else {
      tzIsLocal = ctz.getDefaultTimeZoneId().equals(date.getTzid());
    }

    TimeZone tz = null;
    if (isUtc) {
      tz = TimeZone.getTimeZone("GMT");
    } else if (date.getTzid() != null) {
      tz = ctz.getTimeZone(date.getTzid(), date.getTzowner());
    } else {
      // date only or floating.
      tz = ctz.getDefaultTimeZone();
    }

    Date dt = CalFacadeUtil.getDate(date, ctz);

    tzFormatted = new FormattedDate(dt, date.getDtval(), date.getDateType(),
                                    tz, calInfo);

    if (date.getDateType()) {
      tzIsLocal = true;
    }

    if (tzIsLocal) {
      formatted = tzFormatted;
    } else {
      String localIso = CalFacadeUtil.isoDateTime(dt,
                                                  ctz.getDefaultTimeZone());
      formatted = new FormattedDate(dt, localIso, date.getDateType(),
                                    ctz.getDefaultTimeZone(), calInfo);
    }
  }

  /**
   * @return date formatted for current timezone
   */
  public FormattedDate getFormatted() {
    return formatted;
  }

  /**
   * @return date formatted for supplied timezone
   */
  public FormattedDate getTzFormatted() {
    return tzFormatted;
  }

  /** test for local timezone.
   *
   * @return true if local time zone.
   */
  public boolean getTzIsLocal() {
    return tzIsLocal;
  }

  /** get timezone id.
   *
   * @return String tzid
   */
  public String getTzid() {
    if (isUtc) {
      return "UTC";
    }
    return date.getTzid();
  }

  /** True if this is a date only field - i.e all day
   *
   * @return boolean true for all day
   */
  public boolean getDateType() {
    return date.getDateType();
  }

  /** True if this is a utc date
   *
   * @return boolean true for utc
   */
  public boolean getUtc() {
    return isUtc;
  }

  /** True if this is a floating date
   *
   * @return boolean true for all day
   */
  public boolean getFloating() {
    return date.getFloating();
  }

  /** Return the unformatted date
   *
   * @return String
   * @throws CalFacadeException
   */
  public String getUnformatted() throws CalFacadeException {
    return date.getDtval();
  }

  /** Return the utc formatted date
   *
   * @return String (possibly adjusted) date in the rfc format yyyymmddThhmmssZ
   * @throws CalFacadeException
   */
  public String getUtcDate() throws CalFacadeException {
    return date.getDate();
  }

  /* ====================================================================
   *                        Object methods
   * ==================================================================== */

  public int compare(Object o1, Object o2) {
    if (o1 == o2) {
      return 0;
    }

    if (!(o1 instanceof DateTimeFormatter)) {
      return -1;
    }

    if (!(o2 instanceof DateTimeFormatter)) {
      return 1;
    }

    DateTimeFormatter dt1 = (DateTimeFormatter)o1;
    DateTimeFormatter dt2 = (DateTimeFormatter)o2;

    return dt1.date.compareTo(dt2.date);
  }

  public int compareTo(Object o2) {
    return compare(this, o2);
  }

  public int hashCode() {
    return date.hashCode();
  }

  public boolean equals(Object obj) {
    return compareTo(obj) == 0;
  }
}
