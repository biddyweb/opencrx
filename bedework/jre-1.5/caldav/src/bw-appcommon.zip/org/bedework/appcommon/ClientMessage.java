/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.appcommon;

import java.io.Serializable;

/**
 * Define message property codes emitted by clients. Suggested English Language
 * is supplied in the comment for clarification only.
 *
 * @author Mike Douglass
 *
 */
public interface ClientMessage extends Serializable {
  /** Prefix for all these errors */
  public static final String prefix = "org.bedework.client.message.";

  /** Calendar added. */
  public static final String addedCalendar = prefix + "added.calendar";

  /** n categories added. */
  public static final String addedCategories = prefix + "added.categories";

  /** Contact added. */
  public static final String addedContact = prefix + "added.contact";

  /** n eventrefs added. */
  public static final String addedEventrefs = prefix + "added.eventrefs";

  /** n events added. */
  public static final String addedEvents = prefix + "added.events";

  /** Folder added. */
  public static final String addedFolder = prefix + "added.folder";

  /** n locations added. */
  public static final String addedLocations = prefix + "added.locations";

  /** n tasks added. */
  public static final String addedTasks = prefix + "added.tasks";

  /** Action cancelled. */
  public static final String cancelled = prefix + "cancelled";

  /** Administrator removed. */
  public static final String deletedAuthuser = prefix + "deleted.authuser";

  /** Calendar/folder deleted. */
  public static final String deletedCalendar = prefix + "deleted.calendar";

  /** Category deleted. */
  public static final String deletedCategory = prefix + "deleted.category";

  /** Contact deleted. */
  public static final String deletedContact = prefix + "deleted.contact";

  /** Events deleted. */
  public static final String deletedEvents = prefix + "deleted.events";

  /** Group deleted. */
  public static final String deletedGroup = prefix + "deleted.group";

  /** n locations deleted. */
  public static final String deletedLocations = prefix + "deleted.locations";

  /** Subscription deleted. */
  public static final String deletedSubscription = prefix + "deleted.subscription";

  /** View deleted. */
  public static final String deletedView = prefix + "deleted.view";

  /** Timezones successfully imported. */
  public static final String importedTimezones = prefix + "imported.timezones";

  /** Timezones successfully fixed. */
  public static final String fixedTimezones = prefix + "fixed.timezones";

  /** Event has been mailed. */
  public static final String mailedEvent = prefix + "mailed.event";

  /** Schedule added. */
  public static final String scheduleAdded = prefix + "schedule.added";

  /** Schedule deferred. */
  public static final String scheduleDeferred = prefix + "schedule.deferred";

  /** Schedule ignored. */
  public static final String scheduleIgnored = prefix + "schedule.ignored";

  /** Schedule rescheduled. */
  public static final String scheduleRescheduled = prefix + "schedule.rescheduled";

  /** Schedule send. */
  public static final String scheduleSent = prefix + "schedule.sent";

  /** Schedule updated. */
  public static final String scheduleUpdated = prefix + "schedule.updated";

  /** Alarm has been set. */
  public static final String setAlarm = prefix + "set.alarm";

  /** Administrator updated. */
  public static final String updatedAuthuser = prefix + "updated.authuser";

  /** Calendar updated. */
  public static final String updatedCalendar = prefix + "updated.calendar";

  /** Category updated. */
  public static final String updatedCategory = prefix + "updated.category";

  /** Contact updated. */
  public static final String updatedContact = prefix + "updated.contact";

  /** Event updated. */
  public static final String updatedEvent = prefix + "updated.event";

  /** Folder updated. */
  public static final String updatedFolder = prefix + "updated.folder";

  /** Group updated. */
  public static final String updatedGroup = prefix + "updated.group";

  /** Location updated. */
  public static final String updatedLocation = prefix + "updated.location";

  /** Preferences updated. */
  public static final String updatedPrefs = prefix + "updated.prefs";

  /** System preferences updated. */
  public static final String updatedSyspars = prefix + "updated.syspars";

  /** Task updated. */
  public static final String updatedTask = prefix + "updated.task";

  /** User information updated. */
  public static final String updatedUserinfo = prefix + "updated.userinfo";
}
