/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/

package org.bedework.icalendar;

import org.bedework.calfacade.BwCalendar;
import org.bedework.calfacade.BwCategory;
import org.bedework.calfacade.BwContact;
import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.BwEventObj;
import org.bedework.calfacade.BwEventProxy;
import org.bedework.calfacade.BwFreeBusyComponent;
import org.bedework.calfacade.BwGeo;
import org.bedework.calfacade.BwLocation;
import org.bedework.calfacade.BwOrganizer;
import org.bedework.calfacade.BwRecurrenceId;
import org.bedework.calfacade.BwRelatedTo;
import org.bedework.calfacade.BwRequestStatus;
import org.bedework.calfacade.BwString;
import org.bedework.calfacade.BwXproperty;
import org.bedework.calfacade.CalFacadeDefs;
import org.bedework.calfacade.RecurringRetrievalMode;
import org.bedework.calfacade.RecurringRetrievalMode.Rmode;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.svc.EventInfo;
import org.bedework.calfacade.timezones.CalTimezones;
import org.bedework.calfacade.util.ChangeTable;

import net.fortuna.ical4j.model.CategoryList;
import net.fortuna.ical4j.model.Component;
import net.fortuna.ical4j.model.ComponentList;
import net.fortuna.ical4j.model.ParameterList;
import net.fortuna.ical4j.model.Period;
import net.fortuna.ical4j.model.PeriodList;
import net.fortuna.ical4j.model.ResourceList;
import net.fortuna.ical4j.model.component.Available;
import net.fortuna.ical4j.model.component.VAvailability;
import net.fortuna.ical4j.model.component.VEvent;
import net.fortuna.ical4j.model.component.VFreeBusy;
import net.fortuna.ical4j.model.component.VJournal;
import net.fortuna.ical4j.model.component.VToDo;
import net.fortuna.ical4j.model.Parameter;
import net.fortuna.ical4j.model.Property;
import net.fortuna.ical4j.model.parameter.AltRep;
import net.fortuna.ical4j.model.parameter.FbType;
import net.fortuna.ical4j.model.property.Attach;
import net.fortuna.ical4j.model.property.Attendee;
import net.fortuna.ical4j.model.property.Categories;
import net.fortuna.ical4j.model.property.Clazz;
import net.fortuna.ical4j.model.property.Comment;
import net.fortuna.ical4j.model.property.Completed;
import net.fortuna.ical4j.model.property.Contact;
import net.fortuna.ical4j.model.property.Created;
import net.fortuna.ical4j.model.property.DateListProperty;
import net.fortuna.ical4j.model.property.DateProperty;
import net.fortuna.ical4j.model.property.Description;
import net.fortuna.ical4j.model.property.DtEnd;
import net.fortuna.ical4j.model.property.DtStamp;
import net.fortuna.ical4j.model.property.DtStart;
import net.fortuna.ical4j.model.property.Due;
import net.fortuna.ical4j.model.property.Duration;
import net.fortuna.ical4j.model.property.ExDate;
import net.fortuna.ical4j.model.property.ExRule;
import net.fortuna.ical4j.model.property.FreeBusy;
import net.fortuna.ical4j.model.property.Geo;
import net.fortuna.ical4j.model.property.LastModified;
import net.fortuna.ical4j.model.property.Location;
import net.fortuna.ical4j.model.property.Organizer;
import net.fortuna.ical4j.model.property.PercentComplete;
import net.fortuna.ical4j.model.property.Priority;
import net.fortuna.ical4j.model.property.RDate;
import net.fortuna.ical4j.model.property.RecurrenceId;
import net.fortuna.ical4j.model.property.RRule;
import net.fortuna.ical4j.model.property.RelatedTo;
import net.fortuna.ical4j.model.property.RequestStatus;
import net.fortuna.ical4j.model.property.Resources;
import net.fortuna.ical4j.model.property.Sequence;
import net.fortuna.ical4j.model.property.Status;
import net.fortuna.ical4j.model.property.Summary;
import net.fortuna.ical4j.model.property.Transp;
import net.fortuna.ical4j.model.property.Uid;
import net.fortuna.ical4j.model.property.Url;
import net.fortuna.ical4j.model.property.XProperty;
import net.fortuna.ical4j.model.PropertyList;

import java.util.Collection;
import java.util.Iterator;

/** Class to provide utility methods for translating to BwEvent from ical4j classes
 *
 * @author Mike Douglass   douglm@rpi.edu
 */
public class BwEventUtil extends IcalUtil {

  /** We are going to try to construct a BwEvent object from a VEvent. This
   * may represent a new event or an update to a pre-existing event. In any
   * case, the VEvent probably has insufficient information to completely
   * reconstitute the event object so we'll get the uid first and retrieve
   * the event if it exists.
   *
   * <p>To put it another way we're doing a diff then update.
   *
   * <p>If it doesn't exist, we'll first fill in the appropriate fields,
   * (non-public, creator, created etc) then for both cases update the
   * remaining fields from the VEvent.
   *
   * <p>Recurring events present some challenges. If there is no recurrence
   * id the vevent represents the master entity which defines the recurrence
   * rules. If a recurrence id is present then the vevent represents a
   * recurrence instance and we should not attempt to retrieve the actual
   * object but the referenced instance.
   *
   * <p>For an update we have to keep track of which fields were present in
   * the vevent and set all absent fields to null in the BwEvent.
   *
   * @param cb          IcalCallback object
   * @param cal         Needed so we can retrieve the event.
   * @param ical        Icalendar we are converting. We check its events for
   *                    overrides.
   * @param val         VEvent object
   * @param debug
   * @return EventInfo  object representing new entry or updated entry
   * @throws CalFacadeException
   */
  public static EventInfo toEvent(IcalCallback cb,
                                  BwCalendar cal,
                                  Icalendar ical,
                                  Component val,
                                  boolean debug) throws CalFacadeException {
    if (val == null) {
      return null;
    }

    int methodType = ical.getMethodType();

    ChangeTable chg = new ChangeTable();

    try {
      PropertyList pl = val.getProperties();

      if (pl == null) {
        // Empty component
        return null;
      }

      int entityType;

      if (val instanceof VEvent) {
        entityType = CalFacadeDefs.entityTypeEvent;
      } else if (val instanceof VToDo) {
        entityType = CalFacadeDefs.entityTypeTodo;
      } else if (val instanceof VJournal) {
        entityType = CalFacadeDefs.entityTypeJournal;
      } else if (val instanceof VFreeBusy) {
        entityType = CalFacadeDefs.entityTypeFreeAndBusy;
      } else if (val instanceof VAvailability) {
        entityType = CalFacadeDefs.entityTypeVavailability;
      } else if (val instanceof Available) {
        entityType = CalFacadeDefs.entityTypeAvailable;
      } else {
        throw new CalFacadeException("org.bedework.invalid.component.type",
                                     val.getName());
      }

      Property prop;

      // Get the guid from the component

      String guid = null;

      prop = pl.getProperty(Property.UID);
      if (prop != null) {
        guid = prop.getValue();
      }

      if (guid == null) {
        /* XXX A guid is required - but are there devices out there without a
         *       guid - and if so how do we handle it?
         */
        throw new CalFacadeException(CalFacadeException.noGuid);
      }

      /* See if we have a recurrence id */

      BwRecurrenceId ridObj = null;
      String rid = null;

      prop = pl.getProperty(Property.RECURRENCE_ID);
      if (prop != null) {
        ridObj =  new BwRecurrenceId();
        ridObj.initFromDateTime((DateProperty)prop, null, cb.getTimezones());

        Parameter par = getParameter(prop, "RANGE");
        if (par != null) {
          /* XXX What do I do with it? */
          ridObj.setRange(par.getValue());
          warn("TRANS-TO_EVENT: Got a recurrence id range");
        }

        rid = ridObj.getDate();
      }

      EventInfo masterEI = null;
      EventInfo evinfo = null;
      BwEvent ev = null;

      /* WRONG - should be...
       * If we have a recurrence id see if we already have the master (we should
       * get a master + all it's overrides).
       *
       * If so find the override and use the annnotation or if no override,
       * make one.
       *
       * If no override retrieve the event, add it to our table and then locate the
       * annotation.
       *
       * If there is no annotation, create one.
       */

      if (rid != null) {
        // See if we have a new master event. If so create a proxy to that event.
        masterEI = findMaster(guid, ical.getComponents());

        if (masterEI != null) {
          evinfo = findOverride(masterEI, rid, debug);
        }
      }

      if ((evinfo == null) && (cal != null)) {
        if (debug) {
          debugMsg("TRANS-TO_EVENT: try to fetch event with guid=" + guid +
                   " and rid=" + rid);
        }

        /* FIXME I think this is wrong. We probably want to provide
         * expansions etc.
         */
        RecurringRetrievalMode rrm =
          new RecurringRetrievalMode(Rmode.overrides);
        Collection eis = cb.getEvent(cal, guid, rid, rrm);
        if ((eis == null) || (eis.size() == 0)) {
          // do nothing
        } else if (eis.size() > 1) {
          // DORECUR - wrong again
          throw new CalFacadeException("More than one event returned for guid.");
        } else {
          evinfo = (EventInfo)eis.iterator().next();
        }

        if (debug) {
          if (evinfo != null) {
            debugMsg("TRANS-TO_EVENT: fetched event with guid");
          } else {
            debugMsg("TRANS-TO_EVENT: did not find event with guid");
          }
        }
      }

      if (evinfo == null) {
        evinfo = new EventInfo();
        ev = new BwEventObj();
        ev.setDtstamps();
        ev.setEntityType(entityType);
        ev.setCreator(cb.getUser());
        ev.setUid(guid);
        chg.changed(Property.UID); // get that out of the way
        evinfo.setEvent(ev);
        evinfo.setNewEvent(true);
      } else if (evinfo.getEvent().getEntityType() != entityType) {
        throw new CalFacadeException("org.bedework.mismatched.entity.type",
                                     val.toString());
      } else {
        evinfo.setNewEvent(false);
        evinfo.setPrevLastmod(evinfo.getEvent().getLastmod());
        evinfo.setPrevSeq(evinfo.getEvent().getSeq());

        //if (rid != null) {
        //  masterEI = evinfo;

        //  evinfo = findOverride(masterEI, rid, debug);
        //}
      }

      if (rid != null) {
        String evrid = evinfo.getRecurrenceId();

        if ((evrid == null) || (!evrid.equals(rid))) {
          warn("Mismatched rid ev=" + evrid + " expected " + rid);
          chg.changed(Property.RECURRENCE_ID); // XXX spurious???
          evinfo.setRecurrenceId(rid);
        }
      }

      ev = evinfo.getEvent();
      ev.setScheduleMethod(methodType);

      CalTimezones ctz = cb.getTimezones();
      DtStart dtStart = (DtStart)pl.getProperty(Property.DTSTART);
      DtEnd dtEnd = null;

      if (entityType == CalFacadeDefs.entityTypeTodo) {
        Due due = (Due)pl.getProperty(Property.DUE);
        if (due != null ) {
          dtEnd = new DtEnd(due.getParameters(), due.getValue());
        }
      } else {
        dtEnd = (DtEnd)pl.getProperty(Property.DTEND);
      }

      Duration duration = (Duration)pl.getProperty(Property.DURATION);

      setDates(ctz, ev, dtStart, dtEnd, duration, chg);

      Iterator it = pl.iterator();

      while (it.hasNext()) {
        prop = (Property)it.next();

        //debugMsg("ical prop " + prop.getClass().getName());
        String pval = prop.getValue();
        if ((pval != null) && (pval.length() == 0)) {
          pval = null;
        }

        chg.present(prop.getName());

        if (prop instanceof Attach) {
          /* ------------------- Attachment -------------------- */

          chg.addValue(prop.getName(), getAttachment((Attach)prop));
        } else if (prop instanceof Attendee) {
          /* ------------------- Attendee -------------------- */

          if (methodType == Icalendar.methodTypePublish) {
            if (cb.getStrictness() == IcalCallback.conformanceStrict) {
              throw new CalFacadeException(CalFacadeException.attendeesInPublish);
            }

            if (cb.getStrictness() == IcalCallback.conformanceWarn) {
              warn("Had attendees for PUBLISH");
            }
          }

          chg.addValue(prop.getName(), getAttendee((Attendee)prop));
        } else if (prop instanceof Categories) {
          /* ------------------- Categories -------------------- */

          Categories cats = (Categories)prop;
          CategoryList cl = cats.getCategories();
          String lang = getLang(cats);

          if (cl != null) {
            /* Got some categories */

            Iterator cit = cl.iterator();

            while (cit.hasNext()) {
              String wd = (String)cit.next();
              BwString key = new BwString(lang, wd);

              BwCategory cat = cb.findCategory(key);

              if (cat == null) {
                cat = new BwCategory();
                cat.setWord(key);

                cb.addCategory(cat);
              }

              chg.addValue(prop.getName(), cat);
            }
          }
        } else if (prop instanceof Clazz) {
          /* ------------------- Class -------------------- */

          if (chg.changed(prop.getName(), ev.getClassification(), pval)) {
            ev.setClassification(pval);
          }
        } else if (prop instanceof Comment) {
          /* ------------------- Comment -------------------- */

          chg.addValue(prop.getName(),
                       new BwString(null, pval));
        } else if (prop instanceof Completed) {
          /* ------------------- Completed -------------------- */

          if (chg.changed(prop.getName(), ev.getCompleted(), pval)) {
            ev.setCompleted(pval);
          }
        } else if (prop instanceof Contact) {
          /* ------------------- Contact -------------------- */

          String altrep = getAltRepPar(prop);
          String lang = getLang(prop);
          String uid = getUidPar(prop);

          BwContact contact = null;

          if (uid != null) {
            contact = cb.getContact(uid);
          }

          BwString nm = null;
          if (contact == null) {
            nm = new BwString(lang, pval);
            contact = cb.findContact(nm);
          }

          if (contact == null) {
            contact = BwContact.makeContact();
            contact.setName(nm);
            contact.setLink(altrep);
            cb.addContact(contact);
          } else {
            contact.setName(nm);
            contact.setLink(altrep);
          }

          chg.addValue(prop.getName(), contact);
        } else if (prop instanceof Created) {
          /* ------------------- Created -------------------- */

          if (chg.changed(prop.getName(), ev.getCreated(), pval)) {
            ev.setCreated(pval);
          }
        } else if (prop instanceof Description) {
          /* ------------------- Description -------------------- */

          if (chg.changed(prop.getName(), ev.getDescription(), pval)) {
            ev.setDescription(pval);
          }
        } else if (prop instanceof DtEnd) {
          /* ------------------- DtEnd -------------------- */
        } else if (prop instanceof DtStamp) {
          /* ------------------- DtStamp -------------------- */

          ev.setDtstamp(pval);
        } else if (prop instanceof DtStart) {
          /* ------------------- DtStart -------------------- */
        } else if (prop instanceof Duration) {
          /* ------------------- Duration -------------------- */
        } else if (prop instanceof ExDate) {
          /* ------------------- ExDate -------------------- */

          chg.addValues(prop.getName(),
                        makeDateTimes((DateListProperty)prop, ctz));
        } else if (prop instanceof ExRule) {
          /* ------------------- ExRule -------------------- */

          chg.addValue(prop.getName(), pval);
        } else if (prop instanceof FreeBusy) {
          /* ------------------- freebusy -------------------- */

          FreeBusy fbusy = (FreeBusy)prop;
          PeriodList perpl = fbusy.getPeriods();
          Parameter par = getParameter(fbusy, "FBTYPE");
          int fbtype;

          if (par == null) {
            fbtype = BwFreeBusyComponent.typeBusy;
          } else if (par.equals(FbType.BUSY)) {
            fbtype = BwFreeBusyComponent.typeBusy;
          } else if (par.equals(FbType.BUSY_TENTATIVE)) {
            fbtype = BwFreeBusyComponent.typeBusyTentative;
          } else if (par.equals(FbType.BUSY_UNAVAILABLE)) {
            fbtype = BwFreeBusyComponent.typeBusyUnavailable;
          } else if (par.equals(FbType.FREE)) {
            fbtype = BwFreeBusyComponent.typeFree;
          } else {
            if (debug) {
              debugMsg("Unsupported parameter " + par.getName());
            }

            throw new IcalMalformedException("parameter " + par.getName());
          }

          BwFreeBusyComponent fbc = new BwFreeBusyComponent();

          fbc.setType(fbtype);

          Iterator perit = perpl.iterator();
          while (perit.hasNext()) {
            Period per = (Period)perit.next();

            fbc.addPeriod(per);
          }

          ev.addFreeBusyPeriod(fbc);
        } else if (prop instanceof Geo) {
          /* ------------------- Geo -------------------- */

          BwGeo geo = new BwGeo((Geo)prop);
          if (chg.changed(prop.getName(), ev.getGeo(), geo)) {
            ev.setGeo(geo);
          }
        } else if (prop instanceof LastModified) {
          /* ------------------- LastModified -------------------- */

          if (chg.changed(prop.getName(), ev.getLastmod(), pval)) {
            ev.setLastmod(pval);
          }
        } else if (prop instanceof Location) {
          /* ------------------- Location -------------------- */
          String lang = getLang(prop);
          String uid = getUidPar(prop);
          String venueUid = getVenue(prop);

          BwLocation loc = null;

          if (venueUid != null) {
            loc = cb.findVenueLocation(venueUid);

            if (loc == null) {
              loc = BwLocation.makeLocation();
              loc.setAddress(new BwString(lang, pval));
              loc.setVenueUid(venueUid);

              // We'll add it when the venue is set
            }
          } else {
            if (uid != null) {
              loc = cb.getLocation(uid);
            }

            BwString addr = null;
            if (loc == null) {
              addr = new BwString(lang, pval);
              loc = cb.findLocation(addr);
            }

            if (loc == null) {
              loc = BwLocation.makeLocation();
              loc.setAddress(addr);
              cb.addLocation(loc);
            }
          }

          BwLocation evloc = ev.getLocation();

          if (chg.changed(prop.getName(), evloc, loc)) {
            // CHGTBL - this only shows that it's a different location object
            ev.setLocation(loc);
          } else {
            // See if the value is changed
            String evval = evloc.getAddress().getValue();
            String inval = loc.getAddress().getValue();
            if (!evval.equals(inval)) {
              evloc.getAddress().setValue(inval);
              chg.changed(prop.getName());
            }
          }
        } else if (prop instanceof Organizer) {
          /* ------------------- Organizer -------------------- */

          BwOrganizer org = getOrganizer((Organizer)prop);
          BwOrganizer evorg = ev.getOrganizer();

          if (chg.changed(prop.getName(), evorg, org)) {
            if (evorg == null) {
              ev.setOrganizer(org);
            } else {
              evorg.update(org);
            }
          }
        } else if (prop instanceof PercentComplete) {
          /* ------------------- PercentComplete -------------------- */

          Integer ival = new Integer(((PercentComplete)prop).getPercentage());
          if (chg.changed(prop.getName(), ev.getPercentComplete(), ival)) {
            ev.setPercentComplete(ival);
          }
        } else if (prop instanceof Priority) {
          /* ------------------- Priority -------------------- */

          Integer ival = new Integer(((Priority)prop).getLevel());
          if (chg.changed(prop.getName(), ev.getPriority(), ival)) {
            ev.setPriority(ival);
          }
        } else if (prop instanceof RDate) {
          /* ------------------- RDate -------------------- */

          chg.addValues(prop.getName(),
                        makeDateTimes((DateListProperty)prop, ctz));
        } else if (prop instanceof RecurrenceId) {
          /* ------------------- RecurrenceID -------------------- */
          // Done above
        } else if (prop instanceof RelatedTo) {
          /* ------------------- RelatedTo -------------------- */
          RelatedTo irelto = (RelatedTo)prop;
          BwRelatedTo relto = new BwRelatedTo();

          String par = IcalUtil.getParameterVal(irelto, "RELTYPE");
          if (par != null) {
            relto.setRelType(par);
          }

          relto.setValue(irelto.getValue());

          if (chg.changed(prop.getName(), ev.getRelatedTo(), relto)) {
            ev.setRelatedTo(relto);
          }
        } else if (prop instanceof RequestStatus) {
          /* ------------------- RequestStatus -------------------- */
          BwRequestStatus rs = BwRequestStatus.fromRequestStatus((RequestStatus)prop);

          chg.addValue(prop.getName(), rs);
        } else if (prop instanceof Resources) {
          /* ------------------- Resources -------------------- */

          ResourceList rl = ((Resources)prop).getResources();

          if (rl != null) {
            /* Got some resources */

            Iterator rit = rl.iterator();

            while (rit.hasNext()) {
              // LANG
              chg.addValue(prop.getName(), rit.next());
            }
          }
        } else if (prop instanceof RRule) {
          /* ------------------- RRule -------------------- */

          chg.addValue(prop.getName(), pval);
        } else if (prop instanceof Sequence) {
          /* ------------------- Sequence -------------------- */

          int seq = ((Sequence)prop).getSequenceNo();
          if (seq != ev.getSequence()) {
            chg.changed(prop.getName());
            ev.setSequence(seq);
          }
        } else if (prop instanceof Status) {
          /* ------------------- Status -------------------- */

          if (chg.changed(prop.getName(), ev.getStatus(), pval)) {
            ev.setStatus(pval);
          }
        } else if (prop instanceof Summary) {
          /* ------------------- Summary -------------------- */

          if (chg.changed(prop.getName(), ev.getSummary(), pval)) {
            ev.setSummary(pval);
          }
        } else if (prop instanceof Transp) {
          /* ------------------- Transp -------------------- */

          if (chg.changed(prop.getName(), ev.getTransparency(), pval)) {
            ev.setTransparency(pval);
          }
        } else if (prop instanceof Uid) {
          /* ------------------- Uid -------------------- */

          /* We did this above */
        } else if (prop instanceof Url) {
          /* ------------------- Url -------------------- */

          if (chg.changed(prop.getName(), ev.getLink(), pval)) {
            ev.setLink(pval);
          }
        } else if (prop instanceof XProperty) {
          /* ------------------------- x-property --------------------------- */

          XProperty xp = (XProperty)prop;
          chg.addValue("XPROP",
                       new BwXproperty(xp.getName(),
                                       xp.getParameters().toString(),
                                       xp.getValue()));
        } else {
          if (debug) {
            debugMsg("Unsupported property with class " + prop.getClass() +
                     " and value " + pval);
          }
        }
      }

      if (val instanceof VAvailability) {
        processAvailable(cb, cal, ical, val, evinfo, debug);
      } else if (!(val instanceof Available)) {
        VAlarmUtil.processComponentAlarms(val, ev, chg, ctz);
      }

      chg.processChanges(ev, true);

      ev.setRecurring(new Boolean(ev.isRecurringEntity()));

      if (debug) {
        debugMsg(chg.toString());
        debugMsg(ev.toString());
      }

      evinfo.setChangeset(chg);

      if (masterEI != null) {
        // Just return null as this event is on its override list
        return null;
      }

      return evinfo;
    } catch (CalFacadeException cfe) {
      if (debug) {
        cfe.printStackTrace();
      }
      throw cfe;
    } catch (Throwable t) {
      if (debug) {
        t.printStackTrace();
      }
      throw new CalFacadeException(t);
    }
  }

  /* ====================================================================
                      Private methods
     ==================================================================== */

  private static void processAvailable(IcalCallback cb,
                                       BwCalendar cal,
                                       Icalendar ical,
                                       Component val,
                                       EventInfo vavail,
                                       boolean debug) throws CalFacadeException {

    try {
      ComponentList avls = null;

      if ((avls == null) || avls.isEmpty()) {
        return;
      }

      Iterator it = avls.iterator();

      while (it.hasNext()) {
        Object o = it.next();

        if (!(o instanceof Available)) {
          throw new IcalMalformedException("Invalid available list");
        }

        EventInfo availi = toEvent(cb, cal, ical, (Component)o, debug);
        availi.getEvent().setOwner(vavail.getEvent().getOwner());

        vavail.addAvailable(availi);

      }
    } catch (CalFacadeException cfe) {
      throw cfe;
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /* See if the master event is already in the collection of events
   * we've processed for this calendar. Only called if we have an event
   * with a recurrence id
   */
  private static EventInfo findMaster(String guid, Collection evs) {
    if (evs == null) {
      return null;
    }
    Iterator it = evs.iterator();

    while (it.hasNext()) {
      EventInfo ei = (EventInfo)it.next();
      BwEvent ev = ei.getEvent();

      if ((ev.getRecurrenceId() == null) &&
          guid.equals(ev.getUid()) /* &&
          ei.getNewEvent()  */) {
        return ei;
      }
    }

    return null;
  }

  /* See if the master event has an annotation with the given recurrence id.
   * If not create one.
   */
  private static EventInfo findOverride(EventInfo ei, String rid,
                                        boolean debug) throws CalFacadeException {
    Collection<EventInfo> os = ei.getOverrides();
    EventInfo oei = null;

    if (os != null) {
      for (EventInfo e: os) {
        if (e.getEvent().getRecurrenceId().equals(rid)) {
          oei = e;
          break;
        }
      }
    }

    if (oei != null) {
      return oei;
    }

    oei = new EventInfo();
    BwEventProxy proxy = BwEventProxy.makeAnnotation(ei.getEvent(), null, true);
    proxy.setRecurring(new Boolean(false));
    oei.setEvent(proxy);
    proxy.setRecurrenceId(rid);
    oei.setRecurrenceId(rid);

    ei.addOverride(oei);
    if (debug) {
      debugMsg("TRANS-TO_EVENT: Created override for rid " + rid +
               ", guid " + ei.getEvent().getUid());
    }

    return oei;
  }

  private static String getUidPar(Property p) {
    ParameterList pars = p.getParameters();

    Parameter par = pars.getParameter(Icalendar.xparUid);

    if (par == null) {
      return null;
    }

    return par.getValue();
  }

  private static String getAltRepPar(Property p) {
    AltRep par = IcalUtil.getAltRep(p);

    if (par == null) {
      return null;
    }

    return par.getValue();
  }

}

