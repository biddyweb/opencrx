/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.icalendar;

import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.BwFreeBusy;
import org.bedework.calfacade.BwOrganizer;
import org.bedework.calfacade.BwVenue;
import org.bedework.calfacade.CalFacadeDefs;
import org.bedework.calfacade.ifs.ScheduleMethods;
import org.bedework.calfacade.svc.EventInfo;

import net.fortuna.ical4j.model.TimeZone;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/** Class to represent an RFC icalendar object converted to an internal form.
 *
 * @author Mike Douglass douglm@rpi.edu
 * @version 1.0
 */
public class Icalendar implements ScheduleMethods, Serializable {
  private String prodid;

  private String version;

  private String calscale;

  private String method;

  private Collection<TimeZone> timeZones;

  private Map<String, BwVenue> venues;

  private Collection<Object> components;

  /** */
  public enum ComponentType {
    /** */
    none,

    /** */
    event,

    /** */
    todo,

    /** */
    journal,

    /** */
    freebusy,

    /** */
    vavailability,

    /** */
    mixed}

  /** Used for location, etc
   */
  public static final String xparUid = "X-BEDEWORK-UID";

  private ComponentType componentType = ComponentType.none;

  /**
   * @param val
   */
  public void setProdid(String val) {
    prodid = val;
  }

  /**
   * @return String
   */
  public String getProdid() {
    return prodid;
  }

  /**
   * @param val
   */
  public void setVersion(String val) {
    version = val;
  }

  /**
   * @return String
   */
  public String getVersion() {
    return version;
  }

  /**
   * @param val
   */
  public void setCalscale(String val) {
    calscale = val;
  }

  /**
   * @return String
   */
  public String getCalscale() {
    return calscale;
  }

  /**
   * @param val
   */
  public void setMethod(String val) {
    method = val;
  }

  /**
   * @return String
   */
  public String getMethod() {
    return method;
  }

  /**
   * @return Collection
   */
  public Collection<TimeZone> getTimeZones() {
    if (timeZones == null) {
      timeZones = new ArrayList<TimeZone>();
    }
    return timeZones;
  }

  /** Add a timezone
   *
   * @param tz  TimeZone
   */
  public void addTimeZone(TimeZone tz) {
    getTimeZones().add(tz);
  }

  /**
   * @param val
   */
  public void setVenues(Map<String, BwVenue> val) {
    venues = val;
  }

  /**
   * @return Collection
   */
  public Map<String, BwVenue> getVenues() {
    if (venues == null) {
      venues = new HashMap<String, BwVenue>();
    }
    return venues;
  }

  /** Add a venue
   *
   * @param val  venue
   */
  public void addVenue(BwVenue val) {
    getVenues().put(val.getUid(), val);
  }

  /** Find a venue
   *
   * @param uid  venue uid
   * @return BwVenue or null
   */
  public BwVenue findVenue(String uid) {
    return getVenues().get(uid);
  }

  /**
   * @param val
   */
  public void setComponents(Collection<Object> val) {
    components = val;
  }

  /**
   * @return Collection
   */
  public Collection<Object> getComponents() {
    if (components == null) {
      components = new ArrayList<Object>();
    }
    return components;
  }

  /**
   * @param val
   */
  public void setComponentType(ComponentType val) {
    if ((componentType == ComponentType.none) ||
        (componentType == val)) {
      componentType = val;
    } else {
      componentType = ComponentType.mixed;
    }
  }

  /**
   * @return ComponentType
   */
  public ComponentType getComponentType() {
    return componentType;
  }

  /**
   * @param val
   */
  public void setMethodType(int val) {
    if (val == methodTypeNone) {
      setMethod(null);
      return;
    }

    setMethod(getMethodName(val));
  }

  /**
   * @return int
   */
  public int getMethodType() {
    return getMethodType(method);
  }

  /**
   * @param val   String method name
   * @return int
   */
  public static int getMethodType(String val) {
    if (val == null) {
      return methodTypeNone;
    }

    for (int i = 1; i < methods.length; i++) {
      if (methods[i].equals(val)) {
        return i;
      }
    }

    return methodTypeUnknown;
  }

  /**
   * @param mt
   * @return A string value for the method
   */
  public static String getMethodName(int mt) {
    if (mt < methods.length) {
      return methods[mt];
    }

    return "UNKNOWN";
  }

  /** An event or a free-busy request may contain an organizer. Return it if
   * it is present.
   *
   * @return organizer object if present.
   */
  public BwOrganizer getOrganizer() {
    if (size() != 1) {
      return null;
    }

    if (getComponentType() == ComponentType.event) {
      EventInfo ei = (EventInfo)iterator().next();
      return ei.getEvent().getOrganizer();
    }

    if (getComponentType() == ComponentType.freebusy) {
      Object o = iterator().next();

      if (o instanceof EventInfo) {
        EventInfo ei = (EventInfo)o;
        return ei.getEvent().getOrganizer();
      }
      return ((BwFreeBusy)o).getOrganizer();
    }

    return null;
  }

  /**
   * @return EventInfo
   */
  public EventInfo getEventInfo() {
    if ((size() != 1) || (getComponentType() != ComponentType.event)) {
      throw new RuntimeException("org.bedework.icalendar.component.not.event");
    }

    return (EventInfo)iterator().next();
  }

  /**
   * @param val
   */
  public void addComponent(Object val) {
    if (val instanceof EventInfo) {
      BwEvent ev = ((EventInfo)val).getEvent();
      if (ev.getEntityType() == CalFacadeDefs.entityTypeEvent) {
        setComponentType(ComponentType.event);
      } else if (ev.getEntityType() == CalFacadeDefs.entityTypeTodo) {
        setComponentType(ComponentType.todo);
      } else if (ev.getEntityType() == CalFacadeDefs.entityTypeJournal) {
        setComponentType(ComponentType.journal);
      } else if (ev.getEntityType() == CalFacadeDefs.entityTypeFreeAndBusy) {
        setComponentType(ComponentType.freebusy);
      } else if (ev.getEntityType() == CalFacadeDefs.entityTypeVavailability) {
        setComponentType(ComponentType.vavailability);
      } else {
        throw new RuntimeException("org.bedework.bad.entitytype");
      }
    } else if (val instanceof BwFreeBusy) {
      setComponentType(ComponentType.freebusy);
    }
    getComponents().add(val);
  }

  /**
   * @return Iterator
   */
  public Iterator iterator() {
    return components.iterator();
  }

  /**
   * @return int
   */
  public int size() {
    if (components == null) {
      return 0;
    }

    return components.size();
  }

  /** True for valid itip method
   *
   * @return boolean
   */
  public boolean validItipMethodType() {
    return validItipMethodType(getMethodType());
  }

  /** True for itip request type method
   *
   * @return boolean
   */
  public boolean requestMethodType() {
    return itipRequestMethodType(getMethodType());
  }

  /** True for itip reply type method
   *
   * @return boolean
   */
  public boolean replyMethodType() {
    return itipReplyMethodType(getMethodType());
  }

  /** True for itip request type method
   *
   * @param mt  method
   * @return boolean
   */
  public static boolean itipRequestMethodType(int mt) {
    if ((mt == methodTypeAdd) ||
        (mt == methodTypeCancel) ||
        (mt == methodTypeDeclineCounter) ||
        (mt == methodTypePublish) ||
        (mt == methodTypeRequest)) {
      return true;
    }

    return false;
  }

  /** True for itip reply type method
   *
   * @param mt  method
   * @return boolean
   */
  public static boolean itipReplyMethodType(int mt) {
    if ((mt == methodTypeCounter) ||
        (mt == methodTypeRefresh) ||
        (mt == methodTypeReply)) {
      return true;
    }

    return false;
  }

  /** True for valid itip method
   *
   * @param val
   * @return boolean
   */
  public static boolean validItipMethodType(int val) {
    if (val == methodTypeNone) {
      return false;
    }

    if (val == methodTypeUnknown) {
      return false;
    }

    if (val >= methods.length) {
      return false;
    }

    return true;
  }

  /** True for valid itip method for given component type
   *
   * @param val
   * @param type
   * @return boolean
   */
  public static boolean validItipMethodType(int val, ComponentType type) {
    if (val == methodTypeNone) {
      return false;
    }

    if (val >= methods.length) {
      return false;
    }

    if (type == ComponentType.event) {
      return true;
    }

    if (type == ComponentType.freebusy) {
      if ((val == methodTypePublish) ||
          (val == Icalendar.methodTypeRequest) ||
          (val == Icalendar.methodTypeReply)) {
        return true;
      }

      return false;
    }


    return true;
  }

  /** Convert to int method index
   *
   * @param val  String possible method
   * @return int
   */
  public static int findMethodType(String val) {
    if (val == null) {
      return methodTypeNone;
    }

    for (int i = 1; i < methods.length; i++) {
      if (methods[i].equals(val)) {
        return i;
      }
    }

    return methodTypeUnknown;
  }

  public String toString() {
    StringBuffer sb = new StringBuffer("Icalendar{prodid=");
    sb.append(getProdid());
    sb.append(", version=");
    sb.append(getVersion());

    sb.append("\n, method=");
    sb.append(String.valueOf(getMethod()));
    sb.append(", methodType=");
    sb.append(getMethodType());
    sb.append(", componentType=");
    sb.append(getComponentType());

    sb.append("}");

    return sb.toString();
  }
}
