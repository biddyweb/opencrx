/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/

package org.bedework.icalendar;

import org.bedework.calfacade.BwAlarm;
import org.bedework.calfacade.BwAttendee;
import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.timezones.CalTimezones;
import org.bedework.calfacade.util.ChangeTable;

import net.fortuna.ical4j.model.component.CalendarComponent;
import net.fortuna.ical4j.model.component.VAlarm;
import net.fortuna.ical4j.model.component.VEvent;
import net.fortuna.ical4j.model.component.VToDo;
import net.fortuna.ical4j.model.Component;
import net.fortuna.ical4j.model.ComponentList;
import net.fortuna.ical4j.model.DateTime;
import net.fortuna.ical4j.model.Dur;
import net.fortuna.ical4j.model.parameter.Related;
import net.fortuna.ical4j.model.Property;
import net.fortuna.ical4j.model.property.Action;
import net.fortuna.ical4j.model.property.Attach;
import net.fortuna.ical4j.model.property.Attendee;
import net.fortuna.ical4j.model.property.Description;
import net.fortuna.ical4j.model.property.Duration;
import net.fortuna.ical4j.model.property.Repeat;
import net.fortuna.ical4j.model.property.Summary;
import net.fortuna.ical4j.model.property.Trigger;
import net.fortuna.ical4j.model.PropertyList;

import java.net.URI;
import java.util.Collection;
import java.util.Iterator;

/** Class to provide utility methods for handline VAlarm ical4j classes
 *
 * @author Mike Douglass   douglm@rpi.edu
 */
public class VAlarmUtil extends IcalUtil {

  /** If there are any alarms for this component add them to the events alarm
   * collection
   *
   * @param val
   * @param ev
   * @param chg
   * @param timezones
   * @throws CalFacadeException
   */
  public static void processComponentAlarms(Component val,
                                            BwEvent ev,
                                            ChangeTable chg,
                                            CalTimezones timezones) throws CalFacadeException {
    try {
      ComponentList als = null;

      if (val instanceof VEvent) {
        als = ((VEvent)val).getAlarms();
      } else if (val instanceof VToDo) {
        als = ((VToDo)val).getAlarms();
      } else {
        return;
      }

      if ((als == null) || als.isEmpty()) {
        return;
      }

      for (Object o: als) {
        if (!(o instanceof VAlarm)) {
          throw new IcalMalformedException("Invalid alarm list");
        }

        VAlarm va = (VAlarm)o;

        PropertyList pl = va.getProperties();

        if (pl == null) {
          // Empty VAlarm
          throw new IcalMalformedException("Invalid alarm list");
        }

        Property prop;
        BwAlarm al;

        /* XXX Handle mozilla alarm stuff in a way that might work better with other clients.
         *
         */

        prop = pl.getProperty("X-MOZ-LASTACK");
        boolean mozlastAck = prop != null;

        String mozSnoozeTime = null;
        if (mozlastAck) {
          prop = pl.getProperty("X-MOZ-SNOOZE-TIME");

          if (prop == null) {
            // lastack and no snooze - presume dismiss so delete alarm
            continue;
          }

          mozSnoozeTime = prop.getValue(); // UTC time
        }

        // All alarm types require action and trigger

        prop = pl.getProperty(Property.ACTION);
        if (prop == null) {
          throw new IcalMalformedException("Invalid alarm");
        }

        String actionStr = prop.getValue();

        TriggerVal tr = getTrigger(pl);

        if (mozSnoozeTime != null) {
          tr.trigger = mozSnoozeTime;
          tr.triggerDateTime = true;
          tr.triggerStart = false;
        }

        DurationRepeat dr = getDurationRepeat(pl);

        if ("EMAIL".equals(actionStr)) {
          al = BwAlarm.emailAlarm(ev, ev.getCreator(),
                                  tr.trigger, tr.triggerStart, tr.triggerDateTime,
                                  dr.duration, dr.repeat,
                                  getOptStr(pl, "ATTACH"),
                                  getReqStr(pl, "DESCRIPTION"),
                                  getReqStr(pl, "SUMMARY"),
                                  null, timezones);

          Iterator<?> atts = getReqStrs(pl, "ATTENDEE");

          while (atts.hasNext()) {
            al.addAttendee(getAttendee((Attendee)atts.next()));
          }
        } else if ("AUDIO".equals(actionStr)) {
          al = BwAlarm.audioAlarm(ev, ev.getCreator(),
                                  tr.trigger, tr.triggerStart, tr.triggerDateTime,
                                  dr.duration, dr.repeat,
                                  getOptStr(pl, "ATTACH"), timezones);
        } else if ("DISPLAY".equals(actionStr)) {
          al = BwAlarm.displayAlarm(ev, ev.getCreator(),
                                    tr.trigger, tr.triggerStart, tr.triggerDateTime,
                                    dr.duration, dr.repeat,
                                    getReqStr(pl, "DESCRIPTION"), timezones);
        } else if ("PROCEDURE".equals(actionStr)) {
          al = BwAlarm.procedureAlarm(ev, ev.getCreator(),
                                      tr.trigger, tr.triggerStart, tr.triggerDateTime,
                                      dr.duration, dr.repeat,
                                      getReqStr(pl, "ATTACH"),
                                      getOptStr(pl, "DESCRIPTION"), timezones);
        } else {
          throw new IcalMalformedException("Invalid alarm - bad type");
        }

        al.setEvent(ev);
        al.setOwner(ev.getOwner());
        chg.addValue(va.getName(), al);
      }
    } catch (CalFacadeException cfe) {
      throw cfe;
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /** Process any alarms.
   *
   * @param ev
   * @param comp
   * @throws CalFacadeException
   */
  public static void processEventAlarm(BwEvent ev,
                                       CalendarComponent comp) throws CalFacadeException {
    Collection<BwAlarm> als = ev.getAlarms();
    if ((als == null) || als.isEmpty()) {
      return;
    }

    ComponentList vals = null;

    if (comp instanceof VEvent) {
      vals = ((VEvent)comp).getAlarms();
    } else if (comp instanceof VToDo) {
      vals = ((VToDo)comp).getAlarms();
    } else {
      throw new CalFacadeException("org.bedework.invalid.component.type",
                                   comp.getName());
    }

    for (BwAlarm alarm: als) {
      vals.add(setAlarm(alarm));
    }
  }

  private static VAlarm setAlarm(BwAlarm val) throws CalFacadeException {
    try {
      VAlarm alarm = new VAlarm();

      int atype = val.getAlarmType();

      addProperty(alarm, new Action(BwAlarm.alarmTypes[atype]));

      if (val.getTriggerDateTime()) {
        DateTime dt = new DateTime(val.getTrigger());
        addProperty(alarm, new Trigger(dt));
      } else {
        Trigger tr = new Trigger(new Dur(val.getTrigger()));
        if (!val.getTriggerStart()) {
          addParameter(tr, Related.END);
        }
        addProperty(alarm, tr);
      }

      if (val.getDuration() != null) {
        addProperty(alarm, new Duration(new Dur(val.getDuration())));
        addProperty(alarm, new Repeat(val.getRepeat()));
      }

      if (atype == BwAlarm.alarmTypeAudio) {
        if (val.getAttach() != null) {
          addProperty(alarm, new Attach(new URI(val.getAttach())));
        }
      } else if (atype == BwAlarm.alarmTypeDisplay) {
        checkRequiredProperty(val.getDescription(), "alarm-description");
        addProperty(alarm, new Description(val.getDescription()));
      } else if (atype == BwAlarm.alarmTypeEmail) {
        if (val.getAttach() != null) {
          addProperty(alarm, new Attach(new URI(val.getAttach())));
        }
        checkRequiredProperty(val.getDescription(), "alarm-description");
        addProperty(alarm, new Description(val.getDescription()));
        checkRequiredProperty(val.getSummary(), "alarm-summary");
        addProperty(alarm, new Summary(val.getSummary()));

        if (val.getNumAttendees() > 0) {
          for (BwAttendee att: val.getAttendees()) {
            addProperty(alarm, setAttendee(att));
          }
        }
      } else if (atype == BwAlarm.alarmTypeProcedure) {
        checkRequiredProperty(val.getAttach(), "alarm-attach");
        addProperty(alarm, new Attach(new URI(val.getAttach())));

        if (val.getDescription() != null) {
          addProperty(alarm, new Description(val.getDescription()));
        }
      }

      return alarm;
    } catch (CalFacadeException cfe) {
      throw cfe;
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  private static void checkRequiredProperty(String val,
                                            String name) throws CalFacadeException {
    if (val == null) {
      throw new CalFacadeException("org.bedework.icalendar.missing.required.property",
                                   name);
    }
  }
}
