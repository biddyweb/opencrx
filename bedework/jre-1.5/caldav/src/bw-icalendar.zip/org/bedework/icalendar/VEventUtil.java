/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/

package org.bedework.icalendar;

import org.bedework.calfacade.BwAttachment;
import org.bedework.calfacade.BwAttendee;
import org.bedework.calfacade.BwCategory;
import org.bedework.calfacade.BwDateTime;
import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.BwFreeBusyComponent;
import org.bedework.calfacade.BwGeo;
import org.bedework.calfacade.BwLocation;
import org.bedework.calfacade.BwOrganizer;
import org.bedework.calfacade.BwContact;
import org.bedework.calfacade.BwString;
import org.bedework.calfacade.CalFacadeDefs;
import org.bedework.calfacade.base.BwStringBase;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.timezones.CalTimezones;

import net.fortuna.ical4j.model.CategoryList;
import net.fortuna.ical4j.model.component.CalendarComponent;
import net.fortuna.ical4j.model.component.VEvent;
import net.fortuna.ical4j.model.component.VFreeBusy;
import net.fortuna.ical4j.model.component.VJournal;
import net.fortuna.ical4j.model.component.VToDo;
import net.fortuna.ical4j.model.DateList;
import net.fortuna.ical4j.model.DateTime;
import net.fortuna.ical4j.model.Dur;
import net.fortuna.ical4j.model.Parameter;
import net.fortuna.ical4j.model.Period;
import net.fortuna.ical4j.model.PeriodList;
import net.fortuna.ical4j.model.ResourceList;
import net.fortuna.ical4j.model.parameter.AltRep;
import net.fortuna.ical4j.model.parameter.FbType;
import net.fortuna.ical4j.model.parameter.TzId;
import net.fortuna.ical4j.model.parameter.Value;
import net.fortuna.ical4j.model.parameter.XParameter;
import net.fortuna.ical4j.model.Property;
import net.fortuna.ical4j.model.property.Categories;
import net.fortuna.ical4j.model.property.Clazz;
import net.fortuna.ical4j.model.property.Comment;
import net.fortuna.ical4j.model.property.Completed;
import net.fortuna.ical4j.model.property.Contact;
import net.fortuna.ical4j.model.property.Created;
import net.fortuna.ical4j.model.property.DateListProperty;
import net.fortuna.ical4j.model.property.Description;
import net.fortuna.ical4j.model.property.DtStamp;
import net.fortuna.ical4j.model.property.Duration;
import net.fortuna.ical4j.model.property.ExDate;
import net.fortuna.ical4j.model.property.ExRule;
import net.fortuna.ical4j.model.property.FreeBusy;
import net.fortuna.ical4j.model.property.LastModified;
import net.fortuna.ical4j.model.property.Location;
import net.fortuna.ical4j.model.property.Priority;
import net.fortuna.ical4j.model.property.RDate;
import net.fortuna.ical4j.model.property.RRule;
import net.fortuna.ical4j.model.property.RecurrenceId;
import net.fortuna.ical4j.model.property.Resources;
import net.fortuna.ical4j.model.property.Sequence;
import net.fortuna.ical4j.model.property.Status;
import net.fortuna.ical4j.model.property.Summary;
import net.fortuna.ical4j.model.property.Transp;
import net.fortuna.ical4j.model.property.Uid;
import net.fortuna.ical4j.model.property.Url;
import net.fortuna.ical4j.model.PropertyList;

import java.net.URI;
import java.util.Collection;

/** Class to provide utility methods for translating to VEvent ical4j classes
 *
 * @author Mike Douglass   douglm@rpi.edu
 */
public class VEventUtil extends IcalUtil {

  /** Make an Icalendar component from a BwEvent object. This may produce a
   * VEvent, VTodo or VJournal.
   *
   * @param val
   * @param isOverride - true if event object is an override
   * @param timezones
   * @param uriGen
   * @return CalendarComponent
   * @throws CalFacadeException
   */
  public static CalendarComponent toIcalComponent(BwEvent val,
                                                  boolean isOverride,
                                                  CalTimezones timezones,
                                                  URIgen uriGen) throws CalFacadeException {
    if (val == null) {
      return null;
    }

    try {
      CalendarComponent comp;
      PropertyList pl = new PropertyList();

      int entityType = val.getEntityType();
      if (entityType == CalFacadeDefs.entityTypeEvent) {
        comp = new VEvent(pl);
      } else if (entityType == CalFacadeDefs.entityTypeTodo) {
        comp = new VToDo(pl);
      } else if (entityType == CalFacadeDefs.entityTypeJournal) {
        comp = new VJournal(pl);
      } else if (entityType == CalFacadeDefs.entityTypeFreeAndBusy) {
        comp = new VFreeBusy(pl);
      } else {
        throw new CalFacadeException("org.bedework.invalid.entity.type",
                                     String.valueOf(entityType));
      }

      Property prop;

      /* ------------------- Alarms -------------------- */
      VAlarmUtil.processEventAlarm(val, comp);

      /* ------------------- Attachments -------------------- */
      if (val.getNumAttachments() > 0) {
        for (BwAttachment att: val.getAttachments()) {
          pl.add(setAttachment(att));
        }
      }

      /* ------------------- Attendees -------------------- */
      if (val.getNumAttendees() > 0) {
        for (BwAttendee att: val.getAttendees()) {
          pl.add(setAttendee(att));
        }
      }

      /* ------------------- Categories -------------------- */

      if (val.getNumCategories() > 0) {
        /* This event has a category - do each one separately */

        // LANG - filter on language - group language in one cat list?
        for (BwCategory cat: val.getCategories()) {
          prop = new Categories();
          CategoryList cl = ((Categories)prop).getCategories();

          cl.add(cat.getWord().getValue());

          pl.add(langProp(prop, cat.getWord()));
        }
      }

      /* ------------------- Class -------------------- */

      String pval = val.getClassification();
      if (pval != null) {
        pl.add(new Clazz(pval));
      }

      /* ------------------- Comments -------------------- */

      if (val.getNumComments() > 0) {
        for (BwString str: val.getComments()) {
          pl.add(langProp(new Comment(str.getValue()), str));
        }
      }

      /* ------------------- Completed -------------------- */

      if ((entityType == CalFacadeDefs.entityTypeTodo) &&
          (val.getCompleted() != null)) {
        prop = new Completed(new DateTime(val.getCompleted()));
        pl.add(prop);
      }

      /* ------------------- Contact -------------------- */

      if (val.getNumContacts() > 0) {
        for (BwContact c: val.getContacts()) {
          // LANG
          prop = new Contact(c.getName().getValue());
          String l = c.getLink();

          if (l != null) {
            prop.getParameters().add(new AltRep(l));
          }
          pl.add(langProp(uidProp(prop, c.getUid()), c.getName()));
        }
      }

      /* ------------------- Created -------------------- */

      prop = new Created(val.getCreated());
//      if (pars.includeDateTimeProperty) {
//        prop.getParameters().add(Value.DATE_TIME);
//      }
      pl.add(prop);

      /* ------------------- Description -------------------- */

      BwStringBase bwstr = val.findDescription(null);
      if (bwstr != null) {
        pl.add(langProp(new Description(bwstr.getValue()), bwstr));
      }

      /* ------------------- Due/DtEnd/Duration --------------------
      */

      if (!val.getNoStart()) {
        if (val.getEndType() == BwEvent.endTypeDate) {
          prop = val.getDtend().makeDtEnd(timezones);
          pl.add(prop);
        } else if (val.getEndType() == BwEvent.endTypeDuration) {
          addProperty(comp, new Duration(new Dur(val.getDuration())));
        }
      }

      /* ------------------- DtStamp -------------------- */

      prop = new DtStamp(new DateTime(val.getDtstamp()));
//      if (pars.includeDateTimeProperty) {
//        prop.getParameters().add(Value.DATE_TIME);
//      }
      pl.add(prop);

      /* ------------------- DtStart -------------------- */

      if (!val.getNoStart()) {
        prop = val.getDtstart().makeDtStart(timezones);
        pl.add(prop);
      }

      /* ------------------- ExDate --below------------ */
      /* ------------------- ExRule --below------------- */

      if (entityType == CalFacadeDefs.entityTypeFreeAndBusy) {
        Collection<BwFreeBusyComponent> fbps = val.getFreeBusyPeriods();

        if (fbps != null) {
          for (BwFreeBusyComponent fbc: fbps) {
            FreeBusy fb = new FreeBusy();

            int type = fbc.getType();
            if (type == BwFreeBusyComponent.typeBusy) {
              addParameter(fb, FbType.BUSY);
            } else if (type == BwFreeBusyComponent.typeFree) {
              addParameter(fb, FbType.FREE);
            } else if (type == BwFreeBusyComponent.typeBusyUnavailable) {
              addParameter(fb, FbType.BUSY_UNAVAILABLE);
            } else if (type == BwFreeBusyComponent.typeBusyTentative) {
              addParameter(fb, FbType.BUSY_TENTATIVE);
            } else {
              throw new CalFacadeException("Bad free-busy type " + type);
            }

            PeriodList pdl =  fb.getPeriods();

            for (Period p: fbc.getPeriods()) {
              pdl.add(p);
            }

            pl.add(fb);
          }
        }

      }

      /* ------------------- Geo -------------------- */

      BwGeo geo = val.getGeo();
      if (geo != null) {
        pl.add(geo);
      }

      /* ------------------- LastModified -------------------- */

      prop = new LastModified(new DateTime(val.getLastmod()));
//      if (pars.includeDateTimeProperty) {
//        prop.getParameters().add(Value.DATE_TIME);
//      }
      pl.add(prop);

      /* ------------------- Location -------------------- */

      BwLocation loc = val.getLocation();
      if (loc != null) {
        prop = new Location(loc.getAddress().getValue());

        pl.add(langProp(uidProp(prop, loc.getUid()), loc.getAddress()));
      }

      /* ------------------- Organizer -------------------- */

      BwOrganizer org = val.getOrganizer();
      if (org != null) {
        pl.add(setOrganizer(org));
      }

      /* ------------------- Priority -------------------- */

      Integer prio = val.getPriority();
      if (prio != null) {
        pl.add(new Priority(prio.intValue()));
      }

      /* ------------------- RDate -below------------------- */

      /* ------------------- RecurrenceID -------------------- */

      String strval = val.getRecurrenceId();
      if ((strval != null) && (strval.length() > 0)) {
        // DORECUR - we should be restoring to original form.
        pl.add(new RecurrenceId(new DateTime(strval)));
      }

      /* ------------------- Resources -------------------- */

      if (val.getNumResources() > 0) {
        /* This event has a category */

        prop = new Resources();
        ResourceList rl = ((Resources)prop).getResources();

        for (BwString str: val.getResources()) {
          // LANG
          rl.add(str.getValue());
        }

        pl.add(prop);
      }

      /* ------------------- RRule -below------------------- */

      /* ------------------- Sequence -------------------- */

      pl.add(new Sequence(val.getSequence()));

      /* ------------------- Status -------------------- */

      String status = val.getStatus();
      if (status != null) {
        pl.add(new Status(status));
      }

      /* ------------------- Summary -------------------- */

      bwstr = val.findSummary(null);
      if (bwstr != null) {
        pl.add(langProp(new Summary(bwstr.getValue()), bwstr));
      }

      /* ------------------- Transp -------------------- */

      strval = val.getTransparency();
      if ((strval != null) && (strval.length() > 0)) {
        pl.add(new Transp(strval));
      }

      /* ------------------- Uid -------------------- */

      pl.add(new Uid(val.getUid()));

      /* ------------------- Url -------------------- */

      strval = val.getLink();

      if (strval != null) {
        // Possibly drop this if we do it on input and check all data
        strval = strval.trim();
      }

      if ((strval != null) && (strval.length() > 0)) {
        pl.add(new Url(new URI(strval)));
      }

      if (!isOverride && val.getRecurring().booleanValue()) {
        doRecurring(val, pl, timezones);
      }

      return comp;
    } catch (CalFacadeException cfe) {
      throw cfe;
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /** Build recurring properties from event.
   *
   * @param val
   * @param pl
   * @param timezones
   * @throws CalFacadeException
   */
  public static void doRecurring(BwEvent val,
                                 PropertyList pl,
                                 CalTimezones timezones) throws CalFacadeException {
    try {
      if (val.hasRrules()) {
        for(String s: val.getRrules()) {
          RRule rule = new RRule();
          rule.setValue(s);

          pl.add(rule);
        }
      }

      if (val.hasExrules()) {
        for(String s: val.getExrules()) {
          ExRule rule = new ExRule();
          rule.setValue(s);

          pl.add(rule);
        }
      }

      makeDlp(false, val.getRdates(), pl, timezones);

      makeDlp(true, val.getExdates(), pl, timezones);
    } catch (CalFacadeException cfe) {
      throw cfe;
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /* ====================================================================
                      Private methods
     ==================================================================== */

  private static Property uidProp(Property prop, String uid) {
    Parameter par = new XParameter(Icalendar.xparUid, uid);

    prop.getParameters().add(par);

    return prop;
  }

  private static Property langProp(Property prop, BwStringBase s) {
    Parameter par = s.getLangPar();

    if (par != null) {
      prop.getParameters().add(par);
    }

    return prop;
  }

  private static void makeDlp(boolean exdt,
                              Collection<BwDateTime> dts, PropertyList pl,
                              CalTimezones timezones) throws Throwable {
    if ((dts == null) || (dts.isEmpty())) {
      return;
    }

    DateList dl = new DateList();
    boolean first = true;
    boolean dateType = false;
    String tzid = null;

    for (BwDateTime dt: dts) {
      dl.add(dt.makeDate(timezones));
      if (first) {
        if (dt.getDateType()) {
          dateType = true;
        } else {
          tzid = dt.getTzid();
        }
      }
    }

    DateListProperty dlp;

    if (exdt) {
      dlp = new ExDate(dl);
    } else {
      dlp = new RDate(dl);
    }

    if (dateType) {
      dlp.getParameters().add(Value.DATE);
    } else {
      // The default
      //dt.getParameters().add(Value.DATE_TIME);

      if (tzid != null) {
        dlp.getParameters().add(new TzId(tzid));
      }
    }

    pl.add(dlp);
  }

     /*
  private String makeContactString(BwSponsor sp) {
    if (pars.simpleContact) {
      return sp.getName();
    }

    StringBuilder sb = new StringBuilder(sp.getName());
    addNonNull(defaultDelim, Resources.PHONENBR, sp.getPhone(), sb);
    addNonNull(defaultDelim, Resources.EMAIL, sp.getEmail(), sb);
    addNonNull(urlDelim, Resources.URL, sp.getLink(), sb);

    if (sb.length() == 0) {
      return null;
    }

    return sb.toString();
  }

  /* * Build a location string value from the location.
   *
   * <p>We try to build something we can parse later.
   * /
  private String makeLocationString(BwLocation loc) {
    if (pars.simpleLocation) {
      return loc.getAddress();
    }

    StringBuilder sb = new StringBuilder(loc.getAddress());
    addNonNull(defaultDelim, Resources.SUBADDRESS, loc.getSubaddress(), sb);
    addNonNull(urlDelim, Resources.URL, loc.getLink(), sb);

    if (sb.length() == 0) {
      return null;
    }

    return sb.toString();
  }*/
}

