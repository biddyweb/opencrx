/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.icalendar;

import org.bedework.calfacade.BwCalendar;
import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.BwFreeBusy;
import org.bedework.calfacade.BwLocation;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.BwVenue;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.svc.EventInfo;

import net.fortuna.ical4j.data.CalendarBuilder;
import net.fortuna.ical4j.data.CalendarOutputter;
import net.fortuna.ical4j.data.CalendarParserImpl;
import net.fortuna.ical4j.data.ParserException;
import net.fortuna.ical4j.data.UnfoldingReader;
import net.fortuna.ical4j.model.Calendar;
import net.fortuna.ical4j.model.component.CalendarComponent;
import net.fortuna.ical4j.model.component.VFreeBusy;
import net.fortuna.ical4j.model.component.VTimeZone;
import net.fortuna.ical4j.model.component.VVenue;
import net.fortuna.ical4j.model.ComponentList;
import net.fortuna.ical4j.model.Property;
import net.fortuna.ical4j.model.PropertyList;
import net.fortuna.ical4j.model.TimeZone;
import net.fortuna.ical4j.model.property.Method;
import net.fortuna.ical4j.model.property.ProdId;
import net.fortuna.ical4j.model.property.TzId;
import net.fortuna.ical4j.model.property.Version;

import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.TreeSet;

import org.apache.log4j.Logger;

/** Object to provide translation between an EventVO and an Icalendar format.
 *
 * NOTES: Check out how we deal with all the possible combinations of dtstart,
 * dtend and durations. We probably need to redo date/time stuff in the back end
 * to preserve what was intended. We shouldn't send a different form of an event
 * back if possible.
 *
 * @author Mike Douglass   douglm@rpi.edu
 */
public class IcalTranslator implements Serializable {
  protected boolean debug;

  /** We'll use this to parameterize some of the behaviour
   */
  public static class Pars {
    /** Support simple location only. Many iCalendar-aware
     * applications only support a simple string valued location.
     *
     * <p>If this value is true we only pass the address part of the location
     * and provide an altrep which will allow (some) clients to retrieve the
     * full form of a location.
     */
    public boolean simpleLocation = true;

    /** Support simple contacts only.
     */
    public boolean simpleContact = true;
  }

  /* This needs to come from a property updated with each release.
   */
  protected static final String prodId = "BedeWork V3.4";

  protected transient Logger log;

  protected IcalCallback cb;

  protected Pars pars = new Pars();

  /** Constructor:
   *
   * @param cb     IcalCallback object for retrieval of entities
   */
  public IcalTranslator(IcalCallback cb) {
    this(cb, false);
  }

  /** Constructor:
   *
   * @param cb     IcalCallback object for retrieval of entities
   * @param debug
   */
  public IcalTranslator(IcalCallback cb, boolean debug) {
    this.cb = cb;
    this.debug = debug;
  }

  /* ====================================================================
   *                     Translation methods
   * ==================================================================== */

  /** Make a new Calendar with default properties
   *
   * @param methodType
   * @return Calendar
   * @throws CalFacadeException
   */
  public static Calendar newIcal(int methodType) throws CalFacadeException {
    Calendar cal = new Calendar();

    PropertyList pl = cal.getProperties();

    pl.add(new ProdId(prodId));
    pl.add(Version.VERSION_2_0);

    if ((methodType > Icalendar.methodTypeNone) &&
        (methodType < Icalendar.methodTypeUnknown)) {
      pl.add(new Method(Icalendar.methods[methodType]));
    }

    return cal;
  }

  /** Make a new Calendar with the freebusy object
   *
   * @param methodType
   * @param fb BwFreeBusy
   * @return String representation
   * @throws CalFacadeException
   */
  public static String toIcalString(int methodType,
                                    BwFreeBusy fb) throws CalFacadeException {
    Calendar cal = new Calendar();

    PropertyList pl = cal.getProperties();

    pl.add(new ProdId(prodId));
    pl.add(Version.VERSION_2_0);

    if ((methodType > Icalendar.methodTypeNone) &&
        (methodType < Icalendar.methodTypeUnknown)) {
      pl.add(new Method(Icalendar.methods[methodType]));
    }

    VFreeBusy vfreeBusy = VFreeUtil.toVFreeBusy(fb);

    cal.getComponents().add(vfreeBusy);

    CalendarOutputter co = new CalendarOutputter(false, 74);

    Writer wtr =  new StringWriter();
    try {
      co.output(cal, wtr);
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }

    return wtr.toString();
  }

  /** Convert a Calendar to it's string form
   *
   * @param cal Calendar to convert
   * @return String representation
   * @throws CalFacadeException
   */
  public static String toIcalString(Calendar cal) throws CalFacadeException {
    Writer wtr =  new StringWriter();
    writeCalendar(cal, wtr);

    return wtr.toString();
  }

  /** Write a Calendar
   *
   * @param cal Calendar to convert
   * @param wtr Writer for output
   * @throws CalFacadeException
   */
  public static void writeCalendar(Calendar cal,
                                   Writer wtr) throws CalFacadeException {
    CalendarOutputter co = new CalendarOutputter(false, 74);

    try {
      co.output(cal, wtr);
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /** turn a single event with possible overrides into a calendar
   *
   * @param val
   * @param methodType    int value fromIcalendar
   * @return Calendar
   * @throws CalFacadeException
   */
  public Calendar toIcal(EventInfo val,
                         int methodType) throws CalFacadeException {
    if (val == null) {
      return null;
    }

    try {
      Calendar cal = newIcal(methodType);

      addToCalendar(cal, val, new TreeSet<String>());

      return cal;
    } catch (CalFacadeException cfe) {
      throw cfe;
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /** Turn a collection of events into a calendar
   *
   * @param vals
   * @param methodType    int value fromIcalendar
   * @return Calendar
   * @throws CalFacadeException
   */
  public Calendar toIcal(Collection vals,
                         int methodType) throws CalFacadeException {
    Calendar cal = newIcal(methodType);

    if ((vals == null) || (vals.size() == 0)) {
      return cal;
    }

    TreeSet<String> added = new TreeSet<String>();

    try {
      Iterator it = vals.iterator();
      while (it.hasNext()) {
        Object o = it.next();

        if (o instanceof EventInfo) {
          addToCalendar(cal, (EventInfo)o, added);
        } else {
          // XXX implement
          warn("Unimplemented toIcal for " + o.getClass().getName());
          continue;
        }
      }

      return cal;
    } catch (CalFacadeException cfe) {
      throw cfe;
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /** Convert the Icalendar reader to a Collection of Calendar objects
   *
   * @param cal       calendar
   * @param rdr
   * @return Icalendar
   * @throws CalFacadeException
   */
  public Icalendar fromIcal(BwCalendar cal, Reader rdr) throws CalFacadeException {
    return fromIcal(cal, getCalendar(rdr));
  }

  /** Get the method for the calendar
   *
   * @param val
   * @return String method
   */
  public static String getMethod(Calendar val) {
    Property prop = val.getProperties().getProperty(Property.METHOD);
    if (prop == null) {
      return null;
    }

    return prop.getValue();
  }

  /** Convert the Calendar to a Collection of calendar objects.
   *
   * @param cal       calendar
   * @param val
   * @return Icalendar
   * @throws CalFacadeException
   */
  public Icalendar fromIcal(BwCalendar cal, Calendar val) throws CalFacadeException {
    Icalendar ic = new Icalendar();
    ic.setComponents(new ArrayList<Object>());

    if (val == null) {
      return ic;
    }

    PropertyList pl = val.getProperties();
    Property prop = pl.getProperty(Property.PRODID);
    if (prop != null) {
      ic.setProdid(prop.getValue());
    }

    prop = pl.getProperty(Property.VERSION);
    if (prop != null) {
      ic.setVersion(prop.getValue());
    }

    ic.setMethod(getMethod(val));

    prop = pl.getProperty(Property.CALSCALE);
    if (prop != null) {
      ic.setCalscale(prop.getValue());
    }

    Collection<BwEvent> venued = new ArrayList<BwEvent>();

    Collection<CalendarComponent> clist = orderedComponents(val.getComponents());
    for (CalendarComponent comp: clist) {
      if (comp instanceof VFreeBusy) {
        EventInfo ei = BwEventUtil.toEvent(cb, cal, ic, comp, debug);

        if (ei != null) {
          ic.addComponent(ei);
        }
      } else if (comp instanceof VTimeZone) {
        ic.addTimeZone(doTimeZone((VTimeZone)comp));
      } else if (comp instanceof VVenue) {
        BwVenue venue = BwVenueUtil.toVenue(cb, (VVenue)comp, debug);

        if (venue != null) {
          ic.addVenue(venue);
        }
      } else {
        EventInfo ei = BwEventUtil.toEvent(cb, cal, ic, comp, debug);

        if (ei != null) {
          ic.addComponent(ei);

          BwLocation loc = ei.getEvent().getLocation();

          if ((loc != null) && (loc.getVenueUid() != null)) {
            venued.add(ei.getEvent());
          }
        }
      }
    }

    for (BwEvent ev: venued) {
      BwLocation loc = ev.getLocation();

      loc.setVenue(ic.findVenue(loc.getVenueUid()));
    }

    return ic;
  }

  /** Convert the given string representation of an Icalendar object to a
   * Calendar object
   *
   * @param val
   * @return Calendar
   * @throws CalFacadeException
   */
  public static Calendar getCalendar(String val) throws CalFacadeException {
    try {
      setSystemProperties();
      CalendarBuilder bldr = new CalendarBuilder(new CalendarParserImpl());

      UnfoldingReader ufrdr = new UnfoldingReader(new StringReader(val), true);

      return bldr.build(ufrdr);
    } catch (CalFacadeException cfe) {
      throw cfe;
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /** Convert the given reader to a Calendar object
   *
   * @param rdr     Reader
   * @return Calendar
   * @throws CalFacadeException
   */
  public static Calendar getCalendar(Reader rdr) throws CalFacadeException {
    try {
      setSystemProperties();
      CalendarBuilder bldr = new CalendarBuilder(new CalendarParserImpl());

      UnfoldingReader ufrdr = new UnfoldingReader(rdr, true);

      return bldr.build(ufrdr);
    } catch (CalFacadeException cfe) {
      throw cfe;
    } catch (ParserException pe) {
      throw new IcalMalformedException(pe.getMessage());
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /** Create a Calendar object from the named timezone
   *
   * @param tzid       String timezone id
   * @return Calendar
   * @throws CalFacadeException
   */
  public Calendar getTzCalendar(String tzid) throws CalFacadeException {
    try {
      Calendar cal = newIcal(Icalendar.methodTypeNone);

      addIcalTimezone(cal, tzid, null, null);

      return cal;
    } catch (CalFacadeException cfe) {
      throw cfe;
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /** Create a Calendar object from the named timezone and convert to
   * a String representation
   *
   * @param tzid       String timezone id
   * @return String
   * @throws CalFacadeException
   */
  public String toStringTzCalendar(String tzid) throws CalFacadeException {
    Calendar ical = getTzCalendar(tzid);

    CalendarOutputter calOut = new CalendarOutputter(true);

    StringWriter sw = new StringWriter();

    try {
      calOut.output(ical, sw);

      return sw.toString();
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /* ====================================================================
                      Private methods
     ==================================================================== */

  private void addToCalendar(Calendar cal,
                             EventInfo val,
                             TreeSet<String> added) throws CalFacadeException {
    URIgen uriGen = cb.getURIgen();
    BwEvent ev = val.getEvent();

    /* Add referenced timezones to the calendar */
    addIcalTimezones(cal, ev, added);

    /* Add it to the calendar */
    cal.getComponents().add(VEventUtil.toIcalComponent(ev, false,
                                                       cb.getTimezones(),
                                                       uriGen));

    if (val.getNumOverrides() == 0) {
      return;
    }

    for (EventInfo oei: val.getOverrides()) {
      ev = oei.getEvent();
      cal.getComponents().add(VEventUtil.toIcalComponent(ev, true,
                                                         cb.getTimezones(),
                                                         uriGen));
    }
  }

  /* Order all the components so that they are in the following order:
   *
   * XXX should use a TreeSet with a wrapper round the object and sort them including
   * dates etc.
   *
   * 1. Timezones
   * 2. Events without recurrence id
   * 3. Events with recurrence id
   * 4. Anything else
   */
  private static Collection<CalendarComponent> orderedComponents(ComponentList clist) {
    SubList<CalendarComponent> tzs = new SubList<CalendarComponent>();
    SubList<CalendarComponent> fbs = new SubList<CalendarComponent>();
    SubList<CalendarComponent> instances = new SubList<CalendarComponent>();
    SubList<CalendarComponent> masters = new SubList<CalendarComponent>();

    Iterator it = clist.iterator();

    while (it.hasNext()) {
      CalendarComponent c = (CalendarComponent)it.next();

      if (c instanceof VFreeBusy) {
        fbs.add(c);
      } else if (c instanceof VTimeZone) {
        tzs.add(c);
      } else if (IcalUtil.getProperty(c, Property.RECURRENCE_ID) != null) {
        instances.add(c);
      } else {
        masters.add(c);
      }
    }

    ArrayList<CalendarComponent> all = new ArrayList<CalendarComponent>();

    tzs.appendTo(all);
    masters.appendTo(all);
    instances.appendTo(all);
    fbs.appendTo(all);

    return all;
  }

  private static class SubList<T> {
    ArrayList<T> list;

    void add(T o) {
      if (list == null) {
        list = new ArrayList<T>();
      }
      list.add(o);
    }

    void appendTo(Collection<T> c) {
      if (list != null) {
        c.addAll(list);
      }
    }
  }

  private TimeZone doTimeZone(VTimeZone vtz) throws CalFacadeException {
    TzId tzid = (TzId)IcalUtil.getProperty(vtz, Property.TZID);

    if (tzid == null) {
      throw new CalFacadeException("Missing tzid property");
    }

    String id = tzid.getValue();

    if (debug) {
      debugMsg("Got timezone: \n" + vtz.toString() + " with id " + id);
    }

    /* The ical4j parser calls registerTimeZone (indirectly) so all we have to do
     * now is save it to the db.
     */
    cb.storeTimeZone(id);

    return cb.getTimeZone(id, null);
  }

  /* If the start or end date references a timezone, we retrieve the timezone definition
   * and add it to the calendar.
   */
  private void addIcalTimezones(Calendar cal, BwEvent ev,
                                TreeSet<String> added) throws CalFacadeException {
    BwUser owner = ev.getOwner();

    addIcalTimezone(cal, ev.getDtstart().getTzid(), owner, added);

    if (ev.getEndType() == BwEvent.endTypeDate) {
      addIcalTimezone(cal, ev.getDtend().getTzid(), owner, added);
    }
  }

  private void addIcalTimezone(Calendar cal, String tzid,
                               BwUser owner,
                               TreeSet<String> added) throws CalFacadeException {
    VTimeZone vtz;

    if ((tzid == null) ||
        ((added != null) && added.contains(tzid))) {
      return;
    }

    if (debug) {
      debugMsg("Look for timezone with id " + tzid);
    }

    vtz = cb.findTimeZone(tzid, owner);
    if (vtz != null) {
      if (debug) {
        debugMsg("found timezone with id " + tzid);
      }
      cal.getComponents().add(vtz);
    } else if (debug) {
      debugMsg("Didn't find timezone with id " + tzid);
    }

    if (added != null) {
      added.add(tzid);
    }
  }

  private static void setSystemProperties() throws CalFacadeException {
    try {
      System.setProperty("ical4j.unfolding.relaxed", "true");
      System.setProperty("ical4j.parsing.relaxed", "true");
      System.setProperty("ical4j.compatibility.outlook", "true");
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  private Logger getLog() {
    if (log != null) {
      return log;
    }

    log = Logger.getLogger(this.getClass());
    return log;
  }

  private void warn(String msg) {
    getLog().warn(msg);
  }

  private void debugMsg(String msg) {
    getLog().debug(msg);
  }
}

