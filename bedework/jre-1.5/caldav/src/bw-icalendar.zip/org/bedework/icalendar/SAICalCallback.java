/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.icalendar;

import org.bedework.calfacade.BwCalendar;
import org.bedework.calfacade.BwCategory;
import org.bedework.calfacade.BwContact;
import org.bedework.calfacade.BwLocation;
import org.bedework.calfacade.BwString;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.RecurringRetrievalMode;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.timezones.CalTimezones;
import org.bedework.icalendar.IcalCallback;
import org.bedework.icalendar.URIgen;

import net.fortuna.ical4j.model.TimeZone;
import net.fortuna.ical4j.model.component.VTimeZone;

import java.util.Collection;

/** Class to allow icaltranslator to be used from a standalone non-bedework
 * caldav server.
 *
 * @author douglm
 *
 */
public class SAICalCallback implements IcalCallback {
  private int strictness;

  private CalTimezones timezones;
  private BwUser user;

  /** Constructor
   *
   * @param timezones
   * @param account
   */
  public SAICalCallback(CalTimezones timezones, String account) {
    this.timezones = timezones;
    user = new BwUser(account);
  }

  public void setStrictness(int val) throws CalFacadeException {
    strictness = val;
  }

  public int getStrictness() throws CalFacadeException {
    return strictness;
  }

  public BwUser getUser() throws CalFacadeException {
    return user;
  }

  public BwCategory findCategory(BwString val) throws CalFacadeException {
    return null;
  }

  public void addCategory(BwCategory val) throws CalFacadeException {
  }

  public BwContact getContact(String uid) throws CalFacadeException {
    return null;
  }

  public BwContact findContact(BwString val) throws CalFacadeException {
    return null;
  }

  public void addContact(BwContact val) throws CalFacadeException {
  }

  public BwLocation getLocation(String uid) throws CalFacadeException {
    return null;
  }

  public BwLocation findLocation(BwString address) throws CalFacadeException {
    return null;
  }

  public BwLocation findVenueLocation(String uid) throws CalFacadeException {
    return null;
  }

  public void addLocation(BwLocation val) throws CalFacadeException {
  }

  public Collection getEvent(BwCalendar cal, String guid, String rid,
                             RecurringRetrievalMode recurRetrieval)
          throws CalFacadeException {
    return null;
  }

  public URIgen getURIgen() throws CalFacadeException {
    return null;
  }

  public CalTimezones getTimezones() throws CalFacadeException {
    return timezones;
  }

  public void saveTimeZone(String tzid,
                           VTimeZone vtz) throws CalFacadeException {
    timezones.saveTimeZone(tzid, vtz);
  }

  public void storeTimeZone(final String id) throws CalFacadeException {
    timezones.storeTimeZone(id, getUser());
  }

  public void registerTimeZone(String id, TimeZone timezone)
            throws CalFacadeException {
    timezones.registerTimeZone(id, timezone);
  }

  public TimeZone getTimeZone(final String id,
                              BwUser tzowner) throws CalFacadeException {
    return timezones.getTimeZone(id, tzowner);
  }

  public VTimeZone findTimeZone(final String id, BwUser owner) throws CalFacadeException {
    return timezones.findTimeZone(id, owner);
  }
}
