/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calcore.hibernate;

import edu.rpi.cmt.access.Ace;
import edu.rpi.cmt.access.AceWho;
import edu.rpi.cmt.access.PrivilegeDefs;
import edu.rpi.cmt.access.Acl.CurrentAccess;

import org.bedework.calcore.AccessUtil;
import org.bedework.calcore.CalintfBase;
import org.bedework.calcorei.CalintfInfo;
import org.bedework.calcorei.CoreEventInfo;
import org.bedework.calcorei.EventProperties;
import org.bedework.calcorei.EventsI;
import org.bedework.calcorei.HibSession;
import org.bedework.calfacade.BwAlarm;
import org.bedework.calfacade.BwCalendar;
import org.bedework.calfacade.BwCategory;
import org.bedework.calfacade.BwDateTime;
import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.BwEventProxy;
import org.bedework.calfacade.BwFreeBusy;
import org.bedework.calfacade.BwFreeBusyComponent;
import org.bedework.calfacade.BwLocation;
import org.bedework.calfacade.BwPrincipal;
import org.bedework.calfacade.BwRWStats;
import org.bedework.calfacade.BwContact;
import org.bedework.calfacade.BwStats;
import org.bedework.calfacade.BwString;
import org.bedework.calfacade.BwSystem;
import org.bedework.calfacade.BwTimeZone;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.RecurringRetrievalMode;
import org.bedework.calfacade.TimeZoneInfo;
import org.bedework.calfacade.BwStats.StatsEntry;
import org.bedework.calfacade.RecurringRetrievalMode.Rmode;
import org.bedework.calfacade.base.BwDbentity;
import org.bedework.calfacade.base.BwEventKey;
import org.bedework.calfacade.base.BwShareableDbentity;
import org.bedework.calfacade.base.UpdateFromTimeZonesInfo;
import org.bedework.calfacade.base.UpdateFromTimeZonesInfo.UnknownTimezoneInfo;
import org.bedework.calfacade.exc.CalFacadeAccessException;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.filter.BwEntityTypeFilter;
import org.bedework.calfacade.filter.BwFilter;
import org.bedework.calfacade.filter.BwOrFilter;
import org.bedework.calfacade.ifs.Directories;
import org.bedework.calfacade.timezones.CalTimezones;
import org.bedework.calfacade.util.CalFacadeUtil;
import org.bedework.calfacade.util.ChangeTable;
import org.bedework.calfacade.util.Granulator.EventPeriod;
import org.bedework.calfacade.wrappers.CoreCalendarWrapper;
import org.bedework.icalendar.IcalTranslator;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

import net.fortuna.ical4j.model.Calendar;
import net.fortuna.ical4j.model.Component;
import net.fortuna.ical4j.model.DateTime;
import net.fortuna.ical4j.model.Period;
import net.fortuna.ical4j.model.component.VTimeZone;
import net.fortuna.ical4j.model.property.LastModified;

import org.apache.log4j.Logger;

import org.hibernate.cfg.Configuration;
import org.hibernate.stat.Statistics;
import org.hibernate.SessionFactory;

/** Implementation of CalIntf which uses hibernate as its persistance engine.
 *
 * <p>We assume this interface is accessing public events or private events.
 * In either case it may be read-only or read/write. It is up to the caller
 * to set the appropriate access.
 *
 * <p>Write access to public objects may be restricted to only those owned
 * by the supplied owner. It is up to the caller to determine the setting for
 * the modifyAll flag.
 *
 * <p>The following methods always work within the above context, e.g. 'all'
 * for an object initialised for public access means all public objects of
 * a requested class. For a personal object it means all objects owned by
 * the current user.
 *
 * <p>Currently some classes are only available as public objects. This
 * might change.
 *
 * <p>A public object in readonly mode will deliver all public objects
 * within the given constraints, regardless of ownership, e.g all events for
 * given day or all public categories.
 *
 * <p>A public object in read/write will enforce ownership on display and
 * on update. This might require a client to obtain two or more objects to
 * get the appropriate behaviour. For example, an admin client will only
 * allow update of events owned by the current user but must display all
 * public categories for use.
 *
 * @author Mike Douglass   douglm@rpi.edu
 */
public class CalintfImpl extends CalintfBase implements PrivilegeDefs {
  private BwSystem syspars;

  private BwStats stats = new BwRWStats();

  private CalTimezonesImpl timezones;

  private static CalintfInfo info = new CalintfInfo(
       true,     // handlesLocations
       true,     // handlesContacts
       true      // handlesCategories
     );

  /** For evaluating access control
   */
  private AccessUtil access;

  private EventsI events;

  private Calendars calendars;

  private EventProperties<BwCategory, BwString> categories;

  private EventProperties<BwLocation, String> locations;

  private EventProperties<BwContact, String> contacts;

  /** Prevent updates.
   */
  //sprivate boolean readOnly;

  /** Current hibernate session - exists only across one user interaction
   */
  private HibSession sess;

  /** We make this static for this implementation so that there is only one
   * SessionFactory per server for the calendar.
   *
   * <p>static fields used this way are illegal in the j2ee specification
   * though we might get away with it here as the session factory only
   * contains parsed mappings for the calendar configuration. This should
   * be the same for any machine in a cluster so it might work OK.
   *
   * <p>It might be better to find some other approach for the j2ee world.
   */
  private static SessionFactory sessFactory;
  private static Statistics dbStats;

  static {
    /** Get a new hibernate session factory. This is configured from an
     * application resource hibernate.cfg.xml
     */
    try {
      sessFactory = new Configuration().configure().buildSessionFactory();
    } catch (Throwable t) {
      Logger.getLogger(CalintfImpl.class).error("Failed to get session factory", t);
    }
  }

  /* ====================================================================
   *                   initialisation
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.Calintf#init(org.bedework.calfacade.BwUser, java.lang.String, boolean, boolean, boolean, java.lang.String, boolean)
   */
  public boolean init(String systemName,
                      String url,
                      String authenticatedUser,
                      String user,
                      boolean publicAdmin,
                      Directories groups,
                      boolean debug) throws CalFacadeException {
    super.init(systemName, url, authenticatedUser, user, publicAdmin,
               groups, debug);

    boolean userCreated = false;

    BwUser authUser;

    try {
      access = new AccessUtil();
      access.init(debug);
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }

    if (user == null) {
      user = authenticatedUser;
    }

    if (authenticatedUser == null) {
      // Unauthenticated use
      // Ensure no guest mods
//      this.readOnly = true;
      currentMode = CalintfUtil.guestMode;
      authUser = new BwUser();
//      this.user = getUser(user);
      this.user = new BwUser();
    } else {
//      this.readOnly = false;

      authUser = getUser(authenticatedUser);
      if (authUser == null) {
        /* Add the user to the database. Presumably this is first logon
         */
        getLogger().info("Add new user " + authenticatedUser);
        if (authenticatedUser.endsWith("/")) {
          authenticatedUser = authenticatedUser.substring(0, authenticatedUser.length() - 1);
        }

        addNewUser(new BwUser(authenticatedUser));
        authUser = getUser(authenticatedUser);
        userCreated = true;
      }

      if (!publicAdmin) {
        currentMode = CalintfUtil.userMode;
      } else {
        currentMode = CalintfUtil.publicAdminMode;
      }

      logon(authUser);

      if (authenticatedUser.equals(user)) {
        this.user = authUser;

        getLogger().info("Authenticated user " + authenticatedUser +
        " logged on");
      } else {
        this.user = getUser(user);
        if (this.user == null) {
          throw new CalFacadeException("User " + user + " does not exist.");
        }

        logon(this.user);
        getLogger().info("Authenticated user " + authenticatedUser +
        " logged on - running as " + user);
      }
    }

    this.user.setGroups(groups.getAllGroups(this.user));
    access.setAuthUser(this.user);
    access.setSyspars((BwSystem)getSyspars().clone());

    CalintfHelperCallback cb = new CalintfHelperCallback(this);
    CalintfHelperHib.HibSessionFetcher hsf = new HibSessionFetcher(this);

    events = new Events(hsf, cb, access, currentMode, debug);

    calendars = new Calendars(hsf, cb, access, currentMode, debug);

    categories = new EventPropertiesImpl<BwCategory, BwString>(hsf);
    categories.init(cb, access, currentMode,
                    "word", "word",
                    BwCategory.class.getName(),
                    "getCategoryRefs", "removeCategoryForAll", debug);
    locations = new EventPropertiesImpl<BwLocation, String>(hsf);
    locations.init(cb, access, currentMode,
                   "uid", "address",
                   BwLocation.class.getName(),
                   "getLocationRefs", "removeLocationForAll", debug);
    contacts = new EventPropertiesImpl<BwContact, String>(hsf);
    contacts.init(cb, access, currentMode,
                  "uid", "name",
                  BwContact.class.getName(),
                  "getContactRefs", "removeContactForAll", debug);

    timezones = new CalTimezonesImpl(this, getStats(), publicAdmin,
                                     this.user, debug);
    timezones.setDefaultTimeZoneId(getSyspars().getTzid());

    if (userCreated) {
      calendars.addNewCalendars(this.user);
    }

    return userCreated;
  }

  private static class HibSessionFetcher implements CalintfHelperHib.HibSessionFetcher {
    private CalintfBase intf;

    HibSessionFetcher(CalintfBase intf) {
      this.intf = intf;
    }

    public HibSession getSess() throws CalFacadeException {
      return (HibSession)intf.getDbSession();
    }
  }

  private static class CalintfHelperCallback implements CalintfHelperHib.Callback {
    private CalintfBase intf;

    CalintfHelperCallback(CalintfBase intf) {
      this.intf = intf;
    }

    public void rollback() throws CalFacadeException {
      intf.rollbackTransaction();
    }

    public BwSystem getSyspars() throws CalFacadeException {
      return intf.getSyspars();
    }

    public BwUser getUser() throws CalFacadeException {
      return intf.getUser();
    }

    public boolean getSuperUser() throws CalFacadeException {
      return intf.getSuperUser();
    }

    public CalTimezones getTimezonesHandler() throws CalFacadeException {
      return intf.getTimezonesHandler();
    }

    public Collection<BwCalendar> getCalendars(BwCalendar cal) throws CalFacadeException {
      return intf.getCalendars(cal);
    }
  }

  public void logon(BwUser val) throws CalFacadeException {
    checkOpen();
    Timestamp now = new Timestamp(System.currentTimeMillis());

    val.setLogon(now);
    val.setLastAccess(now);
    sess.update(val);
  }

  public void setSuperUser(boolean val) {
    access.setSuperUser(val);
  }

  public boolean getSuperUser() {
    return access.getSuperUser();
  }

  public BwStats getStats() throws CalFacadeException {
    if (stats == null) {
      return null;
    }

    BwRWStats rwstats = (BwRWStats)stats;

    if (timezones != null) {
      rwstats.setDateCacheHits(timezones.getDateCacheHits());
      rwstats.setDateCacheMisses(timezones.getDateCacheMisses());
      rwstats.setDatesCached(timezones.getDatesCached());
    }

    return stats;
  }

  public void setDbStatsEnabled(boolean enable) throws CalFacadeException {
    if (!enable && (dbStats == null)) {
      return;
    }

    if (dbStats == null) {
      dbStats = sessFactory.getStatistics();
    }

    dbStats.setStatisticsEnabled(enable);
  }

  public boolean getDbStatsEnabled() throws CalFacadeException {
    if (dbStats == null) {
      return false;
    }

    return dbStats.isStatisticsEnabled();
  }

  public void dumpDbStats() throws CalFacadeException {
    DbStatistics.dumpStats(dbStats);
  }

  public Collection<StatsEntry> getDbStats() throws CalFacadeException {
    return DbStatistics.getStats(dbStats);
  }

  public BwSystem getSyspars() throws CalFacadeException {
    return getSyspars(getSystemName());
  }

  public BwSystem getSyspars(String name) throws CalFacadeException {
    if (syspars == null) {
      sess.namedQuery("getSystemPars");

      sess.setString("name", name);

      syspars = (BwSystem)sess.getUnique();

      if (syspars == null) {
        throw new CalFacadeException("No system parameters with name " +
                                     name);
      }

      if (debug) {
        trace("Read system parameters: " + syspars);
      }
    }
    return syspars;
  }

  public void updateSyspars(BwSystem val) throws CalFacadeException {
    checkOpen();
    sess.update(val);
    syspars = null; // Force refresh
    access.setSyspars((BwSystem)getSyspars().clone());
  }

  public CalTimezones getTimezonesHandler() throws CalFacadeException {
    return timezones;
  }

  public CalintfInfo getInfo() throws CalFacadeException {
    return info;
  }

  /* ====================================================================
   *                   Misc methods
   * ==================================================================== */

  public void flushAll() throws CalFacadeException {
    if (debug) {
      debug("flushAll for " + objTimestamp);
    }
    /*
    if (sess == null) {
      return;
    }

    try {
      if (!sess.isOpen()) {
        sess.reconnect();  // for close
        sess.close();
      }
    } finally {
      isOpen = false;
      sess = null;
    }*/
  }

  public synchronized void open() throws CalFacadeException {
    if (isOpen) {
      throw new CalFacadeException("Already open");
    }

    isOpen = true;

    if (sess != null) {
      warn("Session is not null. Will close");
      try {
        close();
      } finally {
      }
    }

    if (debug) {
      debug("New hibernate session for " + objTimestamp);
    }
    sess = new HibSessionImpl();
    sess.init(sessFactory, getLogger());
    /*
    } else {
      if (debug) {
        debug("Reconnect hibernate session for " + objTimestamp);
      }
      sess.reconnect();
    }*/

    if (access != null) {
      access.open();
    }

//    personalModified = new Vector();
  }

  public synchronized void close() throws CalFacadeException {
    if (!isOpen) {
      if (debug) {
        debug("Close for " + objTimestamp + " closed session");
      }
      return;
    }

    if (debug) {
      debug("Close for " + objTimestamp);
    }

    try {
      if (sess != null) {
        if (sess.rolledback()) {
          sess = null;
          return;
        }

        if (sess.transactionStarted()) {
          sess.rollback();
        }
//        sess.disconnect();
        sess.close();
        sess = null;
      }
    } catch (Throwable t) {
      try {
        sess.close();
      } finally {}
      sess = null; // Discard on error
    } finally {
      isOpen = false;
    }

    if (access != null) {
      access.close();
    }
  }

  public void beginTransaction() throws CalFacadeException {
    checkOpen();
//    sess.close();
    if (debug) {
      debug("Begin transaction for " + objTimestamp);
    }
    sess.beginTransaction();
  }

  public void endTransaction() throws CalFacadeException {
    checkOpen();

    if (debug) {
      debug("End transaction for " + objTimestamp);
    }

    if (!sess.rolledback()) {
      sess.commit();
    }
  }

  public void rollbackTransaction() throws CalFacadeException {
    checkOpen();
    sess.rollback();
  }

  public void flush() throws CalFacadeException {
    if (debug) {
      getLogger().debug("flush for " + objTimestamp);
    }
    if (sess.isOpen()) {
      sess.flush();
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.Calintf#getDbSession()
   */
  public Object getDbSession() throws CalFacadeException {
    return sess;
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.Calintf#reAttach(org.bedework.calfacade.base.BwDbentity)
   */
  public void reAttach(BwDbentity val) throws CalFacadeException {
    if (val instanceof CoreCalendarWrapper) {
      CoreCalendarWrapper ccw = (CoreCalendarWrapper)val;
      val = ccw.unwrap();
    }
    sess.reAttach(val);
  }

  /* ====================================================================
   *                   General data methods
   * ==================================================================== */

  /*
  public void lockRead(Object val) throws CalFacadeException {
    checkOpen();
    sess.lockRead(val);
  }

  public void lockMod(Object val) throws CalFacadeException {
    checkOpen();
    sess.lockUpdate(val);
  }
  */

  /* ====================================================================
   *                   Global parameters
   * ==================================================================== */

  public long getPublicLastmod() throws CalFacadeException {
    checkOpen();
    return 0; // for the moment
  }

  public String getSysid() throws CalFacadeException {
    return getSyspars().getSystemid();
  }

  public String getSysname() throws CalFacadeException {
    return getSyspars().getName();
  }

  /* ====================================================================
   *                   Users
   * ==================================================================== */

  public BwUser getUser(String user) throws CalFacadeException {
    checkOpen();
    StringBuilder q = new StringBuilder();

    q.append("from ");
    q.append(BwUser.class.getName());
    q.append(" as u where u.account = :account");
    sess.createQuery(q.toString());

    sess.setString("account", user);

    return (BwUser)sess.getUnique();
  }

  public void addUser(BwUser user) throws CalFacadeException {
    addNewUser(user);
    calendars.addNewCalendars(user);
  }

  private void addNewUser(BwUser user) throws CalFacadeException {
    checkOpen();

    user.setCategoryAccess(access.getDefaultPersonalAccess());
    user.setLocationAccess(access.getDefaultPersonalAccess());
    user.setContactAccess(access.getDefaultPersonalAccess());

    user.setQuota(getSyspars().getDefaultUserQuota());

    sess.save(user);
  }

  public void updateUser(BwUser user) throws CalFacadeException {
    checkOpen();
    sess.update(user);
  }

  public Collection<BwUser> getInstanceOwners() throws CalFacadeException {
    checkOpen();
    StringBuilder q = new StringBuilder();

    q.append("from ");
    q.append(BwUser.class.getName());
    q.append(" as u where u.instanceOwner=true");
    sess.createQuery(q.toString());

    return sess.getList();
  }

  /*
  public void deleteUser(BwUser user) throws CalFacadeException {
    checkOpen();
    throw new CalFacadeException("Unimplemented");
  }*/

  /* ====================================================================
   *                   Access
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calcorei.Calintf#changeAccess(org.bedework.calfacade.base.BwShareableDbentity, java.util.Collection, boolean)
   */
  public void changeAccess(BwShareableDbentity ent,
                           Collection<Ace> aces,
                           boolean replaceAll) throws CalFacadeException {
    if (ent instanceof BwCalendar) {
      changeAccess((BwCalendar)ent, aces, replaceAll);
      return;
    }
    checkOpen();
    access.changeAccess(ent, aces, replaceAll);
    sess.saveOrUpdate(ent);
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.CalendarsI#changeAccess(org.bedework.calfacade.BwCalendar, java.util.Collection)
   */
  public void changeAccess(BwCalendar cal,
                           Collection<Ace> aces,
                           boolean replaceAll) throws CalFacadeException {
    checkOpen();
    calendars.changeAccess(cal, aces, replaceAll);
  }

  public void defaultAccess(BwShareableDbentity ent,
                            AceWho who) throws CalFacadeException {
    if (ent instanceof BwCalendar) {
      defaultAccess((BwCalendar)ent, who);
      return;
    }
    checkOpen();
    checkAccess(ent, privWriteAcl, false);
    access.defaultAccess(ent, who);
    sess.saveOrUpdate(ent);
  }

  public void defaultAccess(BwCalendar cal,
                            AceWho who) throws CalFacadeException {
    checkOpen();
    calendars.defaultAccess(cal, who);
  }

  public CurrentAccess checkAccess(BwShareableDbentity ent, int desiredAccess,
                                   boolean returnResult) throws CalFacadeException {
    return access.checkAccess(ent, desiredAccess, returnResult);
  }

  /* ====================================================================
   *                   Timezones
   * ==================================================================== */

  public void saveTimeZone(String tzid, VTimeZone vtz) throws CalFacadeException {
    checkOpen();

    BwTimeZone tz = new BwTimeZone();

    if (currentMode == CalintfUtil.guestMode) {
      throw new CalFacadeAccessException();
    }

    tz.setTzid(tzid);
    if (currentMode == CalintfUtil.publicAdminMode) {
      tz.setPublick(true);
      tz.setOwner(getUser(syspars.getPublicUser()));
    } else {
      tz.setPublick(false);
      tz.setOwner(user);
    }

    StringBuilder sb = new StringBuilder();

    sb.append("BEGIN:VCALENDAR\n");
    sb.append("PRODID:-//RPI//BEDEWORK//US\n");
    sb.append("VERSION:2.0\n");
    sb.append(vtz.toString());
    sb.append("END:VCALENDAR\n");

    tz.setVtimezone(sb.toString());

    sess.save(tz);
  }

  public VTimeZone getTimeZone(final String id, BwUser owner,
                               boolean publick) throws CalFacadeException {
    if (publick ||
        (currentMode == CalintfUtil.publicAdminMode) ||
        (currentMode == CalintfUtil.guestMode)) {
      sess.namedQuery("getPublicTzByTzid");
    } else {
      if (owner == null) {
        owner = user;
      }
      sess.namedQuery("getTzByTzid");
      sess.setEntity("owner", owner);
    }

    sess.setString("tzid", id);

    BwTimeZone tz = (BwTimeZone)sess.getUnique();

    if (tz == null) {
      return null;
    }

    Calendar cal = IcalTranslator.getCalendar(tz.getVtimezone());

    VTimeZone vtz = (VTimeZone)cal.getComponents().getComponent(Component.VTIMEZONE);
    if (vtz == null) {
      throw new CalFacadeException("Incorrectly stored timezone");
    }

    return vtz;
  }

  @SuppressWarnings("unchecked")
  public Collection<BwTimeZone> getTimeZones() throws CalFacadeException {
    if (currentMode == CalintfUtil.publicAdminMode ||
        currentMode == CalintfUtil.guestMode) {
      sess.namedQuery("getPublicTimezones");

      return sess.getList();
    }

    sess.namedQuery("getMergedTimezones");
    sess.setEntity("owner", user);

    return sess.getList();
  }

  @SuppressWarnings("unchecked")
  public Collection<BwTimeZone> getUserTimeZones(BwUser tzOwner) throws CalFacadeException {
    if (currentMode == CalintfUtil.publicAdminMode ||
        currentMode == CalintfUtil.guestMode) {
      // No user timezones
      return new ArrayList<BwTimeZone>();
    }

    sess.namedQuery("getUserTimezones");
    sess.setEntity("owner", tzOwner);

    return sess.getList();
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.Calintf#getPublicTimeZoneIds()
   */
  @SuppressWarnings("unchecked")
  public Collection<String> getPublicTimeZoneIds() throws CalFacadeException {
    sess.namedQuery("getPublicTimezoneIds");

    Collection<String> ids = new TreeSet<String>();
    Iterator it = sess.getList().iterator();
    while (it.hasNext()) {
      Object[] info = (Object[])it.next();
      ids.add((String)info[0]);
    }

    return ids;
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.Calintf#getPublicTimeZones()
   */
  @SuppressWarnings("unchecked")
  public Collection<BwTimeZone> getPublicTimeZones() throws CalFacadeException {
    sess.namedQuery("getPublicTimezones");

    return sess.getList();
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.Calintf#clearPublicTimezones()
   */
  public void clearPublicTimezones() throws CalFacadeException {
    checkOpen();

    /* Delete all public timezones */
    sess.namedQuery("deleteAllPublicTzs");
    /*int numDeleted =*/ sess.executeUpdate();
  }

  public List<TimeZoneInfo> getTimeZoneIds() throws CalFacadeException {
    ArrayList<TimeZoneInfo> l = new ArrayList<TimeZoneInfo>();

    sess.namedQuery("getPublicTimezoneIds");

    Iterator it = sess.getList().iterator();

    while (it.hasNext()) {
      Object[] os = (Object[])it.next();

      String tzid = (String)os[0];

      l.add(new TimeZoneInfo(tzid, true));
    }

    if (currentMode == CalintfUtil.publicAdminMode ||
        currentMode == CalintfUtil.guestMode) {
      // No user timezones
      return l;
    }

    sess.namedQuery("getUserTimezoneIds");

    it = sess.getList().iterator();

    while (it.hasNext()) {
      Object[] os = (Object[])it.next();

      String tzid = (String)os[0];

      l.add(new TimeZoneInfo(tzid, false));
    }

    return l;
  }

  /** Extended info clas which has internal state information.
   *
   */
  private static class UpdateFromTimeZonesInfoInternal implements
          UpdateFromTimeZonesInfo {
    /* Event ids */
    Collection<? extends InternalEventKey> ids;
    Iterator<? extends InternalEventKey> idIterator;

    long lastmod = 0;

    int totalEventsChecked;

    int totalEventsUpdated;

    Collection<UnknownTimezoneInfo> unknownTzids = new TreeSet<UnknownTimezoneInfo>();

    Collection<BwEventKey> updatedList = new ArrayList<BwEventKey>();

    /* (non-Javadoc)
     * @see org.bedework.calfacade.base.UpdateFromTimeZonesInfo#getTotalEventsToCheck()
     */
    public int getTotalEventsToCheck() {
      return ids.size();
    }

    /* (non-Javadoc)
     * @see org.bedework.calfacade.base.UpdateFromTimeZonesInfo#getTotalEventsChecked()
     */
    public int getTotalEventsChecked() {
      return totalEventsChecked;
    }

    /* (non-Javadoc)
     * @see org.bedework.calfacade.base.UpdateFromTimeZonesInfo#getTotalEventsUpdated()
     */
    public int getTotalEventsUpdated() {
      return totalEventsUpdated;
    }

    public Collection<UnknownTimezoneInfo> getUnknownTzids() {
      return unknownTzids;
    }

    public Collection<BwEventKey> getUpdatedList() {
      return updatedList;
    }

    public String toString() {
      StringBuilder sb = new StringBuilder();

      sb.append("------------------------------------------");
      sb.append("\nUpdateFromTimeZonesInfoInternal:");
      sb.append("\ntotalEventsToCheck: ");
      sb.append(getTotalEventsToCheck());
      sb.append("\ntotalEventsChecked: ");
      sb.append(totalEventsChecked);
      sb.append("\ntotalEventsUpdated: ");
      sb.append(totalEventsUpdated);
      sb.append("\n------------------------------------------");

      return sb.toString();
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.Calintf#updateFromTimeZones(int, boolean, org.bedework.calfacade.base.UpdateFromTimeZonesInfo)
   */
  public UpdateFromTimeZonesInfo updateFromTimeZones(int limit,
                                                     boolean checkOnly,
                                                     UpdateFromTimeZonesInfo info
                                                     ) throws CalFacadeException {
    /* Versions < 3.3 don't have recurrences fully implemented so we'll
     * ignore those.
     *
     * Fields that could be affected:
     * Event start + end
     * rdates and exdates
     * Recurrence instances
     *
     */
    if ((info != null) && !(info instanceof UpdateFromTimeZonesInfoInternal)) {
      throw new CalFacadeException(CalFacadeException.illegalObjectClass);
    }

    boolean redo = false;

    UpdateFromTimeZonesInfoInternal iinfo;

    if (info != null) {
      if (info.getTotalEventsToCheck() == info.getTotalEventsChecked()) {
        redo = true;
      }

      iinfo = (UpdateFromTimeZonesInfoInternal)info;
    } else {
      iinfo = new UpdateFromTimeZonesInfoInternal();
    }

    if (redo || (iinfo.ids == null)) {
      String lastmod = null;

      if (redo) {
        lastmod = new LastModified(new DateTime(iinfo.lastmod - 5000)).getValue();
      }
      // Get event ids from db.
      iinfo.lastmod = System.currentTimeMillis();
      iinfo.ids = events.getEventKeysForTzupdate(lastmod);

      if (iinfo.ids == null) {
        iinfo.ids = new ArrayList<InternalEventKey>();
      }

      iinfo.totalEventsChecked = 0;
      iinfo.totalEventsUpdated = 0;
      iinfo.idIterator = iinfo.ids.iterator();
    }

    CalTimezones tzs = getTimezonesHandler();

    for (int i = 0; i < limit; i++) {
      if (!iinfo.idIterator.hasNext()) {
        break;
      }

      InternalEventKey ikey = iinfo.idIterator.next();

      // See if event needs update
      BwUser owner = ikey.getOwner();

      BwDateTime start = checkDateTimeForTZ(ikey.getStart(), owner, iinfo, tzs);
      BwDateTime end = checkDateTimeForTZ(ikey.getEnd(), owner, iinfo, tzs);

      if ((start != null) || (end != null)) {
        CoreEventInfo cei = events.getEvent(ikey);
        BwEvent ev = cei.getEvent();

        if (cei != null) {
          iinfo.updatedList.add(new BwEventKey(ev.getCalendar().getPath(),
                                               ev.getUid(),
                                               ev.getRecurrenceId(),
                                               ev.getName(),
                                               ev.getRecurring()));
          if (!checkOnly) {
            if (start != null) {
              BwDateTime evstart = ev.getDtstart();
              if (debug) {
                trace("Updated start: ev.tzid=" + evstart.getTzid() +
                      " ev.dtval=" + evstart.getDtval() +
                      " ev.date=" + evstart.getDate() +
                      " newdate=" + start.getDate());
              }
              evstart.setDate(start.getDate());
            }
            if (end != null) {
              BwDateTime evend = ev.getDtend();
              if (debug) {
                trace("Updated end: ev.tzid=" + evend.getTzid() +
                      " ev.dtval=" + evend.getDtval() +
                      " ev.date=" + evend.getDate() +
                      " newdate=" + end.getDate());
              }
              evend.setDate(end.getDate());
            }
            events.updateEvent(ev, null, null);
            iinfo.totalEventsUpdated++;
          }
        }
      }

      iinfo.totalEventsChecked++;
    }

    if (debug) {
      trace(iinfo.toString());
    }

    return iinfo;
  }

  /* Recalculate UTC for the given value.
   *
   * Return null if no change needed otherwise return new value
   */
  private BwDateTime checkDateTimeForTZ(BwDateTime val,
                                        BwUser owner,
                                        UpdateFromTimeZonesInfoInternal iinfo,
                                        CalTimezones timezones) throws CalFacadeException {
    if (val.getDateType()) {
      return null;
    }

    if (val.isUTC()) {
      return null;
    }

    if (val.getFloating()) {
      return null;
    }

    try {
      BwDateTime newVal = CalFacadeUtil.getDateTime(val.getDtval(), false, false,
                                                    false, val.getTzid(),
                                                    val.getTzowner(),
                                                    timezones);

      if (newVal.getDate().equals(val.getDate())) {
        return null;
      }

      return newVal;
    } catch (CalFacadeException cfe) {
      if (cfe.getMessage().equals(CalFacadeException.unknownTimezone)) {
        iinfo.unknownTzids.add(new UnknownTimezoneInfo(owner, val.getTzid()));
        return null;
      }
      throw cfe;
    }
  }

  /* ====================================================================
   *                       Calendars
   * ==================================================================== */

  public BwCalendar getPublicCalendars() throws CalFacadeException {
    checkOpen();

    return calendars.getPublicCalendars();
  }

  public Collection<BwCalendar> getPublicCalendarCollections() throws CalFacadeException {
    checkOpen();

    return calendars.getPublicCalendarCollections();
  }

  public BwCalendar getCalendars() throws CalFacadeException {
    if (currentMode == CalintfUtil.guestMode) {
      return getPublicCalendars();
    }

    checkOpen();

    return calendars.getCalendars();
  }

  public BwCalendar getCalendars(BwUser user,
                                 int desiredAccess) throws CalFacadeException {
    checkOpen();

    return calendars.getCalendars(user, desiredAccess);
  }

  public Collection<BwCalendar> getCalendars(BwCalendar cal) throws CalFacadeException {
    checkOpen();

    return calendars.getCalendars(cal);
  }

  public Collection<BwCalendar> getCalendarCollections() throws CalFacadeException {
    checkOpen();

    return calendars.getCalendarCollections();
  }

  public Collection<BwCalendar> getAddContentPublicCalendarCollections()
          throws CalFacadeException {
    checkOpen();

    return calendars.getAddContentPublicCalendarCollections();
  }

  public Collection<BwCalendar> getAddContentCalendarCollections()
          throws CalFacadeException {
    if (currentMode == CalintfUtil.guestMode) {
      return new TreeSet<BwCalendar>();
    }

    checkOpen();

    return calendars.getAddContentCalendarCollections();
  }

  public BwCalendar getCalendar(int val) throws CalFacadeException {
    checkOpen();

    return calendars.getCalendar(val);
  }

  public BwCalendar getCalendar(String path,
                                int desiredAccess) throws CalFacadeException{
    checkOpen();

    return calendars.getCalendar(path, desiredAccess);
  }

  public String getDefaultCalendarPath(BwUser user) throws CalFacadeException {
    return calendars.getDefaultCalendarPath(user);
  }

  public String getUserRootPath(BwUser user) throws CalFacadeException {
    return calendars.getUserRootPath(user);
  }

  public GetSpecialCalendarResult getSpecialCalendar(BwUser user,
                                       int calType,
                                       boolean create,
                                       int access) throws CalFacadeException {
    return calendars.getSpecialCalendar(user, calType, create, access);
  }

  public BwCalendar addCalendar(BwCalendar val,
                                String parentPath) throws CalFacadeException {
    checkOpen();

    if (val.getCalendarCollection()) {
      val.setCalType(BwCalendar.calTypeCollection);
    } else {
      val.setCalType(BwCalendar.calTypeFolder);
    }
    return calendars.addCalendar(val, parentPath);
  }

  public void updateCalendar(BwCalendar val) throws CalFacadeException {
    checkOpen();
    calendars.updateCalendar(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.CalendarsI#renameCalendar(org.bedework.calfacade.BwCalendar, java.lang.String)
   */
  public void renameCalendar(BwCalendar val,
                             String newName) throws CalFacadeException {
    checkOpen();
    calendars.renameCalendar(val, newName);
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.CalendarsI#moveCalendar(org.bedework.calfacade.BwCalendar, org.bedework.calfacade.BwCalendar)
   */
  public void moveCalendar(BwCalendar val,
                           BwCalendar newParent) throws CalFacadeException {
    checkOpen();
    calendars.moveCalendar(val, newParent);
  }

  public boolean deleteCalendar(BwCalendar val) throws CalFacadeException {
    checkOpen();

    return calendars.deleteCalendar(val);
  }

  public boolean checkCalendarRefs(BwCalendar val) throws CalFacadeException {
    checkOpen();

    return calendars.checkCalendarRefs(val);
  }

  /* ====================================================================
   *                   Filters and search
   * ==================================================================== */

  public void setSearch(String val) throws CalFacadeException {
    checkOpen();
  }

  public String getSearch() throws CalFacadeException {
    checkOpen();

    return null;
  }

  public void addFilter(BwFilter val) throws CalFacadeException {
    checkOpen();
    sess.save(val);
  }

  public void updateFilter(BwFilter val) throws CalFacadeException {
    checkOpen();
    sess.saveOrUpdate(val);
  }

  /* ====================================================================
   *                   Event Properties
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calcorei.Calintf#getCategories()
   */
  public EventProperties<BwCategory, BwString> getCategories()
        throws CalFacadeException {
    checkOpen();

    return categories;
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.Calintf#getLocations()
   */
  public EventProperties<BwLocation, String> getLocations()
        throws CalFacadeException {
    checkOpen();

    return locations;
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.Calintf#getContacts()
   */
  public EventProperties<BwContact, String> getContacts()
        throws CalFacadeException {
    checkOpen();

    return contacts;
  }

  /* ====================================================================
   *                   Free busy
   * ==================================================================== */

  public BwFreeBusy getFreeBusy(BwCalendar cal, BwPrincipal who,
                                BwDateTime start, BwDateTime end,
                                boolean returnAll,
                                boolean ignoreTransparency)
          throws CalFacadeException {
    if (!(who instanceof BwUser)) {
      throw new CalFacadeException("Unsupported: non user principal for free-busy");
    }

    Collection<CoreEventInfo> events = getFreeBusyEntities(cal, start, end, ignoreTransparency);
    BwFreeBusy fb = new BwFreeBusy(who, start, end);
    //assignGuid(fb);

    try {
      TreeSet<EventPeriod> eventPeriods = new TreeSet<EventPeriod>();

      for (CoreEventInfo ei: events) {
        BwEvent ev = ei.getEvent();

        // Ignore if times were specified and this event is outside the times

        BwDateTime estart = ev.getDtstart();
        BwDateTime eend = ev.getDtend();

        /* Don't report out of the requested period */

        String dstart;
        String dend;

        if (estart.before(start)) {
          dstart = start.getDtval();
        } else {
          dstart = estart.getDtval();
        }

        if (eend.after(end)) {
          dend = end.getDtval();
        } else {
          dend = eend.getDtval();
        }

        DateTime psdt = new DateTime(dstart);
        DateTime pedt = new DateTime(dend);

        psdt.setUtc(true);
        pedt.setUtc(true);

        int type = BwFreeBusyComponent.typeBusy;

        if (BwEvent.statusTentative.equals(ev.getStatus())) {
          type = BwFreeBusyComponent.typeBusyTentative;
       }

        eventPeriods.add(new EventPeriod(psdt, pedt, type));
      }

      /* iterate through the sorted periods combining them where they are
       adjacent or overlap */

      Period p = null;

      /* For the moment just build a single BwFreeBusyComponent
       */
      BwFreeBusyComponent fbc = null;
      int lastType = 0;

      for (EventPeriod ep: eventPeriods) {
        if (debug) {
          trace(ep.toString());
        }

        if (p == null) {
          p = new Period(ep.getStart(), ep.getEnd());
          lastType = ep.getType();
        } else if ((lastType != ep.getType()) || ep.getStart().after(p.getEnd())) {
          // Non adjacent periods
          if (fbc == null) {
            fbc = new BwFreeBusyComponent();
            fbc.setType(lastType);
            fb.addTime(fbc);
          }
          fbc.addPeriod(p.getStart(), p.getEnd());

          if (lastType != ep.getType()) {
            fbc = null;
          }

          p = new Period(ep.getStart(), ep.getEnd());
          lastType = ep.getType();
        } else if (ep.getEnd().after(p.getEnd())) {
          // Extend the current period
          p = new Period(p.getStart(), ep.getEnd());
        } // else it falls within the existing period
      }

      if (p != null) {
        if ((fbc == null) || (lastType != fbc.getType())) {
          fbc = new BwFreeBusyComponent();
          fbc.setType(lastType);
          fb.addTime(fbc);
        }
        fbc.addPeriod(p.getStart(), p.getEnd());
      }
    } catch (Throwable t) {
      if (debug) {
        error(t);
      }
      throw new CalFacadeException(t);
    }

    return fb;
  }

  /* ====================================================================
   *                   Events
   * ==================================================================== */

  public Collection<CoreEventInfo> getEvents(BwCalendar calendar, BwFilter filter,
                                             BwDateTime startDate, BwDateTime endDate,
                                             RecurringRetrievalMode recurRetrieval,
                                             boolean freeBusy,
                                             boolean allCalendars) throws CalFacadeException {
    return events.getEvents(calendar, filter,
                            startDate, endDate, recurRetrieval,
                            freeBusy, allCalendars);
  }

 public Collection<CoreEventInfo> getEvent(BwCalendar calendar,
                                           String guid, String rid,
                                           RecurringRetrievalMode recurRetrieval)
           throws CalFacadeException {
    checkOpen();
    return events.getEvent(calendar, guid, rid, recurRetrieval);
  }

  public Collection<BwEventProxy> addEvent(BwEvent val,
                                           Collection<BwEventProxy> overrides,
                                           boolean scheduling,
                                           boolean rollbackOnError) throws CalFacadeException {
    checkOpen();
    try {
      overrides = events.addEvent(val, overrides, scheduling, rollbackOnError);
    } catch (CalFacadeException cfe) {
      rollbackTransaction();
      throw cfe;
    }

    calendars.touchCalendar(val.getCalendar());

    return overrides;
  }

  public void updateEvent(BwEvent val,
                          Collection<BwEventProxy> overrides,
                          ChangeTable changes) throws CalFacadeException {
    checkOpen();
    try {
      events.updateEvent(val, overrides, changes);
    } catch (CalFacadeException cfe) {
      rollbackTransaction();
      throw cfe;
    }

    calendars.touchCalendar(val.getCalendar());
  }

  public DelEventResult deleteEvent(BwEvent val) throws CalFacadeException {
    checkOpen();
    BwCalendar cal = val.getCalendar();
    try {
      try {
        return events.deleteEvent(val);
      } catch (CalFacadeException cfe) {
        rollbackTransaction();
        throw cfe;
      }
    } finally {
      calendars.touchCalendar(cal);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.EventsI#getEventKeys()
   */
  public Collection<? extends InternalEventKey> getEventKeysForTzupdate(String lastmod)
          throws CalFacadeException {
    // Don't respond to these calls.
    return null;
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.EventsI#getEvent(org.bedework.calcorei.EventsI.InternalEventKey)
   */
  public CoreEventInfo getEvent(InternalEventKey key)
          throws CalFacadeException {
    // Don't respond to these calls.
    return null;
  }

  /*public boolean editable(BwEvent val) throws CalFacadeException {
    checkOpen();

    return events.editable(val);
  }*/

  public CoreEventInfo getEvent(BwCalendar cal, String val,
                                RecurringRetrievalMode recurRetrieval)
          throws CalFacadeException {
    checkOpen();
    return events.getEvent(cal, val, recurRetrieval);
  }

  public Collection<BwCalendar> findCalendars(String guid,
                                              String rid) throws CalFacadeException {
    checkOpen();
    return events.findCalendars(guid, rid);
  }

  public Collection<CoreEventInfo> getDeletedProxies() throws CalFacadeException {
    BwCalendar cal = getSpecialCalendar(user, BwCalendar.calTypeDeleted, false,
                                        PrivilegeDefs.privRead).cal;

    if (cal == null) {
      // Not supported or never deleted anything
      return new ArrayList<CoreEventInfo>();
    }

    return events.getDeletedProxies(cal);
  }

  public Collection<CoreEventInfo> getDeletedProxies(BwCalendar cal)
          throws CalFacadeException {
    return events.getDeletedProxies(cal);
  }

  /* ====================================================================
   *                       Alarms
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calcorei.Calintf#getAlarms(org.bedework.calfacade.BwEvent, org.bedework.calfacade.BwUser)
   */
  @SuppressWarnings("unchecked")
  public Collection<BwAlarm> getAlarms(BwEvent event, BwUser user) throws CalFacadeException {
    checkOpen();

    sess.namedQuery("getAlarms");
    sess.setEntity("ev", event);
    sess.setEntity("user", user);

    return sess.getList();
  }

  public void addAlarm(BwAlarm val) throws CalFacadeException {
    checkOpen();

    sess.save(val);
  }

  public void updateAlarm(BwAlarm val) throws CalFacadeException {
    checkOpen();
    sess.saveOrUpdate(val);
  }

  public Collection getUnexpiredAlarms(BwUser user) throws CalFacadeException {
    checkOpen();

    if (user == null) {
      sess.namedQuery("getUnexpiredAlarms");
    } else {
      sess.namedQuery("getUnexpiredAlarmsUser");
      sess.setEntity("user", user);
    }

    return sess.getList();
  }

  public Collection getUnexpiredAlarms(BwUser user, long triggerTime)
          throws CalFacadeException {
    checkOpen();

    sess.namedQuery("getUnexpiredAlarmsUserTime");
    sess.setEntity("user", user);
    sess.setLong("tt", triggerTime);

    return sess.getList();
  }

  /* ====================================================================
   *                   Private methods
   * ==================================================================== */

  private Collection<CoreEventInfo> getFreeBusyEntities(BwCalendar cal,
                                         BwDateTime start, BwDateTime end,
                                         boolean ignoreTransparency)
          throws CalFacadeException {
    /* Only events and freebusy for freebusy reports. */
    BwFilter filter = new BwOrFilter();
    filter.addChild(BwEntityTypeFilter.eventFilter(null, false));
    filter.addChild(BwEntityTypeFilter.freebusyFilter(null, false));

    RecurringRetrievalMode rrm = new RecurringRetrievalMode(
                        Rmode.expanded, start, end);
    Collection<CoreEventInfo> evs = getEvents(cal, filter, start, end, rrm, true, true);

    // Filter out transparent and cancelled events

    Collection<CoreEventInfo> events = new TreeSet<CoreEventInfo>();

    for (CoreEventInfo cei: evs) {
      BwEvent ev = cei.getEvent();

      if (!ignoreTransparency &&
          BwEvent.transparencyTransparent.equals(ev.getTransparency())) {
        // Ignore this one.
        continue;
      }

      if (BwEvent.statusCancelled.equals(ev.getStatus())) {
        // Ignore this one.
        continue;
      }

      events.add(cei);
    }

    return events;
  }
}

