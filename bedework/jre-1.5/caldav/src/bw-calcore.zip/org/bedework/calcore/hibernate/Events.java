/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2007 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calcore.hibernate;

import org.bedework.apiutil.RecurUtil;
import org.bedework.apiutil.RecurUtil.RecurPeriods;
import org.bedework.calcore.AccessUtil;
import org.bedework.calcorei.CoreEventInfo;
import org.bedework.calcorei.EventsI;
import org.bedework.calcorei.HibSession;
import org.bedework.calfacade.BwAlarm;
import org.bedework.calfacade.BwCalendar;
import org.bedework.calfacade.BwDateTime;
import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.BwEventAnnotation;
import org.bedework.calfacade.BwEventObj;
import org.bedework.calfacade.BwEventProxy;
import org.bedework.calfacade.BwRecurrenceInstance;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.RecurringRetrievalMode;
import org.bedework.calfacade.BwCalendar.CollectionInfo;
import org.bedework.calfacade.RecurringRetrievalMode.Rmode;
import org.bedework.calfacade.base.BwDbentity;
import org.bedework.calfacade.exc.CalFacadeAccessException;
import org.bedework.calfacade.exc.CalFacadeDupNameException;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.filter.BwFilter;
import org.bedework.calfacade.timezones.CalTimezones;
import org.bedework.calfacade.util.ChangeTable;
import org.bedework.calfacade.util.ChangeTableEntry;
import org.bedework.calfacade.util.PropertyIndex.PropertyInfoIndex;
import org.bedework.calfacade.wrappers.CoreCalendarWrapper;

import edu.rpi.cmt.access.Acl.CurrentAccess;

import net.fortuna.ical4j.model.Dur;
import net.fortuna.ical4j.model.Period;
import net.fortuna.ical4j.model.TimeZone;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeSet;

/** Class to encapsulate most of what we do with events
 *
 * @author Mike Douglass   douglm  - rpi.edu
 */
public class Events extends CalintfHelperHib implements EventsI {
  /** Constructor
   *
   * @param hsf
   * @param cb
   * @param access
   * @param currentMode
   * @param debug
   */
  public Events(HibSessionFetcher hsf, Callback cb, AccessUtil access,
                int currentMode, boolean debug) {
    super(hsf);
    super.init(cb, access, currentMode, debug);
  }

  @SuppressWarnings("unchecked")
  public Collection<BwCalendar> findCalendars(String guid,
                                              String rid) throws CalFacadeException {
    HibSession sess = getSess();

    StringBuilder sb = new StringBuilder("select ev.calendar from ");
    sb.append(BwEventObj.class.getName());
    sb.append(" ev where ev.uid=:uid");

    if (rid != null) {
      sb.append(" and ev.recurrenceId=:rid");
    }

    sb.append(" and ");
    boolean setUser = CalintfUtil.appendPublicOrOwnerTerm(sb, "ev",
                                                          currentMode, false);

    sess.createQuery(sb.toString());

    sess.setString("uid", guid);

    if (rid != null) {
      sess.setString("rid", rid);
    }

    if (setUser) {
      sess.setEntity("user", getUser());
    }

    return sess.getList();
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.EventsI#getEvent(org.bedework.calfacade.BwCalendar, java.lang.String, java.lang.String, org.bedework.calfacade.RecurringRetrievalMode)
   */
  @SuppressWarnings("unchecked")
  public Collection<CoreEventInfo> getEvent(BwCalendar calendar,
                                            String uid, String rid,
                                            RecurringRetrievalMode recurRetrieval)
          throws CalFacadeException {
    BwEvent master = null;
    TreeSet<CoreEventInfo> ts = new TreeSet<CoreEventInfo>();
    HibSession sess = getSess();

    calendar = unwrap(calendar);

    /* This works as follows:
     *
     * First try to retrieve the master event from the events table.
     *
     * If not there try the annotations table. If it's there, it's a reference
     * to an event owned by somebody else. Otherwise we drew a blank.
     *
     * If no recurrence id was specified process any recurrence information for
     * each event retrieved and return.
     *
     * Note that the event we retrieved might be a reference to a recurring
     * instance. In that case it will inherit the recurrence id. We should check
     * for this case and assume we were being asked for that event.
     *
     * If a recurrence id was specified then, for each master event retrieved,
     * we need to retrieve the instance and build a proxy using any appropriate
     * overrides.
     */

    // First look in the events table for the master(s).
    eventQuery(BwEventObj.class, calendar, null, uid, null, null,
               recurRetrieval, true);

    /* The uid and recurrence id is a unique key for calendar collections
     * other than some special ones, Trash, Inbox and Outbox.
     *
     * These we treat specially as they also cannot be annotated etc so we
     * just return what we find.
     */

    Collection evs = sess.getList();

    // XXX Don't want annotations in the trash
    if ((evs == null) || (evs.isEmpty())) {
      /* Look for an annotation to that event by the current user.
       */
      eventQuery(BwEventAnnotation.class, calendar, null, uid, null, null,
                 recurRetrieval, true);
      evs = sess.getList();
    }

    if ((evs == null) || (evs.isEmpty())) {
      return ts;
    }

    Collection<CoreEventInfo> ceis = postGetEvents(evs, privRead,
                                                   returnResultAlways);

    if (ceis.isEmpty()) {
      return ceis;
    }

    /* If the recurrence id is null, do recurrences for each retrieved event,
     * otherwise just retrieve the instance.
     */

    Collection<BwCalendar> cals = new TreeSet<BwCalendar>();
    cals.add(calendar);

    for (CoreEventInfo cei: ceis) {
      master = cei.getEvent();

      if (!master.getRecurring()) {
        ts.add(cei);
      } else if (rid == null) {
        doRecurrence(cei, null, cals, recurRetrieval);
        if (recurRetrieval.mode == Rmode.expanded) {
          Collection<CoreEventInfo> instances = cei.getInstances();

          if (instances != null) {
            ts.addAll(instances);
          }
        } else {
          ts.add(cei);
        }
      } else {
        cei = getInstanceOrOverride(cals, master, rid);
        if (cei != null) {
          ts.add(cei);
        }
      }
    }

    return ts;
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.EventsI#getEvents(org.bedework.calfacade.BwCalendar, org.bedework.calfacade.filter.BwFilter, org.bedework.calfacade.BwDateTime, org.bedework.calfacade.BwDateTime, org.bedework.calfacade.RecurringRetrievalMode, boolean, boolean)
   */
  public Collection<CoreEventInfo> getEvents(BwCalendar calendar, BwFilter filter,
                                             BwDateTime startDate, BwDateTime endDate,
                                             RecurringRetrievalMode recurRetrieval,
                                             boolean freeBusy,
                                             boolean allCalendars) throws CalFacadeException {
    boolean ignoreCreator = cb.getSuperUser();

    /* Ensure dates are limited explicitly or implicitly */
    recurRetrieval = defaultRecurringRetrieval(recurRetrieval,
                                               startDate, endDate);

    calendar = unwrap(calendar);

    if (debug) {
      trace("getEvents for start=" + startDate + " end=" + endDate);
    }

    /* eventsQuery covers some of what is outlined here.
     *
     * 1. Get events and annotations in range
     *    If no range is supplied we get all events and annotations.
     *    Otherwise we exclude the recurring master events as they turn up later.
     *
     *    We also exclude overrides to recurring instances.
     *
     *    If no date range was supplied we now have all the master events.
     *    Otherwise we have all the non-recurring events
     *    (XXX or recurring reference by an annotation???)
     *
     * 2. If there is a date range supplied, get all instances in date range and
     *    add their masters to the set.
     *
     * 3. If there is a date range supplied, get all overrides in date range and
     *    add their masters to the set.
     *
     * 4. For each event
     *    4a. if not recurring add to result
     *    4b. if recurring {
     *          if expanding
     *             find all instances (in range) and add to result set
     *          else {
     *            find all overrides (in override range if supplied)
     *            find all instances (IF instance range)
     *            attach them to the master
     *            add master to set.
     *          }
     *        }
     *
     * Some points to remind ourselves. We have to fetch overides and instances
     * because the master may be out of the range of a date limited query - usually
     * is, but we need the master to construct a proxy.
     *
     * We could probably just use the overrides and instances obtained in
     * steps 2 and 3 except for the CalDAV complications which allow a different
     * date range for overrides and instances.
     */

    int desiredAccess = privRead;
    if (freeBusy) {
      // DORECUR - freebusy events must have enough info for expansion
      desiredAccess = privReadFreeBusy;
    }

    EventsQueryResult eqr = eventsQuery(calendar, filter,
                                        startDate, endDate,
                                        currentMode, ignoreCreator, null,
                                        freeBusy, allCalendars,
                                        null, getEvents);

    Collection<CoreEventInfo> ceis = postGetEvents(eqr.es, desiredAccess,
                                                   returnResultAlways);

    /* Run the events we got through the filters
     */
    ceis = eqr.flt.postExec(ceis);

    /* Now get the annotations and filter them */
    eqr = eventsQuery(calendar, filter, startDate, endDate, currentMode,
                      ignoreCreator, eqr, freeBusy, allCalendars,
                      null, getAnnotations);

    ceis.addAll(eqr.flt.postExec(postGetEvents(eqr.es, desiredAccess,
                                               returnResultAlways)));

    /* If there were any date limits we need to get any overrides or instances
     * that fall in the range and add the unique masters to the Collection
     */
    if ((startDate != null) || (endDate != null) || (filter != null)) {
      Collection<BwEvent> masters = new TreeSet<BwEvent>();

      eqr = eventsQuery(calendar, filter, startDate, endDate, currentMode,
                        ignoreCreator, eqr, freeBusy, allCalendars,
                        null, getOverrides);

      if (!eqr.es.isEmpty()) {
        Iterator it = eqr.es.iterator();
        while (it.hasNext()) {
          BwEventAnnotation ann = (BwEventAnnotation)it.next();
          masters.add(ann.getMaster());
        }
      }

      eqr = eventsQuery(calendar, filter, startDate, endDate, currentMode,
                        ignoreCreator, eqr, freeBusy, allCalendars,
                        null, getInstances);

      if (!eqr.es.isEmpty()) {
        Iterator it = eqr.es.iterator();
        while (it.hasNext()) {
          BwRecurrenceInstance inst = (BwRecurrenceInstance)it.next();
          masters.add(inst.getMaster());
        }
      }

      for (BwEvent mstr: masters) {
        ceis.add(postGetEvent(mstr, desiredAccess, returnResultAlways));
      }
    }

    Collection<CoreEventInfo> res = new TreeSet<CoreEventInfo>();

    /* Do recurrences or expansion for each retrieved event,
     */

    for (CoreEventInfo cei: ceis) {
      BwEvent master = cei.getEvent();

      if (!master.getRecurring()) {
        res.add(cei);
      } else {
        doRecurrence(cei, null, eqr.calendars, recurRetrieval);
        if (recurRetrieval.mode == Rmode.expanded) {
          Collection<CoreEventInfo> instances = cei.getInstances();

          if (instances != null) {
            res.addAll(instances);
          }
        } else {
          res.add(cei);
        }
      }
    }

    if (freeBusy) {
      res = makeFreeBusy(res);
    }

    return res;
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.EventsI#getEvent(org.bedework.calfacade.BwCalendar, java.lang.String, org.bedework.calfacade.RecurringRetrievalMode)
   */
  public CoreEventInfo getEvent(BwCalendar cal, String name,
                                RecurringRetrievalMode recurRetrieval)
          throws CalFacadeException {
    HibSession sess = getSess();

    cal = unwrap(cal);

    sess.namedQuery("eventsByName");
    sess.setString("name", name);
    sess.setEntity("cal", cal);

    BwEvent ev = (BwEvent)sess.getUnique();

    if (ev == null) {
      // Try annotation
      sess.namedQuery("eventAnnotationsByName");
      sess.setString("name", name);
      sess.setEntity("cal", cal);

      ev = (BwEvent)sess.getUnique();
    }

    if (ev == null) {
      return null;
    }

    CoreEventInfo cei = postGetEvent(ev, privRead, returnResultAlways);

    if (cei != null)  {
      // Access was not denied

      ev = cei.getEvent();
      Boolean rec = ev.getRecurring();
      if ((rec != null) && rec) {
        doRecurrence(cei, null, null, recurRetrieval);
      }
    }

    return cei;
  }

  public Collection<CoreEventInfo> getDeletedProxies(BwCalendar cal) throws CalFacadeException {
    HibSession sess = getSess();
    StringBuilder sb = new StringBuilder();

    sb.append("from ");
    sb.append(BwEventAnnotation.class.getName());
    sb.append(" ev");
    sb.append(" where ev.calendar=:calendar");
    sb.append(" and ev.deleted=true");

    sess.createQuery(sb.toString());
    sess.setEntity("calendar", unwrap(cal));

    Collection evs = sess.getList();

    return postGetEvents(evs, privRead, returnResultAlways);
  }

  public Collection<BwEventProxy> addEvent(BwEvent val,
                                           Collection<BwEventProxy> overrides,
                                           boolean scheduling,
                                           boolean rollbackOnError) throws CalFacadeException {
    RecuridTable recurids = null;
    HibSession sess = getSess();
    CollectionInfo collInf = val.getCalendar().getCollectionInfo();

    ensureUnwrappedCalendar(val);
    BwCalendar cal = val.getCalendar();

    if (scheduling) {
      if (cal.getCalType() != BwCalendar.calTypeInbox) {
        throw new CalFacadeAccessException();
      }
      access.checkAccess(cal, privScheduleRequest, false);
    } else {
      access.checkAccess(cal, privBind, false);
    }

    if ((overrides != null) && (overrides.size() != 0)) {
      if (!val.getRecurring()) {
        throwException(CalFacadeException.overridesForNonRecurring);
      }

      recurids = new RecuridTable(overrides);
    }

    if (val.getUid() == null) {
      throwException(CalFacadeException.noEventGuid);
    }

    if (val.getName() == null) {
      throwException(CalFacadeException.noEventName);
    }

    /* The guid must not exist in the same calendar. We assign a guid if
     * one wasn't assigned already. However, the event may have come with a guid
     * (caldav, import, etc) so we need to check here.
     *
     * It also ensures our guid allocation is working OK
     */
    if (collInf.uniqueKey &&
        (calendarGuidExists(val, false, true) ||
         calendarGuidExists(val, true, true))) {
      throwException(CalFacadeException.duplicateGuid, val.getUid());
    }

    /* Similarly for event names which must be unique within a collection
     */
    if (calendarNameExists(val, false, true) ||
        calendarNameExists(val, true, true)) {
      throwException(CalFacadeException.duplicateName, val.getName());
    }

    setupDependentEntities(val);
    sess.save(val);

    /** If it's a recurring event see what we can do to optimise searching
     * and retrieval
     */
    if ((val instanceof BwEventAnnotation) || !val.getRecurring()) {
      return null;
    }

    /* Get all the times for this event. - this could be a problem. Need to
       limit the number. Should we do this in chunks, stepping through the
       whole period?
     */

    CalTimezones tzs = cb.getTimezonesHandler();

    RecurPeriods rp = RecurUtil.getPeriods(val, cb.getSyspars().getMaxYears(),
                                           cb.getSyspars().getMaxInstances(),
                                           tzs, debug);

    if (rp.instances.isEmpty()) {
      // No instances for an alleged recurring event.
      sess.rollback();
      throwException(CalFacadeException.noRecurrenceInstances);
    }

    String stzid = val.getDtstart().getTzid();
    TimeZone stz = null;
    if (stzid != null) {
      stz = tzs.getTimeZone(stzid, val.getOwner());
    }

    val.setLatestDate(tzs.getUtc(rp.rangeEnd.toString(), stzid, stz,
                                 val.getOwner()));
    int maxInstances = cb.getSyspars().getMaxInstances();

    boolean dateOnly = val.getDtstart().getDateType();

    for (Period p: rp.instances) {
      BwDateTime rstart = new BwDateTime();
      String dtval = p.getStart().toString();
      if (dateOnly) {
        dtval = dtval.substring(0, 8);
      }
      rstart.init(dateOnly, dtval, stzid, val.getOwner(), tzs);

      BwDateTime rend = new BwDateTime();
      dtval = p.getEnd().toString();
      if (dateOnly) {
        dtval = dtval.substring(0, 8);
      }
      rend.init(dateOnly, dtval, stzid, val.getOwner(), tzs);

      BwRecurrenceInstance ri = new BwRecurrenceInstance();

      ri.setDtstart(rstart);
      ri.setDtend(rend);
      ri.setRecurrenceId(ri.getDtstart().getDate());
      ri.setMaster(val);

      if (recurids != null) {
        /* See if we have a recurrence */
        String rid = ri.getRecurrenceId();
        BwEventProxy ov = (BwEventProxy)recurids.get(rid);

        if (ov != null) {
          if (debug) {
            debugMsg("Add override with recurid " + rid);
          }

          setupDependentEntities(ov);
          addOverride(ov, ri);
          recurids.remove(rid);
        }
      }

      sess.save(ri);
      maxInstances--;
      if (maxInstances == 0) {
        // That's all you're getting from me
        break;
      }
    }

    if ((recurids != null) && (recurids.size() != 0)) {
      /* We removed all the valid overrides - we are left with those
       * with recurrence ids that don't match.
       */
      if (rollbackOnError) {
        cb.rollback();
        throwException("org.bedework.error.invalid.override");
      }

      overrides = recurids.values();
    } else {
      overrides = null;
    }

    val.setExpanded(true);
    sess.saveOrUpdate(val);

    return overrides;
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.EventsI#updateEvent(org.bedework.calfacade.BwEvent, java.util.Collection, org.bedework.calfacade.util.ChangeTable)
   */
  public void updateEvent(BwEvent val,
                          Collection<BwEventProxy> overrides,
                          ChangeTable changes) throws CalFacadeException {
    HibSession sess = getSess();
    CollectionInfo collInf = val.getCalendar().getCollectionInfo();

    ensureUnwrappedCalendar(val);

    if (!access.checkAccess(val, privWrite, true).accessAllowed) {
      // See if we get write content
      // XXX Is this correct?
      try {
        access.checkAccess(val, privWriteContent, false);
      } catch (CalFacadeException cfe) {
        sess.rollback();
        throw cfe;
      }
    }

    BwEventProxy proxy = null;

    if (val instanceof BwEventProxy) {
      proxy = (BwEventProxy)val;
    }

    /* Don't allow name and uid changes for overrides */

    if ((proxy != null) && (proxy.getRef().getOverride())) {
      BwEventAnnotation ann = proxy.getRef();
      BwEvent mstr = ann.getMaster();

      if (!proxy.getUid().equals(mstr.getUid())) {
        throwException("org.bedework.cannot.overrideuid");
      }

      if (!proxy.getName().equals(mstr.getName())) {
        throwException("org.bedework.cannot.overridename");
      }
    } else {
      /* The guid must not exist in the same calendar. We assign a guid if
       * one wasn't assigned already. However, the event may have come with a guid
       * (caldav, import, etc) so we need to check here.
       *
       * It also ensures our guid allocation is working OK
       */
      if (collInf.uniqueKey &&
          (calendarGuidExists(val, false, false) ||
              calendarGuidExists(val, true, false))) {
        throwException(CalFacadeException.duplicateGuid);
      }

      /* Similarly for event names which must be unique within a collection
       */
      if (calendarNameExists(val, false, false) ||
          calendarNameExists(val, true, false)) {
        sess.rollback();
        throw new CalFacadeDupNameException(val.getName());
      }
    }

    if (!(val instanceof BwEventProxy)) {
      sess.update(val);

      Collection<BwDbentity<?>> deleted = val.getDeletedEntities();
      if (deleted != null) {
        for (BwDbentity ent: deleted) {
          sess.delete(ent);
        }

        deleted.clear();
      }

      if (val.getRecurring()) {
        /* Check the instances and see if any changes need to be made.
         */
        updateRecurrences(val, overrides, changes);
      } else {
        /* If the event was recurring and now is not remove recurrences */
        deleteRecurrences(val, changes);
      }

      // XXX I don't think we want this updateRefs(val);

      if (!val.getRecurring() || (overrides == null)) {
        return;
      }

      for (BwEventProxy pxy: overrides) {
        BwEventAnnotation ann = pxy.getRef();

        ann.setRecurring(new Boolean(false)); // be safe

        updateProxy(new BwEventProxy(ann));
      }
      return;
    }

    if (!proxy.getRefChanged()) {
      return;
    }

    updateProxy(proxy);
    return;
  }

  public DelEventResult deleteEvent(BwEvent val) throws CalFacadeException {
    HibSession sess = getSess();
    DelEventResult der = new DelEventResult(false, 0);

    try {
      access.checkAccess(val, privUnbind, false);
    } catch (CalFacadeException cfe) {
      sess.rollback();
      throw cfe;
    }

    if (val.getRecurring() && (val.getRecurrenceId() == null)) {
      // Master event - delete all instances and overrides.
      fixReferringAnnotations(val);
      deleteInstances(val, der);

      sess.delete(val);
    } else if ((val.getRecurrenceId() != null) &&
               (val instanceof BwEventProxy)) {
      /* Deleting a single instance. Delete any overrides, delete the instance
       * and add an exdate to the master.
       */

      StringBuilder sb = new StringBuilder();

      BwEventProxy proxy = (BwEventProxy)val;
      BwEventAnnotation ann = proxy.getRef();
      BwEvent master = ann.getMaster();

      /* Fetch the instance so we can delete it */
      sb.append("from ");
      sb.append(BwRecurrenceInstance.class.getName());
      sb.append(" where master=:master and ");
      sb.append(" recurrenceId=:rid");

      sess.createQuery(sb.toString());
      sess.setEntity("master", master);
      sess.setString("rid", val.getRecurrenceId());
      BwRecurrenceInstance inst = (BwRecurrenceInstance)sess.getUnique();

      if (inst == null) {
        return der;
      }

      sess.delete(inst);

      if (!ann.unsaved()) {
        //der.alarmsDeleted = deleteAlarms(ann);

        sess.delete(ann);
      }

      BwDateTime instDate = inst.getDtstart();

      if (!master.getRdates().remove(instDate)) {
        // Wasn't an rdate event
        master.addExdate(instDate);
      }
      master.updateLastmod();
      sess.update(master);
    } else {
      // Single non recurring event.

      if (val instanceof BwEventProxy) {
        // Deleting an annotation
        val = ((BwEventProxy)val).getRef();
      }

      // I think we need something like this -- fixReferringAnnotations(val);

      // XXX This could be wrong.
      /* If this is a proxy we should only delete alarmas attached to the
       * proxy - any attached to the underlying event should be left alone.
       */
      //der.alarmsDeleted = deleteAlarms(val);

      //sess.delete(sess.merge(val));
      sess.delete(val);
    }

    der.eventDeleted = true;

    return der;
  }

  /** This represents an internal key to an event.
   *
   */
  private static class PrivateInternalEventKey extends InternalEventKey {
    Integer key;

    BwDateTime start;

    BwDateTime end;

    BwUser owner;

    /**
     * @param key
     * @param start
     * @param end
     * @param owner
     */
    public PrivateInternalEventKey(Integer key, BwDateTime start, BwDateTime end,
                            BwUser owner) {
      this.key = key;
      this.start = start;
      this.end = end;
      this.owner = owner;
    }

    public BwDateTime getStart() {
      return start;
    }

    public BwDateTime getEnd() {
      return end;
    }

    public BwUser getOwner() {
      return owner;
    }

  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.EventsI#getEventKeys()
   */
  @SuppressWarnings("unchecked")
  public Collection<? extends InternalEventKey> getEventKeysForTzupdate(String lastmod)
          throws CalFacadeException {
    HibSession sess = getSess();

    if (!cb.getSuperUser()) {
      sess.rollback();
      throw new CalFacadeAccessException();
    }

    StringBuilder sb = new StringBuilder();

    sb.append("select new org.bedework.calcore.hibernate.Events$PrivateInternalEventKey(");
    sb.append("ev.id, ev.dtstart, ev.dtend, ev.owner) from ");
    sb.append(BwEventObj.class.getName());
    sb.append(" ev where ");

    if (lastmod != null) {
      sb.append("ev.lastmod >= :lastmod and ");
    }

    sb.append("(ev.dtstart.floatFlag=false or ");

    sb.append("ev.dtstart.dateType=false or ");

    sb.append("ev.dtend.floatFlag=false or ");

    sb.append("ev.dtend.dateType=false)");

    sess.createQuery(sb.toString());

    if (lastmod != null) {
      sess.setString("lastmod", lastmod);
    }

    Collection<PrivateInternalEventKey> ids = sess.getList();

    if (debug) {
      trace(" ----------- number ids = " + ids.size());
    }

    return ids;
  }

  /** Get an event given the internal key. Returns null if event no longer
   * exists.
   *
   * @param key
   * @return CoreEventInfo
   * @throws CalFacadeException
   */
  public CoreEventInfo getEvent(InternalEventKey key)
          throws CalFacadeException {
    HibSession sess = getSess();

    if (!cb.getSuperUser()) {
      sess.rollback();
      throw new CalFacadeAccessException();
    }

    if ((key == null) || !(key instanceof PrivateInternalEventKey)) {
      throwException(CalFacadeException.illegalObjectClass);
    }

    PrivateInternalEventKey ikey = (PrivateInternalEventKey)key;

    StringBuilder sb = new StringBuilder();

    sb.append("from ");
    sb.append(BwEventObj.class.getName());
    sb.append(" ev where ev.id=:id");

    sess.createQuery(sb.toString());
    sess.setInt("id", ikey.key);

    BwEvent ev = (BwEvent)sess.getUnique();

    if (ev == null) {
      return null;
    }

    CurrentAccess ca = new CurrentAccess();

    ca.accessAllowed = true;

    return new CoreEventInfo(ev, ca);
  }

  /* ====================================================================
   *                   Private methods
   * ==================================================================== */

  private void setupDependentEntities(BwEvent val) throws CalFacadeException {
    HibSession sess = getSess();

    if (val.getOrganizer() != null) {
      sess.saveOrUpdate(val.getOrganizer());
    }

    // Ensure collections in reasonable state.
    if (val.getAlarms() != null) {
      for (BwAlarm alarm: val.getAlarms()) {
        alarm.setEvent(val);
        alarm.setOwner(getUser());
      }
    }
  }

  /* Called by updateEvent to update a proxied event (annotation) or an
   * override.
   */
  private void updateProxy(BwEventProxy proxy) throws CalFacadeException {
    HibSession sess = getSess();

    /* if this is a proxy for a recurrence instance of our own event
       then the recurrence instance should point at this override.
       Otherwise we just update the event annotation.
     */
    BwEventAnnotation override = proxy.getRef();
    if (debug) {
      debugMsg("Update override event " + override);
    }

    BwEvent mstr = override.getTarget();

    while (mstr instanceof BwEventAnnotation) {
      /* XXX The master may itself be an annotated event. We should really
         stop when we get to that point
       */
      /*
      BwEventProxy tempProxy = new BwEventProxy(mstr);
      if (some-condition-holds) {
        break;
      }
      */
      mstr = ((BwEventAnnotation)mstr).getTarget();
    }

//    if (mstr.getOwner().equals(getUser()) &&
    if (mstr.getRecurring()) {
      // A recurring event - retrieve the instance
      // from the recurrences table
      StringBuilder sb = new StringBuilder();

      sb.append("from ");
      sb.append(BwRecurrenceInstance.class.getName());
      sb.append(" rec ");
      sb.append(" where rec.master=:mstr ");
      sb.append(" and rec.recurrenceId=:rid ");

      sess.createQuery(sb.toString());

      sess.setEntity("mstr", mstr);
      sess.setString("rid", override.getRecurrenceId());

      BwRecurrenceInstance inst = (BwRecurrenceInstance)sess.getUnique();
      if (inst == null) {
        throwException(CalFacadeException.cannotLocateInstance,
                       mstr + "with recurrence id " + override.getRecurrenceId());
      }

      override.setOwner(mstr.getOwner()); // XXX Force owner????
      sess.saveOrUpdate(override);
//      sess.flush();
      if (inst.getOverride() == null) {
        inst.setOverride(override);
        sess.saveOrUpdate(inst);
      }
    } else {
      sess.saveOrUpdate(override);
    }

    proxy.setRefChanged(false);
  }

  /* Retrieves the overides for a recurring event and if required,
   * retrieves the instances.
   *
   * The overrides we retrieve are optionally limited by date.
   *
   * The CalDAV spec requires that we retrieve all overrides which fall within
   * the given date range AND all instances in that date range including
   * overriden instances that WOULD have fallen in that range had they not been
   * overriden.
   *
   * Thus we need to search both overrides and instances - unless no date range
   * is given in which case all overrides will appear along with the instances.
   *
   * If the calendars parameter is non-null, as it usually will be for a call
   * from getEvents, we limit the result to instances that appear within that
   * set of calendars. This handles the case of an overriden instance moved to a
   * different calendar, for example the trash.
   */
  private void doRecurrence(CoreEventInfo cei, BwFilter filter,
                            Collection<BwCalendar> calendars,
                            RecurringRetrievalMode recurRetrieval)
          throws CalFacadeException {
    HibSession sess = getSess();
    BwEvent master = cei.getEvent();

    // Always fetch overrides
    eventQuery(BwEventAnnotation.class, null, calendars, null, null, master,
               recurRetrieval, false);

    Collection ovs = sess.getList();

    Iterator it = ovs.iterator();
    while (it.hasNext()) {
      BwEventAnnotation override = (BwEventAnnotation)it.next();
      CoreEventInfo ocei = makeProxy(null, override, null, recurRetrieval,
                                     false);

      if (cei != null) {
        cei.addOverride(ocei);
      }
    }

    /* If we are asking for full expansion retrieve all the instances (within
     * the given date range if supplied)
     */

    if (recurRetrieval.mode == Rmode.expanded) {
      cei.setInstances(getRecurrences(master, null,
                                      currentMode, cb.getSuperUser(),
                                      recurRetrieval, false, true));
    }
  }

  /* We were asked for a specific instance. This overrides the retrieval mode
   * as we always want it returned.
   */
  private CoreEventInfo getInstanceOrOverride(Collection<BwCalendar> calendars,
                                              BwEvent master, String rid)
          throws CalFacadeException {
    /* First look for an override */
    HibSession sess = getSess();
    BwEventAnnotation override = null;
    BwRecurrenceInstance inst = null;

    RecurringRetrievalMode rrm = new RecurringRetrievalMode(Rmode.expanded);

    eventQuery(BwEventAnnotation.class, null, calendars, null, rid, master,
               rrm, false);

    Collection ovs = sess.getList();

    if (ovs.size() > 1) {
      throw new CalFacadeException("Multiple overrides");
    }

    if (ovs.size() == 1) {
      override = (BwEventAnnotation)ovs.iterator().next();
    } else {
      inst = getInstance(master, rid);
    }

    if ((override == null) && (inst == null)) {
      return null;
    }

    return makeProxy(inst, override, null, rrm, false);
  }

  private BwRecurrenceInstance getInstance(BwEvent master,
                                           String rid) throws CalFacadeException {
    HibSession sess = getSess();
    StringBuilder sb = new StringBuilder();

    sb.append("from ");
    sb.append(BwRecurrenceInstance.class.getName());
    sb.append(" inst ");
    sb.append(" where inst.master=:master ");

    sb.append(" and inst.recurrenceId=:rid ");

    sess.createQuery(sb.toString());

    sess.setEntity("master", master);
    sess.setString("rid", rid);

    return (BwRecurrenceInstance)sess.getUnique();
  }

  /* Get an object which will limit retrieved enties either to the explicitly
   * given date limits or to th edates (if any) given in the call.
   */
  private RecurringRetrievalMode defaultRecurringRetrieval(
        RecurringRetrievalMode val,
        BwDateTime start, BwDateTime end) {
    if ((start == null) && (end == null)) {
      // No change to make
      return val;
    }

    if ((val.start != null) && (val.end != null)) {
      // Fully specified
      return val;
    }

    RecurringRetrievalMode newval = new RecurringRetrievalMode(val.mode,
                                                               val.start,
                                                               val.end);
    if (newval.start == null) {
      newval.start = start;
    }

    if (newval.end == null) {
      newval.end = end;
    }

    return newval;
  }

  private boolean calendarGuidExists(BwEvent val,
                                     boolean annotation,
                                     boolean adding) throws CalFacadeException {
    HibSession sess = getSess();

    StringBuilder sb = new StringBuilder("select count(*) from ");

    if (!annotation) {
      sb.append(BwEventObj.class.getName());
    } else {
      sb.append(BwEventAnnotation.class.getName());
    }

    sb.append(" ev where ");

    BwEvent testEvent = null;

    if (!adding) {
      if (annotation) {
        if (val instanceof BwEventProxy) {
          BwEventProxy proxy = (BwEventProxy)val;
          BwEventAnnotation ann = proxy.getRef();

          testEvent = ann;
        }
        sb.append("ev.override=false and ");
      } else if (!annotation && (!(val instanceof BwEventProxy))) {
        testEvent = val;
      }
    }

    if (testEvent != null) {
      sb.append("ev<>:event and ");
    }

    sb.append("ev.calendar=:cal and ev.uid = :uid");

    sess.createQuery(sb.toString());

    if (testEvent != null) {
      sess.setEntity("event", testEvent);
    }

    sess.setEntity("cal", val.getCalendar());
    sess.setString("uid", val.getUid());


    Collection refs = sess.getList();

    Object o = refs.iterator().next();

    /* Apparently some get a Long - others get Integer */
    if (o instanceof Long) {
      Long ct = (Long)o;
      return ct.longValue() > 0;
    }

    Integer ct = (Integer)o;
    return ct.intValue() > 0;
  }

  private boolean calendarNameExists(BwEvent val,
                                     boolean annotation,
                                     boolean adding) throws CalFacadeException {
    HibSession sess = getSess();

    StringBuilder sb = new StringBuilder("select count(*) from ");

    if (!annotation) {
      sb.append(BwEventObj.class.getName());
    } else {
      sb.append(BwEventAnnotation.class.getName());
    }

    sb.append(" ev where ");

    BwEvent testEvent = null;

    if (!adding) {
      if (annotation) {
        if (val instanceof BwEventProxy) {
          BwEventProxy proxy = (BwEventProxy)val;
          BwEventAnnotation ann = proxy.getRef();

          testEvent = ann;
        }
        sb.append("ev.override=false and ");
      } else if (!annotation && (!(val instanceof BwEventProxy))) {
        testEvent = val;
      }
    }

    if (testEvent != null) {
      sb.append("ev<>:event and ");
    }

    sb.append("ev.calendar=:cal and ev.name = :name");

    sess.createQuery(sb.toString());

    if (testEvent != null) {
      sess.setEntity("event", testEvent);
    }

    sess.setEntity("cal", val.getCalendar());
    sess.setString("name", val.getName());

    Collection refs = sess.getList();

    Object o = refs.iterator().next();

    /* Apparently some get a Long - others get Integer */
    if (o instanceof Long) {
      Long ct = (Long)o;
      return ct.longValue() > 0;
    }

    Integer ct = (Integer)o;
    return ct.intValue() > 0;
  }

  /* XXX This needs more work, OK until we allow modification of annotations - which
   * could happen anyway through caldav or by synch.
   *
   * If the master changes then either we change the referencing annotations or
   * we let the user know it's changed. At the moment we have no notification
   * mechanism.
   * /
  private void updateRefs(BwEvent val) throws CalFacadeException {
    HibSession sess = getSess();
    Iterator it = getAnnotations(val).iterator();

    while (it.hasNext()) {
      BwEventAnnotation ann = (BwEventAnnotation)it.next();
      boolean changed = false;

      if (!val.getDtstart().equals(ann.getDtstart())) {
        ann.setDtstart(val.getDtstart());
        changed = true;
      }

      if (!val.getDtend().equals(ann.getDtend())) {
        ann.setDtend(val.getDtend());
        changed = true;
      }

      if (!val.getDuration().equals(ann.getDuration())) {
        ann.setDuration(val.getDuration());
        changed = true;
      }

      if (val.getEndType() != ann.getEndType()) {
        ann.setEndType(val.getEndType());
        changed = true;
      }

      if (changed) {
        sess.update(ann);
      }
    }
  }
  */

  /* Called when adding an event with overrides
   */
  private void addOverride(BwEventProxy proxy,
                           BwRecurrenceInstance inst) throws CalFacadeException {
    BwEventAnnotation override = proxy.getRef();
    override.setOwner(getUser());
    override.setMaster(inst.getMaster());
    override.setTarget(inst.getMaster());
    override.setOverride(true);

    getSess().saveOrUpdate(override);
    inst.setOverride(override);
  }

  /* Delete any recurrences.
   */
  private void deleteRecurrences(BwEvent val,
                                 ChangeTable changes) throws CalFacadeException {
    if (changes != null) {
      if (!changes.recurrenceChanged()) {
        return;
      }
    }

    clearCollection(val.getRrules());
    clearCollection(val.getExrules());
    clearCollection(val.getRdates());
    clearCollection(val.getExdates());

    deleteInstances(val, new DelEventResult(false, 0));
  }

  private void clearCollection(Collection c) {
    if (c == null) {
      return;
    }

    c.clear();
  }

  private void deleteInstances(BwEvent val,
                               DelEventResult der) throws CalFacadeException {
    HibSession sess = getSess();

    StringBuilder sb = new StringBuilder();

    /* SEG:   delete from recurrences recur where */
    sb.append("delete from ");
    sb.append(BwRecurrenceInstance.class.getName());
    sb.append(" where master=:master");

    sess.createQuery(sb.toString());
    sess.setEntity("master", val);
    sess.executeUpdate();

    /* XXX Cascades don't seem to do the job here - we have to explicitly delete the
     overriding annotations.

     In any case, this won't work if we have a shared event and there are
     annotations to the annotation. We need a field which identifies all
     annotations related to the master i.e. not just a target field but a
     master field.
     */
    Iterator it = getAnnotations(val, true).iterator();

    while (it.hasNext()) {
      BwEventAnnotation ann = (BwEventAnnotation)it.next();

      if (ann.getAttendees() != null) {
        ann.getAttendees().clear();
      }

      //der.alarmsDeleted += deleteAlarms(ann);
      sess.delete(ann);
    }
  }

  /* XXX This is a bit brute force but it will do for the moment. We have to
   * turn a set of rules into a set of changes. If we'd preserved the rules
   * prior to this I guess we could figure out the differences without querying
   * the db.
   *
   * For the moment create a whole set of instances and then query the db to see if
   * they match.
   */
  private void updateRecurrences(BwEvent val,
                                 Collection<BwEventProxy> overrides,
                                 ChangeTable changes) throws CalFacadeException {
    if (changes != null) {
      if (!changes.recurrenceChanged()) {
        return;
      }

      if (!changes.recurrenceRulesChanged()) {
        // We can handle exdate and rdate changes.
        ChangeTableEntry ent = changes.getEntry(PropertyInfoIndex.EXDATE);
        if (ent.addedValues != null) {
          // exdates added - remove the instances.
          removeInstances(val, overrides, ent.addedValues);
        }

        if (ent.removedValues != null) {
          // exdates removed - add the instances.
          addInstances(val, ent.addedValues);
        }

        ent = changes.getEntry(PropertyInfoIndex.RDATE);
        if (ent.addedValues != null) {
          // rdates added - add the instances.
          addInstances(val, ent.addedValues);
        }

        if (ent.removedValues != null) {
          // rdates removed - remove the instances.
          removeInstances(val, overrides, ent.addedValues);
        }

        return;
      }
    }

    HibSession sess = getSess();

    Map<String, BwRecurrenceInstance> updated = new HashMap<String, BwRecurrenceInstance>();

    /* Get all the times for this event. - this could be a problem. Need to
       limit the number. Should we do this in chunks, stepping through the
       whole period?
     */

    CalTimezones tzs = cb.getTimezonesHandler();

    RecurPeriods rp = RecurUtil.getPeriods(val, cb.getSyspars().getMaxYears(),
                                           cb.getSyspars().getMaxInstances(),
                                           tzs, debug);

    if (rp.instances.isEmpty()) {
      // No instances for an alleged recurring event.
      throwException(CalFacadeException.noRecurrenceInstances);
    }

    String stzid = val.getDtstart().getTzid();
    TimeZone stz = null;
    if (stzid != null) {
      stz = tzs.getTimeZone(stzid, val.getOwner());
    }

    val.setLatestDate(tzs.getUtc(rp.rangeEnd.toString(), stzid, stz,
                                 val.getOwner()));
    int maxInstances = cb.getSyspars().getMaxInstances();

    boolean dateOnly = val.getDtstart().getDateType();

    for (Period p: rp.instances) {
      BwDateTime rstart = new BwDateTime();
      String dtval = p.getStart().toString();
      if (dateOnly) {
        dtval = dtval.substring(0, 8);
      }
      rstart.init(dateOnly, dtval, stzid, val.getOwner(), tzs);

      BwDateTime rend = new BwDateTime();
      dtval = p.getEnd().toString();
      if (dateOnly) {
        dtval = dtval.substring(0, 8);
      }
      rend.init(dateOnly, dtval, stzid, val.getOwner(), tzs);

      BwRecurrenceInstance ri = new BwRecurrenceInstance();

      ri.setDtstart(rstart);
      ri.setDtend(rend);
      ri.setRecurrenceId(ri.getDtstart().getDate());
      ri.setMaster(val);

      updated.put(ri.getRecurrenceId(), ri);
      maxInstances--;
      if (maxInstances == 0) {
        // That's all you're getting from me
        break;
      }
    }

    StringBuilder sb = new StringBuilder();

    sb.append("from ");
    sb.append(BwRecurrenceInstance.class.getName());
    sb.append(" where master=:master");

    sess.createQuery(sb.toString());
    sess.setEntity("master", val);
    Collection current = sess.getList();

    Iterator it = current.iterator();
    while (it.hasNext()) {
      BwRecurrenceInstance ri = (BwRecurrenceInstance)it.next();
      BwRecurrenceInstance updri = updated.get(ri.getRecurrenceId());

      if (updri == null) {
        sess.delete(ri);
      } else {
        /* Found instance with same recurrence id. Is the start and end the same
         */
        if (!ri.getDtstart().equals(updri.getDtstart()) ||
            !ri.getDtend().equals(updri.getDtend())) {
          ri.setDtstart(updri.getDtstart());
          ri.setDtend(updri.getDtend());

          sess.update(ri);
        }

        // Remove the entry
        updated.remove(ri.getRecurrenceId());
      }
    }

    /* updated only contains recurrence ids that don't exist */

    for (BwRecurrenceInstance ri: updated.values()) {
      sess.save(ri);
    }
  }

  /* Remove instances identified by the Collection of recurrence ids
   */
  private void removeInstances(BwEvent master,
                               Collection<BwEventProxy> overrides,
                               Collection rids) throws CalFacadeException {
    HibSession sess = getSess();

    Iterator it = rids.iterator();
    while (it.hasNext()) {
      BwDateTime dt = (BwDateTime)it.next();
      String rid = dt.getDate();

      if (overrides != null) {
        for (BwEventProxy pr: overrides) {
          if (pr.getRecurrenceId().equals(rid)) {
            // This one is being deleted
            overrides.remove(pr);
            break;
          }
        }
      }

      BwRecurrenceInstance inst = getInstance(master, rid);
      if (inst != null) {
        sess.delete(inst);
      }
    }
  }

  /* Add instances identified by the Collection of recurrence ids
   */
  private void addInstances(BwEvent master,
                            Collection rids) throws CalFacadeException {
    HibSession sess = getSess();
    CalTimezones tzs = cb.getTimezonesHandler();
    Dur dur = new Dur(master.getDuration());

    Iterator it = rids.iterator();
    while (it.hasNext()) {
      BwDateTime start = (BwDateTime)it.next();
      BwDateTime end = start.addDur(dur, tzs);

      BwRecurrenceInstance ri = new BwRecurrenceInstance();

      ri.setDtstart(start);
      ri.setDtend(end);
      ri.setRecurrenceId(start.getDate());
      ri.setMaster(master);

      sess.save(ri);
    }
  }

  private Collection getAnnotations(BwEvent val,
                                    boolean overrides) throws CalFacadeException {
    HibSession sess = getSess();
    StringBuilder sb = new StringBuilder();

    sb.append("from ");
    sb.append(BwEventAnnotation.class.getName());
//    sb.append(" where target=:target and override=:override");
    sb.append(" where target=:target");

    sess.createQuery(sb.toString());
    sess.setEntity("target", val);
  //  sess.setBool("override", overrides);

    Collection anns = sess.getList();

    if (debug) {
      debugMsg("getAnnotations for event " + val.getId() +
               " overrides=" + overrides +
               " returns " + anns.size());
    }

    return anns;
  }

  private void fixReferringAnnotations(BwEvent val) throws CalFacadeException {
    HibSession sess = getSess();

    Collection evs = getAnnotations(val, false);

    Iterator it = evs.iterator();
    while (it.hasNext()) {
      BwEvent ev = (BwEvent)it.next();

      fixReferringAnnotations(ev);
      sess.delete(ev);
    }
  }

  private void eventQuery(Class cl, BwCalendar calendar,
                          Collection<BwCalendar> calendars,
                          String guid, String rid,
                          BwEvent master,
                          RecurringRetrievalMode recurRetrieval,
                          boolean masterOnly) throws CalFacadeException {
    HibSession sess = getSess();
    StringBuilder sb = new StringBuilder();
    final String qevName = "ev";
    BwDateTime startDate = null;
    BwDateTime endDate = null;

    /* SEG:   from Events ev where */
    sb.append("from ");
    sb.append(cl.getName());
    sb.append(" ");
    sb.append(qevName);
    sb.append(" where ");

    if (recurRetrieval != null) {
      startDate = recurRetrieval.start;
      endDate = recurRetrieval.end;
    }

    /* SEG:   (<date-ranges>) and */
    if (appendDateTerms(sb, qevName, startDate, endDate)) {
      sb.append(" and ");
    }

    if (master == null) {
      if (calendar != null) {
        sb.append(" ev.calendar=:cal and");
      }
      sb.append(" ev.uid=:uid ");
    } else {
      sb.append(" ev.master=:master ");
    }

    //boolean setUser = false;
    if (calendars != null) {
      sb.append(" and ((ev.calendar is null) or (ev.calendar in (:calendars))) ");
    //} else {
    //  sb.append(" and ");
    //  setUser = CalintfUtil.appendPublicOrOwnerTerm(sb, "ev",
    //                                                currentMode, false);
    }

    if (masterOnly) {
      sb.append(" and ev.recurrenceId is null ");
    } else if (rid != null) {
      sb.append(" and ev.recurrenceId=:rid ");
    }

    sess.createQuery(sb.toString());

    setDateTermValues(sess, startDate, endDate);

    if (master == null) {
      if (calendar != null) {
        sess.setEntity("cal", calendar);
      }
      sess.setString("uid", guid);
    } else {
      sess.setEntity("master", master);
    }

    if (calendars != null) {
      sess.setParameterList("calendars", calendars);
    //} else if (setUser) {
    //  sess.setEntity("user", getUser());
    }

    if (!masterOnly && (rid != null)) {
      sess.setString("rid", rid);
    }

    //debugMsg("Try query " + sb.toString());
  }

  private static class EventsQueryResult {
    /* BwEvent or event instances. */
    Collection es;
    Filters flt;

    /* Calendar clause fields */
    boolean empty;

    /* This is set to the calendars we should search. */
    Collection<BwCalendar> calendars;

    void reset() {
      es = null;
      flt = null;
      empty = true;
    }

    void addCalendar(BwCalendar cal) {
      if (calendars == null) {
        calendars = new ArrayList<BwCalendar>();
      }

      calendars.add(cal);
    }
  }

  // ENUM
  private static final int getEvents = 0;
  private static final int getAnnotations = 1;
  private static final int getOverrides = 2;
  private static final int getInstances = 3;

  private EventsQueryResult eventsQuery(BwCalendar calendar, BwFilter filter,
                                        BwDateTime startDate, BwDateTime endDate,
                                        int currentMode, boolean ignoreCreator,
                                        EventsQueryResult eqr,
                                        boolean freebusy,
                                        boolean allCalendars,
                                        BwEvent master,
                                        int getWhat) throws CalFacadeException {
    HibSession sess = getSess();
    StringBuilder sb = new StringBuilder();
    Class cl;
    /* Name of the event in the query */
    final String qevName = "ev";
    String qevNameMstr = qevName;

    if (getWhat == getInstances) {
      cl = BwRecurrenceInstance.class;
      qevNameMstr = qevName + ".master";
    } else if (getWhat == getAnnotations) {
      cl = BwEventAnnotation.class;
      qevNameMstr = qevName;
    } else if (getWhat == getOverrides) {
      cl = BwEventAnnotation.class;
      qevNameMstr = qevName;
    } else {
      cl = BwEventObj.class;
      qevNameMstr = qevName;
    }

    if (eqr == null) {
      eqr = new EventsQueryResult();
    }

    eqr.reset();

    eqr.flt = new Filters(filter, sb, qevNameMstr, qevName, debug);

    /* SEG:   from <class> ev where */
    sb.append("select ");
    sb.append(qevName);
    sb.append(" from ");
    sb.append(cl.getName());
    sb.append(" ");
    sb.append(qevName);

    eqr.flt.joinPass();

    sb.append(" where ");

    if (freebusy) {
      sb.append(qevNameMstr);
      sb.append(".endType <> '");
      sb.append(BwEvent.endTypeNone);
      sb.append("' and ");
    }

    /* SEG:   (<date-ranges>) and */
    if (appendDateTerms(sb, qevName, startDate, endDate)) {
      sb.append(" and ");
    }

    if ((getWhat == getEvents) &&
        ((startDate != null) || (endDate != null))) {
      /* Don't retrieve any recurrences master records if we have a date range.
       * We pick these up along with the instances that match the time range.
       */
      sb.append("(");
      sb.append(qevName);
      sb.append(".recurring = false or ");
      sb.append(qevName);
      sb.append(".recurring is null) and ");
    }

    if (getWhat == getInstances) {
      if (master != null) {
        // We're asking for all instances for this master
        sb.append("(");
        sb.append(qevName);
        sb.append(".master = :master) and ");
      } else {
        /* We are being called to pick up the master for instances within the
         * date range. If there is an override, either we already have it or it
         * was overriden somewhere else.
         */
        sb.append("(");
        sb.append(qevName);
        sb.append(".override is null) and ");
      }
    }

    /* SEG   (    */
    sb.append(" (");

    boolean setUser = buildCalendarSet(sb, qevNameMstr, calendar,
                                       currentMode, ignoreCreator,
                                       eqr, allCalendars);

    if (eqr.empty) {
      // No valid calendars to search.
      eqr.es = new TreeSet();
      return eqr;
    }

    emitCalendarClause(sb, qevNameMstr, eqr);

    sb.append(") ");

    /* We want to differentiate between annotations and overrides.
     * Overrides are annotations to a master event in the same calendar.
     * Annotations cannot be in the same calendar as their master.
     */
    /* Use the override flag
    if (getWhat == getAnnotations) {
      sb.append(" and (");
      sb.append(qevName);
      sb.append(".calendar<>");
      sb.append(qevName);
      sb.append(".master.calendar");
      sb.append(") ");
    } else if (getWhat == getOverrides) {
      sb.append(" and (");
      sb.append(qevName);
      sb.append(".calendar=");
      sb.append(qevName);
      sb.append(".master.calendar");
      sb.append(") ");
    }*/
    if (getWhat == getAnnotations) {
      sb.append(" and (");
      sb.append(qevName);
      sb.append(".override = false) ");
    } else if (getWhat == getOverrides) {
      sb.append(" and (");
      sb.append(qevName);
      sb.append(".override = true) ");
    }

    eqr.flt.addWhereFilters();

    sb.append(" order by ");
    sb.append(qevName);
    sb.append(".dtstart.date");

    if (debug) {
      trace(sb.toString());
    }

    sess.createQuery(sb.toString());

    /* XXX Limit result set size - pagination allows something like:
       query.setFirstResult(0);
       query.setMaxResults(10);
       */

    setDateTermValues(sess, startDate, endDate);

    if ((getWhat == getInstances) && (master != null)) {
      sess.setEntity("master", master);
    }

    doCalendarEntities(setUser, getUser(), eqr);

    eqr.flt.parPass(sess);

    if (debug) {
      trace(sess.getQueryString());
    }

    eqr.es = sess.getList();

    if (debug) {
      trace("Getting (" + getWhat +
            ") Found " + eqr.es.size() + " entries");
    }

    return eqr;
  }

  /* Return event recurrences within the given date range and calendar for
   * recurrent events which have been expanded.
   *
   * <p>All parameters may be null implying all events for this object.
   * Start or end or both may be null.<ul>
   * <li>startDate=null,endDate=null means all</li>
   * <li>startDate=null means all less than endDate</li>
   * <li>endDate=null means all including and after startDate</li>
   *
   * @param calendar     BwCalendar object restricting search or null.
   * @param filter       BwFilter object restricting search or null.
   * @param currentMode
   * @param ignoreCreator
   * @return Collection  of CoreEventInfo objects
   * @throws CalFacadeException
   */
  private Collection<CoreEventInfo> getRecurrences(BwEvent master, BwFilter filter,
                                                   int currentMode, boolean ignoreCreator,
                                                   RecurringRetrievalMode recurRetrieval,
                                                   boolean freeBusy,
                                                   boolean allCalendars)
          throws CalFacadeException {
    EventsQueryResult eqr = eventsQuery(master.getCalendar(), filter,
                                        recurRetrieval.start,
                                        recurRetrieval.end,
                                        currentMode, ignoreCreator, null,
                                        freeBusy, allCalendars,
                                        master, getInstances);

    /* We have a collection of recurrence instances, each of which has a
     * master event attached. For each unique master we should check it's
     * validity. We will maintain a table of ids we have checked and the result
     * so we only check once.
     *
     * We also handle the processing of the recurRetrieval parameter here.
     */

    CheckMap checked = new CheckMap();
    TreeSet<CoreEventInfo> ceis = new TreeSet<CoreEventInfo>();

    Iterator it = eqr.es.iterator();
    while (it.hasNext()) {
      BwRecurrenceInstance inst = (BwRecurrenceInstance)it.next();

      /* XXX should have a list of overrides that cover
       */
      CoreEventInfo cei = makeProxy(inst, null, checked, recurRetrieval,
                                    freeBusy);
      if (cei != null) {
        //if (debug) {
        //  debugMsg("Ev: " + proxy);
        //}
        ceis.add(cei);
      }
    }

    //if (debug) {
    //  debugMsg("recurrences after postexec " + evs.size());
    //}

    /** Run the events we got through the filters
     */
    return eqr.flt.postExec(ceis);
  }

  /* Append the calendar clauses. Return true if we have to set the user entity
   */
  private boolean buildCalendarSet(StringBuilder sb, String qevName,
                                   BwCalendar calendar,
                                   int currentMode, boolean ignoreCreator,
                                   EventsQueryResult eqr,
                                   boolean allCalendars) throws CalFacadeException {
    /* if no calendar set
          if public
            SEG: publicf=true
          else
            SEG: user=?
     */

    if (calendar == null) {
      // Doesn't count as empty
      eqr.empty = false;
      return CalintfUtil.appendPublicOrOwnerTerm(sb, qevName,
                          currentMode, ignoreCreator);
    }

    if (eqr.calendars != null) {
      // Built previously
      eqr.empty = false;
      return false;
    }

    if (calendar.getCalendarCollection()) {
      // Single leaf calendar - always include
      eqr.addCalendar(calendar);
      eqr.empty = false;
      return false;
    }

    // Non leaf - build a query
    appendCalendarSet(calendar, eqr, allCalendars);

    return false;
  }

  private void appendCalendarSet(BwCalendar calendar,
                                 EventsQueryResult eqr,
                                 boolean allCalendars) throws CalFacadeException {
    if (calendar.getCalendarCollection()) {
      /* It's a calendar collection - add if not 'special' or we're adding all
       */
      if (allCalendars || (calendar.getCalType() == BwCalendar.calTypeCollection)) {
        // leaf calendar
        eqr.addCalendar(calendar);
        eqr.empty = false;
      }

      return;
    }

    for (BwCalendar c: cb.getCalendars(calendar)) {
      appendCalendarSet(c, eqr, allCalendars);
    }
  }

  private void emitCalendarClause(StringBuilder sb, String qevName,
                                  EventsQueryResult eqr) {
    if (eqr.calendars == null) {
      return;
    }

    sb.append("(");
    for (int i = 0; i < eqr.calendars.size(); i++) {
      if (i > 0) {
        sb.append(" or ");
      }
      sb.append(qevName);
      sb.append(".calendar=:calendar" + i);
    }
    sb.append(") ");
  }

  private void doCalendarEntities(boolean setUser, BwUser user,
                                  EventsQueryResult eqr)
          throws CalFacadeException {
    HibSession sess = getSess();
    if (setUser) {
      sess.setEntity("user", user);
    }

    if (eqr.calendars == null) {
      return;
    }

    int i = 0;
    Iterator it = eqr.calendars.iterator();
    while (it.hasNext()) {
      BwCalendar cal = (BwCalendar)it.next();
      sess.setEntity("calendar" + i, unwrap(cal));
      i++;
    }
  }

  /** Check the master for access and if ok build and return an event
   * proxy.
   *
   * <p>If there is an override we don't need the instance. If there is no
   * override we create an annotation.
   *
   * <p>If checked is non-null will use and update the checked map.
   *
   * @param inst        May be null if we retrieved the override
   * @param override    May be null if we retrieved the instance
   * @param checked
   * @param recurRetrieval
   * @param freeBusy
   * @return CoreEventInfo
   * @throws CalFacadeException
   */
  private CoreEventInfo makeProxy(BwRecurrenceInstance inst,
                                  BwEventAnnotation override,
                                  CheckMap checked,
                                  RecurringRetrievalMode recurRetrieval,
                                  boolean freeBusy) throws CalFacadeException {
    BwEvent mstr;
    if (inst != null) {
      mstr = inst.getMaster();
    } else {
      mstr = override.getTarget();
    }

    //int res = 0;
    CurrentAccess ca = null;

    if (checked != null) {
      ca = checked.getca(mstr);
      if ((ca != null) && !ca.accessAllowed) {
        // failed
        return null;
      }
    }

    if ((recurRetrieval.mode == Rmode.masterOnly) &&
        (checked != null) && (ca != null)) {
      // Master only and we've already seen it - we don't want it again
      return null;
    }

    if ((checked == null) || (ca == null)) {
      // untested
      int desiredAccess = privRead;
      if (freeBusy) {
        desiredAccess = privReadFreeBusy;
      }
      ca = access.checkAccess(mstr, desiredAccess, returnResultAlways);
      if (checked != null) {
        checked.setChecked(mstr, ca);
      }

      if (!ca.accessAllowed) {
        return null;
      }
    }

    CalTimezones tzs = cb.getTimezonesHandler();

    if (recurRetrieval.mode == Rmode.masterOnly) {
      // Master only and we've just seen it for the first time
      // Note we will not do this for freebusy. We need all recurrences.

      /* XXX I think this was wrong. Why make an override?
       */
      // make a fake one pointing at the owners override
      override = new BwEventAnnotation();
      override.setTarget(mstr);
      override.setMaster(mstr);

      BwDateTime start = mstr.getDtstart();
      BwDateTime end = mstr.getDtend();

      override.setDtstart(start);
      override.setDtend(end);
      override.setDuration(BwDateTime.makeDuration(start, end, tzs).toString());
      override.setCreator(mstr.getCreator());
      override.setOwner(getUser());

      return new CoreEventInfo(new BwEventProxy(override), ca);
    }

    /* success so now we build a proxy with the event and any override.
     */

    if (override == null) {
      if (recurRetrieval.mode == Rmode.overrides) {
        // Master and overrides only
        return null;
      }

      /* DORECUR The instance could point to an overrride if the owner of the event
             changed an instance.
       */
      BwEventAnnotation instOverride = inst.getOverride();
      boolean newOverride = true;

      if (instOverride != null) {
//        if (instOverride.getOwner().equals(getUser())) {
          // It's our own override.
          override = instOverride;
          newOverride = false;
  //      } else {
    //      // make a fake one pointing at the owners override
      //    override = new BwEventAnnotation();
        //  override.setTarget(instOverride);
          //override.setMaster(instOverride);
        //}
      } else {
        // make a fake one pointing at the master event
        override = new BwEventAnnotation();

        override.setTarget(mstr);
        override.setMaster(mstr);
      }

      if (newOverride) {
        BwDateTime start = inst.getDtstart();
        BwDateTime end = inst.getDtend();

        override.setDtstart(start);
        override.setDtend(end);
        override.setDuration(BwDateTime.makeDuration(start, end, tzs).toString());
        override.setCreator(mstr.getCreator());
        override.setOwner(getUser());
        override.setOverride(true);
        override.setName(mstr.getName());
        override.setUid(mstr.getUid());

        override.setRecurrenceId(inst.getRecurrenceId());
      }
    }

    /* At this point we have an event with possible overrides. If this is free
     * busy we need to replace it all with a skeleton event holding only date/time
     * information.
     *
     * We can't do this before I think because we need to allow the user to
     * override the transparency on a particular instance,
     */

    BwEvent proxy = new BwEventProxy(override);

    if (freeBusy) {
      if (BwEvent.transparencyTransparent.equals(proxy.getTransparency())) {
        return null;
      }

      proxy = proxy.makeFreeBusyEvent();
    }

    return new CoreEventInfo(proxy, ca);
  }

  private static class CheckMap extends HashMap<Integer, CurrentAccess> {
    void setChecked(BwEvent ev, CurrentAccess ca) {
      put(ev.getId(), ca);
    }

    /* Return null for not found.
     */
    CurrentAccess getca(BwEvent ev) {
      return get(ev.getId());
    }
  }

  /* Just encapsulate the date restrictions.
   * If both dates are null just return. Otherwise return the appropriate
   * terms with the ids: <br/>
   * fromDate    -- first day
   * toDate      -- last day
   *
   * We build two near identical terms.
   *
   *   (floatFlag=true AND <drtest>) OR
   *   (floatFlag is null AND <drtest-utc>)
   *
   * where drtest uses the local from and to times and
   *       drtest-utc uses the utc from and to.
   *
   * @return boolean true if we appended something
   */
  private boolean appendDateTerms(StringBuilder sb,
                                  String evname,
                                  BwDateTime from, BwDateTime to) {
    if ((from == null) && (to == null)) {
      return false;
    }

    sb.append("(");
    appendDrtestTerms(true, sb, evname, from, to);
    sb.append(" or ");
    appendDrtestTerms(false, sb, evname, from, to);
    sb.append(")");

    return true;
  }

  private void appendDrtestTerms(boolean floatingTest,
                                 StringBuilder sb,
                                 String evname,
                                 BwDateTime from, BwDateTime to) {
    String startField = evname + ".dtstart.date";
    String endField = evname + ".dtend.date";

    String startFloatTest;
    String endFloatTest;
    String toVal;
    String fromVal;

    if (floatingTest) {
      startFloatTest = evname + ".dtstart.floatFlag=true and ";
      endFloatTest = evname + ".dtend.floatFlag=true and ";
      toVal = "toFltDate";
      fromVal = "fromFltDate";
    } else {
      startFloatTest = evname + ".dtstart.floatFlag is null and ";
      endFloatTest = evname + ".dtend.floatFlag is null and ";
      toVal = "toDate";
      fromVal = "fromDate";
    }

    /* Note that the comparisons below are required to ensure that the
     *  start date is inclusive and the end date is exclusive.
     * From CALDAV:
     * A VEVENT component overlaps a given time-range if:
     *
     * (DTSTART <= start AND DTEND > start) OR
     * (DTSTART <= start AND DTSTART+DURATION > start) OR
     * (DTSTART >= start AND DTSTART < end) OR
     * (DTEND   > start AND DTEND < end)
     *
     *  case 1 has the event starting between the dates.
     *  case 2 has the event ending between the dates.
     *  case 3 has the event starting before and ending after the dates.
     */

    if (from == null) {
      sb.append("(");
      sb.append(startFloatTest);

      sb.append(startField);
      sb.append(" < :");
      sb.append(toVal);
      sb.append(")");
      return;
    }

    if (to == null) {
      sb.append("(");
      sb.append(endFloatTest);

      sb.append(endField);
      sb.append(" >= :");
      sb.append(fromVal);
      sb.append(")");
      return;
    }

    sb.append("(");
    sb.append(startFloatTest); // XXX Inadequate?? - should check each field separately?
    sb.append("(");

    sb.append(startField);
    sb.append(" < :");
    sb.append(toVal);
    sb.append(") and ((");

    sb.append(endField);
    sb.append(" > :");
    sb.append(fromVal);
    sb.append(") or ((");

    sb.append(startField);
    sb.append("=");
    sb.append(endField);
    sb.append(") and (");
    sb.append(endField);
    sb.append(" >= :");
    sb.append(fromVal);
    sb.append("))))");

    /*
    ((start < to) and ((end > from) or
      ((start = end) and (end >= from))))
     */
  }

  private void setDateTermValues(HibSession sess,
                                 BwDateTime startDate,
                                 BwDateTime endDate) throws CalFacadeException {
    if (startDate != null) {
      sess.setString("fromDate", startDate.getDate());
      sess.setString("fromFltDate", makeUtcformat(startDate.getDtval()));
    }

    if (endDate != null) {
      sess.setString("toDate", endDate.getDate());
      sess.setString("toFltDate", makeUtcformat(endDate.getDtval()));
    }
  }

  private String makeUtcformat(String dt) {
    int len = dt.length();

    if (len == 16) {
      return dt;
    }

    if (len == 15) {
      return dt + "Z";
    }

    if (len == 8) {
      return dt + "T000000Z";
    }

    try {
      getSess().rollback();
    } catch (Throwable t) {}
    throw new RuntimeException("Bad date " + dt);
  }

  /*
  private int deleteAlarms(BwEvent ev) throws CalFacadeException {
    HibSession sess = getSess();
    sess.namedQuery("deleteEventAlarms");
    sess.setEntity("ev", ev);

    return sess.executeUpdate();
  }*/

  private Collection<CoreEventInfo> postGetEvents(Collection evs,
                                                  int desiredAccess,
                                                  boolean nullForNoAccess)
          throws CalFacadeException {
    TreeSet<CoreEventInfo> outevs = new TreeSet<CoreEventInfo>();

    Iterator it = evs.iterator();

    while (it.hasNext()) {
      BwEvent ev = (BwEvent)it.next();

      CoreEventInfo cei = postGetEvent(ev, desiredAccess, nullForNoAccess);

      if (cei != null) {
        outevs.add(cei);
      }
    }

    return outevs;
  }

  /* Post processing of event. Return null or throw exception for no access
   */
  private CoreEventInfo postGetEvent(BwEvent ev, int desiredAccess,
                                     boolean nullForNoAccess) throws CalFacadeException {
    if (ev == null) {
      return null;
    }

    CurrentAccess ca = access.checkAccess(ev, desiredAccess, nullForNoAccess);

    if (!ca.accessAllowed) {
      return null;
    }

    /* XXX-ALARM
    if (currentMode == userMode) {
      ev.setAlarms(getAlarms(ev, user));
    }
    */

    if (ev instanceof BwEventAnnotation) {
      ev = new BwEventProxy((BwEventAnnotation)ev);
    }

    CoreEventInfo cei = new CoreEventInfo(ev, ca);

    return cei;
  }

  private Collection<CoreEventInfo> makeFreeBusy(Collection<CoreEventInfo> ceis)
          throws CalFacadeException {
    TreeSet<CoreEventInfo> outevs = new TreeSet<CoreEventInfo>();

    for (CoreEventInfo cei: ceis) {
      BwEvent ev = cei.getEvent();
      if (BwEvent.transparencyTransparent.equals(ev.getTransparency())) {
        continue;
      }

      if (debug) {
        debugMsg(ev.toString());
      }

      cei.setEvent(ev.makeFreeBusyEvent());
      outevs.add(cei);
    }

    return outevs;
  }

  private class RecuridTable extends HashMap<String, BwEventProxy> {
    RecuridTable(Collection<BwEventProxy> events) {
      for (BwEventProxy ev: events) {
        String rid = ev.getRecurrenceId();
        if (debug) {
          debugMsg("Add override to table with recurid " + rid);
        }

        put(rid, ev);
      }
    }
  }

  /* Ensure the calendar object is unwrapped. Wrapped entities will occur
   * when adding an event or changing the calendar.
   */
  private void ensureUnwrappedCalendar(BwEvent val) throws CalFacadeException {
    BwCalendar cal = val.getCalendar();
    if (cal instanceof CoreCalendarWrapper) {
      val.setCalendar(unwrap(cal));
    }
  }

  private void throwException(String pname) throws CalFacadeException {
    getSess().rollback();
    throw new CalFacadeException(pname);
  }

  private void throwException(String pname, String extra) throws CalFacadeException {
    getSess().rollback();
    throw new CalFacadeException(pname, extra);
  }
}
