/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calcore.hibernate;

import org.bedework.calcore.AccessUtil;
import org.bedework.calcorei.CalendarsI;
import org.bedework.calcorei.HibSession;
import org.bedework.calfacade.BwCalendar;
import org.bedework.calfacade.BwSystem;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.exc.CalFacadeException;

import edu.rpi.cmt.access.Ace;
import edu.rpi.cmt.access.AceWho;
import edu.rpi.cmt.access.Acl.CurrentAccess;

import java.util.Collection;
import java.util.TreeSet;

/** Class to encapsulate most of what we do with calendars
 *
 * @author Mike Douglass   douglm - rpi.edu
 */
class Calendars extends CalintfHelperHib implements CalendarsI {
  private String publicCalendarRootPath;
  private String userCalendarRootPath;

  /** Constructor
   *
   * @param hsf
   * @param cb
   * @param access
   * @param currentMode
   * @param debug
   * @throws CalFacadeException
   */
  public Calendars(HibSessionFetcher hsf, Callback cb, AccessUtil access,
                   int currentMode, boolean debug)
                  throws CalFacadeException {
    super(hsf);
    super.init(cb, access, currentMode, debug);

    publicCalendarRootPath = "/" + getSyspars().getPublicCalendarRoot();
    userCalendarRootPath = "/" + getSyspars().getUserCalendarRoot();
  }

  /** Called after a user has been added to the system.
   *
   * @param user
   * @throws CalFacadeException
   */
  public void addNewCalendars(BwUser user) throws CalFacadeException {
    HibSession sess = getSess();

    /* Add a user collection to the userCalendarRoot and then a default
       calendar collection. */

    sess.namedQuery("getCalendarByPath");

    String path =  userCalendarRootPath;
    sess.setString("path", path);

    BwCalendar userrootcal = (BwCalendar)sess.getUnique();

    if (userrootcal == null) {
      throw new CalFacadeException("No user root at " + path);
    }

    BwCalendar parentCal = userrootcal;
    BwCalendar usercal = null;

    /* We may have a principal e.g. /principals/resources/vcc311
     * All except the last may exist already.
     */
    String[] upath = user.getAccountSplit();

    for (int i = 0; i < upath.length; i++) {
      String pathSeg = upath[i];

      if ((pathSeg == null) || (pathSeg.length() == 0)) {
        // Leading or double slash - skip it
        continue;
      }

      path += "/" + pathSeg;
      sess.namedQuery("getCalendarByPath");
      sess.setString("path", path);

      usercal = (BwCalendar)sess.getUnique();
      if (i == upath.length - 1) {
        if (usercal != null) {
          throw new CalFacadeException("User calendar already exists at " + path);
        }

        /* Create a folder for the user */
        usercal = new BwCalendar();
        usercal.setName(pathSeg);
        usercal.setCreator(user);
        usercal.setOwner(user);
        usercal.setPublick(false);
        usercal.setPath(path);
        usercal.setCalendar(parentCal);

        parentCal.addChild(usercal);

        sess.save(parentCal);
      } else {
        if (usercal == null) {
          /* Create a new system owned folder for part of the principal
           * hierarchy
           */
          usercal = new BwCalendar();
          usercal.setName(pathSeg);
          usercal.setCreator(userrootcal.getCreator());
          usercal.setOwner(userrootcal.getOwner());
          usercal.setPublick(false);
          usercal.setPath(path);
          usercal.setCalendar(parentCal);

          parentCal.addChild(usercal);

          sess.save(parentCal);
        }
      }

      parentCal = usercal;
    }

    /* Create a default calendar */
    BwCalendar cal = new BwCalendar();
    cal.setName(getSyspars().getUserDefaultCalendar());
    cal.setCreator(user);
    cal.setOwner(user);
    cal.setPublick(false);
    cal.setPath(path + "/" + getSyspars().getUserDefaultCalendar());
    cal.setCalendar(usercal);
    cal.setCalendarCollection(true);
    cal.setCalType(BwCalendar.calTypeCollection);

    usercal.addChild(cal);

    sess.save(usercal);

    sess.update(user);
  }

  /** Mark calendar as modified
  *
  * @param  val     BwCalendar object
  * @throws CalFacadeException
  */
  public void touchCalendar(BwCalendar val) throws CalFacadeException {
    val = unwrap(val);
    val.updateLastmod();

    // CALWRAPPER - if we're not cloning can we avoid this?
    //val = (BwCalendar)getSess().merge(val);

    val = (BwCalendar)getSess().merge(val);
    getSess().update(val);
  }

  /* ====================================================================
   *                   CalendarsI methods
   * ==================================================================== */

  public BwCalendar getPublicCalendars() throws CalFacadeException {
    HibSession sess = getSess();

    sess.namedQuery("getCalendarByPath");
    sess.setString("path", publicCalendarRootPath);
    sess.cacheableQuery();

    return checkAccess((BwCalendar)sess.getUnique(),
                       privRead, returnResultAlways);
  }

  @SuppressWarnings("unchecked")
  public Collection<BwCalendar> getPublicCalendarCollections() throws CalFacadeException {
    HibSession sess = getSess();

    sess.namedQuery("getPublicCalendarCollections");
    sess.cacheableQuery();

    return postGet(sess.getList(), privWrite);
  }

  public BwCalendar getCalendars() throws CalFacadeException {
    return getCalendars(getUser(), privRead);
  }

  public BwCalendar getCalendars(BwUser user,
                                 int desiredAccess) throws CalFacadeException {
    HibSession sess = getSess();

    sess.namedQuery("getCalendarByPath");
    sess.setString("path", userCalendarRootPath + "/" + user.getAccountNoSlash());
    sess.cacheableQuery();

    return checkAccess((BwCalendar)sess.getUnique(),
                       desiredAccess, returnResultAlways);
  }

  public Collection<BwCalendar> getCalendars(BwCalendar cal) throws CalFacadeException {
    cal = unwrap(cal);

//    HibSession sess = getSess();
//    sess.reAttach(cal);

    if (!cal.hasChildren()) {
      return new TreeSet<BwCalendar>();
    }

    return checkAccess(cal.getChildren(), privAny, true);
  }

  @SuppressWarnings("unchecked")
  public Collection<BwCalendar> getCalendarCollections() throws CalFacadeException {
    HibSession sess = getSess();

    sess.namedQuery("getUserCalendarCollections");
    sess.setEntity("owner", getUser());
    sess.cacheableQuery();

    return postGet(sess.getList(), privWrite);
  }

  public Collection<BwCalendar> getAddContentPublicCalendarCollections()
          throws CalFacadeException {
    Collection<BwCalendar> cals = new TreeSet<BwCalendar>();

    getAddContentCalendarCollections(getPublicCalendars(), cals);

    return cals;
    /*
    HibSession sess = getSess();

    sess.namedQuery("getPublicCalendarCollections");
    sess.cacheableQuery();

    return checkAccess(sess.getList(), privWriteContent, returnResultAlways);
    */
  }

  private void getAddContentCalendarCollections(BwCalendar root,
                                                Collection<BwCalendar> cals)
        throws CalFacadeException {
    if (checkAccess(root, privRead, returnResultAlways) == null) {
      // No access
      return;
    }

    if (root.getCalType() == BwCalendar.calTypeCollection) {
      if (checkAccess(root, privWriteContent, returnResultAlways) != null) {
        cals.add(root);
      }

      return;
    }

    if (root.getCalendarCollection()) {
      // Leaf but cannot add here
      return;
    }

    root = unwrap(root);
    Collection<BwCalendar> chs = root.getChildren();
    for (BwCalendar ch: chs) {
      getAddContentCalendarCollections(ch, cals);
    }
  }


  @SuppressWarnings("unchecked")
  public Collection<BwCalendar> getAddContentCalendarCollections()
          throws CalFacadeException {
    Collection<BwCalendar> cals = new TreeSet<BwCalendar>();

    getAddContentCalendarCollections(getCalendars(), cals);

    return cals;
    /*
    HibSession sess = getSess();

    sess.namedQuery("getUserCalendarCollections");
    sess.setEntity("owner", getUser());
    sess.cacheableQuery();

    return checkAccess(sess.getList(), privWriteContent, returnResultAlways);
    */
  }

  public BwCalendar getCalendar(int val) throws CalFacadeException {
    HibSession sess = getSess();

    sess.namedQuery("getCalendarById");
    sess.setInt("id", val);
    sess.cacheableQuery();

    return checkAccess((BwCalendar)sess.getUnique(), privRead, false);
  }

  public BwCalendar getCalendar(String path,
                                int desiredAccess) throws CalFacadeException {
    HibSession sess = getSess();

    sess.namedQuery("getCalendarByPath");
    sess.setString("path", path);
    sess.cacheableQuery();

    return checkAccess((BwCalendar)sess.getUnique(), desiredAccess, false);
  }

  public String getDefaultCalendarPath(BwUser user) throws CalFacadeException {
    StringBuilder sb = new StringBuilder();

    sb.append("/");
    sb.append(getSyspars().getUserCalendarRoot());
    sb.append("/");
    sb.append(user.getAccountNoSlash());
    sb.append("/");
    sb.append(getSyspars().getUserDefaultCalendar());

    return sb.toString();
  }

  public String getUserRootPath(BwUser user) throws CalFacadeException {
    StringBuilder sb = new StringBuilder();

    sb.append("/");
    sb.append(getSyspars().getUserCalendarRoot());
    sb.append("/");
    sb.append(user.getAccountNoSlash());

    return sb.toString();
  }

  public GetSpecialCalendarResult getSpecialCalendar(BwUser user,
                                                     int calType,
                                                     boolean create,
                                                     int access) throws CalFacadeException {
    StringBuilder sb = new StringBuilder();
    String name;
    BwSystem sys = getSyspars();

    if (calType == BwCalendar.calTypeBusy) {
      name = sys.getBusyCalendar();
    } else if (calType == BwCalendar.calTypeDeleted) {
      name = sys.getDeletedCalendar();
    } else if (calType == BwCalendar.calTypeInbox) {
      name = sys.getUserInbox();
    } else if (calType == BwCalendar.calTypeOutbox) {
      name = sys.getUserOutbox();
    } else if (calType == BwCalendar.calTypeTrash) {
      name = sys.getDefaultTrashCalendar();
    } else {
      // Not supported
      return null;
    }

    sb.append(userCalendarRootPath);
    sb.append("/");
    sb.append(user.getAccountNoSlash());

    String pathTo = sb.toString();

    sb.append("/");
    sb.append(name);

    GetSpecialCalendarResult gscr = new GetSpecialCalendarResult();

    gscr.cal = getCalendar(sb.toString(), access);

    if ((gscr.cal != null) || !create) {
      return gscr;
    }

    /*
    BwCalendar parent = getCalendar(pathTo, privRead);

    if (parent == null) {
      throw new CalFacadeException("org.bedework.calcore.calendars.unabletocreate");
    }
    */

    gscr.cal = new BwCalendar();
    gscr.cal.setName(name);
    gscr.cal.setCreator(user);
    gscr.cal.setOwner(user);
    gscr.cal.setCalendarCollection(true);
    gscr.cal.setCalType(calType);
    gscr.cal = addCalendar(gscr.cal, pathTo, privNone);
    gscr.created = true;

    return gscr;
  }

  public BwCalendar addCalendar(BwCalendar val,
                                String parentPath) throws CalFacadeException {
    return addCalendar(val, parentPath, privBind);
  }

  private BwCalendar addCalendar(BwCalendar val,
                                String parentPath,
                                int access) throws CalFacadeException {
    HibSession sess = getSess();

    BwCalendar parent = getCalendar(parentPath, access);
    if (parent == null) {
      throw new CalFacadeException("org.bedework.error.nosuchcalendarpath",
                                   parentPath);
    }

    // XXX We might relax this following check to allow non-calendar collections
    // inside a calendar collection.

    /** Is the parent a calendar collection?
     */
    if (parent.getCalendarCollection()) {
      throw new CalFacadeException(CalFacadeException.illegalCalendarCreation);
    }

    /* Ensure the new path is unique */
    String path = parent.getPath() + "/" + val.getName();

    sess.namedQuery("getCalendarByPath");
    sess.setString("path", path);

    if (sess.getUnique() != null) {
      throw new CalFacadeException(CalFacadeException.duplicateCalendar);
    }

    val.setPath(path);
    if (val.getOwner() == null) {
      val.setOwner(getUser());
    }

    parent = unwrap(parent);

    val.setCalendar(parent);
    val.setPublick(parent.getPublick());
    val.updateLastmod();

    parent.addChild(val);

    sess.update(parent);

    return checkAccess(val, privAny, true);
  }

  public void renameCalendar(BwCalendar val,
                             String newName) throws CalFacadeException {
    val = unwrap(val);

    /* update will check access
     */

    BwCalendar parent = val.getCalendar();

    val.setName(newName);

    /* This triggers off a cascade of updates down the tree as we are storing the
     * path in the calendar objects. This may be prefereable to calculating the
     * path at every access
     */
    updatePaths(val, parent);
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.CalendarsI#moveCalendar(org.bedework.calfacade.BwCalendar, org.bedework.calfacade.BwCalendar)
   */
  public void moveCalendar(BwCalendar val,
                           BwCalendar newParent) throws CalFacadeException {
    val = unwrap(val);
    newParent = unwrap(newParent);

    /* check access - privbind on new parent privunbind on val?
     */
    access.checkAccess(val, privUnbind, false);
    access.checkAccess(newParent, privBind, false);

    if (newParent.getCalType() != BwCalendar.calTypeFolder) {
      throw new CalFacadeException(CalFacadeException.illegalCalendarCreation);
    }

    BwCalendar oldParent = val.getCalendar();
    oldParent.removeChild(val);

    val.setCalendar(newParent);
    newParent.addChild(val);

//    updateCalendar(oldParent);
//    updateCalendar(newParent);

    /* This triggers off a cascade of updates down the tree as we are storing the
     * path in the calendar objects. This may be preferable to calculating the
     * path at every access
     */
    updatePaths(val, newParent);
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.CalendarsI#updateCalendar(org.bedework.calfacade.BwCalendar)
   */
  public void updateCalendar(BwCalendar val) throws CalFacadeException {
    val = unwrap(val);

    access.checkAccess(val, privWriteProperties, false);

    // CALWRAPPER - did I need this?
    //val = (BwCalendar)getSess().merge(val);

    val = (BwCalendar)getSess().merge(val);
    getSess().update(val);
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.CalendarsI#changeAccess(org.bedework.calfacade.BwCalendar, java.util.Collection)
   */
  public void changeAccess(BwCalendar cal,
                           Collection<Ace> aces,
                           boolean replaceAll) throws CalFacadeException {
    HibSession sess = getSess();

    cal = unwrap(cal);

    try {
      access.checkAccess(cal, privWriteAcl, false);
    } catch (CalFacadeException cfe) {
      sess.rollback();
      throw cfe;
    }

    access.changeAccess(cal, aces, replaceAll);
    sess.saveOrUpdate(cal);
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.CalendarsI#defaultAccess(org.bedework.calfacade.BwCalendar, edu.rpi.cmt.access.AceWho)
   */
  public void defaultAccess(BwCalendar cal,
                            AceWho who) throws CalFacadeException {
    HibSession sess = getSess();

    cal = unwrap(cal);

    access.defaultAccess(cal, who);
    sess.saveOrUpdate(cal);
  }

  public boolean deleteCalendar(BwCalendar val) throws CalFacadeException {
    HibSession sess = getSess();

    val = unwrap(val);

    try {
      access.checkAccess(val, privUnbind, false);
    } catch (CalFacadeException cfe) {
      sess.rollback();
      throw cfe;
    }

    BwCalendar parent = val.getCalendar();
    if (parent == null) {
      throw new CalFacadeException(CalFacadeException.cannotDeleteCalendarRoot);
    }

    /* Ensure the parent exists and we have writeContent on the parent.
     */
    parent = getCalendar(parent.getPath(), privWriteContent);
    if (parent == null) {
      throw new CalFacadeException(CalFacadeException.calendarNotFound);
    }

    parent = unwrap(parent);

    val = getCalendar(val.getPath(), privUnbind);
    if (val == null) {
      throw new CalFacadeException(CalFacadeException.calendarNotFound);
    }

    if (val.hasChildren()) {
      throw new CalFacadeException(CalFacadeException.calendarNotEmpty);
    }

    parent.removeChild(val);
    sess.update(parent);

    return true;
  }

  public boolean checkCalendarRefs(BwCalendar val) throws CalFacadeException {
    HibSession sess = getSess();

    sess.namedQuery("countCalendarEventRefs");
    sess.setEntity("cal", unwrap(val));

    Integer res = (Integer)sess.getUnique();

    if (debug) {
      trace(" ----------- count = " + res);
    }

    if (res == null) {
      return false;
    }

    return res.intValue() > 0;
  }

  /* ====================================================================
   *                   Private methods
   * ==================================================================== */

  private void updatePaths(BwCalendar val,
                           BwCalendar newParent) throws CalFacadeException {
    val.setPath(newParent.getPath() + "/" + val.getName());
    //updateCalendar(val);

    for (BwCalendar ch: getCalendars(val)) {
      updatePaths(ch, val);
    }
  }

  /* Return a Collection of the calendars after checking access
   *
   */
  private Collection<BwCalendar> postGet(Collection<BwCalendar> cals,
                                         int desiredAccess)
             throws CalFacadeException {
    TreeSet<BwCalendar> out = new TreeSet<BwCalendar>();

    for (BwCalendar cal: cals) {
      cal = checkAccess(cal, desiredAccess, returnResultAlways);
      if (cal != null) {
        out.add(cal);
      }
    }

    return out;
  }

  /** Return a Collection of the objects after checking access and wrapping
   *
   * @param ents          Collection of Bwcalendar
   * @param desiredAccess access we want
   * @param nullForNoAccess boolean flag behaviour on no access
   * @return Collection   of checked objects
   * @throws CalFacadeException for no access or other failure
   */
  private Collection<BwCalendar> checkAccess(Collection<BwCalendar> ents,
                                             int desiredAccess,
                                             boolean nullForNoAccess)
          throws CalFacadeException {
    TreeSet<BwCalendar> out = new TreeSet<BwCalendar>();
    if (ents == null) {
      return out;
    }

    for (BwCalendar cal: ents) {
      cal = checkAccess(cal, desiredAccess, nullForNoAccess);
      if (cal != null) {
        out.add(cal);
      }
    }

    return out;
  }

  private BwCalendar checkAccess(BwCalendar cal, int desiredAccess,
                                 boolean alwaysReturnResult)
          throws CalFacadeException {
    if (cal == null) {
      return null;
    }

    boolean noAccessNeeded = desiredAccess == privNone;
    CurrentAccess ca = access.checkAccess(cal, desiredAccess,
                                          alwaysReturnResult || noAccessNeeded);

    if (!noAccessNeeded && !ca.accessAllowed) {
      return null;
    }

    cal = wrap(cal);
    cal.setCurrentAccess(ca);

    return cal;
  }
}
