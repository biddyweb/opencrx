/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calcore;

import edu.rpi.cmt.access.Access;
import edu.rpi.cmt.access.Ace;
import edu.rpi.cmt.access.AceWho;
import edu.rpi.cmt.access.Acl;
import edu.rpi.cmt.access.PrivilegeSet;
import edu.rpi.cmt.access.Acl.CurrentAccess;

import org.bedework.calfacade.base.BwShareableContainedDbentity;
import org.bedework.calfacade.base.BwShareableDbentity;
import org.bedework.calfacade.exc.CalFacadeAccessException;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.util.AccessUtilI;
import org.bedework.calfacade.BwCalendar;
import org.bedework.calfacade.BwCategory;
import org.bedework.calfacade.BwLocation;
import org.bedework.calfacade.BwContact;
import org.bedework.calfacade.BwSystem;
import org.bedework.calfacade.BwUser;

import org.apache.log4j.Logger;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.TreeSet;

/** An access helper class. This class makes some assumptions about the
 * classes it deals with but there is no explicit hibernate, or other
 * persistance engine, dependencoes.
 *
 * <p>It assumes that t has access to the parent object when needed,
 * continuing on up to the root. For systems which do not allow for a
 * retrieval of the parent on calls to the getCalendar method, the getParent
 * method for this class will need to be overridden. This would presumably
 * take place within the core implemnentation.
 *
 *
 * @author Mike Douglass   douglm@rpi.edu
 */
public class AccessUtil implements AccessUtilI {
  private boolean debug;

  /** For evaluating access control
   */
  private Access access;

  private boolean superUser;

  private BwUser authUser;

  private BwSystem syspars;

  private String userRootPath;

  private String userHomePathPrefix;

  private transient Logger log;

  /* Information created and saved about access on a given path.
   */
  private class PathInfo implements Serializable {
    String path;   // The key
    Acl pathAcl;   // Merged acl for the path.
    char[] encoded;
  }

  private static class PathInfoMap extends HashMap<String, PathInfo> {
    synchronized PathInfo getInfo(String path) {
      return (PathInfo)get(path);
    }

    synchronized void putInfo(String path, PathInfo pi) {
      put(path, pi);
    }

    synchronized void flush() {
      clear();
    }
  }

  private PathInfoMap pathInfoMap = new PathInfoMap();

  /**
   *
   * @param debug
   * @throws CalFacadeException
   */
  public void init(boolean debug) throws CalFacadeException {
    this.debug = debug;
    try {
      access = new Access(debug);
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /** Indicate if we are in superuser mode.
   * @param val
   */
  public void setSuperUser(boolean val) {
    superUser = val;
  }

  /**
   * @return boolean
   */
  public boolean getSuperUser() {
    return superUser;
  }

  /** Set the current authenticated user.
   *
   * @param val
   */
  public void setAuthUser(BwUser val) {
    authUser = val;
  }

  /** Called at request start
   *
   */
  public void open() {
  }

  /** Called at request end
   *
   */
  public void close() {
  }

  /** Set the system parameters object.
   * @param val
   */
  public void setSyspars(BwSystem val) {
    syspars = val;

    userRootPath = "/" + syspars.getUserCalendarRoot();
    userHomePathPrefix = userRootPath + "/";
  }

  /** Called to get the parent object for a shared entity. This method should be
   * overriden if explicit calls to the back end calendar are required.
   *
   * @param val
   * @return parent calendar or null.
   */
  public BwCalendar getParent(BwShareableContainedDbentity<?> val) {
    return val.getCalendar();
  }

  /* ====================================================================
   *                   Access control
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calcorei.AccessUtilI#getDefaultPublicAccess()
   */
  public String getDefaultPublicAccess() {
    return Access.getDefaultPublicAccess();
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.AccessUtilI#getDefaultPersonalAccess()
   */
  public String getDefaultPersonalAccess() {
    return Access.getDefaultPersonalAccess();
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.AccessUtilI#changeAccess(org.bedework.calfacade.base.BwShareableDbentity, java.util.Collection, boolean)
   */
  public void changeAccess(BwShareableDbentity<?> ent,
                           Collection<Ace> aces,
                           boolean replaceAll) throws CalFacadeException {
    try {
      Acl acl = checkAccess(ent, privWriteAcl, false).acl;

      if (replaceAll) {
        acl = new Acl();
      }

      /* Now add the access */
      for (Ace ace: aces) {
        acl.addAce(ace);
      }

      ent.setAccess(acl.encodeStr());

      pathInfoMap.flush();
    } catch (CalFacadeException cfe) {
      throw cfe;
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.AccessUtilI#defaultAccess(org.bedework.calfacade.base.BwShareableDbentity, edu.rpi.cmt.access.AceWho)
   */
  public void defaultAccess(BwShareableDbentity<?> ent,
                            AceWho who) throws CalFacadeException {
    try {
      Acl acl = checkAccess(ent, privWriteAcl, false).acl;

      /* Now remove any access */

      acl.removeWho(who);

      ent.setAccess(acl.encodeStr());

      pathInfoMap.flush();
    } catch (CalFacadeException cfe) {
      throw cfe;
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.AccessUtilI#checkAccess(java.util.Collection, int, boolean)
   */
  public Collection<? extends BwShareableDbentity<?>>
                checkAccess(Collection<? extends BwShareableDbentity<?>> ents,
                                int desiredAccess,
                                boolean alwaysReturn)
          throws CalFacadeException {
    TreeSet<BwShareableDbentity<?>> out = new TreeSet<BwShareableDbentity<?>>();

    for (BwShareableDbentity<?> sdbe: ents) {
      if (checkAccess(sdbe, desiredAccess, alwaysReturn).accessAllowed) {
        out.add(sdbe);
      }
    }

    return out;
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.AccessUtilI#checkAccess(org.bedework.calfacade.base.BwShareableDbentity, int, boolean)
   */
  public CurrentAccess checkAccess(BwShareableDbentity<?> ent,
                                   int desiredAccess,
                        boolean alwaysReturnResult) throws CalFacadeException {
    if (ent == null) {
      return null;
    }

    if (debug) {
      String cname = ent.getClass().getName();
      String ident;
      if (ent instanceof BwCalendar) {
        ident = ((BwCalendar)ent).getPath();
      } else {
        ident = String.valueOf(ent.getId());
      }
      getLog().debug("Check access for object " +
                     cname.substring(cname.lastIndexOf(".") + 1) +
                     " ident=" + ident);
    }

    try {
      CurrentAccess ca = null;

      String account = ent.getOwner().getAccount();
      PrivilegeSet maxPrivs = null;

      char[] aclChars = null;

      if (ent instanceof BwCalendar) {
        BwCalendar cal = (BwCalendar)ent;
        String path = cal.getPath();

        /* Special case the access to the user root e.g /user and
         * the 'home' directory, e.g. /user/douglm
         */

        /* I think this was wrong. For superuser we want to see the real
         * access but they are going to be allowed access whatever.
        if (userRootPath.equals(path)) {
          ca = new CurrentAccess();

          if (getSuperUser()) {
            ca.privileges = PrivilegeSet.makeDefaultOwnerPrivileges();
          } else {
            ca.privileges = PrivilegeSet.makeDefaultNonOwnerPrivileges();
          }
        } else if (path.equals(userHomePathPrefix + account)){
          // Accessing user home directory
          if (getSuperUser()) {
            ca = new CurrentAccess();

            ca.privileges = PrivilegeSet.makeDefaultOwnerPrivileges();
          } else {
            // Set the maximumn access
            maxPrivs = PrivilegeSet.userHomeMaxPrivileges;
          }
        }
         */
        if (!getSuperUser()) {
          if (userRootPath.equals(path)) {
            ca = new CurrentAccess();

            ca.privileges = PrivilegeSet.makeDefaultNonOwnerPrivileges();
          } else if (path.equals(userHomePathPrefix + account)){
            // Accessing user home directory
            // Set the maximumn access
            maxPrivs = PrivilegeSet.userHomeMaxPrivileges;
          }
        }
      }

      if (ca == null) {
        /* Not special. getAclChars provides merged access for the current
         * entity.
         */
        aclChars = getAclChars(ent);

        if (desiredAccess == privAny) {
          ca = access.checkAny(authUser, account, aclChars, maxPrivs);
        } else if (desiredAccess == privRead) {
          ca = access.checkRead(authUser, account, aclChars, maxPrivs);
        } else if (desiredAccess == privWrite) {
          ca = access.checkReadWrite(authUser, account, aclChars, maxPrivs);
        } else {
          ca = access.evaluateAccess(authUser, account, desiredAccess, aclChars,
                                     maxPrivs);
        }
      }

      if ((authUser != null) && superUser) {
        // Nobody can stop us - BWAAA HAA HAA
        if (debug && !ca.accessAllowed) {
          getLog().debug("Override for superuser");
        }
        ca.accessAllowed = true;
      }

      if (!ca.accessAllowed && !alwaysReturnResult) {
        throw new CalFacadeAccessException();
      }

      return ca;
    } catch (CalFacadeException cfe) {
      throw cfe;
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /* ====================================================================
   *                   Private methods
   * ==================================================================== */

  /* If the entity is not a calendar we merge the access in with the container
   * access then return the merged aces.
   *
   * For a calendar we just use the access for the calendar.
   *
   * The calendar/container access might be cached in the pathInfoTable.
   */
  private char[] getAclChars(BwShareableDbentity<?> ent) throws CalFacadeException {
    if (ent instanceof BwShareableContainedDbentity) {
      BwCalendar container;

      if (ent instanceof BwCalendar) {
        container = (BwCalendar)ent;
      } else {
        container = getParent((BwShareableContainedDbentity<?>)ent);
      }

      String path = container.getPath();
      PathInfo pi = pathInfoMap.getInfo(path);

      if (pi == null) {
        /* Get path info object with acls merged to the root.
         */
        pi = getPathInfo(container);
        pathInfoMap.putInfo(path, pi);
      }

      char[] aclChars = pi.encoded;

      if (ent instanceof BwCalendar) {
        return aclChars;
      }

      /* Create a merged access string from the entity access and the
       * container access
       */

      String entAccess = ent.getAccess();
      /*
      if (entAccess == null) {
        // Nomerge needed
        return aclChars;
      }
      */

      try {
        Acl acl = new Acl();
        if (entAccess != null) {
          acl.decode(entAccess.toCharArray());
        }
        acl.merge(aclChars, path);

        return acl.encodeAll();
      } catch (Throwable t) {
        throw new CalFacadeException(t);
      }
    }

    /* This is a way of making other objects sort of shareable.
     * The objects are locations, sponsors and categories.
     *
     * We store the default access in the owner principal and manipulate that to give
     * us some degree of sharing.
     *
     * In effect, the owner becomes the container for the object.
     */

    String aclString = null;
    String entAccess = ent.getAccess();
    BwUser owner = ent.getOwner();

    if (ent instanceof BwCategory) {
      aclString = owner.getCategoryAccess();
    } else if (ent instanceof BwLocation) {
      aclString = owner.getLocationAccess();
    } else if (ent instanceof BwContact) {
      aclString = owner.getContactAccess();
    }

    if (aclString == null) {
      if (entAccess == null) {
        if (ent.getPublick()) {
          return Access.getDefaultPublicAccess().toCharArray();
        }
        return Access.getDefaultPersonalAccess().toCharArray();
      }
      return entAccess.toCharArray();
    }

    if (entAccess == null) {
      return aclString.toCharArray();
    }

    try {
      Acl acl = new Acl();
      acl.decode(entAccess.toCharArray());
      acl.merge(aclString.toCharArray(), "/owner");

      return acl.getEncoded();
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /* Create a merged Acl for the given calendar. Progresses up to the root of
   * the system merging acls as it goes.
   */
  private PathInfo getPathInfo(BwCalendar cal) throws CalFacadeException {
    Acl acl = null;
    PathInfo pi = new PathInfo();

    pi.path = cal.getPath();

    try {
      while (cal != null) {
        String aclString = cal.getAccess();

        if ((aclString != null) && (aclString.length() == 0)) {
          warn("Zero length acl for " + cal.getPath());
          aclString = null;
        }

        /* Validity check. The system MUST be set up so that /public and /user
         * have the appropriate default access stored as the acl string.
         *
         * Failure to do so results in incorrect evaluation of access. We'll
         * check it here.
         */
        if ((aclString == null) && (getParent(cal) == null)) {
          // At root
          throw new CalFacadeException("Calendars must have default access set at root");
        }

        if (acl == null) {
          acl = new Acl();
          if (aclString != null) {
            acl.decode(aclString);
          }
        } else if (aclString != null) {
          acl.merge(aclString.toCharArray(), cal.getPath());
        }

        cal = getParent(cal);
      }

      pi.pathAcl = acl;
      pi.encoded = acl.encodeAll();

      return pi;
    } catch (CalFacadeException cfe) {
      throw cfe;
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }

  /* Update the merged Acl for the given calendar.
   * Doesn't work because any children in the table need the access changing.
  private void updatePathInfo(BwCalendar cal, Acl acl) throws CalFacadeException {
    try {
      String path = cal.getPath();
      PathInfo pi = pathInfoMap.getInfo(path);

      if (pi == null) {
        pi = new PathInfo();

        pi.path = cal.getPath();
      }

      pi.pathAcl = acl;
      pi.encoded = acl.encodeAll();

      pathInfoMap.putInfo(path, pi);
    } catch (Throwable t) {
      throw new CalFacadeException(t);
    }
  }
   */

  private Logger getLog() {
    if (log == null) {
      log = Logger.getLogger(getClass());
    }

    return log;
  }

  private void warn(String msg) {
    getLog().warn(msg);
  }
}

