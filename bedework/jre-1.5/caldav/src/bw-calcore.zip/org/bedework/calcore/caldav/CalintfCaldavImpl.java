/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2005 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calcore.caldav;

//import org.bedework.calenv.CalEnv;
import org.bedework.calcore.CalintfBase;
import org.bedework.calcorei.CalintfDefs;
import org.bedework.calcorei.CalintfInfo;
import org.bedework.calcorei.CoreEventInfo;
import org.bedework.calcorei.EventProperties;
import org.bedework.calfacade.BwAlarm;
import org.bedework.calfacade.BwCalendar;
import org.bedework.calfacade.BwCategory;
import org.bedework.calfacade.BwDateTime;
import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.BwEventProxy;
import org.bedework.calfacade.BwFreeBusy;
import org.bedework.calfacade.BwLocation;
import org.bedework.calfacade.BwPrincipal;
import org.bedework.calfacade.BwContact;
import org.bedework.calfacade.BwStats;
import org.bedework.calfacade.BwString;
import org.bedework.calfacade.BwSystem;
import org.bedework.calfacade.BwTimeZone;
import org.bedework.calfacade.RecurringRetrievalMode;
//import org.bedework.calfacade.BwTimeZone;
import org.bedework.calfacade.BwUser;
//import org.bedework.calfacade.CalFacadeAccessException;
//import org.bedework.calfacade.CalFacadeDefs;
import org.bedework.calfacade.BwStats.StatsEntry;
import org.bedework.calfacade.base.BwDbentity;
import org.bedework.calfacade.base.BwShareableDbentity;
import org.bedework.calfacade.base.UpdateFromTimeZonesInfo;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.exc.CalFacadeUnimplementedException;
import org.bedework.calfacade.filter.BwFilter;
import org.bedework.calfacade.ifs.Directories;
import org.bedework.calfacade.timezones.CalTimezones;
import org.bedework.calfacade.util.ChangeTable;
import org.bedework.http.client.DavioException;
import org.bedework.http.client.HttpManager;

import edu.rpi.cmt.access.AceWho;
import edu.rpi.cmt.access.Acl.CurrentAccess;

//import net.fortuna.ical4j.model.Calendar;
import net.fortuna.ical4j.model.component.VTimeZone;

import java.util.Collection;
import java.util.List;
import java.util.TreeSet;

/** Implementation of CalIntf which interacts with a caldav server.
 *
 * @author Mike Douglass   douglm@rpi.edu
 */
public class CalintfCaldavImpl extends CalintfBase {
  private static volatile HttpManager httpManager;

  private static CalintfInfo info = new CalintfInfo(
       false,     // handlesLocations
       false,     // handlesSponsors
       false      // handlesCategories
     );

  /* ====================================================================
   *                   initialisation
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calfacade.Calintf#init(org.bedework.calfacade.BwUser, java.lang.String, boolean, boolean, boolean, java.lang.String, boolean)
   */
  public boolean init(String systemName,
                      String url,
                      String authenticatedUser,
                      String user,
                      boolean publicAdmin,
                      Directories dirs,
                      boolean debug) throws CalFacadeException {
    boolean userAdded = super.init(systemName, url, authenticatedUser, user, publicAdmin,
                                   dirs, debug);
    try {
      if (httpManager == null) {
        synchronized (this) {
          if (httpManager == null) {
            httpManager = new HttpManager("org.bedework.http.client.caldav.CaldavClient");
          }
        }
      }
    } catch (DavioException de) {
      throw new CalFacadeException(de);
    }

    return userAdded;
  }

  public void logon(BwUser val) throws CalFacadeException {
    checkOpen();
    throw new CalFacadeUnimplementedException();
  }

  public void setSuperUser(boolean val) {
  }

  public boolean getSuperUser() {
    return false;
  }

  public BwStats getStats() throws CalFacadeException {
    return null;
  }

  public void setDbStatsEnabled(boolean enable) throws CalFacadeException {
  }

  public boolean getDbStatsEnabled() throws CalFacadeException {
    return false;
  }

  public void dumpDbStats() throws CalFacadeException {
  }

  public Collection<StatsEntry> getDbStats() throws CalFacadeException {
    return null;
  }

  public BwSystem getSyspars() throws CalFacadeException {
    return null;
  }

  public BwSystem getSyspars(String name) throws CalFacadeException {
    return null;
  }

  public void updateSyspars(BwSystem val) throws CalFacadeException {
  }

  public CalTimezones getTimezonesHandler() throws CalFacadeException {
    return null;
  }

  public CalintfInfo getInfo() throws CalFacadeException {
    return info;
  }

  public void setUser(String val) throws CalFacadeException {
    user = getUser(val);
    if (this.user == null) {
      throw new CalFacadeException("User " + val + " does not exist.");
    }

    logon(user);

    if (debug) {
      getLogger().debug("User " + val + " set in calintf");
    }
  }

  /* ====================================================================
   *                   Misc methods
   * ==================================================================== */

  public void flushAll() throws CalFacadeException {
    if (debug) {
      getLogger().debug("flushAll for " + objTimestamp);
    }
  }

  public void beginTransaction() throws CalFacadeException {
    checkOpen();
  }

  public void endTransaction() throws CalFacadeException {
  }

  public void rollbackTransaction() throws CalFacadeException {
    checkOpen();
    throw new CalFacadeUnimplementedException();
  }

  public void flush() throws CalFacadeException {
    if (debug) {
      getLogger().debug("flush for " + objTimestamp);
    }
  }

  public Object getDbSession() throws CalFacadeException {
    return null;
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.Calintf#reAttach(org.bedework.calfacade.base.BwDbentity)
   */
  public void reAttach(BwDbentity val) throws CalFacadeException {
  }

  /* ====================================================================
   *                   Global parameters
   * ==================================================================== */

  public long getPublicLastmod() throws CalFacadeException {
    checkOpen();
    return 0; // for the moment
  }

  public String getSysid() throws CalFacadeException {
    return "";
  }

  public String getSysname() throws CalFacadeException {
    return "";
  }

  /* ====================================================================
   *                   Users
   * ==================================================================== */

  public void updateUser(BwUser user) throws CalFacadeException {
    checkOpen();
    throw new CalFacadeUnimplementedException();
  }

  public void addUser(BwUser user) throws CalFacadeException {
    checkOpen();

    throw new CalFacadeUnimplementedException();
  }

  public BwUser getUser(String user) throws CalFacadeException {
    checkOpen();
    throw new CalFacadeUnimplementedException();
  }

  public Collection<BwUser> getInstanceOwners() throws CalFacadeException {
    checkOpen();
    throw new CalFacadeUnimplementedException();
  }

  /* ====================================================================
   *                   Access
   * ==================================================================== */

  public void changeAccess(BwShareableDbentity ent,
                           Collection aces,
                           boolean replaceAll) throws CalFacadeException {
    checkOpen();
    throw new CalFacadeUnimplementedException();
  }

  public void changeAccess(BwCalendar cal,
                           Collection aces,
                           boolean replaceAll) throws CalFacadeException {
    checkOpen();
    throw new CalFacadeUnimplementedException();
  }

  public void defaultAccess(BwShareableDbentity ent,
                            AceWho who) throws CalFacadeException {
    checkOpen();
    throw new CalFacadeUnimplementedException();
  }

  public void defaultAccess(BwCalendar cal,
                            AceWho who) throws CalFacadeException {
    checkOpen();
    throw new CalFacadeUnimplementedException();
  }

  public CurrentAccess checkAccess(BwShareableDbentity ent, int desiredAccess,
                                   boolean returnResult) throws CalFacadeException {
    checkOpen();
    throw new CalFacadeUnimplementedException();
  }

  /* ====================================================================
   *                   Timezones
   * ==================================================================== */

  public void saveTimeZone(String tzid, VTimeZone vtz) throws CalFacadeException {
    throw new CalFacadeUnimplementedException();
  }

  public VTimeZone getTimeZone(final String id,
                               BwUser owner,
                               boolean publick) throws CalFacadeException {
    return null;
  }

  public Collection<BwTimeZone> getTimeZones() throws CalFacadeException {
    throw new CalFacadeUnimplementedException();
  }

  public Collection<BwTimeZone> getUserTimeZones(BwUser tzOwner) throws CalFacadeException {
    throw new CalFacadeUnimplementedException();
  }

  public Collection<String> getPublicTimeZoneIds() throws CalFacadeException {
    throw new CalFacadeUnimplementedException();
  }

  public Collection<BwTimeZone> getPublicTimeZones() throws CalFacadeException {
    throw new CalFacadeUnimplementedException();
  }

  public void clearPublicTimezones() throws CalFacadeException {
    throw new CalFacadeUnimplementedException();
  }

  public List getTimeZoneIds() throws CalFacadeException {
    throw new CalFacadeUnimplementedException();
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.Calintf#updateFromTimeZones(int, boolean, org.bedework.calfacade.base.UpdateFromTimeZonesInfo)
   */
  public UpdateFromTimeZonesInfo updateFromTimeZones(int limit,
                                                     boolean checkOnly,
                                                     UpdateFromTimeZonesInfo info
                                                     ) throws CalFacadeException {
    throw new CalFacadeUnimplementedException();
  }

  /* ====================================================================
   *                   Calendars and search
   * ==================================================================== */

  public BwCalendar getPublicCalendars() throws CalFacadeException {
    throw new CalFacadeUnimplementedException();
  }

  public Collection<BwCalendar> getPublicCalendarCollections() throws CalFacadeException {
    checkOpen();

    throw new CalFacadeUnimplementedException();
  }

  public BwCalendar getCalendars() throws CalFacadeException {
    throw new CalFacadeUnimplementedException();
  }

  public BwCalendar getCalendars(BwUser user,
                                 int desiredAccess) throws CalFacadeException {
    throw new CalFacadeUnimplementedException();
  }

  public Collection<BwCalendar> getCalendars(BwCalendar cal) throws CalFacadeException {
    throw new CalFacadeUnimplementedException();
  }

  public Collection<BwCalendar> getCalendarCollections() throws CalFacadeException {
    checkOpen();

    throw new CalFacadeUnimplementedException();
  }

  public Collection<BwCalendar> getAddContentPublicCalendarCollections()
          throws CalFacadeException {
    checkOpen();

    throw new CalFacadeUnimplementedException();
  }

  public Collection<BwCalendar> getAddContentCalendarCollections()
          throws CalFacadeException {
    if (currentMode == CalintfDefs.guestMode) {
      return new TreeSet<BwCalendar>();
    }

    checkOpen();

    throw new CalFacadeUnimplementedException();
  }

  public BwCalendar getCalendar(int val) throws CalFacadeException {
    checkOpen();

    throw new CalFacadeUnimplementedException();
  }

  public BwCalendar getCalendar(String path,
                                int desiredAccess) throws CalFacadeException{
    checkOpen();

    throw new CalFacadeUnimplementedException();
  }

  public String getDefaultCalendarPath(BwUser user) throws CalFacadeException {
    throw new CalFacadeUnimplementedException();
  }

  public String getUserRootPath(BwUser user) throws CalFacadeException {
    throw new CalFacadeUnimplementedException();
  }

  public GetSpecialCalendarResult getSpecialCalendar(BwUser user,
                                       int calType,
                                       boolean create,
                                       int access) throws CalFacadeException {
    throw new CalFacadeUnimplementedException();
  }

  public BwCalendar addCalendar(BwCalendar val,
                                String parentPath) throws CalFacadeException {
    checkOpen();

    throw new CalFacadeUnimplementedException();
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.CalendarsI#renameCalendar(org.bedework.calfacade.BwCalendar, java.lang.String)
   */
  public void renameCalendar(BwCalendar val,
                             String newName) throws CalFacadeException {
    checkOpen();
    throw new CalFacadeUnimplementedException();
  }

  public void moveCalendar(BwCalendar val,
                           BwCalendar newParent) throws CalFacadeException {
    checkOpen();
    throw new CalFacadeUnimplementedException();
  }

  public void updateCalendar(BwCalendar val) throws CalFacadeException {
    checkOpen();
    throw new CalFacadeUnimplementedException();
  }

  public boolean deleteCalendar(BwCalendar val) throws CalFacadeException {
    checkOpen();
    throw new CalFacadeUnimplementedException();
  }

  public boolean checkCalendarRefs(BwCalendar val) throws CalFacadeException {
    checkOpen();

    throw new CalFacadeUnimplementedException();
  }

  /* ====================================================================
   *                   Filters and search
   * ==================================================================== */

  public void setSearch(String val) throws CalFacadeException {
    checkOpen();
  }

  public String getSearch() throws CalFacadeException {
    checkOpen();

    return null;
  }

  public void addFilter(BwFilter val) throws CalFacadeException {
    checkOpen();
    throw new CalFacadeUnimplementedException();
  }

  public void updateFilter(BwFilter val) throws CalFacadeException {
    checkOpen();
    throw new CalFacadeUnimplementedException();
  }

  /* ====================================================================
   *                   Event Properties
   * ==================================================================== */

  /* (non-Javadoc)
   * @see org.bedework.calcorei.Calintf#getCategories()
   */
  public EventProperties<BwCategory, BwString> getCategories()
        throws CalFacadeException {
    checkOpen();

    throw new CalFacadeUnimplementedException();
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.Calintf#getLocations()
   */
  public EventProperties<BwLocation, String> getLocations()
        throws CalFacadeException {
    checkOpen();

    throw new CalFacadeUnimplementedException();
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.Calintf#getSponsors()
   */
  public EventProperties<BwContact, String> getContacts()
        throws CalFacadeException {
    checkOpen();

    throw new CalFacadeUnimplementedException();
  }

  /* ====================================================================
   *                   Free busy
   * ==================================================================== */

  public BwFreeBusy getFreeBusy(BwCalendar cal, BwPrincipal who,
                                BwDateTime start, BwDateTime end,
                                boolean returnAll,
                                boolean ignoreTransparency)
          throws CalFacadeException {
    throw new CalFacadeUnimplementedException();
  }

  /* ====================================================================
   *                   Events
   * ==================================================================== */

  public Collection<CoreEventInfo> getEvent(BwCalendar calendar,
                                            String guid, String rid,
                                            RecurringRetrievalMode recurRetrieval)
          throws CalFacadeException {
    checkOpen();
    throw new CalFacadeUnimplementedException();
  }

  public Collection<CoreEventInfo> getEvents(BwCalendar calendar, BwFilter filter,
                                             BwDateTime startDate, BwDateTime endDate,
                                             RecurringRetrievalMode recurRetrieval,
                                             boolean freeBusy,
                                             boolean allCalendars) throws CalFacadeException {
    throw new CalFacadeUnimplementedException();
  }

  public Collection<BwEventProxy> addEvent(BwEvent val,
                                           Collection<BwEventProxy> overrides,
                                           boolean scheduling,
                                           boolean rollbackOnError) throws CalFacadeException {
    checkOpen();
    throw new CalFacadeUnimplementedException();
  }

  public void updateEvent(BwEvent val,
                          Collection overrides,
                          ChangeTable changes) throws CalFacadeException {
    checkOpen();
    throw new CalFacadeUnimplementedException();
  }

  public DelEventResult deleteEvent(BwEvent val) throws CalFacadeException {
    checkOpen();
    throw new CalFacadeUnimplementedException();
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.EventsI#getEventKeys()
   */
  public Collection<? extends InternalEventKey> getEventKeysForTzupdate(String lastmod)
          throws CalFacadeException {
    throw new CalFacadeUnimplementedException();
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.EventsI#getEvent(org.bedework.calcorei.EventsI.InternalEventKey)
   */
  public CoreEventInfo getEvent(InternalEventKey key)
          throws CalFacadeException {
    throw new CalFacadeUnimplementedException();
  }

  public Collection<CoreEventInfo> getDeletedProxies() throws CalFacadeException {
    throw new CalFacadeUnimplementedException();
  }

  public Collection<CoreEventInfo> getDeletedProxies(BwCalendar cal) throws CalFacadeException {
    throw new CalFacadeUnimplementedException();
  }

  public CoreEventInfo getEvent(BwCalendar cal, String val,
                                RecurringRetrievalMode recurRetrieval)
          throws CalFacadeException {
    checkOpen();
    throw new CalFacadeUnimplementedException();
  }

  public Collection<BwCalendar> findCalendars(String guid,
                                              String rid) throws CalFacadeException {
    checkOpen();
    throw new CalFacadeUnimplementedException();
  }

  /* ====================================================================
   *                       Alarms
   * ==================================================================== */

  public Collection<BwAlarm> getAlarms(BwEvent event,
                                       BwUser user) throws CalFacadeException {
    checkOpen();

    throw new CalFacadeUnimplementedException();
  }

  public void addAlarm(BwAlarm val) throws CalFacadeException {
    checkOpen();

    throw new CalFacadeUnimplementedException();
  }

  public void updateAlarm(BwAlarm val) throws CalFacadeException {
    checkOpen();
    throw new CalFacadeUnimplementedException();
  }

  public Collection getUnexpiredAlarms(BwUser user) throws CalFacadeException {
    checkOpen();

    throw new CalFacadeUnimplementedException();
  }

  public Collection getUnexpiredAlarms(BwUser user, long triggerTime)
          throws CalFacadeException {
    checkOpen();

    throw new CalFacadeUnimplementedException();
  }

  /* ====================================================================
   *                   Free busy
   * ==================================================================== */
}

