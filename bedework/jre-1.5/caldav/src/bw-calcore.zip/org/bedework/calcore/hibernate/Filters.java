/*
 Copyright (c) 2000-2005 University of Washington.  All rights reserved.

 Redistribution and use of this distribution in source and binary forms,
 with or without modification, are permitted provided that:

   The above copyright notice and this permission notice appear in
   all copies and supporting documentation;

   The name, identifiers, and trademarks of the University of Washington
   are not used in advertising or publicity without the express prior
   written permission of the University of Washington;

   Recipients acknowledge that this distribution is made available as a
   research courtesy, "as is", potentially with defects, without
   any obligation on the part of the University of Washington to
   provide support, services, or repair;

   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR
   IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION
   ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
   PARTICULAR PURPOSE, AND IN NO EVENT SHALL THE UNIVERSITY OF
   WASHINGTON BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
   DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
   PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT (INCLUDING
   NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION WITH
   THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calcore.hibernate;

import org.bedework.calcorei.CoreEventInfo;
import org.bedework.calcorei.HibSession;
import org.bedework.calfacade.BwDateTime;
import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.base.BwDbentity;
import org.bedework.calfacade.base.TimeRange;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.filter.BwAndFilter;
import org.bedework.calfacade.filter.BwCategoryFilter;
import org.bedework.calfacade.filter.BwEntityTimeRangeFilter;
import org.bedework.calfacade.filter.BwObjectFilter;
import org.bedework.calfacade.filter.BwFilter;
import org.bedework.calfacade.filter.BwOrFilter;
import org.bedework.calfacade.filter.BwPresenceFilter;
import org.bedework.calfacade.filter.BwPropertyFilter;
import org.bedework.calfacade.filter.BwTimeRangeFilter;
import org.bedework.calfacade.util.PropertyIndex;
import org.bedework.calfacade.util.PropertyIndex.PropertyInfo;
import org.bedework.calfacade.util.PropertyIndex.PropertyInfoIndex;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.TreeSet;

/** Class to carry out some of the manipulations needed for filter support.
 * We attempt to modify the query so that the minimum  number of events are
 * returned. Later on we run the results through the filters to deal with
 * the remaining conditions.
 *
 * <p>We process the query in a number of passes to allow the query sections
 * to be built.
 *
 * <p>Pass 1 is the join pass and assumes we have added the select and from
 * clauses. It gives the method the opportunity to add any join clauses.
 *
 * <p>Pass 2 the where pass, allows us to add additional where clauses.
 * There are two methods associated with this: addWhereSubscriptions
 * and addWhereFilters
 *
 * <p>Pass 3 is parameter replacement and the methods can now replace any
 * parameters.
 *
 * <p>Pass 4 the post execution pass allows the filters to process the
 * result and handle any filters that could not be handled by the query.
 *
 * <p>The kind of query we're looking to build is something like:
 * XXX out of date
 * <br/>
 * select ev from BwEvent<br/>
 * [ join ev.categories as keyw ] --- only for any category matching <br/>
 * where<br/>
 * [ date-ranges-match and ] -- usually have this<br/>
 * ( public-or-creator-test <br/>
 *   [ or  subscriptions ] )<br/>
 * and ( filters )<br/>
 *
 * <p>where the filters and subscriptions are a bunch of parenthesised tests.
 *
 * @author Mike Douglass   douglm@rpi.edu
 */
public class Filters implements Serializable {
//  private boolean debug;

  private BwFilter filter;

  /** The query we are building
   */
  StringBuilder q;

  /** The query segment we are building
   */
  StringBuffer qseg;

  /** True if we can modify the query.
   */
  boolean canModQuery;

  private boolean joined = false;

  private HashMap<PropertyInfoIndex, PropertyInfoIndex> joinDone =
    new HashMap<PropertyInfoIndex, PropertyInfoIndex>();

  /** True if we need to run the result through the filter.
   */
  boolean postFilter;

  /** This provides an index to append to parameter names in the
   * generated query.
   */
  int qi;

  /** This is set for the second pass when we set the pars
   */
  HibSession sess;

  /** Name of the master event we are testing. e.g. for a recurrence it might be
   * ev.master
   */
  String masterName;

  /** Name of the actual event we are testing. e.g. for a recurrence it might be
   * ev
   */
  String evName;

  /**
   * Prefix for filterquery parameters
   */
  String parPrefix = "fq__";

  //private transient Logger log;

  /** Go with the defaults (mostly)
   *
   * @param filter
   * @param q
   * @param masterName
   * @param evName
   * @param debug
   */
  public Filters(BwFilter filter,
                 StringBuilder q,
                 String masterName,
                 String evName,
                 boolean debug) {
    this.filter = filter;
    this.q = q;
    this.masterName = masterName;
    this.evName = evName;
//    this.debug = debug;
  }

  /* * Don't go with the defaults
   *
   * @param filter
   * @param q
   * @param masterName
   * @param evName
   * @param parPrefix
   * @param debug
   * /
  public Filters(BwFilter filter,
                 StringBuffer q,
                 String masterName,
                 String evName,
                 String parPrefix,
                 boolean debug) {
    this(filter, q, masterName, evName, debug);
    this.parPrefix = parPrefix;
  }*/

  /** Pass 1 is the join pass and assumes we have added the select and from
   * clauses. It gives the method the opportunity to add any join clauses.
   *
   * @throws CalFacadeException
   */
  public void joinPass() throws CalFacadeException {
    if (filter == null) {
      return;
    }

    joined = false;
    joinDone.clear();

    addJoins(filter);
  }

  /** Pass 2 the where pass, allows us to add additional where clauses.
   * filters are added to the existing statement.
   *
   * Generate a where clause for a query which selects the events for the
   * given filter.
   *
   * @throws CalFacadeException
   */
  public void addWhereFilters() throws CalFacadeException {
    if (filter == null) {
      return;
    }

    qseg = new StringBuffer();
    postFilter = makeWhere(filter);

    if (qseg.length() != 0) {
      q.append(" and (");
      q.append(qseg);
      q.append(")");
    }
  }

  /** Pass 3 is parameter replacement and the methods can now replace any
   * parameters
   *
   * @param sess
   * @throws CalFacadeException
   */
  public void parPass(HibSession sess) throws CalFacadeException {
    if (filter == null) {
      return;
    }

    qi = 0;
    this.sess = sess;

    parReplace(filter);
  }

  /** Pass 4 the post execution pass allows the filters to process the
   * result and handle any filters that could not be handled by the query.
   *
   * @param val         Collection of CoreEventInfo to be filtered
   * @return Collection filtered
   * @throws CalFacadeException
   */
  public Collection<CoreEventInfo> postExec(Collection<CoreEventInfo> val)
          throws CalFacadeException {
    if (!postFilter) {
      return val;
    }

    TreeSet<CoreEventInfo> l = new TreeSet<CoreEventInfo>();

    for (CoreEventInfo cei: val) {
      BwEvent ev = cei.getEvent();

      if (matches(filter, ev)) {
        l.add(cei);
      }
    }

    return l;
  }

  /* Generate a where clause for a query which selects the events for the
   * given filter. If any filter element cannot be handled by the selection
   * will return false. In that case run the selected result through the
   * filter to select the elements.
   *
   * @param f         Filter element.
   */
  private boolean makeWhere(BwFilter f) throws CalFacadeException {
    if ((f instanceof BwAndFilter) || (f instanceof BwOrFilter)) {
      boolean itsAnd = (f instanceof BwAndFilter);

      qseg.append('(');

      boolean first = true;
      boolean postFilter = false;

      for (BwFilter flt: f.getChildren()) {
        if (!first) {
          if (itsAnd) {
            qseg.append(" and ");
          } else {
            qseg.append(" or ");
          }
        }

        if (makeWhere(flt)) {
          postFilter = true;
        }

        first = false;
      }

      qseg.append(")");

      return postFilter;
    }

    if (f instanceof BwPropertyFilter) {
      BwPropertyFilter pf = (BwPropertyFilter)f;
      PropertyInfo pi = PropertyIndex.propertyInfo.get(pf.getPropertyIndex());

      if (pi == null) {
        throw new CalFacadeException("org.bedework.filters.unknownproperty",
                                     String.valueOf(pf.getPropertyIndex()));
      }

      String fieldName = pi.getField();
      boolean multi = pi.getMultiValued();
      boolean param = pi.getParam();

      if (param) {
        PropertyInfo parentPi = PropertyIndex.propertyInfo.get(pf.getParentPropertyIndex());

        fieldName = parentPi.getField() + "." + fieldName;
      }

      if (multi) {
        if (f instanceof BwPresenceFilter) {
          BwPresenceFilter prf = (BwPresenceFilter)f;
          qseg.append("(size(");
          qseg.append(masterName);
          qseg.append(".");
          qseg.append(fieldName);
          if (pi.getPresenceField() != null) {
            qseg.append(".");
            qseg.append(pi.getPresenceField());
          }
          qseg.append(")");
          if (prf.getTestPresent()) {
            qseg.append(">0)");
          } else {
            qseg.append("=0)");
          }
        } else if (pf instanceof BwTimeRangeFilter) {
          String fld = "joined_" + pi.getField();
          String subfld = "unknown";

          if (pi.getPindex() == PropertyInfoIndex.VALARM) {
            subfld = "triggerTime";
          }

          doTimeRange((BwTimeRangeFilter)pf, false, fld, subfld);
        } else if (pf instanceof BwObjectFilter) {
          String fld = "joined_" + pi.getField();
          String subfld = "value";

          if (pi.getPindex() == PropertyInfoIndex.CATEGORIES) {
            subfld = "word.value";
          }

          doObject((BwObjectFilter)pf, fld, subfld);
        } else {
          qseg.append("(:");
          parTerm();
          if (f.getNot()) {
            qseg.append(" not");
          }
          qseg.append(" in elements(");
          qseg.append(masterName);
          qseg.append(".");
          qseg.append(fieldName);
          qseg.append("))");
        }

        // not multi follow
      } else if (f instanceof BwPresenceFilter) {
        BwPresenceFilter prf = (BwPresenceFilter)f;
        qseg.append('(');
        qseg.append(masterName);
        qseg.append(".");
        qseg.append(fieldName);

        if (prf.getTestPresent()) {
          qseg.append(" is not null");
        } else {
          qseg.append(" is null");
        }
        qseg.append(")");
      } else if (pf instanceof BwEntityTimeRangeFilter) {
        doEntityTimeRange((BwEntityTimeRangeFilter)pf);
      } else if (pf instanceof BwTimeRangeFilter) {
        doTimeRange((BwTimeRangeFilter)pf,
                    (pi.getValClass().getName().equals(BwDateTime.class.getName())),
                    masterName, fieldName);
      } else if (pf instanceof BwObjectFilter) {
        doObject((BwObjectFilter)pf, masterName, fieldName);
      }

      return false;
    }

    /* We assume we can't handle this one as a query.
     */
    return true;
  }

  /* If both dates are null just return. Otherwise return the appropriate
   * terms with the ids: <br/>
   * fromDate    -- first day
   * toDate      -- last day
   *
   * We build two near identical terms.
   *
   *   (floatFlag=true AND <drtest>) OR
   *   (floatFlag is null AND <drtest-utc>)
   *
   * where drtest uses the local from and to times and
   *       drtest-utc uses the utc from and to.
   *
   */
  private void doEntityTimeRange(BwEntityTimeRangeFilter trf) {
    TimeRange tr = trf.getEntity();

    if ((tr.getEnd() == null) && (tr.getStart() == null)) {
      return;
    }

    qseg.append("(");
    appendDrtestTerms(true, tr);
    qseg.append(" or ");
    appendDrtestTerms(false, tr);
    qseg.append(")");
  }

  private void appendDrtestTerms(boolean floatingTest, TimeRange tr) {
    /* We always test the time in the actual entity, not the related master */
    String startField = evName + ".dtstart.date";
    String endField = evName + ".dtend.date";

    String startFloatTest;
    String endFloatTest;

    if (floatingTest) {
      startFloatTest = evName + ".dtstart.floatFlag=true and ";
      endFloatTest = evName + ".dtend.floatFlag=true and ";
    } else {
      startFloatTest = evName + ".dtstart.floatFlag is null and ";
      endFloatTest = evName + ".dtend.floatFlag is null and ";
    }

    /* Note that the comparisons below are required to ensure that the
     *  start date is inclusive and the end date is exclusive.
     * From CALDAV:
     * A VEVENT component overlaps a given time-range if:
     *
     * (DTSTART <= start AND DTEND > start) OR
     * (DTSTART <= start AND DTSTART+DURATION > start) OR
     * (DTSTART >= start AND DTSTART < end) OR
     * (DTEND   > start AND DTEND < end)
     *
     *  case 1 has the event starting between the dates.
     *  case 2 has the event ending between the dates.
     *  case 3 has the event starting before and ending after the dates.
     */

    if (tr.getStart() == null) {
      qseg.append("(");
      qseg.append(startFloatTest);

      qseg.append(startField);
      qseg.append(" < :");
      parTerm();
      qseg.append(")");
      return;
    }

    if (tr.getEnd() == null) {
      qseg.append("(");
      qseg.append(endFloatTest);

      qseg.append(endField);
      qseg.append(" >= :");
      parTerm();
      qseg.append(")");
      return;
    }

    qseg.append("(");
    qseg.append(startFloatTest); // XXX Inadequate?? - should check each field separately?
    qseg.append("(");

    qseg.append(startField);
    qseg.append(" < :");
    parTerm();
    qseg.append(") and ((");

    qseg.append(endField);
    qseg.append(" > :");
    parTerm();
    qseg.append(") or ((");

    qseg.append(startField);
    qseg.append("=");
    qseg.append(endField);
    qseg.append(") and (");
    qseg.append(endField);
    qseg.append(" >= :");
    parTerm();
    qseg.append("))))");

    /*
    ((start < to) and ((end > from) or
      ((start = end) and (end >= from))))
     */
  }

  private void doTimeRange(BwTimeRangeFilter trf, boolean dateTimeField,
                           String fld, String subfld) {
    TimeRange tr = trf.getEntity();

    qseg.append('(');

    if (tr.getStart() != null) {
      qseg.append('(');
      qseg.append(fld);
      qseg.append(".");
      qseg.append(subfld);

      if (dateTimeField) {
        qseg.append(".date");
      }

      qseg.append(">=:");
      parTerm();
      qseg.append(')');
    }

    if (tr.getEnd() != null) {
      if (tr.getStart() != null) {
        qseg.append(" and ");
      }

      qseg.append('(');
      qseg.append(fld);
      qseg.append(".");
      qseg.append(subfld);

      if (dateTimeField) {
        qseg.append(".date");
      }

      qseg.append("<:");
      parTerm();
      qseg.append(')');
    }

    qseg.append(')');
  }

  private void doObject(BwObjectFilter of,
                        String fld, String subfld) {
    qseg.append('(');

    boolean doCaseless = (of.getEntity() instanceof String) &&
                         of.getCaseless();

    if (doCaseless) {
      qseg.append("lower(");
    }

    qseg.append(fld);
    qseg.append(".");
    qseg.append(subfld);

    if (doCaseless) {
      qseg.append(")");
    }

    if (!of.getExact()) {
      if (of.getNot()) {
        qseg.append(" not");
      }
      qseg.append(" like :");
    } else if (of.getNot()) {
      qseg.append("<>:");
    } else {
      qseg.append("=:");
    }
    parTerm();

    qseg.append(")");
  }

  /* Fill in the parameters after we generated the query.
   */
  private void parReplace(BwFilter f) throws CalFacadeException {
    if (f instanceof BwAndFilter) {
      BwAndFilter fb = (BwAndFilter)f;

      for (BwFilter flt: fb.getChildren()) {
        parReplace(flt);
      }

      return;
    }

    if (f instanceof BwEntityTimeRangeFilter) {
      doEntityTimeRangeReplace((BwEntityTimeRangeFilter)f);

      return;
    }

    if (f instanceof BwTimeRangeFilter) {
      BwTimeRangeFilter trf = (BwTimeRangeFilter)f;
      TimeRange tr = trf.getEntity();

      if (tr.getStart() != null) {
        sess.setParameter(parPrefix + qi, tr.getStart().getDate());
        qi++;
      }

      if (tr.getEnd() != null) {
        sess.setParameter(parPrefix + qi, tr.getEnd().getDate());
        qi++;
      }

      return;
    }

    if (f instanceof BwObjectFilter) {
      BwObjectFilter of = (BwObjectFilter)f;

      Object o = of.getEntity();
      if (o instanceof BwDbentity) {
        sess.setEntity(parPrefix + qi, o);
      } else if (of.getExact()) {
        sess.setParameter(parPrefix + qi, o);
      } else if (of.getEntity() instanceof String) {
        String s = o.toString();

        if (of.getCaseless()) {
          s = s.toLowerCase();
        }

        sess.setString(parPrefix + qi, "%" + s + "%");
      } else {
        sess.setString(parPrefix + qi, "%" + o + "%");
      }

      qi++;

      return;
    }

    if (f instanceof BwOrFilter) {
      BwOrFilter fb = (BwOrFilter)f;

      for (BwFilter flt: fb.getChildren()) {
        parReplace(flt);
      }

      return;
    }
  }

  private void doEntityTimeRangeReplace(BwEntityTimeRangeFilter trf) throws CalFacadeException {
    TimeRange tr = trf.getEntity();

    if ((tr.getEnd() == null) && (tr.getStart() == null)) {
      return;
    }

    qseg.append("(");
    drReplace(true, tr);
    qseg.append(" or ");
    drReplace(false, tr);
    qseg.append(")");
  }

  private void drReplace(boolean floatingTest, TimeRange tr) throws CalFacadeException {
    String startVal = null;
    String endVal = null;
    BwDateTime start = tr.getStart();
    BwDateTime end = tr.getEnd();

    if (floatingTest) {
      if (start != null) {
        startVal = makeUtcformat(start.getDtval());
      }

      if (end != null) {
        endVal = makeUtcformat(end.getDtval());
      }
    } else {
      if (start != null) {
        startVal = start.getDate();
      }

      if (end != null) {
        endVal = end.getDate();
      }
    }

    if (start == null) {
      sess.setString(parPrefix + qi, endVal);
      qi++;
      return;
    }

    if (end == null) {
      sess.setString(parPrefix + qi, startVal);
      qi++;
      return;
    }

    sess.setString(parPrefix + qi, endVal);
    qi++;
    sess.setString(parPrefix + qi, startVal);
    qi++;
    sess.setString(parPrefix + qi, startVal);
    qi++;
  }

  private String makeUtcformat(String dt) {
    int len = dt.length();

    if (len == 16) {
      return dt;
    }

    if (len == 15) {
      return dt + "Z";
    }

    if (len == 8) {
      return dt + "T000000Z";
    }

    throw new RuntimeException("Bad date " + dt);
  }

  private void addJoins(BwFilter f) throws CalFacadeException {
    if ((f instanceof BwAndFilter) ||
        (f instanceof BwOrFilter)) {
      for (BwFilter flt: f.getChildren()) {
        addJoins(flt);
      }

      return;
    }

    if (!(f instanceof BwPropertyFilter)) {
      return;
    }

    if (f instanceof BwPresenceFilter) {
      return;
    }

    BwPropertyFilter pf = (BwPropertyFilter)f;
    PropertyInfo pi = PropertyIndex.propertyInfo.get(pf.getPropertyIndex());

    if (pi == null) {
      throw new CalFacadeException("org.bedework.filters.unknownproperty",
                                   String.valueOf(pf.getPropertyIndex()));
    }

    if (!pi.getMultiValued()) {
      return;
    }

    if (f instanceof BwCategoryFilter) {
      addThisJoin(pi);
      return;
    }

    if (f instanceof BwTimeRangeFilter) {
      addThisJoin(pi);
      return;
    }

    if (f instanceof BwObjectFilter) {
      addThisJoin(pi);
      return;
    }
  }

  private void addThisJoin(PropertyInfo pi) {
    if (joinDone.get(pi.getPindex()) != null) {
      // Already done
      return;
    }

    joinDone.put(pi.getPindex(), pi.getPindex());

    if (!joined) {
      q.append(" join ");
      joined = true;
    } else {
      q.append(", ");
    }

    q.append(masterName);
    q.append(".");
    q.append(pi.getField());
    q.append(" as joined_");
    q.append(pi.getField());
    q.append(" ");
  }

  /* See if event makes it through. We assume OK for filters we can handle
   * with the query
   */
  private boolean matches(BwFilter f, BwEvent ev)
          throws CalFacadeException {
    if (f instanceof BwAndFilter) {
      for (BwFilter flt: f.getChildren()) {
        if (!matches(flt, ev)) {
          return false;
        }
      }

      return true;
    }

    if (f instanceof BwObjectFilter) {
      return true;
    }

    if (f instanceof BwOrFilter) {
      for (BwFilter flt: f.getChildren()) {
        if (matches(flt, ev)) {
          return true;
        }
      }

      return false;
    }

    return false;
  }

  private void parTerm() {
    qseg.append(parPrefix);
    qseg.append(qi);
    qi++;
  }

  /* Get a logger for messages
   * /
  private Logger getLogger() {
    if (log == null) {
      log = Logger.getLogger(this.getClass());
    }

    return log;
  }

  private void trace(String msg) {
    getLogger().debug(msg);
  }*/
}

