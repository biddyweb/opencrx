/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calcore.hibernate;

import org.bedework.calcorei.CoreEventInfo;
import org.bedework.calcorei.EventProperties;
import org.bedework.calcorei.HibSession;
import org.bedework.calfacade.BwEvent;
import org.bedework.calfacade.BwEventProperty;
import org.bedework.calfacade.BwString;
import org.bedework.calfacade.BwUser;
import org.bedework.calfacade.exc.CalFacadeAccessException;
import org.bedework.calfacade.exc.CalFacadeException;
import org.bedework.calfacade.util.AccessUtilI;

import edu.rpi.cmt.access.Acl.CurrentAccess;

import java.util.Collection;
import java.util.TreeSet;

/** Class which handles manipulation of BwEventProperty subclasses which are
 * treated in the same manner, these being Category, Location and contact.
 *
 * <p>Each has a single field which together with the owner makes a unique
 * key and all operations on those classes are the same.
 *
 * @author Mike Douglass   douglm - rpi.edu
 *
 * @param <T> type of property, Location, contact etc.
 * @param <K> type of key - String or subclass of BwDbentity
 */
public class EventPropertiesImpl <T extends BwEventProperty, K>
        extends CalintfHelperHib implements EventProperties<T, K> {
  private String keyFieldName;

  private String finderFieldName;

  private String className;

  /* Named query to get refs */
  private String refQuery;

  /* Named query to delete all from prefs */
  private String delPrefQuery;

  /**
   * @param hsf
   */
  public EventPropertiesImpl(HibSessionFetcher hsf) {
    super(hsf);
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.EventProperties#init(org.bedework.calcore.hibernate.CalintfHelper.Callback, org.bedework.calcore.AccessUtil, int, java.lang.String, java.lang.String, java.lang.String, java.lang.String, int, boolean)
   */
  public void init(Callback cb, AccessUtilI access,
                   int currentMode,
                   String keyFieldName,
                   String finderFieldName,
                   String className,
                   String refQuery,
                   String delPrefQuery,
                   boolean debug) {
    super.init(cb, access, currentMode, debug);

    this.keyFieldName = keyFieldName;
    this.finderFieldName = finderFieldName;
    this.className = className;
    this.refQuery = refQuery;
    this.delPrefQuery = delPrefQuery;
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.EventProperties#get(org.bedework.calfacade.BwUser, org.bedework.calfacade.BwUser)
   */
  @SuppressWarnings("unchecked")
  public Collection<T> get(BwUser owner, BwUser creator) throws CalFacadeException {
    /* Use a report query to try to prevent the appearance of a lot of
       persistent objects we don't need.

       This isn't too good. If we change fields we'll need to change this.
       We could use reflection - we could use persistent objects if it
       doesn't mean the reappearance of the non-unique object problem.
    * /
    StringBuilder qstr = new StringBuilder("select new ");
    qstr.append(className);
    qstr.append("(ent.id, ent.creator, ent.owner, ent.access, ent.publick, " +
                 "ent.address, ent.subaddress, ent.link) ");

    qstr.append("from ");
    */

    HibSession sess = getSess();

    StringBuilder qstr = new StringBuilder("from ");
    qstr.append(className);
    qstr.append(" ent where ");
    if (owner != null) {
      qstr.append(" ent.owner=:owner");
    }

    if (creator != null) {
      if (owner != null) {
        qstr.append(" and ");
      }
      qstr.append(" ent.creator=:creator");
    }

    qstr.append(" order by ent.");
    qstr.append(keyFieldName);

    sess.createQuery(qstr.toString());

    if (owner != null) {
      sess.setEntity("owner", owner);
    }

    if (creator != null) {
      sess.setEntity("creator", creator);
    }

    return (Collection<T>)access.checkAccess(sess.getList(), privRead, true);
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.EventProperties#get(int)
   */
  @SuppressWarnings("unchecked")
  public T get(int id) throws CalFacadeException {
    HibSession sess = getSess();

    StringBuilder qstr = new StringBuilder("from ");
    qstr.append(className);
    qstr.append(" ent where ");
    boolean setUser = CalintfUtil.appendPublicOrOwnerTerm(qstr, "ent",
                                      currentMode, cb.getSuperUser());
    qstr.append(" and ent.id=:id");

    sess.createQuery(qstr.toString());

    sess.setInt("id", id);

    if (setUser) {
      sess.setEntity("user", cb.getUser());
    }

    return check((T)sess.getUnique());
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.EventProperties#get(java.lang.Object, org.bedework.calfacade.BwUser)
   */
  @SuppressWarnings("unchecked")
  public T get(K keyVal, BwUser owner) throws CalFacadeException {
    if (keyVal == null) {
      throw new CalFacadeException("Missing key value");
    }

    if (owner == null) {
      throw new CalFacadeException("Missing owner value");
    }

    HibSession sess = getSess();

    StringBuilder qstr = new StringBuilder("from ");
    qstr.append(className);
    qstr.append(" ent where ");
    addKeyTerms(keyVal, qstr);
    qstr.append("and ent.owner=:owner");

    sess.createQuery(qstr.toString());

    addKeyvals(keyVal);
    sess.setEntity("owner", owner);

    return check((T)sess.getUnique());
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.EventProperties#find(org.bedework.calfacade.BwString, org.bedework.calfacade.BwUser)
   */
  @SuppressWarnings("unchecked")
  public T find(BwString val, BwUser owner) throws CalFacadeException {
    HibSession sess = getSess();

    findQuery(false, val, owner);

    return check((T)sess.getUnique());
  }

  /* (non-Javadoc)
   * @see org.bedework.calcorei.EventProperties#findVenue(java.lang.String, org.bedework.calfacade.BwUser)
   */
  @SuppressWarnings("unchecked")
  public T findVenue(String val, BwUser owner) throws CalFacadeException {
    HibSession sess = getSess();

    findVenueQuery(false, val, owner);

    return check((T)sess.getUnique());
  }

  /** Add an entity to the database. The id will be set in the parameter
   * object.
   *
   * @param val   BwEventProperty object to be added
   * @throws CalFacadeException
   */
  @SuppressWarnings("unchecked")
  public void add(T val) throws CalFacadeException {
    HibSession sess = getSess();

    if ((val.getCreator() == null) ||
        (val.getOwner() == null)) {
      throw new CalFacadeException("Owner and creator must be set");
    }

    sess.save(val);

    findQuery(true, val.getFinderKeyValue(), val.getOwner());

    Collection<Integer> counts = sess.getList();
    if (counts.iterator().next() > 1) {
      sess.rollback();
      throw new CalFacadeException("org.bedework.duplicate.object");
    }
  }

  /** Update an entity in the database.
   *
   * @param val   BwEventProperty object to be updated
   * @throws CalFacadeException
   */
  @SuppressWarnings("unchecked")
  public void update(T val) throws CalFacadeException {
    HibSession sess = getSess();

    if ((val.getCreator() == null) ||
        (val.getOwner() == null)) {
      throw new CalFacadeException("Owner and creator must be set");
    }

    if (check(val) == null) {
      throw new CalFacadeAccessException();
    }

    sess.update(val);

    findQuery(true, val.getFinderKeyValue(), val.getOwner());

    Collection<Integer> counts = sess.getList();
    if (counts.iterator().next() > 1) {
      sess.rollback();
      throw new CalFacadeException("org.bedework.duplicate.object");
    }
  }

  /** Delete an entity
   *
   * @param val      BwEventProperty object to be deleted
   * @throws CalFacadeException
   */
  @SuppressWarnings("unchecked")
  public void delete(T val) throws CalFacadeException {
    if (check(val) == null) {
      throw new CalFacadeAccessException();
    }

    val = (T)getSess().merge(val);

    HibSession sess = getSess();

    sess.namedQuery(delPrefQuery);
    sess.setInt("id", val.getId());
    sess.executeUpdate();

    sess.delete(val);
  }

  /** Return events referencing the given entity
   *
   * @param val      BwEventProperty object to be checked
   * @return Collection of Integer
   * @throws CalFacadeException
   */
  @SuppressWarnings("unchecked")
  public Collection<CoreEventInfo> getRefs(T val) throws CalFacadeException {
    HibSession sess = getSess();

    sess.namedQuery(refQuery);
    sess.setEntity("ent", val);

    Collection<BwEvent> refs = sess.getList();

    if (debug) {
      trace(" ----------- count = " + refs.size());
      if (refs.size() > 0) {
        trace(" ---------- first el class is " + refs.iterator().next().getClass().getName());
      }
    }

    TreeSet<CoreEventInfo> res = new TreeSet<CoreEventInfo>();
    for (BwEvent ev: refs) {
      CurrentAccess ca = access.checkAccess(ev, privRead, true);
      res.add(new CoreEventInfo(ev, ca));
    }

    return res;
  }

  /** Return count of events referencing the given entity
   *
   * @param val      BwEventProperty object to be checked
   * @return Collection of Integer
   * @throws CalFacadeException
   */
  @SuppressWarnings("unchecked")
  public int getRefsCount(T val) throws CalFacadeException {
    HibSession sess = getSess();

    sess.namedQuery(refQuery + "Count");
    sess.setEntity("ent", val);

    Collection<Integer> counts = sess.getList();

    if (debug) {
      trace(" ----------- count = " + counts.size());
      if (counts.size() > 0) {
        trace(" ---------- first el class is " + counts.iterator().next().getClass().getName());
      }
    }

    return counts.iterator().next();
  }

  private T check(T ent) throws CalFacadeException {
    if (ent == null) {
      return null;
    }

    if (!access.checkAccess(ent, privRead, true).accessAllowed) {
      return null;
    }

    return ent;
  }

  private void addKeyTerms(K key, StringBuilder sb) throws CalFacadeException {
    if (key instanceof String) {
      sb.append("ent.");
      sb.append(keyFieldName);
      sb.append("=:keyval ");

      return;
    }

    if (!(key instanceof BwString)) {
      throw new CalFacadeException("org.bedework.error.invalidkeytype");
    }

    addBwStringKeyTerms((BwString)key, keyFieldName, sb);
  }

  private void addKeyvals(K key) throws CalFacadeException {
    HibSession sess = getSess();

    if (key instanceof String) {
      sess.setString("keyval", (String)key);

      return;
    }

    addBwStringKeyvals((BwString)key);
  }

  private void addBwStringKeyTerms(BwString key, String keyName,
                                   StringBuilder sb) throws CalFacadeException {
    sb.append("((ent.");
    sb.append(keyName);
    sb.append(".lang");

    if (key.getLang() == null) {
      sb.append(" is null) and");
    } else {
      sb.append("=:langval) and");
    }

    sb.append("(ent.");
    sb.append(keyName);
    sb.append(".value");

    if (key.getValue() == null) {
      sb.append(" is null)) ");
    } else {
      sb.append("=:val)) ");
    }
  }

  private void addBwStringKeyvals(BwString key) throws CalFacadeException {
    HibSession sess = getSess();

    if (key.getLang() != null) {
      sess.setString("langval", key.getLang());
    }

    if (key.getValue() != null) {
      sess.setString("val", key.getValue());
    }
  }

  private void findQuery(boolean count,
                         BwString val, BwUser owner) throws CalFacadeException {
    if (val == null) {
      throw new CalFacadeException("Missing key value");
    }

    if (owner == null) {
      throw new CalFacadeException("Missing owner value");
    }

    HibSession sess = getSess();

    StringBuilder qstr = new StringBuilder();
    if (count) {
      qstr.append("select count(*) ");
    }

    qstr.append("from ");
    qstr.append(className);
    qstr.append(" ent where ");
    addBwStringKeyTerms(val, finderFieldName, qstr);
    qstr.append("and ent.owner=:owner");

    sess.createQuery(qstr.toString());

    addBwStringKeyvals(val);
    sess.setEntity("owner", owner);
  }

  private void findVenueQuery(boolean count,
                              String uid, BwUser owner) throws CalFacadeException {
    if (uid == null) {
      throw new CalFacadeException("Missing uid value");
    }

    if (owner == null) {
      throw new CalFacadeException("Missing owner value");
    }

    HibSession sess = getSess();

    StringBuilder qstr = new StringBuilder();
    if (count) {
      qstr.append("select count(*) ");
    }

    qstr.append("from ");
    qstr.append(className);
    qstr.append(" ent where (ent.venue is not null) and (ent.venue.uid=:uid) ");
    qstr.append("and (ent.owner=:owner)");

    sess.createQuery(qstr.toString());

    sess.setString("uid", uid);
    sess.setEntity("owner", owner);
  }
}

