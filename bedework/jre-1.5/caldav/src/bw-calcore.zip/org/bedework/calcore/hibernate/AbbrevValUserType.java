/* **********************************************************************
    Copyright 2006 Rensselaer Polytechnic Institute. All worldwide rights reserved.

    Redistribution and use of this distribution in source and binary forms,
    with or without modification, are permitted provided that:
       The above copyright notice and this permission notice appear in all
        copies and supporting documentation;

        The name, identifiers, and trademarks of Rensselaer Polytechnic
        Institute are not used in advertising or publicity without the
        express prior written permission of Rensselaer Polytechnic Institute;

    DISCLAIMER: The software is distributed" AS IS" without any express or
    implied warranty, including but not limited to, any implied warranties
    of merchantability or fitness for a particular purpose or any warrant)'
    of non-infringement of any current or pending patent rights. The authors
    of the software make no representations about the suitability of this
    software for any particular purpose. The entire risk as to the quality
    and performance of the software is with the user. Should the software
    prove defective, the user assumes the cost of all necessary servicing,
    repair or correction. In particular, neither Rensselaer Polytechnic
    Institute, nor the authors of the software are liable for any indirect,
    special, consequential, or incidental damages related to the software,
    to the maximum extent the law permits.
*/
package org.bedework.calcore.hibernate;

import org.bedework.calfacade.base.AbbreviatedValue;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.usertype.UserType;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;

/** Class to handle persistance of BwVenue.AbbreviatedValue
 *
 * @author Mike Douglass
 */
public class AbbrevValUserType implements UserType {
  private static final int[] TYPES = { Types.VARCHAR };

  /* (non-Javadoc)
   * @see org.hibernate.usertype.UserType#sqlTypes()
   */
  public int[] sqlTypes() {
    return TYPES;
  }

  /* (non-Javadoc)
   * @see org.hibernate.usertype.UserType#returnedClass()
   */
  public Class returnedClass() {
    return AbbreviatedValue.class;
  }

  /* (non-Javadoc)
   * @see org.hibernate.usertype.UserType#isMutable()
   */
  public boolean isMutable() {
    return false;
  }

  public Object deepCopy(Object value) throws HibernateException {
    return value;
  }

  /* (non-Javadoc)
   * @see org.hibernate.usertype.UserType#equals(java.lang.Object, java.lang.Object)
   */
  public boolean equals(Object x, Object y) throws HibernateException {
    if (x == null) {
      return y == null;
    }

    return x.equals(y);
  }

  /* (non-Javadoc)
   * @see org.hibernate.usertype.UserType#hashCode(java.lang.Object)
   */
  public int hashCode(Object x) throws HibernateException {
    if (x == null) {
      return 0;
    }

    return x.hashCode();
  }

  /* (non-Javadoc)
   * @see org.hibernate.usertype.UserType#nullSafeGet(java.sql.ResultSet, java.lang.String[], java.lang.Object)
   */
  public Object nullSafeGet(ResultSet resultSet,
                            String[] names,
                            Object owner) throws HibernateException, SQLException {
    return assemble((Serializable)Hibernate.STRING.nullSafeGet(resultSet, names),
                    owner);
  }

  /* (non-Javadoc)
   * @see org.hibernate.usertype.UserType#nullSafeSet(java.sql.PreparedStatement, java.lang.Object, int)
   */
  public void nullSafeSet(PreparedStatement statement,
                          Object value,
                          int index) throws HibernateException, SQLException {
    Hibernate.STRING.nullSafeSet(statement, disassemble(value), index);
  }


  /* (non-Javadoc)
   * @see org.hibernate.usertype.UserType#disassemble(java.lang.Object)
   */
  public Serializable disassemble(Object value) throws HibernateException {
    if (value == null) {
      return null;
    }

    AbbreviatedValue abval = (AbbreviatedValue)value;

    StringBuilder sb = new StringBuilder();

    for (String s: abval.abbrevs) {
      sb.append(s);
      sb.append("\t");
    }

    sb.append(abval.value);

    return sb.toString();
  }

  /* (non-Javadoc)
   * @see org.hibernate.usertype.UserType#assemble(java.io.Serializable, java.lang.Object)
   */
  public Object assemble(Serializable cached,
                         Object owner) throws HibernateException {
    String val = (String)cached;

    if (val == null) {
      return null;
    }

    String[] tokens = val.split("\\t");
    int len = tokens.length;

    if (len < 1) {
      return null;
    }

    Collection<String> abbrevs = new ArrayList<String>();
    for (int i = 0; i < len - 1; i++) {
      abbrevs.add(tokens[i]);
    }

    return new AbbreviatedValue(abbrevs, tokens[len - 1]);
  }

  /**
   * During merge, replace the existing (target) value in the entity we are merging to
   * with a new (original) value from the detached entity we are merging. For immutable
   * objects, or null values, it is safe to simply return the first parameter. For
   * mutable objects, it is safe to return a copy of the first parameter. For objects
   * with component values, it might make sense to recursively replace component values.
   *
   * @param original the value from the detached entity being merged
   * @param target the value in the managed entity
   * @return the value to be merged
   */
  public Object replace(Object original,
                        Object target,
                        Object owner) throws HibernateException {
    return deepCopy(original);
  }
}
